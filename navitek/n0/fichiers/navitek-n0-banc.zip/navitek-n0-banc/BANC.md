# Le banc de N0 : les gestes de Yoan, une seule fois

> Écrit le 09.11.2026 par la boucle Navitek (B35). Tout ce qui suit a été éprouvé **en simulation** (cahier R-045) ; rien n'a encore touché un vrai
> Pico ni un vrai servo. La première séance dira ce qui accroche.

## À quoi sert le banc

La simulation de N0 repose sur des hypothèses sur ses servos (`navitek-sim/modele_n0.py`) : leur raideur, l'inertie de leur moteur, leur amortissement,
leur retard. R-036 (T6) a montré que la marche tombe si certaines sont fausses de moitié. Le banc les **mesure** sur un vrai servo, avant de monter le
robot : le PC commande le servo par le Pico, la webcam du portable regarde son bras, et le PC en tire les quatre chiffres. Ensuite, la simulation tourne
avec des chiffres mesurés, et non plus supposés.

## Ce qu'il faut (tout est en main, sauf les pastilles)

- Le Raspberry Pi Pico 2 W et son câble USB.
- Un servo MG90S (ou SG90), avec son palonnier long.
- Le gabarit d'essai imprimé (plateau P0 de N0, `gabarit-essai.stl`).
- Le boîtier de 4 piles AA NiMH (4,8 V) et trois fils.
- **Trois pastilles de couleur vive, d'environ 8 mm** : une **verte**, une **magenta** (rose fuchsia), une **bleue**. Des gommettes, ou un rond de papier
  colorié au feutre. Pas de rouge ni d'orange : le robot est orange.

## Les gestes, une seule fois

1. **MicroPython sur le Pico.** Tenir le bouton BOOTSEL enfoncé en branchant le câble USB ; le Pico apparaît comme une clé USB. Y glisser le fichier
   MicroPython du Pico 2 W (`micropython.org/download`, la carte « Pico 2 W » ; vérifier le nom exact sur la page). Il redémarre seul.
2. **Le programme du banc.** Dans Thonny, ouvrir `navitek-n0/banc/banc_pico.py`, puis Fichier > Enregistrer sous > Raspberry Pi Pico, sous le nom
   **`main.py`**. (Pour revenir au robot, on y remettra `firmware/main.py`.)
3. **Le câblage du servo** (le Pico reste alimenté par l'USB) :
   - le fil **orange** (signal) du servo sur **GP2** (la patte 4 du Pico) ;
   - le fil **rouge** du servo sur le **+** des piles ;
   - le fil **brun** du servo sur le **−** des piles, et le **−** des piles sur une **masse (GND)** du Pico (la patte 3) ;
   - **jamais** le + des piles sur le Pico pendant que l'USB est branché.
4. **Le servo dans le gabarit**, le palonnier long sur son axe, libre de tourner de −60° à +60° sans rien toucher.
5. **Les pastilles** : la **verte** sur le palonnier, près de l'axe ; la **magenta** au bout du palonnier ; la **bleue** sur le gabarit, à côté, là où rien ne bouge.
6. **La webcam** : le gabarit debout devant l'écran du portable, à 20 ou 30 cm, le palonnier tourné vers la caméra (il tourne dans un plan vertical, face
   à elle). Elle peut être un peu de biais : l'étalonnage corrige. **La petite DEL verte du Pico doit être dans l'image** (elle sert à mesurer le retard de
   la webcam). Une lumière stable, pas de soleil direct qui bouge.
7. Brancher les piles, puis dire à Claude : **« lance la séance du banc »**.

## Ce que fait la séance (Claude, environ deux minutes par servo)

`python -X utf8 navitek-n0/banc/seance.py --servo hanche_g` :
1. dit bonjour au Pico, mesure le retard de la webcam par huit allumages de la DEL ;
2. étalonne la vision : le servo à −60, −30, 0, 30 et 60°, une image au repos à chaque angle ;
3. fait cinq fois chaque échelon (2°, 10°, 40°) et regarde le bras pendant 0,6 s après chaque ordre ;
4. ajuste le modèle du servo à ce qu'il a vu : `kp`, `armature`, `amortissement`, `retard` ; le **résidu** dit si le modèle tient (proche du bruit de la
   vision : oui ; bien plus grand : le servo ne ressemble pas au modèle, et c'est une découverte) ;
5. écrit `navitek-n0/banc/mesures/seance-hanche_g-<date>.json`.
Puis Claude reporte les chiffres dans `modele_n0.py`, refait T5 et T6, et met la page à jour.

## Sécurité

- Au démarrage du Pico, **aucun servo ne reçoit de signal**. Chaque angle est borné par les bornes de `main.py` (la hanche : ±60°).
- Sans commande pendant 30 s, le Pico **relâche tout**. Pour tout arrêter : débrancher les piles.
- Le servo force au plus 1,8 kg·cm : il ne blesse pas, mais il pince un doigt posé sur le palonnier.

## Ce que le banc ne mesure pas encore

- **Le couple de blocage** reste celui de la fiche (1,8 kg·cm à 4,8 V). R-036 (T6) dit pourtant qu'il compte : divisé par deux, la marche tombe. Le mesurer
  demande une charge connue (une masse suspendue au bout du palonnier, que l'on augmente jusqu'à ce que le servo cède) : à ajouter.
- **La masse de l'électronique**, l'autre hypothèse qui fait tomber la marche : une balance de cuisine suffit (les piles, le boîtier, le Pico, les fils).

## En option, plus tard

- **Le Wi-Fi** : copier `wifi-exemple.py` sur le Pico sous le nom `secrets.py` et y écrire le nom et le mot de passe du réseau. Ce fichier ne quitte
  jamais le Pico. Le banc écoute alors sur le port 7300 (`pilote.py --wifi <adresse>`).
- **Le curseur du servo** (le « hack du potentiomètre » de la page, `etalonner.py`) : avec le multiplexeur, le Pico lit l'angle 100 fois par seconde, sans
  webcam. En simulation, c'est la mesure la plus juste (R-045 : les quatre paramètres à 2 % près).

---

## La deuxième séance : le vrai N0 contre la simulation (ajoutée le 14.11.2026)

> Demande de Yoan, 14.11 à 16:24 : « faire un premier N0 avec ses limites, confirmer les ajustements entre la réalité et la simulation
> vs les chiffres techniques, plus la latence Wi-Fi ». Chaque ligne ci-dessous est une hypothèse de la simulation, sa valeur, sa source,
> et ce que la simulation devient si la mesure est différente. Cahiers : R-036, R-045, R-148, R-150, R-151, R-152.

### Ce que la simulation de N0 suppose, et comment le mesurer

| # | Hypothèse | Dans la simulation | Source | Mesure (matériel) | Si c'est différent |
|---|---|---|---|---|---|
| 1 | Couple de blocage du servo | 0,177 N·m (1,8 kg·cm) | fiche SG90 | masse suspendue au palonnier (ci-dessous) | R-036 T6 : la moitié fait tomber la marche ; refaire T5, T6 et le banc de N0b |
| 2 | Vitesse à vide | environ 9 rad/s (500°/s) | fiche : 0,1 s pour 60° | `seance.py` étape 6 (le grand échelon) | la droite couple-vitesse de `n0-gpu.xml` (amortissement = couple / vitesse) |
| 3 | Raideur, inertie, amortissement, retard du servo | kp, armature 0,002, amortissement 0,02, retard | supposés | `seance.py` (déjà prévu) | `modele_n0.py`, puis N0b réappris |
| 4 | Masse de l'électronique | 165 g (piles, Pico, fils) | estimée | balance de cuisine | R-036 T6 : +20 % fait tomber la marche à 4 s |
| 5 | Masse totale du robot | 0,587 kg | CAO + estimation | balance de cuisine, le robot monté | masses des pièces dans le modèle |
| 6 | Frottement pied-sol | 0,6 | supposé | plan incliné (ci-dessous) | N0b traîne les pieds (R-150 : 15 à 25 cm de vrai glissement en 10 s) : un sol plus glissant change sa marche |
| 7 | Latence de la commande | 0 ms | aucune | `pilote.py latence 500 --wifi <adresse>` | N0b tient à 20 ms, tombe à chaque départ à 40 ms (R-150) |
| 8 | Chaleur | aucune | non modélisée | le doigt sur le servo après 2 min debout | un SG90 qui force longtemps chauffe et perd du couple |

### Les gestes de mesure

1. **Le couple de blocage** (chaque servo de jambe, ou trois servos tirés au hasard) : le palonnier à l'horizontale, un fil noué au trou
   à une distance mesurée de l'axe (r, en cm, à la règle) ; au bout, un petit sac. On commande +30° (lever). On ajoute de l'eau ou des
   pièces de monnaie, 20 g à la fois, jusqu'à ce qu'il ne lève plus. **Couple = masse (kg) × 9,81 × r (m).** Fiche : à r = 2 cm, il
   devrait lever environ 0,9 kg. Puis la même chose en le laissant tenir l'horizontale (le couple qui tient est plus grand que celui qui
   lève). Chaque essai dure moins de 5 s ; on laisse refroidir 30 s entre deux (un servo bloqué chauffe). Les piles NiMH fraîchement
   chargées (4,8 V à 5,2 V) : noter la tension.
2. **Les masses** : la balance de cuisine ; le boîtier de piles chargé, le Pico avec ses fils, chaque plateau de pièces imprimées, puis le
   robot entier.
3. **Le frottement** : un pied imprimé (ou le robot debout, relâché) sur la planche de la table ; on lève un bout de la planche jusqu'à
   ce que le pied glisse ; **frottement = tan(angle)** (hauteur levée ÷ longueur de la planche). Trois fois, sur la vraie surface de
   marche.
4. **La latence Wi-Fi** : le Pico avec `secrets.py` (en option ci-dessus), le portable à l'endroit où le robot marchera ;
   `python -X utf8 pilote.py latence 500 --wifi <adresse>` (500 allers-retours au rythme du réseau : un toutes les 20 ms). Le fichier
   `mesures/latence-wifi-<date>.json` donne la médiane, p95, p99, le maximum et la part au-dessus de 20 et de 40 ms. Puis la même chose
   par le câble USB (`latence 500`), pour comparer. **La règle** : si p99 dépasse 20 ms, le réseau de marche tourne à bord, pas sur le
   portable.

### Les gestes du robot entier (quand il est monté), contre leurs prédictions

| Geste | Prédiction de la simulation | Cahier |
|---|---|---|
| Debout 60 s, servos à la position de repos | tient : 0,5° d'inclinaison, au plus 4 % du couple de blocage | R-036 T1 |
| Accroupi sur deux jambes, genoux à 70° | tient (25 % en moyenne, 58 % au pic) | R-036 T2 |
| Accroupi sur une jambe, 70° | le genou sature (100 %), il tombe (26° d'inclinaison) ; à 40° il tient (29 % / 51 %) | R-036 T2 |
| La marche en boucle ouverte de R-036 | 0,6 à 0,8 cm/s, un trottinement | R-036 T5 |
| Un saut | aucun : le SG90 ne quitte pas le sol | R-151, R-152 |
| Départ à 3 appuis (une main au sol) | impossible : les butées de la hanche (±60°) | R-148 |

Chaque écart entre le geste réel et sa prédiction va dans le cahier du jour, avec le chiffre mesuré et l'hypothèse corrigée
dans la simulation. On ne réapprend un réseau (N0b) qu'avec les chiffres mesurés.
