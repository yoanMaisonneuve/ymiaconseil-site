"""Essai B30 (cahier R-044 § 5) : les appuis des marches publiées de N0 et de N1, comme essai_n2_appuis.py pour N2.
Chaque marche est rejouée sur son modèle avec la boucle de son essai (essai_t5.py pour N0, essai_n1_marche.py pour N1 ; consigne toutes les 0,01 s),
en relevant, après la montée de 1,5 s : la fraction de simple appui, la hauteur maximale de chaque pied, le glissement des pieds au sol.

    python -X utf8 essai_appuis.py        → resultats/appuis-n0-n1.json
"""
import json
import multiprocessing as mp
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")
# (robot, fichier, retour coupé, plafond en part du blocage)
MARCHES = ([("N0", f"t5-marche-g{g}.json", True, 1.0) for g in (1, 2, 3)] + [("N0", f"t5-marche-robuste-g{g}.json", True, 1.0) for g in (1, 2)]
           + [("N1", f"n1-marche-g{g}.json", False, 1.0) for g in (1, 2, 3)] + [("N1", f"n1-marche-aveugle-g{g}.json", True, 1.0) for g in (1, 2, 3)]
           + [("N1", f"n1-marche-robuste-g{g}.json", False, 1.0) for g in (1, 2)] + [("N1", f"n1-marche-robuste-plafond60-g{g}.json", False, 0.6) for g in (1, 2)])


def tache(args):
    robot, f, sans_retour, plaf = args
    import mujoco
    import commun as C
    if robot == "N0":
        import essai_t5 as em
        em.init()
        pose = lambda p, t, d: em.pose_marche(p, t)
        seuil = 35
    else:
        import essai_n1_marche as em
        em.SANS_RETOUR = sans_retour
        em.init()
        pose = lambda p, t, d: em.pose_marche(p, t, em.attitude(d))
        seuil = 40
    m, d = em._m, em._d
    m.actuator_forcerange[:] *= plaf
    r = json.load(open(os.path.join(RES, f), encoding="utf-8"))
    p = np.array(r["parametres_liste"])
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    sol = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, "sol")
    pieds = {c: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, f"jambe-{c}-pied") for c in ("gauche", "droite")}
    z0 = {c: float(d.geom_xpos[g][2]) for c, g in pieds.items()}
    zmax, gliss, prec = {c: 0.0 for c in pieds}, {c: 0.0 for c in pieds}, {c: None for c in pieds}
    compte = {"double": 0, "simple": 0, "aucun": 0}
    x0 = float(d.subtree_com[1][0])
    n, pas_pose = int(em.DUREE / m.opt.timestep), int(0.01 / m.opt.timestep)
    c = np.zeros(m.nu)
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, pose(p, t, d), em._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20:
            continue
        if C.inclinaison(d) > seuil:
            break
        if t < 1.5:
            continue
        touche = {cc: False for cc in pieds}
        for i in range(d.ncon):
            g1, g2 = d.contact[i].geom1, d.contact[i].geom2
            for cc, g in pieds.items():
                if (g1 == g and g2 == sol) or (g2 == g and g1 == sol):
                    touche[cc] = True
        nb = sum(touche.values())
        compte["double" if nb == 2 else "simple" if nb == 1 else "aucun"] += 1
        for cc, g in pieds.items():
            xy = d.geom_xpos[g][:2].copy()
            zmax[cc] = max(zmax[cc], float(d.geom_xpos[g][2]) - z0[cc])
            if touche[cc] and prec[cc] is not None:
                gliss[cc] += float(np.linalg.norm(xy - prec[cc]))
            prec[cc] = xy if touche[cc] else None
    tot = max(1, sum(compte.values()))
    return {"robot": robot, "marche": f, "avance_publiee_m": r["avance_m"], "avance_rejeu_m": round(float(d.subtree_com[1][0]) - x0, 4),
            "fraction_double": round(compte["double"] / tot, 3), "fraction_simple": round(compte["simple"] / tot, 3), "fraction_aucun": round(compte["aucun"] / tot, 3),
            "pied_hauteur_max_mm": {cc: round(v * 1000, 1) for cc, v in zmax.items()}, "glissement_m": {cc: round(v, 3) for cc, v in gliss.items()}}


def main():
    with mp.Pool(14) as pool:
        sorties = pool.map(tache, MARCHES, chunksize=1)
    json.dump({"essai": "B30 / R-044 § 5 : les appuis des marches publiées de N0 et N1", "marches": sorties},
              open(os.path.join(RES, "appuis-n0-n1.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{'marche':<38}{'avance pub/rejeu':>18}{'double':>8}{'simple':>8}{'aucun':>7}{'pied haut g/d mm':>18}{'gliss. g/d m':>15}")
    for s in sorties:
        print(f"{s['marche']:<38}{s['avance_publiee_m']:>9.3f}/{s['avance_rejeu_m']:<8.3f}{s['fraction_double']:>8.2f}{s['fraction_simple']:>8.2f}{s['fraction_aucun']:>7.2f}"
              f"{s['pied_hauteur_max_mm']['gauche']:>9.1f}/{s['pied_hauteur_max_mm']['droite']:<8.1f}{s['glissement_m']['gauche']:>7.3f}/{s['glissement_m']['droite']:<7.3f}")


if __name__ == "__main__":
    main()
