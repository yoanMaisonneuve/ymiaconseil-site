"""Essai T3 du Navitek N0 : rejoue la démo de firmware/main.py (debout, le non de la tête, le salut, deux accroupis) avec les mêmes
poses, les mêmes durées et la même interpolation. Mesure : l'inclinaison, le couple de chaque servo, et tous les contacts entre
pièces du robot (hors le sol et hors pièces voisines, que MuJoCo écarte déjà) avec leur pénétration.
    python -X utf8 essai_t3.py        → resultats/t3-demo.json, t3-demo.mp4 (si imageio-ffmpeg)
"""
import json
import os
import sys

import mujoco
import numpy as np

import commun as C

m, d = C.charger()
noms = C.noms(m)
tau = m.actuator_forcerange[0, 1]
SG = C.signes()
actuel = {C.court(n): 0.0 for n in noms}
ENREGISTRER = "--video" in sys.argv
images = []
rend = mujoco.Renderer(m, 360, 480) if ENREGISTRER else None
cam = mujoco.MjvCamera()
cam.lookat[:] = [0, 0, 0.17]
cam.distance, cam.azimuth, cam.elevation = 0.8, 150, -10

pire = np.zeros(m.nu)
incl_max = 0.0
contacts = {}
t_sim = [0.0]
cible = np.zeros(m.nu)
BORNES = {n: (-60, 60) for n in actuel}
BORNES.update({"genou_g": (-10, 90), "genou_d": (-10, 90), "cou": (-80, 80)})


def avancer(duree):
    global incl_max, pire
    for _ in range(int(duree / m.opt.timestep)):
        d.ctrl[:] = cible
        mujoco.mj_step(m, d)
        t_sim[0] += m.opt.timestep
        if t_sim[0] > 0.6:
            pire = np.maximum(pire, np.abs(d.actuator_force))
        incl_max = max(incl_max, C.inclinaison(d))
        for k in range(d.ncon):
            c = d.contact[k]
            n1 = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, c.geom1)
            n2 = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, c.geom2)
            if "sol" in (n1, n2) or "pied" in (n1 or "") and "pied" in (n2 or ""):
                continue
            cle = " ~ ".join(sorted([n1, n2]))
            e = contacts.setdefault(cle, {"premier_t_s": round(t_sim[0], 2), "penetration_max_mm": 0.0})
            e["penetration_max_mm"] = round(max(e["penetration_max_mm"], -c.dist * 1000), 2)
        if ENREGISTRER and int(t_sim[0] / m.opt.timestep) % 100 == 0:       # 20 images par seconde simulée... 1 sur 100 pas
            rend.update_scene(d, camera=cam)
            images.append(rend.render().copy())


def pose(cib, duree=0.6, pas=30):
    depart = dict(actuel)
    for k in range(1, pas + 1):
        t = k / pas
        t = t * t * (3 - 2 * t)
        for nom, a in cib.items():
            a0 = depart[nom]
            v = a0 + (a - a0) * t
            lo, hi = BORNES[nom]
            actuel[nom] = max(lo, min(hi, v))
        cible[:] = C.consigne(m, actuel, SG)
        avancer(duree / pas)


DEBOUT = {n: 0 for n in actuel}
mujoco.mj_forward(m, d)
avancer(0.5)
pose(DEBOUT, 1.0)
avancer(0.5)
for a in (35, -35, 35, 0):
    pose({"cou": a}, 0.35)
pose({"epaule_d": -60, "coude_d": 40}, 0.7)
for _ in range(3):
    pose({"coude_d": 10}, 0.3)
    pose({"coude_d": 50}, 0.3)
pose({"epaule_d": 0, "coude_d": 0}, 0.7)
for _ in range(2):
    pose(C.accroupi(1.0), 0.9)
    pose(DEBOUT, 0.9)
avancer(0.5)

res = {"essai": "T3 démo de main.py rejouée", "duree_simulee_s": round(t_sim[0], 1), "inclinaison_max_deg": round(incl_max, 1),
       "tombe": bool(incl_max > 30),
       "couple_max_sur_blocage": {n: round(float(pire[i] / tau), 3) for i, n in enumerate(noms)},
       "contacts_entre_pieces": contacts}
json.dump(res, open(os.path.join(C.ICI, "resultats", "t3-demo.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(res, ensure_ascii=False, indent=1))
if ENREGISTRER:
    import imageio.v2 as iio
    iio.mimsave(os.path.join(C.ICI, "resultats", "t3-demo.mp4"), images, fps=20, macro_block_size=1)
    print("vidéo :", len(images), "images")
