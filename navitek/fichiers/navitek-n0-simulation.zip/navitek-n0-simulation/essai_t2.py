"""Essai T2 du Navitek N0 : accroupi. Le couple au genou, à la hanche et à la cheville (en part du couple de blocage) pour un genou de
0 à 70°, sur deux jambes, puis sur une jambe (l'autre est repliée ; la cheville-roulis de la jambe d'appui cherche l'équilibre).
    python -X utf8 essai_t2.py        → resultats/t2-accroupi.json
"""
import json
import os

import mujoco
import numpy as np

import commun as C

m, d = C.charger()
noms = C.noms(m)
idx = {C.court(n): i for i, n in enumerate(noms)}
tau = m.actuator_forcerange[0, 1]
SG = C.signes()


def pose_genou(K, cote):
    s = "_" + cote
    return {"hanche" + s: -K / 2, "genou" + s: K, "cheville_tangage" + s: -K / 2}


def run(K, une_jambe, roulis=0.0, duree=3.0):
    """Renvoie (tenu, inclinaison max, couples moyens sur la dernière seconde, couples max après 1 s)."""
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    pose = pose_genou(K, "g")
    if une_jambe:
        pose.update({"hanche_d": 0, "genou_d": 85, "cheville_tangage_d": 0, "cheville_roulis_g": roulis})
    else:
        pose.update(pose_genou(K, "d"))
    c = C.consigne(m, pose, SG)
    n = int(duree / m.opt.timestep)
    somme = np.zeros(m.nu)
    pic = np.zeros(m.nu)
    ns = 0
    incl = 0.0
    for k in range(n):
        t = k * m.opt.timestep
        d.ctrl[:] = c * min(1.0, t / 1.0)
        mujoco.mj_step(m, d)
        incl = max(incl, C.inclinaison(d))
        if t > duree - 1.0:
            somme += np.abs(d.actuator_force)
            ns += 1
        if t > 1.0:
            pic = np.maximum(pic, np.abs(d.actuator_force))
    fin = C.inclinaison(d)
    return fin < 20 and incl < 35, incl, fin, somme / ns / tau, pic / tau


def resume(r):
    ok, incl, fin, moy, pic = r
    pour = lambda a: {k: round(float(a[i]), 3) for k, i in idx.items() if k.endswith("_g") and k.split("_")[0] in ("hanche", "genou", "cheville") or k == "genou_d"}
    return {"tient": bool(ok), "inclinaison_max_deg": round(incl, 1), "inclinaison_fin_deg": round(fin, 1),
            "couple_moyen_sur_blocage": pour(moy), "couple_max_sur_blocage": pour(pic)}


res = {"essai": "T2 accroupi", "couple_blocage_Nm": round(float(tau), 4), "deux_jambes": {}, "une_jambe": {}}
for K in (0, 10, 20, 30, 40, 50, 60, 70):
    res["deux_jambes"][str(K)] = resume(run(K, False))
    print("2 jambes, genou", K, res["deux_jambes"][str(K)]["tient"], res["deux_jambes"][str(K)]["couple_max_sur_blocage"].get("genou_g"))

# une jambe : on cherche le roulis de cheville qui garde le robot debout (dans les deux sens), à 20° puis aux autres plis
for K in (0, 10, 20, 30, 40, 50, 60, 70):
    meilleur = None
    for roulis in range(-40, 41, 4):
        r = run(K, True, float(roulis), duree=2.5)
        note = r[1]
        if meilleur is None or note < meilleur[0]:
            meilleur = (note, roulis, r)
    ok, incl, fin, moy, pic = meilleur[2]
    res["une_jambe"][str(K)] = dict(resume(meilleur[2]), roulis_cheville_deg=meilleur[1])
    print("1 jambe, genou", K, "roulis", meilleur[1], "tient", ok, "inclinaison max", round(incl, 1), "genou max", res["une_jambe"][str(K)]["couple_max_sur_blocage"].get("genou_g"))
json.dump(res, open(os.path.join(C.ICI, "resultats", "t2-accroupi.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
