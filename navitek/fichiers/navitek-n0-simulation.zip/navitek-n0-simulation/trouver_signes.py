"""Trouve le signe de charnière de chaque articulation de jambe (hanche, genou, cheville-tangage, par côté) : celui pour lequel
l'accroupi de main.py (35°) garde le torse droit et abaisse le centre de masse. Écrit resultats/signes.json.
    python -X utf8 trouver_signes.py
"""
import itertools
import json
import os

import mujoco
import numpy as np

import commun as C

m, d = C.charger()
cles = ["hanche", "genou", "cheville_tangage"]
tous = {"cou": 1, "epaule_g": 1, "coude_g": 1, "epaule_d": 1, "coude_d": 1, "cheville_roulis_g": 1, "cheville_roulis_d": 1}


def essai(sg, f=1.0, duree=2.0):
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    z0 = float(d.subtree_com[1][2])
    c = C.consigne(m, C.accroupi(f), sg)
    pire = 0.0
    for k in range(int(duree / m.opt.timestep)):
        d.ctrl[:] = c * min(1.0, k * m.opt.timestep / 1.0)
        mujoco.mj_step(m, d)
        pire = max(pire, C.inclinaison(d))
    return pire, z0 - float(d.subtree_com[1][2])


meilleur = None
for sg_g in itertools.product((1, -1), repeat=3):
    for sg_d in itertools.product((1, -1), repeat=3):
        sg = dict(tous)
        for c, s in zip(cles, sg_g):
            sg[c + "_g"] = s
        for c, s in zip(cles, sg_d):
            sg[c + "_d"] = s
        incl, baisse = essai(sg)
        note = incl - 100 * baisse                       # torse droit et centre de masse plus bas
        if incl < 25 and (meilleur is None or note < meilleur[0]):
            meilleur = (note, incl, baisse, sg)
        print(sg_g, sg_d, f"inclinaison max {incl:5.1f}°, centre de masse abaissé de {baisse * 100:5.1f} cm")
print("MEILLEUR :", meilleur)
os.makedirs(os.path.join(C.ICI, "resultats"), exist_ok=True)
json.dump(meilleur[3], open(os.path.join(C.ICI, "resultats", "signes.json"), "w", encoding="utf-8"), indent=1)
