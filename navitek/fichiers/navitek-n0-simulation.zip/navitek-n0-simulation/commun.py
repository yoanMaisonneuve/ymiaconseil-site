"""Outils communs des essais du Navitek N0 : chargement du modèle, signes des articulations, poses en degrés de main.py.

Les angles de main.py (degrés autour du neutre, le côté droit en miroir) sont traduits en angles de charnière du modèle par
SIGNES, trouvés par `trouver_signes.py` (la pose accroupie qui garde le torse droit) et écrits dans resultats/signes.json.
"""
import json
import os

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))


def charger(xml="n0.xml"):
    m = mujoco.MjModel.from_xml_path(os.path.join(ICI, xml))
    return m, mujoco.MjData(m)


def noms(m):
    return [mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i) for i in range(m.nu)]


def court(nom):
    """Nom du modèle → nom de main.py (jambe-gauche-genou → genou_g)."""
    cote = {"gauche": "_g", "droite": "_d", "droit": "_d"}
    p = nom.split("-")
    if p[0] == "cou":
        return "cou"
    return "_".join(p[2:]).replace("-", "_") + cote[p[1]]


def signes(nom="signes.json"):
    f = os.path.join(ICI, "resultats", nom)
    return json.load(open(f, encoding="utf-8")) if os.path.exists(f) else {}


def consigne(m, pose_deg, sg=None):
    """Vecteur de consignes (rad) pour une pose {nom_main: degrés}."""
    sg = sg if sg is not None else signes()
    c = np.zeros(m.nu)
    for i, n in enumerate(noms(m)):
        k = court(n)
        if k in pose_deg:
            c[i] = np.radians(pose_deg[k]) * sg.get(k, 1)
    return c


def accroupi(f=1.0):
    a = 35 * f
    return {"hanche_g": -a, "genou_g": 2 * a, "cheville_tangage_g": -a,
            "hanche_d": -a, "genou_d": 2 * a, "cheville_tangage_d": -a}


def inclinaison(d):
    q = d.qpos[3:7]
    z = 1 - 2 * (q[1] ** 2 + q[2] ** 2)
    return float(np.degrees(np.arccos(np.clip(z, -1, 1))))


def hauteur_com(d, m):
    return float(d.subtree_com[1][2])
