"""Essai T5 du Navitek N0 : une marche lente en boucle ouverte, réglée par CMA-ES.

La marche est une oscillation périodique des consignes (hanche, genou, cheville-tangage en opposition de phase d'une jambe à
l'autre, plus un balancement de la cheville-roulis pour porter le poids sur le pied d'appui), à 11 paramètres. L'amplitude
monte sur 1,5 s depuis la posture debout. Seuls les pieds touchent le sol dans cet essai (les contacts entre pièces sont l'objet
de T4). Aptitude : une chute (inclinaison > 35°) arrête l'essai et vaut moins que n'importe quelle marche debout (la plus tardive des chutes gagne) ; sans chute, l'avance du centre de masse vers l'avant (+x) en 10 s moins 0,3 fois la dérive de côté.

    python -X utf8 essai_t5.py --graine 1 --generations 40 --population 28 [--video]
    python -X utf8 essai_t5.py --rejouer resultats/t5-marche-g1.json --video
"""
import argparse
import json
import multiprocessing as mp
import os
import sys

import mujoco
import numpy as np

import commun as C

DUREE = 10.0
NOMS_P = ["periode", "hanche_amp", "hanche_decal", "genou_base", "genou_amp", "genou_phase", "chev_amp", "chev_phase",
          "roulis_g", "roulis_d", "roulis_phase"]
BAS = np.array([0.8, 0, -10, 0, 0, -3.14, 0, -3.14, -12, -12, -3.14])
HAUT = np.array([2.0, 25, 10, 40, 40, 3.14, 25, 3.14, 12, 12, 3.14])
ROUL_G = (-60, 7)
ROUL_D = (-7, 60)

_m = _d = None


def init():
    global _m, _d, _sg, _pieds
    _m, _d = C.charger()
    _sg = C.signes()
    for g in range(_m.ngeom):
        n = mujoco.mj_id2name(_m, mujoco.mjtObj.mjOBJ_GEOM, g)
        if n != "sol" and "pied" not in n:
            _m.geom_contype[g] = 0
            _m.geom_conaffinity[g] = 0


def pose_marche(p, t):
    T, ah, h0, kb, ak, pk, aa, pa, rg, rd, pr = p
    out = {}
    montee = min(1.0, t / 1.5)
    th = 2 * np.pi * t / T
    for cote, dec in (("g", 0.0), ("d", np.pi)):
        out["hanche_" + cote] = montee * (h0 + ah * np.sin(th + dec))
        out["genou_" + cote] = montee * (kb + ak * 0.5 * (1 + np.sin(th + dec + pk)))
        out["cheville_tangage_" + cote] = montee * (aa * np.sin(th + dec + pa))
    s = np.sin(th + pr)
    out["cheville_roulis_g"] = float(np.clip(montee * rg * s, *ROUL_G))
    out["cheville_roulis_d"] = float(np.clip(montee * rd * s, *ROUL_D))
    return out


def evaluer(p, trace=False, video=None):
    m, d = _m, _d
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    tau = m.actuator_forcerange[0, 1]
    pire = np.zeros(m.nu)
    x0 = float(d.subtree_com[1][0])
    chute = None
    n = int(DUREE / m.opt.timestep)
    cadre = int(0.05 / m.opt.timestep)
    pas_pose = int(0.01 / m.opt.timestep)
    c = np.zeros(m.nu)
    hauteur_min = 9
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, pose_marche(p, t), _sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0:
            pire = np.maximum(pire, np.abs(d.actuator_force))
            if C.inclinaison(d) > 35:
                chute = t
                break
        if video is not None and k % cadre == 0:
            video(d)
    x = float(d.subtree_com[1][0]) - x0
    y = float(d.subtree_com[1][1])
    tt = chute if chute is not None else DUREE
    # tenir debout d'abord : toute chute vaut moins que n'importe quelle marche debout, y compris rester immobile ;
    # entre les chutes, la plus tardive gagne ; entre les marches debout, la plus longue distance, sans dévier de côté.
    score = (tt / DUREE - 1.0) if chute is not None else (x - 0.3 * abs(y))
    if not trace:
        return -score
    return {"avance_m": round(x, 4), "deviation_laterale_m": round(y, 4), "tombe": chute is not None,
            "temps_tenu_s": round(tt, 2), "couple_max_sur_blocage": {nm: round(float(pire[i] / tau), 3) for i, nm in enumerate(C.noms(m))},
            "inclinaison_fin_deg": round(C.inclinaison(d), 1)}


def f(u):
    return evaluer(BAS + np.clip(u, 0, 1) * (HAUT - BAS))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--graine", type=int, default=1)
    ap.add_argument("--generations", type=int, default=40)
    ap.add_argument("--population", type=int, default=28)
    ap.add_argument("--rejouer")
    ap.add_argument("--video", action="store_true")
    a = ap.parse_args()
    if a.rejouer:
        p = np.array(json.load(open(a.rejouer, encoding="utf-8"))["parametres_liste"])
        sortie = a.rejouer
        fichier = os.path.splitext(sortie)[0]
        init()
    else:
        from cmaes import CMA
        init()
        cma = CMA(mean=np.full(len(BAS), 0.5), sigma=0.3, population_size=a.population, seed=a.graine, bounds=np.array([[0, 1]] * len(BAS)))
        meilleur = (1e9, None)
        histo = []
        with mp.Pool(min(14, a.population), initializer=init) as pool:
            for g in range(a.generations):
                xs = [cma.ask() for _ in range(cma.population_size)]
                vals = pool.map(f, xs)
                cma.tell(list(zip(xs, vals)))
                i = int(np.argmin(vals))
                if vals[i] < meilleur[0]:
                    meilleur = (vals[i], xs[i])
                histo.append(round(-meilleur[0], 4))
                print(f"génération {g + 1:3d}  meilleur {-meilleur[0] * 100:6.2f} cm  (cette génération {-vals[i] * 100:6.2f})", flush=True)
        p = BAS + meilleur[1] * (HAUT - BAS)
        fichier = os.path.join(C.ICI, "resultats", f"t5-marche-g{a.graine}")
    images = []
    rend = mujoco.Renderer(_m, 360, 480) if a.video else None
    cam = mujoco.MjvCamera()
    cam.distance, cam.azimuth, cam.elevation = 0.9, 140, -10

    def video(d):
        cam.lookat[:] = [d.subtree_com[1][0], d.subtree_com[1][1], 0.12]
        rend.update_scene(d, camera=cam)
        images.append(rend.render().copy())

    res = evaluer(p, trace=True, video=video if a.video else None)
    res.update({"essai": "T5 marche lente", "duree_s": DUREE, "parametres": dict(zip(NOMS_P, [round(float(v), 4) for v in p])),
                "parametres_liste": [float(v) for v in p]})
    if not a.rejouer:
        res.update({"graine": a.graine, "generations": a.generations, "population": a.population, "optimiseur": "CMA-ES (cmaes), sigma 0,3",
                    "meilleur_par_generation_m": histo})
    json.dump(res, open(fichier + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in res.items() if k not in ("parametres_liste", "meilleur_par_generation_m")}, ensure_ascii=False, indent=1))
    if a.video:
        import imageio.v2 as iio
        iio.mimsave(fichier + ".mp4", images, fps=20, macro_block_size=1)
        print("vidéo :", fichier + ".mp4", len(images), "images")


if __name__ == "__main__":
    main()
