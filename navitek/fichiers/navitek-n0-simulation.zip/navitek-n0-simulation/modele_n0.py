"""Le modèle physique MuJoCo du Navitek N0, tiré de la CAO : rien n'est recopié à la main.

- La géométrie et les placements : navitek-n0/web/assemblage.json et les STL du même dossier (écrits par cao/n0.py).
- L'arbre des articulations : déduit des noms des pièces. Chaque « palonnier » ouvre un nouveau corps, articulé sur l'axe de
  l'arbre de son servo (l'axe z du repère de son boîtier, passant par son origine).
- Les masses : les grammes du tranchage (navitek-n0/tranchage/tranchage.json) pour les pièces imprimées, les fiches pour les
  servos (MG90S 13,4 g aux jambes, SG90 9 g aux bras et au cou), et un bloc de 165 g dans le bas du torse pour les piles, le
  Pico, les fils et les vis.
- Les servos : un actionneur de position par articulation, borné au couple de blocage annoncé (1,8 kg·cm = 0,177 N·m à 4,8 V).

Les hypothèses du modèle (inertie du moteur ramenée à la sortie, amortissement, frottement des pieds) sont dans HYPOTHESES
ci-dessous : ce sont elles que le banc à la webcam devra mesurer.

    python -X utf8 modele_n0.py        → n0.xml (à côté)
"""
import io
import json
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
N0 = os.path.join(ICI, "..", "navitek-n0")

HYPOTHESES = {
    "couple_blocage_Nm": 1.8 * 9.81 / 100,   # 1,8 kg·cm à 4,8 V (fiches SG90 et MG90S)
    "kp": 3.0,                               # N·m/rad : 3,4° d'écart suffisent à saturer le couple
    "kv": 0.03,                              # N·m·s/rad
    "armature": 0.002,                       # kg·m², inertie du moteur et du réducteur ramenée à la sortie (à mesurer)
    "amortissement": 0.02,                   # N·m·s/rad dans la charnière (à mesurer)
    "frottement_sol": 0.6,                   # PLA sur une table (à mesurer)
    "masse_electronique_g": 165,             # piles NiMH 104 + boîtier 15 + Pico 4 + fils 20 + vis 22
}
MASSE_SERVO = {"jambe": 13.4, "bras": 9.0, "tete": 9.0}
MASSE_PALONNIER = 1.0
BORNES = {"hanche": (-60, 60), "genou": (-10, 90), "cheville-tangage": (-60, 60), "cheville-roulis": (-60, 60),
          "epaule": (-60, 60), "coude": (-60, 60), "cou": (-80, 80)}


def quat(R):
    """Quaternion (w, x, y, z) d'une matrice de rotation."""
    w = np.sqrt(max(0.0, 1 + R[0, 0] + R[1, 1] + R[2, 2])) / 2
    x = np.sqrt(max(0.0, 1 + R[0, 0] - R[1, 1] - R[2, 2])) / 2
    y = np.sqrt(max(0.0, 1 - R[0, 0] + R[1, 1] - R[2, 2])) / 2
    z = np.sqrt(max(0.0, 1 - R[0, 0] - R[1, 1] + R[2, 2])) / 2
    x = np.copysign(x, R[2, 1] - R[1, 2])
    y = np.copysign(y, R[0, 2] - R[2, 0])
    z = np.copysign(z, R[1, 0] - R[0, 1])
    q = np.array([w, x, y, z])
    return q / np.linalg.norm(q)


def matrice(inst):
    M = np.array(inst["matrice"], dtype=float).reshape(4, 4)
    M[:3, 3] /= 1000.0                       # mm → m
    return M


def pose(M):
    p, q = M[:3, 3], quat(M[:3, :3])
    return f'pos="{p[0]:.6f} {p[1]:.6f} {p[2]:.6f}" quat="{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}"'


asm = json.load(io.open(os.path.join(N0, "web", "assemblage.json"), encoding="utf-8"))
# 10.11, réveil 10 (B57) : N0_TRANCHAGE donne un autre tranchage.json (défaut : celui du dossier) ; sert à garder les masses d'un tranchage
# précédent quand la session change le sien (EXIGENCES § 4 ter.4)
tr = json.load(io.open(os.environ.get("N0_TRANCHAGE") or os.path.join(N0, "tranchage", "tranchage.json"), encoding="utf-8"))
GRAMMES = {p["piece"]: p["grammes"] for p in tr["pieces"]}


def masse(inst):
    p, g = inst["piece"], inst["groupe"]
    if p == "servo-sg90":
        return MASSE_SERVO[g.split("-")[0]]
    if p == "palonnier":
        return MASSE_PALONNIER
    return GRAMMES[p]


# --- l'arbre : chaque palonnier ouvre un corps ; les autres pièces vont au corps courant de leur groupe ---------------------
corps = {"torse": {"parent": None, "M": np.eye(4), "geoms": [], "articulation": None}}
courant = {}                                  # groupe → corps courant
for inst in asm["instances"]:
    g = inst["groupe"]
    cour = courant.get(g, "torse")
    if inst["piece"] == "palonnier":
        art = inst["nom"].rsplit("-palonnier", 1)[0]                     # ex. jambe-gauche-genou, cou
        corps[art] = {"parent": cour, "M": matrice(inst), "geoms": [], "articulation": art}
        courant[g] = cour = art
    corps[cour]["geoms"].append(inst)

xml = []
a = xml.append
a('<mujoco model="navitek-n0">')
a('  <compiler angle="radian" meshdir="../navitek-n0/web" autolimits="true"/>')
a('  <option timestep="0.0005" integrator="implicitfast"/>')
a(f'  <default><joint armature="{HYPOTHESES["armature"]}" damping="{HYPOTHESES["amortissement"]}"/>'
  f'<geom friction="{HYPOTHESES["frottement_sol"]} 0.01 0.001" condim="3"/></default>')
a('  <visual><global offwidth="1280" offheight="960"/><quality shadowsize="4096"/></visual>')
a('  <asset>')
for p in sorted({i["piece"] for i in asm["instances"]}):
    a(f'    <mesh name="{p}" file="{p}.stl" scale="0.001 0.001 0.001"/>')
a('    <texture name="damier" type="2d" builtin="checker" rgb1="0.93 0.92 0.89" rgb2="0.86 0.85 0.82" width="512" height="512"/>')
a('    <material name="sol" texture="damier" texrepeat="12 12"/>')
a('  </asset>')
a('  <worldbody>')
a('    <light pos="0.4 -0.4 1.2" dir="-0.3 0.3 -1" diffuse="0.9 0.9 0.9" castshadow="true"/>')
a('    <geom name="sol" type="plane" size="2 2 0.01" material="sol"/>')


def hexrgba(h):
    h = h.lstrip("#")
    return " ".join(f"{int(h[i:i + 2], 16) / 255:.3f}" for i in (0, 2, 4)) + " 1"


def sens_miroir(nom):
    """09.11 (ERREURS E29) : −1 si l'axe de cette articulation droite est, dans le monde, opposé à celui de sa jumelle de gauche (le servo droit est
    monté retourné ; le programme du robot, main.py, l'inverse par SENS). Son axe s'écrit alors « 0 0 −1 » : le même angle fait le même geste des
    deux côtés, et les plages restent justes. Jusque-là, le côté droit faisait le geste inverse dans toutes les simulations de N0."""
    jumelle = nom.replace("jambe-droite", "jambe-gauche").replace("bras-droit", "bras-gauche")
    if jumelle == nom or jumelle not in corps:
        return 1
    return -1 if float(corps[nom]["M"][:3, 2] @ corps[jumelle]["M"][:3, 2]) < -0.5 else 1


def ecrire_corps(nom, indent):
    c = corps[nom]
    Mp = corps[c["parent"]]["M"] if c["parent"] else np.eye(4)
    rel = np.linalg.inv(Mp) @ c["M"]
    sp = " " * indent
    a(f'{sp}<body name="{nom}" {pose(rel)}>')
    if c["parent"] is None:
        a(f'{sp}  <freejoint name="libre"/>')
    else:
        cle = next(k for k in BORNES if nom.endswith(k))
        lo, hi = BORNES[cle]
        a(f'{sp}  <joint name="{nom}" type="hinge" axis="0 0 {sens_miroir(nom)}" range="{np.radians(lo):.4f} {np.radians(hi):.4f}"/>')
    for inst in c["geoms"]:
        rel_g = np.linalg.inv(c["M"]) @ matrice(inst)
        a(f'{sp}  <geom name="{inst["nom"]}" type="mesh" mesh="{inst["piece"]}" {pose(rel_g)} mass="{masse(inst) / 1000:.5f}" '
          f'rgba="{hexrgba(inst["couleur"])}"/>')
    if c["parent"] is None:   # le bloc des piles, du Pico, des fils et des vis, dans le bas du torse (sans contact)
        a(f'{sp}  <geom name="electronique" type="box" size="0.0155 0.029 0.0155" pos="-0.006 0 0.204" '
          f'mass="{HYPOTHESES["masse_electronique_g"] / 1000}" contype="0" conaffinity="0" rgba="0.2 0.2 0.2 0.0"/>')
        a(f'{sp}  <site name="imu" pos="0 0 0.228"/>')
    for enfant in [k for k, v in corps.items() if v["parent"] == nom]:
        ecrire_corps(enfant, indent + 2)
    a(f'{sp}</body>')


ecrire_corps("torse", 4)
a('  </worldbody>')
# ERREURS E38 (10.11, réveil 10 ; EXIGENCES § 4 ter.5a, trouvé par la session, R-061) : l'enveloppe convexe de chaque étrier d'avant-bras pénétrait celle
# du torse de 1,66 mm au neutre (48 N de contact permanent, de chaque côté) ; les maillages exacts ne se touchent pas (T4). Paire exclue.
a('  <contact>')
for _c in ("gauche", "droit"):
    a(f'    <exclude body1="torse" body2="bras-{_c}-coude"/>')
a('  </contact>')
a('  <actuator>')
tau = HYPOTHESES["couple_blocage_Nm"]
articulations = [k for k, v in corps.items() if v["articulation"]]
for art in articulations:
    a(f'    <position name="{art}" joint="{art}" kp="{HYPOTHESES["kp"]}" kv="{HYPOTHESES["kv"]}" forcerange="{-tau:.4f} {tau:.4f}"/>')
a('  </actuator>')
a('  <sensor>')
a('    <framequat name="orientation" objtype="site" objname="imu"/>')
a('    <subtreecom name="centre_de_masse" body="torse"/>')
a('  </sensor>')
a('</mujoco>')
io.open(os.path.join(ICI, "n0.xml"), "w", encoding="utf-8").write("\n".join(xml))
masse_totale = sum(masse(i) for i in asm["instances"]) + HYPOTHESES["masse_electronique_g"]
print(f"n0.xml : {len(corps)} corps, {len(articulations)} articulations, masse {masse_totale:.0f} g")
print("articulations :", ", ".join(articulations))
