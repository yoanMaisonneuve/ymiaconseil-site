"""Navitek N0 : le petit humanoïde à imprimer (08.11.2026). Toute la CAO, dans FreeCAD 1.1 en ligne de commande :

    freecadcmd n0.py          (FreeCAD 1.1 ; sous Windows : "<dossier de FreeCAD>/bin/freecadcmd.exe" n0.py, lancé depuis cao/)

Variable NAVITEK_OUT : le dossier de sortie (par défaut, le dossier parent de ce fichier).
Sorties : stl-impression/<pièce>.stl (orientée pour l'impression, posée sur le plateau), step/<pièce>.step, step/n0-assemblage.step,
web/<pièce>.stl (dans le repère de l'assemblage) et web/assemblage.json (une instance par pièce posée : matrice, couleur, groupe).

Le système : un BOÎTIER enferme chaque micro-servo (SG90/MG90S) ; un ÉTRIER en U tourne avec l'arbre (bras A vissé au palonnier,
bras B qui pivote par un pion dans le fond du boîtier) ; la base de l'étrier se visse (4 vis M2, carré de 9 mm) sur la face arrière
du boîtier suivant. Repère d'un servo : l'arbre sur l'axe z, le dessus du boîtier du servo à z = 0, le corps vers +x.
Toutes les cotes du servo sont en tête : les mesurer au pied à coulisse sur VOS servos, puis relancer (les fournisseurs varient).
"""
import json
import math
import os

import FreeCAD as App
import MeshPart
import Part

V = App.Vector
OUT = os.environ.get("NAVITEK_OUT", os.path.abspath(os.path.join(os.getcwd(), "..")))   # le dossier navitek-n0 (lancé depuis cao/)
POLICE = os.environ.get("NAVITEK_POLICE", "C:/Windows/Fonts/arialbd.ttf")   # une police grasse TrueType (Linux : DejaVuSans-Bold.ttf)

# --- Le micro-servo SG90 / MG90S (à vérifier au pied à coulisse) -----------------------------------------------------------
SL, SW, SH = 22.8, 12.3, 22.7      # longueur, largeur, hauteur du boîtier du servo (du fond au dessus)
E = 5.9                            # de l'axe de l'arbre au bout du servo côté arbre
FL, FT = 32.3, 2.5                 # longueur et épaisseur des oreilles de fixation
FZ0 = -6.8                         # dessous des oreilles (sous le dessus du servo)
TROU_SP = 27.8                     # entraxe des deux trous des oreilles
TOUR_D, TOUR_H = 11.8, 4.0         # la tour d'engrenage autour de l'arbre
CANNELURE_D, CANNELURE_H = 4.8, 3.2
# le palonnier simple (un bras) fourni avec le servo
HZ0, HT = 4.2, 1.8                 # dessous du palonnier, épaisseur du bras
MOYEU_D = 7.4                      # moyeu du palonnier
PAL_L = 14.5                       # longueur du bras du palonnier (de l'axe au bout)
PAL_TROUS = (10.0, 13.0)           # trous du palonnier où passent les vis
JEU = 0.3                          # jeu d'impression autour du servo

# --- Le système -----------------------------------------------------------------------------------------------------------
PAROI, FOND = 2.2, 2.5
XC = SL / 2 - E                    # centre du servo en x
BX0, BX1 = XC - FL / 2 - 0.6, XC + FL / 2 + 0.6     # le boîtier, en x (passe sous les oreilles)
BY = SW / 2 + JEU + PAROI          # demi-largeur du boîtier
BZ0 = -SH - JEU - FOND             # dessous du boîtier
MOTIF = 4.5                        # demi-côté du carré de 4 trous M2
MOTIF_Z = -13.0                    # centre du motif (même hauteur sur le boîtier et sur l'étrier : la chaîne reste droite)
PILOTE, PASSAGE = 1.6, 2.3         # trou pour vis M2 autotaraudeuse ; trou de passage
UA0, UA_T = HZ0, 2.8               # bras A de l'étrier (côté palonnier)
UB_T = 2.5
UB1 = BZ0 - 0.3                    # dessus du bras B
UB0 = UB1 - UB_T
UX1, UX0 = -16.0, -18.5            # la base de l'étrier, en x
UY = 7.5                           # demi-largeur des bras
PION_D, PION_H = 5.0, 2.4          # le pion du bras B (l'axe de pivot)
LS = 10.0                          # rallonge de cuisse et de tibia : 2,5 (étrier) + 10 + 3,5 de prise = une vis M2 x 16 (08.11 : à 12, elle ne mordait que 1,5 mm)

ORANGE, GRIS, BLEU, NOIR = "#f26b1d", "#7d838c", "#1d2a6b", "#23262b"


def boite(x0, x1, y0, y1, z0, z1):
    return Part.makeBox(x1 - x0, y1 - y0, z1 - z0, V(x0, y0, z0))


def cyl(r, z0, z1, x=0.0, y=0.0):
    return Part.makeCylinder(r, z1 - z0, V(x, y, z0))


def cyl_x(r, x0, x1, y, z):
    return Part.makeCylinder(r, x1 - x0, V(x0, y, z), V(1, 0, 0))


def cyl_y(r, y0, y1, x, z):
    return Part.makeCylinder(r, y1 - y0, V(x, y0, z), V(0, 1, 0))


def unir(formes):
    s = formes[0]
    for f in formes[1:]:
        s = s.fuse(f)
    return s.removeSplitter()


def axes(xa, ya, za, o=V(0, 0, 0)):
    """Placement dont les colonnes sont les axes donnés (le repère local vu du parent)."""
    return App.Placement(App.Matrix(xa.x, ya.x, za.x, o.x, xa.y, ya.y, za.y, o.y, xa.z, ya.z, za.z, o.z, 0, 0, 0, 1))


def rot(axe, deg):
    return App.Placement(V(0, 0, 0), App.Rotation(axe, deg))


def trans(x, y, z):
    return App.Placement(V(x, y, z), App.Rotation())


# =========================================================================================================================
# Les pièces, chacune dans son repère
# =========================================================================================================================
def servo_modele():
    """Le servo lui-même (pas imprimé), pour l'assemblage."""
    corps = boite(-E, SL - E, -SW / 2, SW / 2, -SH, 0)
    oreilles = boite(XC - FL / 2, XC + FL / 2, -SW / 2, SW / 2, FZ0, FZ0 + FT)
    for xt in (XC - TROU_SP / 2, XC + TROU_SP / 2):
        oreilles = oreilles.cut(cyl(1.0, FZ0 - 1, FZ0 + FT + 1, xt, 0))
    tour = cyl(TOUR_D / 2, 0, TOUR_H)
    bosse = cyl(2.9, 0, TOUR_H, 6.0, 0)
    cannelure = cyl(CANNELURE_D / 2, TOUR_H, TOUR_H + CANNELURE_H)
    return unir([corps, oreilles, tour, bosse, cannelure])


def palonnier_modele():
    moyeu = cyl(MOYEU_D / 2, HZ0, HZ0 + 3.6)
    bras = Part.Face(Part.makePolygon([V(0, -2.8, HZ0), V(-PAL_L, -2.0, HZ0), V(-PAL_L, 2.0, HZ0), V(0, 2.8, HZ0), V(0, -2.8, HZ0)])).extrude(V(0, 0, HT))
    bout = cyl(2.0, HZ0, HZ0 + HT, -PAL_L, 0)
    s = unir([moyeu, bras, bout])
    for xt in PAL_TROUS:
        s = s.cut(cyl(0.5, HZ0 - 1, HZ0 + 3, -xt, 0))
    return s


def boitier():
    """Le boîtier d'un servo : la poche, les vis des oreilles, la fente du câble, la douille du pion, le motif de 4 trous à l'arrière."""
    s = boite(BX0, BX1, -BY, BY, BZ0, FZ0)
    s = s.cut(boite(-E - JEU, SL - E + JEU, -SW / 2 - JEU, SW / 2 + JEU, -SH - JEU, FZ0 + 1))
    for xt in (XC - TROU_SP / 2, XC + TROU_SP / 2):
        s = s.cut(cyl(PILOTE / 2, FZ0 - 8, FZ0 + 1, xt, 0))
    s = s.cut(boite(SL - E - 1, BX1 + 1, -2.8, 2.8, -12.0, FZ0 + 1))         # le câble sort sous l'oreille, au bout opposé à l'arbre
    s = s.cut(cyl(PION_D / 2 + 0.2, BZ0 - 1, -SH - JEU + 0.01))               # la douille du pion de l'étrier
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PILOTE / 2, BX1 - 4.5, BX1 + 1, dy, MOTIF_Z + dz))
    return s.removeSplitter()


def bras_etrier(z0, z1):
    return unir([boite(UX0, 0, -UY, UY, z0, z1), cyl(UY, z0, z1)])


def etrier():
    """L'étrier en U : le bras A reçoit le palonnier (poche, deux vis, trou du moyeu), le bras B porte le pion de pivot, la base
    porte le motif de 4 trous de passage."""
    a = bras_etrier(UA0, UA0 + UA_T)
    a = a.cut(Part.Face(Part.makePolygon([V(0.5, -3.1, HZ0 - 0.1), V(-PAL_L, -2.3, HZ0 - 0.1), V(-PAL_L, 2.3, HZ0 - 0.1), V(0.5, 3.1, HZ0 - 0.1), V(0.5, -3.1, HZ0 - 0.1)])).extrude(V(0, 0, HT + 0.15)))
    a = a.cut(cyl(2.3, HZ0 - 0.1, HZ0 + HT + 0.05, -PAL_L, 0))
    a = a.cut(cyl(MOYEU_D / 2 + 0.25, UA0 - 1, UA0 + UA_T + 1))
    for xt in PAL_TROUS:
        a = a.cut(cyl(0.8, UA0 - 1, UA0 + UA_T + 1, -xt, 0))
    b = bras_etrier(UB0, UB1)
    pion = cyl(PION_D / 2, UB1, UB1 + PION_H)
    base = boite(UX0, UX1, -UY, UY, UB0, UA0 + UA_T)
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            base = base.cut(cyl_x(PASSAGE / 2, UX0 - 1, UX1 + 1, dy, MOTIF_Z + dz))
    return unir([a, b, pion, base])


def rallonge():
    """Rallonge de cuisse et de tibia : x de -LS à 0, le motif traversant (vis M2 x 16)."""
    s = boite(-LS, 0, -BY, BY, MOTIF_Z - 9, MOTIF_Z + 9)
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PASSAGE / 2, -LS - 1, 1, dy, MOTIF_Z + dz))
    return s


def main_piece():
    """La main : une mitaine sous la base de l'étrier du coude. Repère : la face de montage dans le plan x = 0, la main vers -x."""
    paume = boite(-38, 0, -6, 6, MOTIF_Z - 10, MOTIF_Z + 10)
    pouce = boite(-26, -10, -6, 6, MOTIF_Z + 10, MOTIF_Z + 15)
    s = unir([paume, pouce, cyl_y(10, -6, 6, -38, MOTIF_Z)])
    s = s.cut(boite(-48, -30, -7, 7, MOTIF_Z - 1.2, MOTIF_Z + 1.2))              # la fente entre les doigts
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PILOTE / 2, -7, 1, dy, MOTIF_Z + dz))
    return s.removeSplitter()


# --- Le torse (repère du monde : z vers le haut, x vers l'avant, y vers la gauche) ---------------------------------------
TX, TY = 23.0, 42.0                # demi-profondeur et demi-largeur du torse
TZ0, TZ1 = 191.0, 265.0            # bas et haut du torse
TP = 2.4                           # parois
YH = 20.0                          # centre des motifs des hanches
YS = 61.0                          # centre des motifs des épaules
XN = 5.0                           # l'arbre du cou (légèrement vers l'avant)


def texte(chaine, taille, centre, xa, ya, profondeur):
    """Un texte en creux : les lettres extrudées de « profondeur », posées dans le plan (xa, ya) autour de « centre »."""
    lettres = Part.makeWireString(chaine, POLICE, taille, 0.0)
    faces = [Part.Face(fils, "Part::FaceMakerBullseye") for fils in lettres if fils]
    c = Part.makeCompound(faces)
    bb = c.BoundBox
    c.translate(V(-(bb.XMin + bb.XMax) / 2, -(bb.YMin + bb.YMax) / 2, 0))
    s = c.extrude(V(0, 0, profondeur))
    za = xa.cross(ya)
    s.Placement = axes(xa, ya, za, centre).multiply(trans(0, 0, -profondeur / 2))
    return s


def torse():
    s = boite(-TX, TX, -TY, TY, TZ0, TZ1)
    s = s.cut(boite(-TX - 1, TX - TP, -TY + TP, TY - TP, TZ0 + 3, TZ1 - 3))      # creux, ouvert à l'arrière
    for sy in (1, -1):
        # rebord d'épaule (le torse s'imprime couché sur la poitrine : le rebord devient une paroi verticale, sans support) ;
        # il va jusqu'à la poitrine (x = TX) pour partir du plateau (08.11 : à x = 11, il commençait à 12 mm en l'air)
        s = s.fuse(boite(-11, TX, sy * TY if sy > 0 else -(YS + 11), YS + 11 if sy > 0 else -TY, TZ1 - 6, TZ1))
        for dx in (-MOTIF, MOTIF):
            for dy in (-MOTIF, MOTIF):
                s = s.cut(cyl(PASSAGE / 2, TZ1 - 7, TZ1 + 1, dx, sy * YS + dy))   # épaules : vis par le dessus
                s = s.cut(cyl(PASSAGE / 2, TZ0 - 1, TZ0 + 4, dx, sy * YH + dy))  # hanches : vis par l'intérieur
        s = s.cut(boite(-6, 6, sy * (YH + 9) - 4, sy * (YH + 9) + 4, TZ0 - 1, TZ0 + 4) if sy > 0 else boite(-6, 6, -(YH + 9) - 4, -(YH + 9) + 4, TZ0 - 1, TZ0 + 4))  # câbles des jambes
        s = s.cut(boite(-4, 4, sy * TY - 2 if sy > 0 else -TY - 1, sy * TY + 1 if sy > 0 else -TY + 2, TZ1 - 14, TZ1 - 7))   # câbles des bras
    # le servo du cou : ouverture dans le toit, trous des oreilles
    s = s.cut(boite(XN - (SL - E) - JEU, XN + E + JEU, -SW / 2 - JEU, SW / 2 + JEU, TZ1 - 4, TZ1 + 1))
    for xt in (XC - TROU_SP / 2, XC + TROU_SP / 2):
        s = s.cut(cyl(PILOTE / 2, TZ1 - 8, TZ1 + 1, XN - xt, 0))
    # coins pour les vis du dos
    for sy in (1, -1):
        for z in (TZ0 + 8, TZ1 - 8):
            s = s.fuse(boite(-TX, -TX + 6, sy * (TY - TP - 5) if sy > 0 else -(TY - TP), sy * (TY - TP) if sy > 0 else -(TY - TP - 5), z - 3, z + 3))
            yw = sy * (TY - TP)                                                  # la paroi de côté
            biseau = Part.Face(Part.makePolygon([V(-TX + 6, yw, z - 3), V(-TX + 6, yw - sy * 5, z - 3), V(-TX + 11, yw, z - 3), V(-TX + 6, yw, z - 3)]))
            s = s.fuse(biseau.extrude(V(0, 0, 6)))
            s = s.cut(cyl_x(PILOTE / 2, -TX - 1, -TX + 6, sy * (TY - TP - 2.5), z))
    # le Pico 2 W : 4 entretoises sur la paroi avant, trous M2 (47 x 11,4 mm)
    for dy in (-23.5, 23.5):
        for dz in (-5.7, 5.7):
            s = s.fuse(cyl_x(2.2, TX - TP - 4, TX - TP, dy, 228 + dz))
            s = s.cut(cyl_x(PILOTE / 2, TX - TP - 5, TX - TP, dy, 228 + dz))
    # NAVITEK en creux sur la poitrine
    s = s.cut(texte(u"NAVITEK", 8.0, V(TX, 0, 246), V(0, 1, 0), V(0, 0, 1), 1.6))
    return s.removeSplitter()


def dos():
    s = boite(-TX - 2.4, -TX, -TY, TY, TZ0, TZ1)
    for sy in (1, -1):
        for z in (TZ0 + 8, TZ1 - 8):
            s = s.cut(cyl_x(PASSAGE / 2, -TX - 3, -TX + 1, sy * (TY - TP - 2.5), z))
    for k in range(5):                                                           # aération
        s = s.cut(boite(-TX - 3, -TX + 1, -20, 20, 212 + 7 * k, 215 + 7 * k))
    s = s.cut(texte(u"N0", 9.0, V(-TX - 2.4, 0, 252), V(0, -1, 0), V(0, 0, 1), 1.2))
    return s.removeSplitter()


# --- La tête (repère du servo du cou : l'arbre en z, z = 0 au dessus du servo) -------------------------------------------
def tete():
    z0 = UA0                                                                     # le dessous de la tête repose sur le palonnier
    h = 40.0
    s = boite(-24, 20, -21, 21, z0, z0 + h)
    s = s.makeFillet(5.0, [e for e in s.Edges if e.BoundBox.ZMin > z0 + 1])      # arêtes du haut et verticales arrondies
    # le creux : un plafond en pignon à 45° (porte-à-faux du 08.11 : le plafond plat faisait un pont de 37,6 mm) ; le faîte court en y
    x0, x1, zt = -21.8, 17.8, z0 + h - 2.2
    zr = zt - (x1 - x0) / 2
    s = s.cut(boite(x0, x1, -18.8, 18.8, z0 + 3.0, zr + 0.01))
    pignon = Part.Face(Part.makePolygon([V(x0, -18.8, zr), V(x1, -18.8, zr), V((x0 + x1) / 2, -18.8, zt), V(x0, -18.8, zr)]))
    s = s.cut(pignon.extrude(V(0, 37.6, 0)))
    # poche du palonnier sous le fond, trous du moyeu et des vis
    s = s.cut(Part.Face(Part.makePolygon([V(0.5, -3.1, z0 - 0.1), V(-PAL_L, -2.3, z0 - 0.1), V(-PAL_L, 2.3, z0 - 0.1), V(0.5, 3.1, z0 - 0.1), V(0.5, -3.1, z0 - 0.1)])).extrude(V(0, 0, HT + 0.15)))
    s = s.cut(cyl(2.3, z0 - 0.1, z0 + HT + 0.05, -PAL_L, 0))
    s = s.cut(cyl(MOYEU_D / 2 + 0.25, z0 - 1, z0 + 3.5))
    for xt in PAL_TROUS:
        s = s.cut(cyl(0.8, z0 - 1, z0 + 3.5, -xt, 0))
    s = s.cut(cyl(3.2, z0 + h - 8, z0 + h + 1))                                  # accès au tournevis, fermé par l'antenne
    # la fente de la visière, sur la face -x du repère du cou (le cou tourne de 180° : -x ici est le devant du robot)
    s = s.cut(boite(-25, -21, -15, 15, z0 + 17, z0 + 27))
    return s.removeSplitter()


def visiere():
    """L'insert gris de la visière (repère de la tête)."""
    z0 = UA0
    s = boite(-24.6, -21.4, -14.7, 14.7, z0 + 17.3, z0 + 26.7)
    return s.cut(boite(-25, -23.8, -12, 12, z0 + 21.3, z0 + 22.7))               # une ligne d'« yeux »


def antenne():
    z0 = UA0 + 40.0
    return unir([cyl(3.0, z0 - 3, z0 + 0.6), cyl(4.2, z0, z0 + 2.0), cyl(1.2, z0 + 2.0, z0 + 14), Part.makeSphere(2.6, V(0, 0, z0 + 15.5))])


# --- Le pied (repère du monde), fait autour de la base de l'étrier de la cheville --------------------------------------------
def pied(trous, cote):
    """Une semelle : la base de l'étrier de la cheville vissée par le dessus (4 trous, positions réelles) ; centrée sous la jambe."""
    cx = sum(p.x for p in trous) / 4
    cy = sum(p.y for p in trous) / 4
    # le bord intérieur s'arrête à 1,5 mm du plan du milieu (contrôle des collisions du 08.11 : les semelles se chevauchaient)
    y_in, y_out = cote * 1.5, cy + cote * 22
    y0, y1 = min(y_in, y_out), max(y_in, y_out)
    print("PIED", cote, "centre y", round(cy, 1), "semelle de", round(y0, 1), "à", round(y1, 1))
    s = boite(cx - 30, cx + 38, y0, y1, 0, 4.5)
    s = s.makeFillet(6.0, [e for e in s.Edges if abs(e.BoundBox.ZMax - e.BoundBox.ZMin) > 4])
    s = s.cut(boite(cx - 24, cx + 32, y0 + 6, y1 - 6, 2.2, 5))                 # allègement (la semelle reste à 2,2 mm)
    s = s.fuse(boite(cx - 9, cx + 9, cy - 9, cy + 9, 0, 4.5))                    # le bloc du motif
    for p in trous:
        s = s.cut(cyl(PILOTE / 2, -1, 6, p.x, p.y))
    return s.removeSplitter()


def gabarit():
    """Le gabarit d'essai (15 min) : une tranche du boîtier (la poche et les vis des oreilles) et un bout de bras A (la poche du
    palonnier). Imprimer, essayer un vrai servo, ajuster les cotes en tête du fichier, puis imprimer le robot."""
    tranche = boitier().common(boite(BX0 - 1, BX1 + 1, -BY - 1, BY + 1, -14.0, FZ0 + 0.01))
    tranche.translate(V(0, 0, 14.0))
    bras = etrier().common(boite(-PAL_L - 4, 8, -UY - 1, UY + 1, UA0 - 0.01, UA0 + UA_T + 0.01))
    bras.translate(V(0, 30, -UA0))
    return tranche.fuse(bras).removeSplitter()


# =========================================================================================================================
# L'assemblage
# =========================================================================================================================
instances = []   # (nom, pièce, placement, couleur, groupe)


def poser(nom, piece, pl, couleur, groupe):
    instances.append((nom, piece, App.Placement(pl.toMatrix()), couleur, groupe))


def articulation(nom, pl_boitier, angle, groupe):
    """Un boîtier, son servo, le palonnier et l'étrier tourné de « angle » ; rend le placement de l'étrier."""
    poser(nom + "-boitier", "boitier-servo", pl_boitier, ORANGE, groupe)
    poser(nom + "-servo", "servo-sg90", pl_boitier, BLEU, groupe)
    pl_u = pl_boitier.multiply(rot(V(0, 0, 1), angle))
    poser(nom + "-palonnier", "palonnier", pl_u, "#f2f2f2", groupe)
    poser(nom + "-etrier", "etrier", pl_u, GRIS, groupe)
    return pl_u


def enfant(pl_u, phi, rallonge_mm=0.0, nom=None, groupe=None):
    """Le boîtier suivant, vissé sur la base de l'étrier (tourné de phi autour de l'axe de la chaîne), après une rallonge."""
    if rallonge_mm:
        pl_r = pl_u.multiply(trans(UX0, 0, 0)).multiply(rot(V(1, 0, 0), phi)).multiply(trans(0, 0, 0))
        poser(nom + "-rallonge", "rallonge", pl_r, GRIS, groupe)
    r = rot(V(1, 0, 0), phi)
    p_h = r.multVec(V(BX1, 0, MOTIF_Z))
    p_u = V(UX0 - rallonge_mm, 0, MOTIF_Z)
    return pl_u.multiply(trans(p_u.x - p_h.x, p_u.y - p_h.y, p_u.z - p_h.z)).multiply(r)


def jambe(cote):
    g = "jambe-gauche" if cote > 0 else "jambe-droite"
    # la hanche : le boîtier pend sous le torse, l'axe le long de y (vers l'extérieur), la face du motif en haut
    za = V(0, cote, 0)
    xa = V(0, 0, 1)
    ya = za.cross(xa)
    p_h = axes(xa, ya, za).multVec(V(BX1, 0, MOTIF_Z))
    pl = axes(xa, ya, za, V(0, cote * YH, TZ0) - p_h)
    u = articulation(g + "-hanche", pl, 0, g)
    u = articulation(g + "-genou", enfant(u, 0, LS, g + "-cuisse", g), 0, g)
    u = articulation(g + "-cheville-tangage", enfant(u, 0, LS, g + "-tibia", g), 0, g)
    u = articulation(g + "-cheville-roulis", enfant(u, 90 * cote), 0, g)
    # la semelle sous la base de l'étrier de la cheville
    trous = [u.multVec(V(UX0, dy, MOTIF_Z + dz)) for dy in (-MOTIF, MOTIF) for dz in (-MOTIF, MOTIF)]
    return trous, g


def bras(cote):
    g = "bras-gauche" if cote > 0 else "bras-droit"
    za = V(0, cote, 0)
    xa = V(0, 0, 1)
    ya = za.cross(xa)
    p_h = axes(xa, ya, za).multVec(V(BX1, 0, MOTIF_Z))
    pl = axes(xa, ya, za, V(0, cote * YS, TZ1 - 6) - p_h)
    u = articulation(g + "-epaule", pl, 0, g)
    u = articulation(g + "-coude", enfant(u, 0), 0, g)
    poser(g + "-main", "main", u.multiply(trans(UX0, 0, 0)), ORANGE, g)


def construire():
    # les jambes d'abord : le sol est sous les semelles
    sols = []
    for cote in (1, -1):
        sols.append(jambe(cote))
    z_sol = min(p.z for trous, _ in sols for p in trous) - 4.5
    for trous, g in sols:
        cote = 1 if trous[0].y > 0 else -1
        poser(g + "-pied", "pied-gauche" if cote > 0 else "pied-droit", App.Placement(), ORANGE, g)
        PIEDS[cote] = trous
    for cote in (1, -1):
        bras(cote)
    poser("torse", "torse", App.Placement(), ORANGE, "torse")
    poser("dos", "dos", App.Placement(), GRIS, "torse")
    # le cou : le servo debout dans le toit, l'arbre vers le haut, le corps vers l'arrière
    pl_cou = axes(V(-1, 0, 0), V(0, -1, 0), V(0, 0, 1), V(XN, 0, TZ1 - FZ0))
    poser("cou-servo", "servo-sg90", pl_cou, BLEU, "tete")
    poser("cou-palonnier", "palonnier", pl_cou, "#f2f2f2", "tete")
    poser("tete", "tete", pl_cou, ORANGE, "tete")
    poser("visiere", "visiere", pl_cou, GRIS, "tete")
    poser("antenne", "antenne", pl_cou, GRIS, "tete")
    return z_sol


PIEDS = {}
z_sol = construire()

PIECES = {
    "boitier-servo": boitier(), "etrier": etrier(), "rallonge": rallonge(), "main": main_piece(), "torse": torse(), "dos": dos(),
    "tete": tete(), "visiere": visiere(), "antenne": antenne(), "servo-sg90": servo_modele(), "palonnier": palonnier_modele(),
    "gabarit-essai": gabarit(),
}
# les pieds dans le repère du monde, ramenés au sol (z = 0 sous la semelle)
for cote, nom in ((1, "pied-gauche"), (-1, "pied-droit")):
    PIECES[nom] = pied(PIEDS[cote], cote)
# tout le robot remonte de -z_sol : le sol à z = 0
for i, (n, p, pl, col, g) in enumerate(instances):
    if not p.startswith("pied"):
        instances[i] = (n, p, trans(0, 0, -z_sol).multiply(pl), col, g)
    else:
        instances[i] = (n, p, App.Placement(), col, g)

IMPRIMEES = ["boitier-servo", "etrier", "rallonge", "torse", "dos", "tete", "visiere", "antenne", "pied-gauche", "pied-droit", "main", "gabarit-essai"]
# orientation d'impression (appliquée avant de poser la pièce à plat au centre du plateau)
ORIENT = {
    "boitier-servo": App.Placement(), "etrier": rot(V(0, 1, 0), -90), "rallonge": rot(V(0, 1, 0), -90), "torse": rot(V(0, 1, 0), 90),
    "dos": rot(V(0, 1, 0), -90), "tete": App.Placement(), "visiere": rot(V(0, 1, 0), 90), "antenne": App.Placement(),
    "pied-gauche": App.Placement(), "pied-droit": App.Placement(), "main": rot(V(1, 0, 0), 90), "gabarit-essai": App.Placement(),
}
QUANTITE = {}
for _, p, _, _, _ in instances:
    QUANTITE[p] = QUANTITE.get(p, 0) + 1
QUANTITE["gabarit-essai"] = 1


def maillage(forme, chemin):
    m = MeshPart.meshFromShape(Shape=forme, LinearDeflection=0.04, AngularDeflection=0.3, Relative=False)
    m.write(chemin)
    return m.CountFacets


for d in ("stl-impression", "step", "web"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)
resume = []
for nom, forme in PIECES.items():
    assert forme.isValid(), nom
    forme.exportStep(os.path.join(OUT, "step", nom + ".step"))
    maillage(forme, os.path.join(OUT, "web", nom + ".stl"))
    if nom in IMPRIMEES:
        f = forme.copy()
        f.Placement = ORIENT[nom].multiply(f.Placement)
        f = f.copy()
        bb = f.BoundBox
        f.translate(V(-(bb.XMin + bb.XMax) / 2, -(bb.YMin + bb.YMax) / 2, -bb.ZMin))
        bb = f.BoundBox
        maillage(f, os.path.join(OUT, "stl-impression", nom + ".stl"))
        resume.append({"piece": nom, "quantite": QUANTITE.get(nom, 1), "x": round(bb.XLength, 1), "y": round(bb.YLength, 1),
                       "z": round(bb.ZLength, 1), "volume_cm3": round(forme.Volume / 1000, 2)})

# l'assemblage complet en STEP et le JSON pour la page
tout = []
for n, p, pl, col, g in instances:
    f = PIECES[p].copy()
    f.Placement = pl.multiply(f.Placement)
    tout.append(f)
Part.makeCompound(tout).exportStep(os.path.join(OUT, "step", "n0-assemblage.step"))
bb = Part.makeCompound(tout).BoundBox
json.dump({
    "robot": "Navitek N0", "date": "2026-11-08", "unites": "mm",
    "encombrement": [round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1)],
    "instances": [{"nom": n, "piece": p, "couleur": col, "groupe": g, "imprimee": p in IMPRIMEES,
                   "matrice": [round(v, 5) for v in pl.toMatrix().A]} for n, p, pl, col, g in instances],
    "pieces": resume,
}, open(os.path.join(OUT, "web", "assemblage.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ENCOMBREMENT", round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1), "mm ;", len(instances), "instances")
for r in resume:
    print("PIECE", r)


# --- Contrôle des collisions (N0_COLLISIONS=1) ------------------------------------------------------------------------------
# Le servo et son palonnier sont DANS leur boîtier et leur étrier : on n'y cherche pas de collision. Tout le reste doit être libre.
if os.environ.get("N0_COLLISIONS"):
    formes = []
    for (n, p, pl, col, g), f in zip(instances, tout):
        formes.append((n, p, f))
    attendu = lambda a, b: a.rsplit("-", 1)[0] == b.rsplit("-", 1)[0] and {a.rsplit("-", 1)[1], b.rsplit("-", 1)[1]} & {"servo", "palonnier"}
    vus = 0
    for i in range(len(formes)):
        for j in range(i + 1, len(formes)):
            (na, pa, fa), (nb, pb, fb) = formes[i], formes[j]
            if attendu(na, nb) or not fa.BoundBox.intersect(fb.BoundBox):
                continue
            vus += 1
            v = fa.common(fb).Volume
            if v > 0.5:
                print("COLLISION", na, "x", nb, round(v, 1), "mm3")
    print("COLLISIONS : paires examinées", vus)
