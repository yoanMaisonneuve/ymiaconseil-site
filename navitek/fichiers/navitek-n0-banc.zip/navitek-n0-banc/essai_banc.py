"""L'épreuve du banc sur un Pico simulé (B31, B32) : le vrai code de banc_pico.py et de pilote.py, sans Pico.

    python -X utf8 essai_banc.py        → imprime chaque épreuve et son verdict ; code de sortie 1 si une épreuve échoue

1. Les constantes de banc_pico.py sont celles de firmware/main.py (broches, sens, réglages fins, bornes, largeurs d'impulsion).
2. Au démarrage, aucun servo ne reçoit de signal.
3. Le protocole : chaque commande, les bornes, les erreurs (ligne illisible, nom inconnu, champ manquant), l'identifiant renvoyé.
4. Le chien de garde relâche tout après 30 s sans commande.
5. L'échelon : le curseur simulé suit l'arbre ; l'angle relu par le curseur arrive à la consigne, au bruit près.
6. Le pilote contre le faux port : ping, angle, pose, échelon, synchronisation, événements mis de côté, bruit non JSON ignoré, journal écrit.
"""
import ast
import json
import os
import sys
import tempfile

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import banc_pico as BP  # noqa: E402
import pilote as PL  # noqa: E402
import simule as SM  # noqa: E402

RESULTATS = []


def verdict(nom, ok, detail=""):
    RESULTATS.append((nom, bool(ok), detail))
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")


def constantes_main():
    """Les affectations de BROCHES, SENS, TRIM, BORNES, MIN_US, MAX_US de firmware/main.py, sans exécuter le reste (il pilote des broches)."""
    src = open(os.path.join(ICI, "..", "firmware", "main.py"), encoding="utf-8").read()
    arbre = ast.parse(src)
    garde = []
    for n in arbre.body:
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id in ("BROCHES", "SENS", "TRIM", "BORNES") for t in n.targets):
            garde.append(n)
        elif isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Tuple) and "MIN_US" in ast.unparse(n.targets[0]):
            garde.append(n)
        elif isinstance(n, ast.Expr) and "BORNES.update" in ast.unparse(n):
            garde.append(n)
    ns = {}
    exec(compile(ast.Module(body=garde, type_ignores=[]), "main.py", "exec"), ns)
    return ns


def main():
    # 1. les constantes
    c = constantes_main()
    for k in ("BROCHES", "SENS", "TRIM", "BORNES", "MIN_US", "MAX_US"):
        verdict(f"constante {k} identique à main.py", c[k] == getattr(BP, k), "" if c[k] == getattr(BP, k) else f"main.py {c[k]} / banc {getattr(BP, k)}")
    verdict("ORDRE = les clés de BROCHES dans l'ordre de main.py", BP.ORDRE == list(c["BROCHES"]))

    # 2. relâchés au démarrage
    m = SM.MaterielSimule()
    banc = BP.Banc(m)
    verdict("aucun signal au démarrage", all(p.duty == 0 for p in m.pwms.values()) and not any(banc.actif.values()))

    # 3. le protocole
    t = banc.traiter_ligne
    r = t('{"cmd": "ping", "id": 7}')
    verdict("ping", r["ok"] and r["programme"] == "banc_pico" and r["id"] == 7 and len(r["servos"]) == 13 and r["curseurs"] is True)
    r = t('{"cmd": "angle", "nom": "hanche_g", "deg": 20}')
    us = m.pwms[BP.BROCHES["hanche_g"]].duty / 1000
    verdict("angle 20° à gauche → 1722 µs", r["ok"] and r["deg"] == 20 and not r["borne"] and abs(us - (1500 + 20 * 2000 / 180)) < 1, f"{us:.1f} µs")
    r = t('{"cmd": "angle", "nom": "hanche_d", "deg": 20}')
    us = m.pwms[BP.BROCHES["hanche_d"]].duty / 1000
    verdict("angle 20° à droite → 1278 µs (le miroir de SENS)", abs(us - (1500 - 20 * 2000 / 180)) < 1, f"{us:.1f} µs")
    r = t('{"cmd": "angle", "nom": "cheville_roulis_g", "deg": 30}')
    verdict("borne : cheville-roulis gauche plafonnée à 7°", r["ok"] and r["deg"] == 7 and r["borne"])
    r = t('{"cmd": "angle", "nom": "genou_g", "deg": -45}')
    verdict("borne : genou gauche plafonné à -10°", r["deg"] == -10 and r["borne"])
    verdict("ligne illisible", t("pas du json")["ok"] is False)
    verdict("ligne JSON qui n'est pas un objet", t("[1, 2]")["ok"] is False)
    verdict("nom inconnu", t('{"cmd": "angle", "nom": "queue", "deg": 3}')["ok"] is False)
    verdict("champ manquant", t('{"cmd": "angle", "nom": "cou"}')["ok"] is False)
    verdict("valeur invalide", t('{"cmd": "angle", "nom": "cou", "deg": "beaucoup"}')["ok"] is False)
    verdict("commande inconnue", "inconnue" in t('{"cmd": "danse"}')["erreur"])
    t0 = m._t
    r = t('{"cmd": "pose", "angles": {"epaule_g": 30, "coude_g": -20}, "duree_s": 0.6}')
    verdict("pose en douceur, en 0,6 s", r["ok"] and r["angles"] == {"epaule_g": 30.0, "coude_g": -20.0} and abs(m._t - t0 - 0.6) < 0.05, f"{m._t - t0:.3f} s simulées")
    r = t('{"cmd": "bornes"}')
    verdict("bornes", r["bornes"]["cou"] == [-80, 80])
    r = t('{"cmd": "relacher", "nom": "cou"}')
    verdict("relâcher un servo", r["relaches"] == ["cou"] and m.pwms[BP.BROCHES["cou"]].duty == 0)
    r = t('{"cmd": "arret"}')
    verdict("arrêt : tout relâché", len(r["relaches"]) == 13 and all(p.duty == 0 for p in m.pwms.values()))
    r = t('{"cmd": "led", "allumee": true}')
    verdict("DEL pilotée par le PC", r["ok"] and m.led_allumee and banc.led_pilotee)
    t('{"cmd": "led", "allumee": false}')
    banc.traiter({"cmd": "echelon", "nom": "cou", "de": 0, "a": 5, "attente_s": 0.1, "duree_s": 0.1})
    verdict("DEL éteinte après un échelon", m.led_allumee is False)
    m2 = SM.MaterielSimule(curseurs=False)
    verdict("lire sans multiplexeur → erreur dite", BP.Banc(m2).traiter({"cmd": "lire"})["ok"] is False)

    # 4. le chien de garde
    t('{"cmd": "angle", "nom": "cou", "deg": 10}')
    verdict("chien de garde : rien avant 30 s", banc.surveiller() is None)
    m.dormir_ms(29_000)
    verdict("chien de garde : rien à 29 s", banc.surveiller() is None)
    m.dormir_ms(1_500)
    e = banc.surveiller()
    verdict("chien de garde : tout relâché après 30 s", e is not None and e["evt"] == "relache" and m.pwms[BP.BROCHES["cou"]].duty == 0)

    # 5. l'échelon : le curseur suit l'arbre
    m = SM.MaterielSimule(graine=1)
    banc = BP.Banc(m)
    r = banc.traiter({"cmd": "echelon", "nom": "hanche_g", "de": 0, "a": 30, "attente_s": 1.0, "duree_s": 1.0, "periode_ms": 10})
    ech = r["echantillons"]
    fin = sum(c for _, c in ech[-10:]) / 10
    angle_fin = (fin - 32768) / SM.MaterielSimule.COMPTES_PAR_DEGRE
    t50 = next((dt for dt, c in ech if (c - 32768) / SM.MaterielSimule.COMPTES_PAR_DEGRE >= 15), None)
    attendu50 = 20 + 15 / 600 * 1000             # retard 20 ms + 15° à 600 °/s
    verdict("échelon : 100 échantillons, toutes les 10 ms", len(ech) == 100 and abs(ech[1][0] - ech[0][0] - 10) < 1, f"{len(ech)} échantillons")
    verdict("échelon : l'angle relu arrive à 30°", abs(angle_fin - 30) < 0.5, f"{angle_fin:.2f}°")
    verdict("échelon : mi-course à 45 ms (20 ms de retard + 15° à 600 °/s)", t50 is not None and abs(t50 - attendu50) <= 11, f"{t50} ms (attendu {attendu50:.0f})")

    # 6. le pilote contre le faux port
    with tempfile.TemporaryDirectory() as d:
        journal = os.path.join(d, "journal.jsonl")
        p = PL.Pilote.simule(journal=journal)
        r = p.ping()
        verdict("pilote : ping", r["ok"] and r["version"] == BP.VERSION)
        verdict("pilote : l'événement « prêt » mis de côté", any(e.get("evt") == "pret" for e in p.evenements))
        p.port._sortie.append(b"MicroPython v1.24 sur Pico 2 W\r\n")
        p.port._sortie.append(b'{"evt": "relache", "raison": "test"}\n')
        r = p.angle("genou_g", 45)
        verdict("pilote : angle, malgré une ligne de texte et un événement intercalés", r["ok"] and r["deg"] == 45 and p.bruit and p.evenements[-1]["raison"] == "test")
        r = p.pose({"hanche_g": -20, "hanche_d": -20}, 0.4)
        verdict("pilote : pose", r["ok"])
        r = p.echelon("coude_g", 0, -40, attente_s=0.5, duree_s=0.8)
        verdict("pilote : échelon", r["ok"] and len(r["echantillons"]) == 80)
        dec, ar = p.synchroniser(5)
        verdict("pilote : synchronisation des horloges", isinstance(dec, float) and ar >= 0)
        p.port._sortie.clear()
        orig = p.port.write
        p.port.write = lambda data: len(data)             # un Pico qui ne répond plus
        try:
            p.envoyer("ping", delai_s=0.2)
            verdict("pilote : pas de réponse → exception", False)
        except PL.PasDeReponse:
            verdict("pilote : pas de réponse → exception", True)
        p.port.write = orig
        p.fermer()
        verdict("pilote : fermer relâche tout et ferme le port", p.port.ferme and all(x.duty == 0 for x in p.port.materiel.pwms.values()))
        lignes = [json.loads(x) for x in open(journal, encoding="utf-8")]
        verdict("pilote : journal écrit (envois et réponses)", any(x["sens"] == "->" for x in lignes) and any(x["sens"] == "<-" for x in lignes), f"{len(lignes)} lignes")

    n_ok = sum(ok for _, ok, _ in RESULTATS)
    print(f"\n{n_ok} sur {len(RESULTATS)} épreuves réussies")
    json.dump({"epreuves": [{"nom": n, "ok": ok, "detail": dt} for n, ok, dt in RESULTATS], "reussies": n_ok, "total": len(RESULTATS)},
              open(os.path.join(ICI, "essai_banc-resultats.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    sys.exit(0 if n_ok == len(RESULTATS) else 1)


if __name__ == "__main__":
    main()
