"""Le Pico simulé du banc : le VRAI code du banc (banc_pico.Banc) sur un matériel simulé, pour éprouver le pilote et la vision
sans Pico. Sous Python ordinaire, sur le PC.

- MaterielSimule : les mêmes méthodes que banc_pico.MaterielPico. Une horloge simulée (elle n'avance que quand le banc dort,
  plus 50 µs par lecture de l'horloge), et derrière chaque broche un servo simulé : il suit sa consigne à vitesse bornée
  (600 °/s, l'ordre de grandeur des fiches SG90 : 0,1 s pour 60° à 4,8 V), après un retard pur (20 ms), et ne bouge plus quand il
  est relâché. Le curseur rend 32768 + COMPTES_PAR_DEGRE × angle de l'arbre, plus un bruit gaussien.
- FauxPort : un port série qui répond comme le vrai Pico (write d'une ligne JSON, readline de la réponse), pour pilote.py.

Les paramètres du servo simulé sont la VÉRITÉ que l'identification (identifier.py) doit retrouver.
"""
import bisect
import json
import math
import os
import random
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import banc_pico as BP  # noqa: E402


class ServoSimule:
    def __init__(self, vitesse_dps=600.0, retard_s=0.020, depart_deg=0.0):
        self.vitesse = vitesse_dps
        self.retard = retard_s
        self.angle = depart_deg          # angle de l'arbre, dans le repère du servo (SENS et TRIM déjà appliqués)
        self.consignes = []              # [(t_s, angle ou None si relâché)]

    def commander(self, t, angle):
        self.consignes.append((t, angle))

    def avancer(self, t0, t1, pas=0.0005):
        t = t0
        while t < t1:
            dt = min(pas, t1 - t)
            c = None
            for tc, a in self.consignes:
                if tc + self.retard <= t:
                    c = a
                else:
                    break
            if c is not None:
                e = c - self.angle
                v = self.vitesse * dt
                self.angle += max(-v, min(v, e))
            t += dt
        # on ne garde que la dernière consigne déjà appliquée et les suivantes
        while len(self.consignes) > 1 and self.consignes[1][0] + self.retard <= t1:
            self.consignes.pop(0)


class ServoMujoco:
    """Un servo simulé par le modèle de identifier.py (une charnière MuJoCo, paramètres connus) : pour l'épreuve de bout en bout de seance.py.
    Relâché (consigne None), son actionneur n'a plus de raideur. Garde l'histoire de son angle (une valeur par milliseconde)."""

    def __init__(self, params, depart_deg=0.0):
        import mujoco
        import identifier as ID
        self._mj, self.ID = mujoco, ID
        self.p = dict(params)
        self.m, self.d = ID._modele(params["kp"], params["armature"], params["amortissement"])
        self.gain = self.m.actuator_gainprm[0].copy()
        self.biais = self.m.actuator_biasprm[0].copy()
        self.retard = params["retard_s"]
        self.d.qpos[0] = math.radians(depart_deg)
        self.t = 0.0
        self.consignes = []
        self.ts, self.angles = [0.0], [depart_deg]
        self._relache(True)

    @property
    def angle(self):
        return math.degrees(self.d.qpos[0])

    def _relache(self, oui):
        if oui:
            self.m.actuator_gainprm[0][:] = 0
            self.m.actuator_biasprm[0][:] = 0
        else:
            self.m.actuator_gainprm[0][:] = self.gain
            self.m.actuator_biasprm[0][:] = self.biais

    def commander(self, t, angle):
        self.consignes.append((t, angle))

    def avancer(self, t0, t1):
        pas = self.ID.PAS
        while self.t + pas <= t1:
            c = "rien"
            for tc, a in self.consignes:
                if tc + self.retard <= self.t:
                    c = a
                else:
                    break
            if c is None:
                self._relache(True)
            elif c != "rien":
                self._relache(False)
                self.d.ctrl[0] = math.radians(c)
            self._mj.mj_step(self.m, self.d)
            self.t += pas
            if self.t - self.ts[-1] >= 0.001 - 1e-9:
                self.ts.append(self.t)
                self.angles.append(self.angle)
        while len(self.consignes) > 1 and self.consignes[1][0] + self.retard <= self.t:
            self.consignes.pop(0)

    def angle_a(self, t):
        """L'angle de l'arbre à l'instant t (secondes simulées), d'après l'histoire."""
        ts = self.ts
        i = bisect.bisect_left(ts, t)
        if i <= 0:
            return self.angles[0]
        if i >= len(ts):
            return self.angles[-1]
        ta, tb, a, b = ts[i - 1], ts[i], self.angles[i - 1], self.angles[i]
        return a + (b - a) * (t - ta) / (tb - ta)


class FauxPWM:
    def __init__(self, materiel, broche):
        self.m, self.broche = materiel, broche
        self.duty = 0
        self.f = None

    def freq(self, f):
        self.f = f

    def duty_ns(self, ns):
        self.duty = ns
        self.m._commande(self.broche, ns)

    def deinit(self):
        self.duty_ns(0)


class MaterielSimule:
    COMPTES_PAR_DEGRE = 180.0

    def __init__(self, curseurs=True, bruit_comptes=20.0, graine=0, servo=None, servo_mujoco=None):
        """servo_mujoco : {"nom": "hanche_g", "params": {kp, armature, amortissement, retard_s}} : ce servo-là est simulé par MuJoCo."""
        self._t = 0.0                                   # secondes simulées
        self._curseurs = curseurs
        self.bruit = bruit_comptes
        self.rng = random.Random(graine)
        self.pwms = {}
        self.led_allumee = False
        self.servos = {b: ServoSimule(**(servo or {})) for b in BP.BROCHES.values()}
        if servo_mujoco:
            self.servos[BP.BROCHES[servo_mujoco["nom"]]] = ServoMujoco(servo_mujoco["params"])

    def led(self, allumee):
        self.led_allumee = bool(allumee)

    # --- l'horloge -------------------------------------------------------------------------------------------------------
    def _avance(self, dt):
        t1 = self._t + dt
        for s in self.servos.values():
            s.avancer(self._t, t1)
        self._t = t1

    def t_us(self):
        self._avance(50e-6)
        return int(self._t * 1e6)

    def ecart_us(self, t1, t0):
        return t1 - t0

    def dormir_ms(self, ms):
        if ms > 0:
            self._avance(ms / 1000.0)

    # --- les servos et les curseurs --------------------------------------------------------------------------------------
    def pwm(self, broche):
        p = FauxPWM(self, broche)
        p.freq(50)
        p.duty_ns(0)
        self.pwms[broche] = p
        return p

    def _commande(self, broche, ns):
        angle = None if ns == 0 else (ns / 1000.0 - 1500) * 180 / (BP.MAX_US - BP.MIN_US)
        self.servos[broche].commander(self._t, angle)

    def curseurs(self):
        return self._curseurs

    def angle_arbre(self, nom):
        return self.servos[BP.BROCHES[nom]].angle

    def lire_canal(self, canal, n=8):
        self._avance(300e-6 + n * 4e-6)
        a = self.servos[BP.BROCHES[BP.ORDRE[canal]]].angle
        v = 32768 + self.COMPTES_PAR_DEGRE * a + self.rng.gauss(0, self.bruit / n ** 0.5)
        return int(max(0, min(65535, v)))


class FauxPort:
    """Un port série qui répond comme le vrai Pico : ce qu'on y écrit est traité par banc_pico.Banc, la réponse se lit par readline()."""

    def __init__(self, materiel=None):
        self.materiel = materiel or MaterielSimule()
        self.banc = BP.Banc(self.materiel)
        self._sortie = [json.dumps({"evt": "pret", "programme": "banc_pico", "version": BP.VERSION, "wifi": None}).encode() + b"\n"]
        self.ferme = False

    def write(self, data):
        for ligne in data.decode().splitlines():
            if ligne.strip():
                self._sortie.append(json.dumps(self.banc.traiter_ligne(ligne)).encode() + b"\n")
        return len(data)

    def readline(self):
        return self._sortie.pop(0) if self._sortie else b""

    def reset_input_buffer(self):
        self._sortie = []

    def close(self):
        self.ferme = True
