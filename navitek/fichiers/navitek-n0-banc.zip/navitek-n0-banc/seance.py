"""La séance de banc d'un servo, du début à la fin : le Pico, la webcam, l'étalonnage, les échelons, l'identification.

    python -X utf8 seance.py --servo hanche_g            le vrai banc : le Pico sur l'USB (banc_pico.py), la webcam du portable
    python -X utf8 seance.py --servo hanche_g --simule   tout simulé : le vrai code du Pico sur un servo MuJoCo aux paramètres connus,
                                                         des images rendues ; l'épreuve de bout en bout (cahier R-045)

Le déroulé (BANC.md) :
1. Bonjour au Pico (ping) ; le servo doit être un nom de main.py.
2. Vrai banc seulement : le retard de la webcam, mesuré par la DEL du Pico (elle doit être dans l'image) : 8 allumages, la médiane.
3. L'étalonnage de la vision : le servo à −60, −30, 0, 30 et 60°, une image au repos à chaque angle (regarder.Regard, 5 angles).
4. Les échelons : 2°, 10° et 40° depuis 0°, cinq fois chacun ; les images de 0,6 s après chaque ordre, leur instant corrigé du retard de la webcam.
5. L'identification (identifier.py) : kp, armature, amortissement, retard ; le résidu dit si le modèle tient.
Résultat : mesures/seance-<servo>-<date>.json (le vrai banc) ou navitek-sim/resultats/banc-seance-simulee.json (la simulation).
"""
import argparse
import collections
import json
import os
import subprocess
import sys
import threading
import time

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import identifier as ID  # noqa: E402
import pilote as PL  # noqa: E402
import regarder as RG  # noqa: E402

ETALONNAGE = (-60, -30, 0, 30, 60)
ECHELONS = (2.0, 10.0, 40.0)
REPETITIONS = 5
DUREE = 0.6
IPS = 30
VERITE_SIMULEE = {"kp": 2.4, "armature": 0.0026, "amortissement": 0.016, "retard_s": 0.028}   # loin du nominal exprès


class CameraSimulee:
    """Ce que verrait la webcam : la scène de essai_vision.py rendue à l'angle de l'arbre du servo simulé, plus le bruit d'image."""

    def __init__(self, servo, graine=0):
        import mujoco
        import essai_vision as EV
        self.EV, self.servo = EV, servo
        self.m = mujoco.MjModel.from_xml_string(EV.SCENE)
        self.d = mujoco.MjData(self.m)
        self.r = mujoco.Renderer(self.m, EV.H, EV.L)
        self.rng = np.random.default_rng(graine)

    def image_a(self, t):
        return self.EV.rendre(self.m, self.d, self.r, self.servo.angle_a(t), 8, 0, self.rng)   # webcam penchée de 8°

    def images_entre(self, t0, t1):
        ph = self.rng.uniform(0, 1 / IPS)
        return [(t, self.image_a(t)) for t in t0 + ph + np.arange(int((t1 - t0) * IPS)) / IPS if t < t1]


class WebcamReelle:
    """ffmpeg en continu (dshow) ; un fil lit chaque image et note l'heure du PC à son arrivée."""

    def __init__(self, appareil="Integrated Webcam", largeur=640, hauteur=480):
        self.L, self.H = largeur, hauteur
        cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "dshow", "-video_size", f"{largeur}x{hauteur}", "-framerate", str(IPS),
               "-i", f"video={appareil}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        self.images = collections.deque(maxlen=600)
        self.fil = threading.Thread(target=self._lire, daemon=True)
        self.fil.start()
        time.sleep(2.0)                                    # l'exposition automatique se règle

    def _lire(self):
        n = self.L * self.H * 3
        while True:
            brut = self.proc.stdout.read(n)
            if len(brut) < n:
                return
            self.images.append((time.perf_counter(), np.frombuffer(brut, np.uint8).reshape(self.H, self.L, 3)))

    def derniere(self):
        return self.images[-1][1]

    def images_entre(self, t0, t1):
        return [(t, im) for t, im in list(self.images) if t0 <= t <= t1]

    def arreter(self):
        self.proc.kill()


def latence_webcam(p, cam, n=8):
    """Le retard de la webcam (s), par la DEL du Pico : de l'ordre « allume » à la première image où la zone de la DEL s'éclaire."""
    p.envoyer("led", allumee=False)
    time.sleep(0.5)
    eteinte = cam.derniere().mean(-1)
    p.envoyer("led", allumee=True)
    time.sleep(0.5)
    diff = cam.derniere().mean(-1) - eteinte
    zone = diff > max(30.0, 0.5 * diff.max())
    if zone.sum() < 3:
        raise RuntimeError("la DEL du Pico n'est pas visible dans l'image : la tourner vers la webcam (BANC.md)")
    seuil = (eteinte[zone].mean() + (eteinte + diff)[zone].mean()) / 2
    mesures = []
    for _ in range(n):
        p.envoyer("led", allumee=False)
        time.sleep(0.4)
        t = time.perf_counter()
        p.envoyer("led", allumee=True)
        time.sleep(0.4)
        vues = [ta for ta, im in cam.images_entre(t, t + 0.4) if im.mean(-1)[zone].mean() > seuil]
        if vues:
            mesures.append(vues[0] - t)
    p.envoyer("led", allumee=False)
    if len(mesures) < n // 2:
        raise RuntimeError("la DEL n'a pas été vue assez souvent")
    return float(np.median(mesures)), [round(x, 4) for x in mesures]


def seance(servo, simule=False, port=None):
    rapport = {"servo": servo, "simule": simule, "debut": time.strftime("%Y-%m-%d %H:%M:%S")}
    if simule:
        import simule as SM
        materiel = SM.MaterielSimule(curseurs=False, servo_mujoco={"nom": servo, "params": VERITE_SIMULEE})
        p = PL.Pilote.simule(materiel)
        servo_sim = materiel.servos[__import__("banc_pico").BROCHES[servo]]
        cam = CameraSimulee(servo_sim)
        attendre = lambda s: materiel.dormir_ms(s * 1000)
        maintenant = lambda: materiel._t
        rapport["verite"] = VERITE_SIMULEE
    else:
        p = PL.Pilote.usb(port, journal=os.path.join(ICI, "mesures", "journal-" + time.strftime("%Y%m%d") + ".jsonl"))
        cam = WebcamReelle()
        attendre = time.sleep
        maintenant = time.perf_counter
    try:
        r = p.ping()
        if servo not in r["servos"]:
            raise ValueError(f"servo inconnu : {servo}")
        latence = 0.0
        if not simule:
            latence, brut = latence_webcam(p, cam)
            rapport["latence_webcam_s"], rapport["latence_mesures_s"] = round(latence, 4), brut
        # l'étalonnage de la vision
        images = []
        for a in ETALONNAGE:
            p.angle(servo, a)
            attendre(1.0)
            images.append(cam.image_a(maintenant()) if simule else cam.derniere())
        regard = RG.Regard().etalonner(images, list(ETALONNAGE))
        rapport["etalonnage_deg"] = list(ETALONNAGE)
        # les échelons
        mesures = []
        for rep in range(REPETITIONS):
            for a in ECHELONS:
                if simule:
                    rep_p = p.echelon(servo, 0.0, a, attente_s=1.0, duree_s=DUREE)
                    t0 = rep_p["t0_us"] / 1e6
                    vues = [(t - t0, im) for t, im in cam.images_entre(t0, t0 + DUREE)]
                else:
                    t_envoi = time.perf_counter()
                    p.echelon(servo, 0.0, a, attente_s=1.0, duree_s=DUREE)
                    t0 = t_envoi + 1.0 + latence
                    vues = [(t - t0, im) for t, im in cam.images_entre(t0, t0 + DUREE)]
                ts, angles = [], []
                for t, im in vues:
                    x = regard.angle(im)
                    if x is not None:
                        ts.append(round(float(t), 4))
                        angles.append(round(x, 3))
                mesures.append({"de": 0.0, "a": a, "t_s": ts, "angle_deg": angles})
        rapport["mesures"] = mesures
        res = ID.identifier(mesures, departs=6)
        rapport["identification"] = {k: float(f"{v:.5g}") for k, v in res["parametres"].items()}
        rapport["residu_deg"] = round(res["residu_deg"], 3)
        rapport["nominal_modele_n0"] = ID.NOMINAL
        if simule:
            rapport["ecart_pc"] = {k: round((res["parametres"][k] - VERITE_SIMULEE[k]) / VERITE_SIMULEE[k] * 100, 2) for k in ID.NOMS}
    finally:
        p.fermer()
        if not simule:
            cam.arreter()
    if simule:
        f = os.path.join(ICI, "..", "..", "navitek-sim", "resultats", "banc-seance-simulee.json")
    else:
        os.makedirs(os.path.join(ICI, "mesures"), exist_ok=True)
        f = os.path.join(ICI, "mesures", f"seance-{servo}-{time.strftime('%Y%m%d-%H%M')}.json")
    json.dump(rapport, open(f, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return rapport, f


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--servo", default="hanche_g")
    ap.add_argument("--simule", action="store_true")
    ap.add_argument("--port")
    a = ap.parse_args()
    r, f = seance(a.servo, a.simule, a.port)
    print("identifié :", r["identification"], "; résidu", r["residu_deg"], "°")
    if "ecart_pc" in r:
        print("écart à la vérité simulée (%) :", r["ecart_pc"])
    print("→", os.path.normpath(f))


if __name__ == "__main__":
    main()
