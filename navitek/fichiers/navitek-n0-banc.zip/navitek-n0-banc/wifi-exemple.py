# Le Wi-Fi du banc, en option : copier ce fichier sur le Pico sous le nom secrets.py, et y écrire le nom et le mot de passe du réseau.
# Ce fichier-ci reste vide : secrets.py n'entre jamais dans le dépôt (.gitignore), et le mot de passe ne s'écrit que sur le Pico.
# Sans secrets.py, le banc marche par le câble USB seulement.

SSID = ""
MOT_DE_PASSE = ""
