"""La vision du banc : l'image de la webcam → les pastilles de couleur → l'angle de l'articulation.

Le montage (BANC.md) : un servo dans le gabarit, un bras sur son palonnier, DEUX pastilles sur le bras (verte près de l'axe, magenta au
bout) et une pastille bleue fixe sur le gabarit (le repère : si elle bouge, la webcam a bougé). L'angle est la direction du bras (de la
verte à la magenta), ramenée par un étalonnage sur des angles commandés connus :
- à deux angles (0° et un autre) : le zéro et le sens, si la webcam regarde le bras de face ;
- à cinq angles ou plus : en plus, la correction d'une webcam de biais (la vue oblique d'un plan est, de près, une transformation affine :
  une matrice 2 × 2 apprise sur les directions, cahier R-045).
Sans OpenCV : teinte, saturation et valeur en numpy, la plus grande tache de chaque couleur par scipy.ndimage.label, son centre.

    python -X utf8 regarder.py image.png                      les pastilles trouvées dans une image
    python -X utf8 regarder.py --webcam --images 1 --sortie mesures/   une image de la webcam (ffmpeg, dshow)
"""
import argparse
import os
import subprocess

import numpy as np
from scipy import ndimage

# teinte au centre (degrés), tolérance (degrés) ; saturation et valeur minimales (0 à 1)
COULEURS = {"vert": (130, 30), "magenta": (305, 25), "bleu": (220, 22)}
SAT_MIN, VAL_MIN = 0.45, 0.25
AIRE_MIN = 12            # pixels : en dessous, ce n'est pas une pastille


def tsv(img):
    """Teinte (degrés), saturation, valeur (0 à 1) d'une image RGB uint8 (h, l, 3)."""
    x = img.astype(np.float32) / 255.0
    r, g, b = x[..., 0], x[..., 1], x[..., 2]
    mx, mn = x.max(-1), x.min(-1)
    d = mx - mn
    t = np.zeros_like(mx)
    m = d > 1e-6
    rm, gm, bm = m & (mx == r), m & (mx == g) & (mx != r), m & (mx == b) & (mx != r) & (mx != g)
    t[rm] = (60 * ((g - b)[rm] / d[rm])) % 360
    t[gm] = 60 * ((b - r)[gm] / d[gm]) + 120
    t[bm] = 60 * ((r - g)[bm] / d[bm]) + 240
    s = np.where(mx > 1e-6, d / np.maximum(mx, 1e-6), 0)
    return t, s, mx


def trouver(img, couleur, tsv_=None):
    """Le centre (x, y) en pixels et l'aire de la plus grande tache de cette couleur, ou None."""
    t, s, v = tsv_ if tsv_ is not None else tsv(img)
    c, tol = COULEURS[couleur]
    dt = np.abs((t - c + 180) % 360 - 180)
    masque = (dt <= tol) & (s >= SAT_MIN) & (v >= VAL_MIN)
    etiq, n = ndimage.label(masque)
    if n == 0:
        return None
    aires = ndimage.sum(masque, etiq, range(1, n + 1))
    k = int(np.argmax(aires)) + 1
    if aires[k - 1] < AIRE_MIN:
        return None
    # centre pondéré par la saturation : plus précis sur les bords flous
    ys, xs = np.nonzero(etiq == k)
    w = s[ys, xs]
    return float((xs * w).sum() / w.sum()), float((ys * w).sum() / w.sum()), int(aires[k - 1])


def pastilles(img):
    q = tsv(img)
    return {c: trouver(img, c, q) for c in COULEURS}


def direction(p):
    """Le vecteur du bras (de la verte à la magenta), en repère image (x à droite, y en haut), ou None."""
    if p.get("vert") is None or p.get("magenta") is None:
        return None
    return np.array([p["magenta"][0] - p["vert"][0], -(p["magenta"][1] - p["vert"][1])])


class Regard:
    """L'étalonnage et la mesure. etalonner() avec des images à des angles commandés connus, puis angle(image)."""

    def __init__(self):
        self.A_inv = np.eye(2)
        self.zero = 0.0
        self.sens = 1.0
        self.repere = None

    def etalonner(self, images, angles_deg):
        dirs = [direction(pastilles(im)) for im in images]
        if any(d is None for d in dirs):
            raise ValueError("une pastille du bras manque sur une image d'étalonnage")
        self.repere = pastilles(images[0]).get("bleu")
        a = np.radians(np.asarray(angles_deg, dtype=float))
        if len(images) >= 5:
            # d_i ∝ A u_i, avec u_i = (cos a_i, sin a_i) : d_i × (A u_i) = 0, linéaire en A (4 inconnues) → SVD
            M = []
            for d, ai in zip(dirs, a):
                u = np.array([np.cos(ai), np.sin(ai)])
                M.append([d[0] * u[0], d[0] * u[1], -d[1] * u[0], -d[1] * u[1]])   # d_x (A u)_y − d_y (A u)_x, avec A = [[a, b], [c, e]] réordonné
            _, _, vt = np.linalg.svd(np.array(M))
            c_, e_, a_, b_ = vt[-1]
            A = np.array([[a_, b_], [c_, e_]])
            self.A_inv = np.linalg.inv(A)
            self.zero, self.sens = 0.0, 1.0
            # le signe de A est indéterminé : on le fixe par le premier angle d'étalonnage
            if abs(self._brut(dirs[0]) - angles_deg[0]) > 90:
                self.A_inv = -self.A_inv
        else:
            z = np.degrees(np.arctan2(dirs[0][1], dirs[0][0]))
            autre = np.degrees(np.arctan2(dirs[1][1], dirs[1][0]))
            delta = (autre - z + 180) % 360 - 180
            self.zero = z - angles_deg[0] * (1 if delta * (angles_deg[1] - angles_deg[0]) > 0 else -1)
            self.sens = 1.0 if delta * (angles_deg[1] - angles_deg[0]) > 0 else -1.0
        return self

    def _brut(self, d):
        x = self.A_inv @ d
        return (np.degrees(np.arctan2(x[1], x[0])) - self.zero + 180) % 360 - 180

    def angle(self, img):
        """L'angle de l'articulation (degrés), ou None si une pastille du bras manque."""
        d = direction(pastilles(img))
        if d is None:
            return None
        return float(self.sens * self._brut(d))

    def webcam_bougee(self, img, seuil_px=3.0):
        b = pastilles(img).get("bleu")
        if self.repere is None or b is None:
            return None
        return float(np.hypot(b[0] - self.repere[0], b[1] - self.repere[1])) > seuil_px


def webcam(n=1, appareil="Integrated Webcam", largeur=640, hauteur=480, ips=30):
    """n images de la webcam par ffmpeg (entrée dshow), en tableaux RGB. Rend (images, horodatages ffmpeg en s)."""
    cmd = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-f", "dshow", "-video_size", f"{largeur}x{hauteur}", "-framerate", str(ips),
           "-i", f"video={appareil}", "-frames:v", str(n), "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    brut = subprocess.run(cmd, capture_output=True, check=True).stdout
    taille = largeur * hauteur * 3
    return [np.frombuffer(brut[i * taille:(i + 1) * taille], np.uint8).reshape(hauteur, largeur, 3) for i in range(len(brut) // taille)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("image", nargs="?")
    ap.add_argument("--webcam", action="store_true")
    ap.add_argument("--images", type=int, default=1)
    ap.add_argument("--sortie", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "mesures"))
    a = ap.parse_args()
    import imageio.v2 as iio
    if a.webcam:
        os.makedirs(a.sortie, exist_ok=True)
        for i, im in enumerate(webcam(a.images)):
            f = os.path.join(a.sortie, f"webcam-{i:03d}.png")
            iio.imwrite(f, im)
            print(f, pastilles(im))
    else:
        im = iio.imread(a.image)[..., :3]
        print(pastilles(im))


if __name__ == "__main__":
    main()
