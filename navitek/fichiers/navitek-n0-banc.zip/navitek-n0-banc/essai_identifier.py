"""L'épreuve de l'identification (B34, cahier R-045 § 4 et § 5.3) : des réponses simulées à des paramètres connus, l'identification doit les retrouver.

Trois vérités (modele_n0.py, puis tout × 0,7, puis tout × 1,4, retard compris) ; trois échelons depuis 0° (2°, 10°, 40°) ; trois façons de voir :
- « webcam » : 30 images par seconde, instant de la première image tiré au hasard dans la période, bruit de 0,5° (hypothèse I1) ;
- « curseur » : 100 mesures par seconde, bruit de 0,2° (hypothèse I2) ;
- « webcam floue » (hors hypothèses, pour voir) : comme « webcam », mais chaque image est la moyenne de l'angle sur 10 ms d'exposition.
Passage 1 : un tirage par cas. Passage 2 (hypothèse I3) : la webcam, 10 tirages par vérité, chaque échelon vu 1 fois puis 5 fois.
Les graines sont fixes (zlib.crc32 du nom du cas) : le résultat se refait à l'identique.

    python -X utf8 essai_identifier.py        → ../../navitek-sim/resultats/banc-identification.json
"""
import json
import multiprocessing as mp
import os
import sys
import zlib

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import identifier as ID  # noqa: E402

RES = os.path.join(ICI, "..", "..", "navitek-sim", "resultats")
VERITES = {"nominal": 1.0, "x0,7": 0.7, "x1,4": 1.4}
ECHELONS = (2.0, 10.0, 40.0)
VUES = {"webcam": (30.0, 0.5, 0.0), "curseur": (100.0, 0.2, 0.0), "webcam floue": (30.0, 0.5, 0.010)}


def mesurer(vraie, frequence, bruit, flou, rng, repetitions=1):
    mes = []
    for _ in range(repetitions):
        for a in ECHELONS:
            t = rng.uniform(0, 1 / frequence) + np.arange(int(ID.DUREE * frequence)) / frequence
            t = t[t < ID.DUREE - 0.02]
            if flou:
                fin = np.linspace(-flou / 2, flou / 2, 11)
                th = np.mean([ID.simuler(vraie, [{"de": 0.0, "a": a, "t_s": t + dt}])[0] for dt in fin], axis=0)
            else:
                th = ID.simuler(vraie, [{"de": 0.0, "a": a, "t_s": t}])[0]
            mes.append({"de": 0.0, "a": a, "t_s": t.tolist(), "angle_deg": (th + rng.normal(0, bruit, len(t))).tolist()})
    return mes


def tache(args):
    nom_v, f, nom_vue, tirage, repetitions = args
    vraie = {k: v * f for k, v in ID.NOMINAL.items()}
    frequence, bruit, flou = VUES[nom_vue]
    rng = np.random.default_rng(zlib.crc32(f"{nom_v}|{nom_vue}|{tirage}|{repetitions}".encode()))
    mes = mesurer(vraie, frequence, bruit, flou, rng, repetitions)
    r = ID.identifier(mes, departs=6, rng=rng)
    ecarts = {k: round((r["parametres"][k] - vraie[k]) / vraie[k] * 100, 2) for k in ID.NOMS}
    return {"verite": nom_v, "vue": nom_vue, "tirage": tirage, "repetitions": repetitions, "vrai": vraie,
            "trouve": {k: float(f"{v:.5g}") for k, v in r["parametres"].items()},
            "ecart_pc": ecarts, "residu_deg": round(r["residu_deg"], 3), "dans_10pc": all(abs(e) <= 10 for e in ecarts.values())}


def main():
    p1 = [(nv, f, vue, 0, 1) for nv, f in VERITES.items() for vue in VUES]
    p2 = [(nv, f, "webcam", k, rep) for nv, f in VERITES.items() for rep in (1, 5) for k in range(10)]
    with mp.Pool(14) as pool:
        s1 = pool.map(tache, p1, chunksize=1)
        s2 = pool.map(tache, p2, chunksize=1)
    bilan = {}
    for rep in (1, 5):
        l = [s for s in s2 if s["repetitions"] == rep]
        bilan[f"{rep} passage(s)"] = {"dans_10pc": sum(s["dans_10pc"] for s in l), "sur": len(l),
                                      "ecart_max_pc": {k: round(max(abs(s["ecart_pc"][k]) for s in l), 1) for k in ID.NOMS},
                                      "ecart_median_pc": {k: round(float(np.median([abs(s["ecart_pc"][k]) for s in l])), 1) for k in ID.NOMS}}
    json.dump({"essai": "B34 / R-045 : l'identification sur des réponses simulées", "echelons_deg": ECHELONS, "vues": VUES,
               "passage_1": s1, "passage_2_repetitions": s2, "bilan_repetitions": bilan},
              open(os.path.join(RES, "banc-identification.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{'vérité':<9}{'vue':<14}{'kp':>8}{'armature':>10}{'amort.':>9}{'retard':>9}{'résidu':>9}  à 10 %")
    for s in s1:
        e = s["ecart_pc"]
        print(f"{s['verite']:<9}{s['vue']:<14}{e['kp']:>7.1f}%{e['armature']:>9.1f}%{e['amortissement']:>8.1f}%{e['retard_s']:>8.1f}%{s['residu_deg']:>8.2f}°  {'oui' if s['dans_10pc'] else 'NON'}")
    for k, b in bilan.items():
        print(k, b)


if __name__ == "__main__":
    main()
