"""L'épreuve de la vision (B33, cahier R-045 § 3) : des images rendues par MuJoCo, à des angles connus, passées à regarder.py.

La scène : un fond gris, le gabarit (un bloc fixe) avec une pastille bleue, une charnière d'axe Y, un bras orange de 45 mm portant une pastille
verte (à 8 mm de l'axe) et une magenta (à 38 mm) ; pastilles de 8 mm. Caméra à 25 cm, 640 × 480, regardant le plan du bras, penchée de 0, 10
et 20° (vers le bas), et un cas penché de 10° vers le bas et 10° de côté. Bruit gaussien de 4 niveaux sur 255. 40 angles tirés entre −80 et +80°.
Deux étalonnages : à 2 angles (0 et 30°) et à 5 angles (−60, −30, 0, 30, 60°).

    python -X utf8 essai_vision.py        → ../../navitek-sim/resultats/banc-vision.json et banc-vision-exemple.png
"""
import json
import os
import sys

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import regarder as RG  # noqa: E402

RES = os.path.join(ICI, "..", "..", "navitek-sim", "resultats")
L, H = 640, 480

SCENE = f"""<mujoco>
  <visual><global offwidth="{L}" offheight="{H}"/><headlight ambient="0.35 0.35 0.35" diffuse="0.55 0.55 0.55" specular="0.1 0.1 0.1"/></visual>
  <worldbody>
    <light pos="0.1 -0.4 0.3" dir="-0.2 1 -0.7" diffuse="0.5 0.5 0.5"/>
    <geom name="fond" type="box" size="0.2 0.002 0.15" pos="0 0.03 0" rgba="0.62 0.62 0.6 1"/>
    <geom name="gabarit" type="box" size="0.03 0.012 0.022" pos="-0.012 0.012 -0.012" rgba="0.55 0.56 0.58 1"/>
    <geom name="bleu" type="cylinder" size="0.004 0.0005" pos="-0.032 -0.0002 -0.022" zaxis="0 1 0" rgba="0.12 0.3 0.9 1"/>
    <body name="bras" pos="0 -0.004 0">
      <joint name="axe" type="hinge" axis="0 1 0" range="-3.2 3.2"/>
      <geom name="palonnier" type="cylinder" size="0.006 0.002" zaxis="0 1 0" rgba="0.95 0.95 0.95 1"/>
      <geom name="bras" type="box" size="0.0225 0.002 0.006" pos="0.0175 -0.002 0" rgba="0.93 0.45 0.1 1"/>
      <geom name="vert" type="cylinder" size="0.004 0.0005" pos="0.008 -0.0045 0" zaxis="0 1 0" rgba="0.1 0.75 0.25 1"/>
      <geom name="magenta" type="cylinder" size="0.004 0.0005" pos="0.038 -0.0045 0" zaxis="0 1 0" rgba="0.85 0.1 0.75 1"/>
    </body>
  </worldbody>
</mujoco>"""

CAS = [("face", 0, 0), ("penchée de 10°", 10, 0), ("penchée de 20°", 20, 0), ("10° vers le bas et 10° de côté", 10, 10)]


def rendre(m, d, r, angle_deg, bas, cote, rng):
    d.qpos[0] = np.radians(angle_deg)
    mujoco.mj_forward(m, d)
    cam = mujoco.MjvCamera()
    cam.lookat[:] = [0.012, -0.006, -0.004]
    cam.distance, cam.azimuth, cam.elevation = 0.25, 90 + cote, -bas
    r.update_scene(d, camera=cam)
    im = r.render().astype(np.float32)
    im += rng.normal(0, 4, im.shape)
    return np.clip(im, 0, 255).astype(np.uint8)


def main():
    m = mujoco.MjModel.from_xml_string(SCENE)
    d = mujoco.MjData(m)
    r = mujoco.Renderer(m, H, L)
    rng = np.random.default_rng(0)
    angles = rng.uniform(-80, 80, 40)
    sortie = {"essai": "B33 / R-045 § 3 : la vision sur des images rendues par MuJoCo", "angles_vrais_deg": [round(float(a), 3) for a in angles], "cas": []}
    for nom, bas, cote in CAS:
        ligne = {"cas": nom, "bas_deg": bas, "cote_deg": cote}
        for etal, ref in (("2 angles", [0, 30]), ("5 angles", [-60, -30, 0, 30, 60])):
            reg = RG.Regard().etalonner([rendre(m, d, r, a, bas, cote, rng) for a in ref], ref)
            mes = [reg.angle(rendre(m, d, r, a, bas, cote, rng)) for a in angles]
            manque = sum(x is None for x in mes)
            err = np.array([x - a for x, a in zip(mes, angles) if x is not None])
            ligne[etal] = {"erreur_max_deg": round(float(np.abs(err).max()), 3), "erreur_moyenne_deg": round(float(np.abs(err).mean()), 3),
                           "biais_deg": round(float(err.mean()), 3), "manquees": manque}
        sortie["cas"].append(ligne)
        print(f"{nom:<32} 2 angles : max {ligne['2 angles']['erreur_max_deg']:5.2f}°, moyenne {ligne['2 angles']['erreur_moyenne_deg']:4.2f}°"
              f"   |   5 angles : max {ligne['5 angles']['erreur_max_deg']:5.2f}°, moyenne {ligne['5 angles']['erreur_moyenne_deg']:4.2f}°"
              f"   (manquées {ligne['2 angles']['manquees']}/{ligne['5 angles']['manquees']})")
    # une image d'exemple, avec les pastilles trouvées marquées
    im = rendre(m, d, r, 35, 10, 0, rng).copy()
    for c, p in RG.pastilles(im).items():
        if p:
            x, y = int(round(p[0])), int(round(p[1]))
            im[max(0, y - 1):y + 2, max(0, x - 12):x + 13] = 255
            im[max(0, y - 12):y + 13, max(0, x - 1):x + 2] = 255
    import imageio.v2 as iio
    iio.imwrite(os.path.join(RES, "banc-vision-exemple.png"), im)
    json.dump(sortie, open(os.path.join(RES, "banc-vision.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    r.close()


if __name__ == "__main__":
    main()
