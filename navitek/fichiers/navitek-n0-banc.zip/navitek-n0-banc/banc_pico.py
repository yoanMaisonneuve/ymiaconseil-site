# Navitek N0 — le programme du banc (MicroPython, Raspberry Pi Pico 2 W)
#
# Le Pico obéit au PC, une commande à la fois, en lignes JSON par le câble USB (et, en option, par le Wi-Fi). Il sert à mesurer
# les servos avant de monter le robot : le PC commande un angle ou un échelon, la webcam regarde, et le PC compare.
#
# Copier ce fichier sur le Pico sous le nom main.py (Thonny : Fichier > Enregistrer sous > Raspberry Pi Pico), à la place du
# main.py du robot, le temps du banc. Les gestes de Yoan sont dans BANC.md.
#
# Sécurité : au démarrage, AUCUN servo ne reçoit de signal (relâchés) ; chaque angle est borné par BORNES ; sans commande
# pendant 30 s, tous les servos sont relâchés ; la commande « arret » relâche tout.
#
# Le protocole (une ligne JSON par commande, une ligne JSON par réponse ; « id » est renvoyé tel quel s'il est donné) :
#   {"cmd": "ping"}                                   le programme, la version, les servos, les curseurs, le Wi-Fi
#   {"cmd": "temps"}                                  l'horloge du Pico en microsecondes (pour aligner avec la webcam)
#   {"cmd": "angle", "nom": "genou_g", "deg": 20}     un servo, borné
#   {"cmd": "pose", "angles": {...}, "duree_s": 0.6}  plusieurs servos, en douceur
#   {"cmd": "relacher"} ou {"cmd": "relacher", "nom": "genou_g"}
#   {"cmd": "lire"}                                   les curseurs (comptes de 0 à 65535), si le multiplexeur est branché
#   {"cmd": "echelon", "nom": "hanche_g", "de": 0, "a": 30, "attente_s": 1.0, "duree_s": 1.5, "periode_ms": 10}
#                                                     un échelon, et le curseur relevé pendant la réponse (si branché)
#   {"cmd": "bornes"}                                 les bornes de chaque articulation
#   {"cmd": "arret"}                                  tout relâcher
#   {"cmd": "led", "allumee": true}                   la DEL du Pico (pour mesurer le retard de la webcam) ; elle s'allume
#                                                     aussi pendant chaque échelon, de l'instant de l'ordre à la fin de la mesure
#
# Version 0.1 (09.11.2026) : écrit avec la simulation, éprouvé sur un Pico simulé (banc/essai_banc.py), pas encore sur un vrai Pico.

import json
import time

VERSION = "0.1"

# Les mêmes valeurs que firmware/main.py (essai_banc.py vérifie qu'elles n'ont pas divergé).
BROCHES = {
    "hanche_g": 2, "genou_g": 3, "cheville_tangage_g": 4, "cheville_roulis_g": 5,
    "hanche_d": 6, "genou_d": 7, "cheville_tangage_d": 8, "cheville_roulis_d": 9,
    "epaule_g": 10, "coude_g": 11,
    "epaule_d": 12, "coude_d": 13,
    "cou": 14,
}
# L'ordre des canaux du multiplexeur (canal 0 = hanche_g), écrit en liste : il ne dépend pas de l'ordre d'un dictionnaire.
ORDRE = ["hanche_g", "genou_g", "cheville_tangage_g", "cheville_roulis_g", "hanche_d", "genou_d", "cheville_tangage_d",
         "cheville_roulis_d", "epaule_g", "coude_g", "epaule_d", "coude_d", "cou"]
SENS = {nom: (-1 if nom.endswith("_d") else 1) for nom in BROCHES}
TRIM = {nom: 0 for nom in BROCHES}
BORNES = {nom: (-60, 60) for nom in BROCHES}
BORNES.update({"genou_g": (-10, 90), "genou_d": (-10, 90), "cou": (-80, 80)})
BORNES.update({"cheville_roulis_g": (-60, 7), "cheville_roulis_d": (-7, 60)})
MIN_US, MAX_US = 500, 2500

# Les curseurs (le « hack du potentiomètre », etalonner.py) : un CD74HC4067, S0 à S3 sur GP15 à GP18, SIG sur GP26.
# Le canal de chaque articulation est son rang dans BROCHES (canal 0 = hanche_g). MULTIPLEXEUR = False si rien n'est branché.
MULTIPLEXEUR = False
SELECT_BROCHES = (15, 16, 17, 18)
ADC_BROCHE = 26

CHIEN_DE_GARDE_S = 30
PORT_WIFI = 7300
MAX_ECHANTILLONS = 400


class MaterielPico:
    """Le vrai matériel. Le Pico simulé (essai_banc.py) fournit les mêmes méthodes."""

    def __init__(self):
        from machine import Pin, PWM, ADC
        self._Pin, self._PWM = Pin, PWM
        self._sel = [Pin(n, Pin.OUT) for n in SELECT_BROCHES] if MULTIPLEXEUR else None
        self._adc = ADC(ADC_BROCHE) if MULTIPLEXEUR else None
        self._led = Pin("LED", Pin.OUT)

    def led(self, allumee):
        self._led.value(1 if allumee else 0)

    def pwm(self, broche):
        p = self._PWM(self._Pin(broche))
        p.freq(50)
        p.duty_ns(0)                       # aucun signal : le servo est relâché
        return p

    def curseurs(self):
        return self._adc is not None

    def lire_canal(self, canal, n=8):
        for k in range(4):
            self._sel[k].value((canal >> k) & 1)
        time.sleep_us(300)
        s = 0
        for _ in range(n):
            s += self._adc.read_u16()
        return s // n

    def t_us(self):
        return time.ticks_us()

    def ecart_us(self, t1, t0):
        return time.ticks_diff(t1, t0)

    def dormir_ms(self, ms):
        time.sleep_ms(int(ms))


class Banc:
    def __init__(self, materiel):
        self.m = materiel
        self.servos = {nom: materiel.pwm(b) for nom, b in BROCHES.items()}
        self.actuel = {nom: 0.0 for nom in BROCHES}
        self.actif = {nom: False for nom in BROCHES}
        self.dernier = materiel.t_us()
        self.wifi = None
        self.led_pilotee = False          # quand le PC pilote la DEL, elle ne clignote plus d'elle-même

    # --- les gestes -------------------------------------------------------------------------------------------------------
    def ecrire(self, nom, a):
        lo, hi = BORNES[nom]
        b = max(lo, min(hi, a))
        self.actuel[nom] = b
        self.actif[nom] = True
        us = 1500 + (SENS[nom] * b + TRIM[nom]) * (MAX_US - MIN_US) / 180
        self.servos[nom].duty_ns(int(us * 1000))
        return b

    def relacher(self, nom=None):
        noms = [nom] if nom else list(ORDRE)
        for n in noms:
            self.servos[n].duty_ns(0)
            self.actif[n] = False
        return noms

    def surveiller(self):
        """À appeler souvent : relâche tout si aucune commande depuis CHIEN_DE_GARDE_S. Rend un événement ou None."""
        if any(self.actif.values()) and self.m.ecart_us(self.m.t_us(), self.dernier) > CHIEN_DE_GARDE_S * 1000000:
            self.relacher()
            return {"evt": "relache", "raison": "aucune commande depuis %d s" % CHIEN_DE_GARDE_S}
        return None

    # --- le protocole ------------------------------------------------------------------------------------------------------
    def traiter_ligne(self, ligne):
        try:
            demande = json.loads(ligne)
            if not isinstance(demande, dict):
                raise ValueError("pas un objet")
        except Exception:
            return {"ok": False, "erreur": "ligne illisible (JSON attendu)"}
        rep = self.traiter(demande)
        if "id" in demande:
            rep["id"] = demande["id"]
        return rep

    def traiter(self, d):
        self.dernier = self.m.t_us()
        cmd = d.get("cmd")
        try:
            if cmd == "ping":
                return {"ok": True, "programme": "banc_pico", "version": VERSION, "servos": list(ORDRE),
                        "curseurs": self.m.curseurs(), "wifi": self.wifi}
            if cmd == "temps":
                return {"ok": True, "t_us": self.m.t_us()}
            if cmd == "bornes":
                return {"ok": True, "bornes": {n: list(b) for n, b in BORNES.items()}}
            if cmd == "angle":
                nom = self._nom(d)
                deg = float(d["deg"])
                b = self.ecrire(nom, deg)
                return {"ok": True, "nom": nom, "deg": b, "borne": b != deg}
            if cmd == "pose":
                return self._pose(d)
            if cmd == "relacher":
                return {"ok": True, "relaches": self.relacher(self._nom(d) if "nom" in d else None)}
            if cmd == "arret":
                return {"ok": True, "relaches": self.relacher()}
            if cmd == "lire":
                if not self.m.curseurs():
                    return {"ok": False, "erreur": "pas de multiplexeur (MULTIPLEXEUR = False)"}
                noms = [self._nom(d)] if "nom" in d else list(ORDRE)
                return {"ok": True, "comptes": {n: self.m.lire_canal(ORDRE.index(n)) for n in noms}}
            if cmd == "echelon":
                return self._echelon(d)
            if cmd == "led":
                self.led_pilotee = True
                self.m.led(bool(d["allumee"]))
                return {"ok": True, "allumee": bool(d["allumee"]), "t_us": self.m.t_us()}
            return {"ok": False, "erreur": "commande inconnue : %s" % cmd}
        except KeyError as e:
            return {"ok": False, "erreur": "champ manquant ou nom inconnu : %s" % e}
        except (ValueError, TypeError) as e:
            return {"ok": False, "erreur": "valeur invalide : %s" % e}

    def _nom(self, d):
        nom = d["nom"]
        if nom not in BROCHES:
            raise KeyError(nom)
        return nom

    def _pose(self, d):
        cible = {}
        for nom, a in d["angles"].items():
            if nom not in BROCHES:
                raise KeyError(nom)
            cible[nom] = float(a)
        duree = max(0.0, min(10.0, float(d.get("duree_s", 0.6))))
        pas = max(1, int(duree / 0.02))
        depart = dict(self.actuel)
        for k in range(1, pas + 1):
            t = k / pas
            t = t * t * (3 - 2 * t)
            for nom, a in cible.items():
                self.ecrire(nom, depart[nom] + (a - depart[nom]) * t)
            self.m.dormir_ms(duree * 1000 / pas)
        return {"ok": True, "angles": {n: self.actuel[n] for n in cible}}

    def _echelon(self, d):
        nom = self._nom(d)
        de, a = float(d["de"]), float(d["a"])
        attente = max(0.0, min(5.0, float(d.get("attente_s", 1.0))))
        duree = max(0.0, min(5.0, float(d.get("duree_s", 1.5))))
        periode = max(2, int(d.get("periode_ms", 10)))
        de_b = self.ecrire(nom, de)
        self.m.dormir_ms(attente * 1000)
        canal = ORDRE.index(nom)
        t0 = self.m.t_us()
        a_b = self.ecrire(nom, a)
        self.m.led(True)                  # la DEL s'allume à l'instant de l'échelon : la webcam voit l'origine du temps
        ech = []
        if self.m.curseurs():
            n = min(MAX_ECHANTILLONS, int(duree * 1000 / periode))
            for k in range(n):
                ech.append([round(self.m.ecart_us(self.m.t_us(), t0) / 1000, 2), self.m.lire_canal(canal)])
                cible = t0 + (k + 1) * periode * 1000
                reste = self.m.ecart_us(cible, self.m.t_us())
                if reste > 0:
                    self.m.dormir_ms(reste / 1000)
        else:
            self.m.dormir_ms(duree * 1000)
        self.m.led(False)
        return {"ok": True, "nom": nom, "de": de_b, "a": a_b, "t0_us": t0, "echantillons": ech}


# --- la boucle (sur le Pico seulement) -------------------------------------------------------------------------------------
def wifi_demarrer():
    """Le Wi-Fi, si secrets.py existe (SSID, MOT_DE_PASSE). Rend (socket serveur, adresse IP) ou (None, None)."""
    try:
        import secrets
    except ImportError:
        return None, None
    import network
    import socket
    w = network.WLAN(network.STA_IF)
    w.active(True)
    w.connect(secrets.SSID, secrets.MOT_DE_PASSE)
    for _ in range(30):
        if w.isconnected():
            break
        time.sleep_ms(500)
    if not w.isconnected():
        return None, None
    ip = w.ifconfig()[0]
    s = socket.socket()
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind(("0.0.0.0", PORT_WIFI))
    s.listen(1)
    s.setblocking(False)
    return s, ip


def principal():
    import select
    import sys
    banc = Banc(MaterielPico())
    serveur, ip = wifi_demarrer()
    banc.wifi = ("%s:%d" % (ip, PORT_WIFI)) if ip else None
    print(json.dumps({"evt": "pret", "programme": "banc_pico", "version": VERSION, "wifi": banc.wifi}))
    p = select.poll()
    p.register(sys.stdin, select.POLLIN)
    client, tampon = None, b""
    led = None
    try:
        from machine import Pin
        led = Pin("LED", Pin.OUT)
    except Exception:
        pass
    tic = 0
    while True:
        for obj, ev in p.poll(20):
            if obj is sys.stdin or obj == sys.stdin:
                ligne = sys.stdin.readline()
                if ligne.strip():
                    print(json.dumps(banc.traiter_ligne(ligne)))
            elif client is not None:
                try:
                    morceau = client.recv(512)
                except OSError:
                    morceau = b""
                if not morceau:
                    p.unregister(client)
                    client.close()
                    client, tampon = None, b""
                    continue
                tampon += morceau
                while b"\n" in tampon:
                    ligne, tampon = tampon.split(b"\n", 1)
                    if ligne.strip():
                        client.send((json.dumps(banc.traiter_ligne(ligne.decode())) + "\n").encode())
        if serveur is not None and client is None:
            try:
                client, _ = serveur.accept()
                client.setblocking(False)
                p.register(client, select.POLLIN)
            except OSError:
                pass
        evt = banc.surveiller()
        if evt:
            print(json.dumps(evt))
        tic += 1
        if led is not None and tic % 25 == 0 and not banc.led_pilotee:
            led.toggle()                     # la DEL clignote : le banc attend (sauf si le PC la pilote)


import sys as _sys
if _sys.implementation.name == "micropython":       # sur le Pico ; sous Python ordinaire (le Pico simulé), on importe sans lancer
    principal()
