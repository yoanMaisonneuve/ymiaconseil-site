"""L'identification du servo (B34, cahier R-045 § 4) : des réponses à des échelons (angle commandé, angle vu, dans le temps) aux paramètres
du servo dans le modèle de simulation de N0 (navitek-sim/modele_n0.py, HYPOTHESES) : kp, armature, amortissement, retard.

Le modèle : une seule charnière MuJoCo, comme une articulation de n0.xml (actionneur de position kp, kv ; couple borné au blocage de la fiche ;
armature et amortissement dans la charnière), qui porte le bras du banc (palonnier et pastilles : 2 g, centre à 15 mm, estimés) dans un plan
vertical (la webcam du portable regarde à l'horizontale), donc avec la pesanteur. kv (0,03) et le couple de blocage (0,177 N·m) restent ceux de
la fiche et du modèle. Le retard est un décalage pur du temps : θ(t) = θ_sans_retard(t − retard), exact pour un échelon.

Ajustement : moindres carrés (scipy.optimize.least_squares) sur le logarithme des quatre paramètres, plusieurs départs, le meilleur gardé.

    from identifier import identifier, simuler
    p = identifier([{"de": 0, "a": 10, "t_s": [...], "angle_deg": [...]}, ...])
"""
import numpy as np
import mujoco
from scipy.optimize import least_squares

KV = 0.03
COUPLE_BLOCAGE = 1.8 * 9.81 / 100
BRAS = {"masse_kg": 0.002, "centre_m": 0.015, "inertie_kgm2": 2e-7}
NOMS = ("kp", "armature", "amortissement", "retard_s")
NOMINAL = {"kp": 3.0, "armature": 0.002, "amortissement": 0.02, "retard_s": 0.020}     # modele_n0.py ; le retard : une estimation
BORNES = {"kp": (0.3, 30.0), "armature": (2e-4, 2e-2), "amortissement": (1e-3, 0.2), "retard_s": (1e-3, 0.1)}
PAS = 0.0005
DUREE = 0.6


def _modele(kp, armature, amortissement):
    xml = f"""<mujoco><option timestep="{PAS}" gravity="0 0 -9.81"/>
  <worldbody><body name="bras">
    <joint name="axe" type="hinge" axis="0 1 0" armature="{armature}" damping="{amortissement}"/>
    <inertial pos="{BRAS['centre_m']} 0 0" mass="{BRAS['masse_kg']}" diaginertia="{BRAS['inertie_kgm2']} {BRAS['inertie_kgm2']} {BRAS['inertie_kgm2']}"/>
  </body></worldbody>
  <actuator><position joint="axe" kp="{kp}" kv="{KV}" forcerange="{-COUPLE_BLOCAGE} {COUPLE_BLOCAGE}"/></actuator>
</mujoco>"""
    m = mujoco.MjModel.from_xml_string(xml)
    return m, mujoco.MjData(m)


def _sans_retard(m, d, de, a):
    """La réponse sans retard à un échelon de « de » à « a » (degrés), à partir du repos à « de » : (temps, angle en degrés)."""
    mujoco.mj_resetData(m, d)
    d.qpos[0] = np.radians(de)
    d.ctrl[0] = np.radians(de)
    for _ in range(int(0.3 / PAS)):                 # repos à « de » (la pesanteur fait un petit écart)
        mujoco.mj_step(m, d)
    d.ctrl[0] = np.radians(a)
    n = int(DUREE / PAS)
    th = np.empty(n + 1)
    th[0] = d.qpos[0]
    for k in range(n):
        mujoco.mj_step(m, d)
        th[k + 1] = d.qpos[0]
    return np.arange(n + 1) * PAS, np.degrees(th)


def simuler(params, echelons, temps=None):
    """L'angle simulé aux instants demandés, pour chaque échelon. echelons : [{"de", "a", "t_s"}], t_s comptés depuis l'ordre envoyé."""
    m, d = _modele(params["kp"], params["armature"], params["amortissement"])
    sorties, deja = [], {}
    for e in echelons:
        cle = (float(e["de"]), float(e["a"]))           # un échelon répété ne se simule qu'une fois
        if cle not in deja:
            deja[cle] = _sans_retard(m, d, *cle)
        t, th = deja[cle]
        tq = np.asarray(e["t_s"] if temps is None else temps) - params["retard_s"]
        sorties.append(np.interp(tq, t, th, left=th[0], right=th[-1]))
    return sorties


def _vers(x):
    return {k: float(np.exp(v)) for k, v in zip(NOMS, x)}


def identifier(mesures, departs=None, rng=None):
    """mesures : [{"de", "a", "t_s", "angle_deg"}]. Rend les paramètres, le résidu (degrés, moyenne quadratique) et les départs essayés."""
    rng = rng or np.random.default_rng(0)
    obs = np.concatenate([np.asarray(e["angle_deg"]) for e in mesures])

    def residu(x):
        return np.concatenate(simuler(_vers(x), mesures)) - obs

    lo = np.log([BORNES[k][0] for k in NOMS])
    hi = np.log([BORNES[k][1] for k in NOMS])
    x0s = [np.log([NOMINAL[k] for k in NOMS])]
    for _ in range((departs or 6) - 1):
        x0s.append(np.log([NOMINAL[k] for k in NOMS]) + rng.uniform(-np.log(2.5), np.log(2.5), 4))
    meilleur = None
    for x0 in x0s:
        r = least_squares(residu, np.clip(x0, lo + 1e-6, hi - 1e-6), bounds=(lo, hi), x_scale=1.0, diff_step=1e-3, max_nfev=200)
        rms = float(np.sqrt(np.mean(r.fun ** 2)))
        if meilleur is None or rms < meilleur[1]:
            meilleur = (r.x, rms)
    return {"parametres": _vers(meilleur[0]), "residu_deg": meilleur[1], "departs": len(x0s)}
