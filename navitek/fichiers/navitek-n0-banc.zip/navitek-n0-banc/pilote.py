"""Le pilote du banc, côté PC : il parle au Pico qui fait tourner banc_pico.py, par le câble USB (ou le Wi-Fi), en lignes JSON.

    python -X utf8 pilote.py ping                         trouve le Pico et lui dit bonjour
    python -X utf8 pilote.py angle hanche_g 20            un angle
    python -X utf8 pilote.py echelon hanche_g 0 30        un échelon (curseur relevé si le multiplexeur est branché)
    python -X utf8 pilote.py arret                        tout relâcher
    options : --port COM7 (sinon cherché), --wifi 192.168.1.42 (au lieu de l'USB), --simule (le Pico simulé de simule.py)

Chaque échange est écrit dans mesures/journal-AAAAMMJJ.jsonl (heure du PC, sens, ligne). Le port USB demande pyserial
(`python -m pip install pyserial`) ; le Pico simulé et le Wi-Fi n'en ont pas besoin.
"""
import argparse
import itertools
import json
import os
import socket
import sys
import time

ICI = os.path.dirname(os.path.abspath(__file__))
VID_RASPBERRY_PI = 0x2E8A          # l'identifiant USB des cartes Raspberry Pi (Pico, Pico 2)


class PasDeReponse(Exception):
    pass


class PortWifi:
    """Le Wi-Fi du banc (banc_pico.PORT_WIFI), avec les mêmes write et readline qu'un port série."""

    def __init__(self, hote, port=7300, delai=2.0):
        self.s = socket.create_connection((hote, port), timeout=delai)
        self.tampon = b""

    def write(self, data):
        self.s.sendall(data)
        return len(data)

    def readline(self):
        while b"\n" not in self.tampon:
            try:
                morceau = self.s.recv(4096)
            except socket.timeout:
                return b""
            if not morceau:
                return b""
            self.tampon += morceau
        ligne, self.tampon = self.tampon.split(b"\n", 1)
        return ligne + b"\n"

    def reset_input_buffer(self):
        self.tampon = b""

    def close(self):
        self.s.close()


def trouver_port():
    """Le port série du Pico (identifiant USB de Raspberry Pi), ou None."""
    from serial.tools import list_ports
    for p in list_ports.comports():
        if p.vid == VID_RASPBERRY_PI:
            return p.device
    return None


class Pilote:
    def __init__(self, port, journal=None, horloge=time.perf_counter):
        self.port = port
        self.horloge = horloge
        self.evenements = []           # les lignes {"evt": ...} reçues entre deux réponses (prêt, relâché par le chien de garde)
        self.bruit = []                # les lignes qui ne sont pas du JSON (le texte de MicroPython, par exemple)
        self.ids = itertools.count(1)
        self.journal = journal
        if journal:
            os.makedirs(os.path.dirname(journal), exist_ok=True)

    # --- l'ouverture -------------------------------------------------------------------------------------------------------
    @classmethod
    def usb(cls, device=None, **kw):
        import serial
        device = device or trouver_port()
        if not device:
            raise PasDeReponse("aucun Pico trouvé sur l'USB (identifiant 2E8A) : brancher le câble, ou donner --port")
        return cls(serial.Serial(device, 115200, timeout=0.5), **kw)

    @classmethod
    def wifi(cls, hote, port=7300, **kw):
        return cls(PortWifi(hote, port), **kw)

    @classmethod
    def simule(cls, materiel=None, **kw):
        if ICI not in sys.path:
            sys.path.insert(0, ICI)
        import simule
        return cls(simule.FauxPort(materiel), **kw)

    # --- l'échange -----------------------------------------------------------------------------------------------------------
    def _noter(self, sens, ligne):
        if self.journal:
            with open(self.journal, "a", encoding="utf-8") as f:
                f.write(json.dumps({"t_pc": round(time.time(), 4), "sens": sens, "ligne": ligne}, ensure_ascii=False) + "\n")

    def envoyer(self, cmd, delai_s=5.0, **champs):
        """Envoie une commande et rend la réponse qui porte son identifiant. Les événements et le bruit sont mis de côté."""
        i = next(self.ids)
        demande = dict(champs, cmd=cmd, id=i)
        ligne = json.dumps(demande)
        self._noter("->", ligne)
        self.port.write((ligne + "\n").encode())
        fin = self.horloge() + delai_s
        while self.horloge() < fin:
            brut = self.port.readline()
            if not brut:
                continue
            texte = brut.decode(errors="replace").strip()
            if not texte:
                continue
            self._noter("<-", texte)
            try:
                r = json.loads(texte)
            except ValueError:
                self.bruit.append(texte)
                continue
            if not isinstance(r, dict):
                self.bruit.append(texte)
            elif "evt" in r:
                self.evenements.append(r)
            elif r.get("id") == i:
                return r
        raise PasDeReponse(f"pas de réponse à « {cmd} » en {delai_s} s")

    # --- les commandes -------------------------------------------------------------------------------------------------------
    def ping(self):
        return self.envoyer("ping")

    def angle(self, nom, deg):
        return self.envoyer("angle", nom=nom, deg=deg)

    def pose(self, angles, duree_s=0.6):
        return self.envoyer("pose", angles=angles, duree_s=duree_s, delai_s=duree_s + 5)

    def relacher(self, nom=None):
        return self.envoyer("relacher", **({"nom": nom} if nom else {}))

    def arret(self):
        return self.envoyer("arret")

    def lire(self, nom=None):
        return self.envoyer("lire", **({"nom": nom} if nom else {}))

    def echelon(self, nom, de, a, attente_s=1.0, duree_s=1.5, periode_ms=10):
        return self.envoyer("echelon", nom=nom, de=de, a=a, attente_s=attente_s, duree_s=duree_s, periode_ms=periode_ms,
                            delai_s=attente_s + duree_s + 5)

    def synchroniser(self, n=10):
        """L'horloge du Pico par rapport à celle du PC : rend (décalage en µs, aller-retour en µs) de l'échange le plus court."""
        meilleur = None
        for _ in range(n):
            t0 = self.horloge()
            r = self.envoyer("temps")
            t1 = self.horloge()
            aller_retour = (t1 - t0) * 1e6
            decalage = r["t_us"] - (t0 + t1) / 2 * 1e6
            if meilleur is None or aller_retour < meilleur[1]:
                meilleur = (decalage, aller_retour)
        return meilleur

    def fermer(self):
        try:
            self.arret()
        finally:
            self.port.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("commande", choices=["ping", "angle", "echelon", "lire", "arret", "bornes"])
    ap.add_argument("args", nargs="*")
    ap.add_argument("--port")
    ap.add_argument("--wifi")
    ap.add_argument("--simule", action="store_true")
    a = ap.parse_args()
    journal = os.path.join(ICI, "mesures", "journal-" + time.strftime("%Y%m%d") + ".jsonl")
    if a.simule:
        sys.path.insert(0, ICI)
        p = Pilote.simule(journal=journal)
    elif a.wifi:
        p = Pilote.wifi(a.wifi, journal=journal)
    else:
        p = Pilote.usb(a.port, journal=journal)
    try:
        if a.commande == "angle":
            r = p.angle(a.args[0], float(a.args[1]))
        elif a.commande == "echelon":
            r = p.echelon(a.args[0], float(a.args[1]), float(a.args[2]))
        elif a.commande == "lire":
            r = p.lire(a.args[0] if a.args else None)
        else:
            r = p.envoyer(a.commande)
        print(json.dumps(r, ensure_ascii=False, indent=1))
    finally:
        p.fermer()


if __name__ == "__main__":
    main()
