# R-112 — Le pendule dans la marche apprise : la marche trouvée par essais a-t-elle redécouvert les équations du mouvement ?
mots-cles: Navitek, N3, pendule inversé, LIPM, point de capture, placement du pied, Raibert, équations du mouvement, centre de gravité, marche, CMA-ES, MuJoCo

> Ouvert le 12.11.2026 à 09:48 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42 : « n'attends pas mon
> accord pour tester les hypothèses que tu as : quand tu en as, on écrit tout et on teste [...] centre de gravité, équations de mouvement des
> humanoïdes. Documente tout sur le site »). Prédictions écrites avant de lire les gains appris ; verdicts après. Tout est simulé.

## 1. La question

La marche de N3 n'a jamais vu une équation : ses réglages ont été trouvés par essais et erreurs (CMA-ES, R-091, R-107, puis le
pré-entraînement de R-111). Parmi eux, le gain qui pose le pied selon la vitesse du corps. Les roboticiens le calculent avec le **pendule
inversé linéaire** (le centre de masse à hauteur constante au-dessus d'un pied ponctuel). **Les essais ont-ils retrouvé la valeur que donne
l'équation ?** Si oui, l'équation peut remplacer l'apprentissage pour ce réglage ; si non, on apprend ce que l'équation ne voit pas.

## 2. L'équation

Le pendule inversé linéaire : ẍ = ω² (x − p), avec ω = √(g / z₀), z₀ la hauteur du centre de masse, p le pied d'appui. Le **point de capture**
ξ = x + ẋ / ω : là où poser le pied pour s'arrêter. Pour corriger la vitesse d'un pas à l'autre (pas de durée Tₛ), le pied posé à u devant le
centre de masse donne, au premier ordre, ∂u/∂v = coth(ω Tₛ) / ω (en mètres par m/s).

Dans la commande de N3, la hanche de la jambe en l'air reçoit kv × (v − v_visée) degrés ; le pied se déplace d'environ L × Δθ (L : de la
hanche à la semelle, Δθ en radians). **La valeur du pendule** : kv_pendule = − (180 / π) × coth(ω Tₛ) / (ω L) degrés par m/s. Le signe moins :
dans la convention de N3, plier la hanche (porter le pied devant) est négatif ; ce signe est vérifié dans le modèle avant tout (§ 4).

Les constantes sont mesurées dans le simulateur, pas apprises : z₀ (la hauteur moyenne du centre de masse en marchant), L (de l'axe de la
hanche à la semelle, debout sur ce pied). Tₛ (la moitié de la période du pas) est un réglage de la marche ; il n'entre que par coth(ω Tₛ),
qui varie de 1,05 à 1,30 pour Tₛ entre 0,5 et 0,25 s.

## 3. Les prédictions, écrites avant de lire les gains appris (avec ma crédence)

Les marches comparées : la meilleure de R-107 (B-g1), la marche pré-entraînée de R-111, et la marche de R0-g1 (R-111, sans variance) ;
celles des autres régimes de R-111 s'ajoutent quand elles finissent.

- **H142 — le signe** : dans les trois marches, kv a le signe du pendule (le pied posé plus loin devant quand le corps va trop vite).
  Crédence 0,70.
- **H143 — la grandeur** : pour au moins deux des trois, |kv| appris est à ±30 % de |kv_pendule|. Crédence 0,30.
- **H144 — l'équation à la place de l'apprentissage** : dans la marche pré-entraînée, kv et ky remplacés par les valeurs du pendule (ky :
  la même grandeur, le signe du pendule vu de côté, vérifié dans le modèle), le reste inchangé : elle passe encore le juge au nominal
  (au moins 9 sur 10), et garde au moins 80 % de sa réussite sous poussées. Crédence 0,45.
- **H145 — le placement compte** : sans placement (kv = ky = 0), la réussite sous poussées baisse d'au moins 20 points par rapport à la
  marche apprise. Crédence 0,55.

**Les poussées** : 50 conditions tirées une fois (graine 112) : tout au nominal sauf les poussées (plage large de R-111 : 2 poussées de 0,1 s
jusqu'à 60 N, direction et instant au hasard) et la vitesse visée (plage étroite). Le juge : celui de R-111, inchangé (pas de chute, au moins
0,6 m en 10 s, couloir de 0,5 m, pas plus de 0,1 s en vol).

## 4. Le protocole

1. Vérifier le signe dans le modèle : la hanche de tangage à −10° puis +10°, où va le pied (devant ou derrière) ; la hanche de roulis, où va le
   pied (dehors ou dedans) ; aucune marche, de la cinématique.
2. Mesurer z₀ et L dans la marche pré-entraînée, au nominal (de 2 à 10 s).
3. Calculer kv_pendule (et ky_pendule) ; puis lire les gains appris des trois marches.
4. Jouer la marche pré-entraînée telle quelle, avec les gains du pendule, et sans placement : au nominal (les 10 conditions du jeu de R-111)
   et sous poussées (les 50).

**Une règle fixée avant** : si la vérification du § 4.1 montre que le même roulis de hanche envoie le pied gauche et le pied droit de
côtés opposés (la commande ajoute ky × v_y aux deux jambes avec le même signe), la commande ne peut pas exprimer le pendule de côté avec
un seul ky : alors la variante « pendule » de H144 garde le ky appris et ne remplace que kv, et on le dit.

## 5. Ce qui ne serait pas une preuve

Le pendule linéaire suppose un centre de masse à hauteur constante et un pied ponctuel ; N3 a des pieds, une hanche qui bouge, et la
commande ajoute le placement pendant tout le vol de la jambe, filtré. Un accord à ±30 % serait une ressemblance, pas une identité.

## 6. Résultats (12.11, de 09:50 à 10:03, simulé)

**Un défaut d'abord (E55).** Le premier passage a calculé le signe du pendule à l'envers (le signe de −dx au lieu de dx) : sa variante
« pendule » jouait presque le gain appris. Repéré parce que le résultat surprenait ; vérifié dans la cinématique et dans la dynamique
(`diag_signe_placement_n3.py` : N3 tenu en l'air, la vraie chaîne de commande ; la pose de tangage de hanche à −10° met le pied à +0,132 m,
à +10° à −0,092 m : **augmenter la pose recule le pied**). Passage archivé (`navitek-sim/archive-r112-signe-inverse-2026-11-12/`), script
corrigé (la vérification dynamique y est intégrée et arrête tout si elle contredit la cinématique), relancé. Les chiffres ci-dessous sont
ceux du passage corrigé (`essai_n3_pendule.py`, `resultats/n3-pendule.json`).

**Les constantes mesurées** (la marche pré-entraînée, au nominal, de 2 à 10 s) : z₀ = 0,762 m, ω = √(g / z₀) = 3,59 /s ; L = 0,650 m (axe de la
hanche, en appui simple, 61 mesures). Le roulis n'est pas en miroir (le même roulis porte les deux pieds vers +y).

| marche | kv appris (°/(m/s)) | kv du pendule | rapport | ky appris | période T | ω Tₛ |
|---|---|---|---|---|---|---|
| R-107 B-g1 | +31,7 | −24,7 | −1,29 | +1,2 | 1,75 s | 3,14 |
| pré-entraînement (R-111) | +24,7 | −24,8 | −1,00 | +9,5 | 1,53 s | 2,75 |
| R0-g1 (R-111, 2e passage) | +10,1 | −24,8 | −0,41 | −16,8 | 1,49 s | 2,68 |

| la marche pré-entraînée | nominal (10) | sous poussées (50) | chutes sous poussées |
|---|---|---|---|
| apprise (kv +24,7, ky +9,5) | 10 | 45 | 5 |
| **le gain du pendule** (kv −24,8, ky +24,8) | **0** | **0** | 14 (les autres reculent) |
| sans placement (kv = ky = 0) | 10 | 41 | 6 |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H142 | le signe du pendule dans les trois marches (0,70) | les trois sont positifs (+31,7, +24,7, +10,1) ; le pendule demande −24,8 | **réfutée** |
| H143 | \|kv\| à ±30 % du pendule pour au moins deux sur trois (0,30) | rapports en grandeur 1,29, 1,00, 0,41 : deux sur trois | **confirmée** (la grandeur seulement : le signe est opposé, voir H142 ; la ressemblance ne dit pas que la marche a trouvé le pendule) |
| H144 | avec le gain du pendule, au moins 9 sur 10 au nominal et 80 % de la réussite sous poussées (0,45) | 0 sur 10 ; 0 sur 50 ; il **recule** (−0,85 m dans le film) | **réfutée** |
| H145 | sans placement, au moins 20 points de moins sous poussées (0,55) | 45 → 41 sur 50 : 8 points | **réfutée** |

## 7. Ce que ça dit

1. **La marche de N3 n'est pas un pendule.** Ses pas durent 0,75 s ; un pendule inversé de 0,76 m diverge d'un facteur e^(ω Tₛ) ≈ 15 pendant
   un seul pas. N3 ne peut donc pas compter sur le pas suivant pour se rattraper, comme le suppose l'équation : il garde son centre de masse
   au-dessus du pied d'appui, et c'est le pied (la cheville, la semelle) qui tient l'équilibre. Le film le montre : le fil vert du centre de
   masse tombe entre les pieds, le point de capture (cyan) reste à côté.
2. **Sa vitesse vient de la longueur du pas.** Trop lent, il pose le pied plus loin devant (kv positif) : le pas s'allonge, il accélère. Le
   pendule fait l'inverse (un pied posé loin devant freine) ; sur N3, son signe donne une rétroaction positive : plus il ralentit, plus il
   raccourcit le pas, jusqu'à reculer. Le signe du gain est la signature du régime de marche.
3. **Contre les poussées, le placement compte peu (8 points).** Ce qui tient la marche est ailleurs : la cadence qui suit la vitesse (kt
   négatif dans les trois marches) et les pieds.
4. **Ce qu'il faut tester ensuite (R-113)** : mesurer si le centre de masse reste dans le polygone d'appui (marche quasi statique) et si le
   point de capture annonce la chute ; puis, plus tard, une marche rapide (dynamique), où le signe devrait basculer vers celui du pendule.

Films (sur le site) : la marche apprise, avec le gain du pendule, sans placement, dans la même condition de poussée (deux poussées jusqu'à
51 N) ; le corps à demi transparent, le centre de masse en vert et son fil jusqu'au sol, le point de capture en cyan.
