# R-114 — Une alarme qui apprend sa marche : sentir la chute venir, appris sur une moitié, jugé sur l'autre
mots-cles: Navitek, N3, chute, prédiction, alarme, point de capture, inclinaison, centrale inertielle, régression logistique, apprendre son corps, sentir le corps, MuJoCo

> Ouvert le 12.11.2026 à 10:29 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42). Suite de R-113 :
> une alarme à seuil fixe sonne partout, parce que la marche elle-même sort le point de capture des semelles. Prédictions écrites avant ;
> verdicts après. Tout est simulé.

## 1. La question

**Un robot peut-il apprendre à reconnaître, dans ce qu'il sent, la différence entre un pas et le début d'une chute ?** R-113 : le point de
capture sort des semelles 41 % du temps en marchant normalement ; une alarme fixe ne distingue rien. Ici, l'alarme apprend : elle combine
ce que le robot peut lire, sur des épisodes où il marche et où il tombe, puis elle est jugée sur des épisodes qu'elle n'a jamais vus.

## 2. Le dispositif

- **La marche** : la marche pré-entraînée de R-111. **Les épisodes** (tirés une fois, graines 3001 à 3004) : 100 sous variance étroite,
  100 sous variance large, 100 sous poussées (les autres axes au nominal), 30 nominaux. **Une moitié pour apprendre** (les épisodes de rang
  pair), **l'autre pour juger** (rang impair) ; fixé avant.
- **Ce que l'alarme lit, toutes les 0,04 s** (ce qu'un vrai robot peut estimer) : l'inclinaison du torse vers l'avant et de côté, et leurs
  vitesses (une centrale inertielle) ; la distance signée du point de capture et du centre de masse au polygone des semelles (R-113) ; le
  nombre de pieds qui touchent. Ici les valeurs sont exactes ; un vrai robot les aura bruitées.
- **Trois alarmes**, chacune réglée sur la moitié d'apprentissage pour **au plus 10 % de fausses alarmes** (épisodes debout où elle sonne) :
  (a) l'inclinaison seule (un seuil sur l'inclinaison totale) ; (b) le point de capture seul (un seuil sur sa distance aux semelles) ;
  (c) **apprise** : une régression logistique sur les sept mesures, entraînée à reconnaître les lectures qui précèdent une chute de moins d'une
  seconde, puis un seuil sur sa probabilité. Une alarme sonne quand son signal dépasse le seuil 3 lectures de suite (0,12 s).
- **Le jugement**, sur la moitié jamais vue : la part des chutes annoncées **au moins 0,3 s avant** ; la part des épisodes debout où elle a
  sonné (fausses alarmes) ; l'avance médiane.

## 3. Les prédictions (avec ma crédence)

- **H156 — l'alarme apprise sent la chute** : sur la moitié jamais vue, elle annonce au moins 70 % des chutes au moins 0,3 s avant, avec au
  plus 20 % de fausses alarmes. Crédence 0,45.
- **H157 — mieux que l'inclinaison seule** : elle annonce plus de chutes (au moins 0,3 s avant) que l'alarme d'inclinaison. Crédence 0,60.
- **H158 — mieux que le point de capture seul** : elle annonce plus de chutes (au moins 0,3 s avant) que l'alarme du point de capture.
  Crédence 0,65.
- **H159 — assez tôt pour agir** : l'avance médiane de l'alarme apprise, sur les chutes annoncées, est d'au moins 0,5 s (un pas de N3 dure
  0,75 s). Crédence 0,40.

## 4. Ce qui ne serait pas une preuve

Des mesures exactes (le simulateur) ; une seule marche ; des chutes provoquées par la variance de R-111. Une alarme n'est pas un rattrapage :
savoir qu'on tombe ne dit pas encore quoi faire (l'essai suivant).

## 5. Résultats (12.11, de 10:30 à 10:38, simulé ; `essai_n3_alarme.py`, `resultats/n3-alarme.json`)

330 épisodes : apprendre sur 165 (81 chutes), juger sur 165 jamais vus (82 chutes, 83 debout). Chaque seuil réglé sur la moitié
d'apprentissage pour au plus 10 % de fausses alarmes.

| alarme (jugée sur la moitié jamais vue) | seuil | chutes annoncées au moins 0,3 s avant | fausses alarmes | avance médiane |
|---|---|---|---|---|
| l'inclinaison seule | 9,8° | 72 sur 82 (88 %) | 12 % | 0,94 s |
| le point de capture seul | 13,6 cm hors des semelles | 70 sur 82 (85 %) | 12 % | 0,62 s |
| **apprise** (sept mesures) | probabilité 0,62 | **72 sur 82 (88 %)** | **10 %** | **0,97 s** |

**Les poids de l'alarme apprise** (mesures centrées réduites) : ξ hors des semelles +3,65 ; inclinaison de côté +3,28 ; centre de masse hors
des semelles −3,09 ; vitesse d'inclinaison de côté +1,34 ; inclinaison avant +0,93 ; vitesse avant +0,39 ; pieds qui touchent −0,43. Les deux
premiers et le troisième, ensemble, disent : **ξ dehors alors que le centre de masse est encore dedans**, c'est-à-dire une vitesse qui emmène
le corps hors de ses pieds ; et **de côté**.

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H156 | l'alarme apprise annonce au moins 70 % des chutes 0,3 s avant, avec au plus 20 % de fausses alarmes (0,45) | 88 %, 10 % | **confirmée** |
| H157 | elle annonce plus de chutes que l'inclinaison seule (0,60) | 72 contre 72 (moins de fausses alarmes : 10 % contre 12 %) | **réfutée** |
| H158 | elle annonce plus de chutes que le point de capture seul (0,65) | 72 contre 70 (de peu) | **confirmée** |
| H159 | avance médiane d'au moins 0,5 s (0,40) | 0,97 s | **confirmée** |

## 6. Ce que ça dit

1. **N3 peut sentir sa chute venir environ une seconde à l'avance** (88 % des chutes, 10 % de fausses alarmes) : plus qu'un pas (0,75 s).
   Assez pour agir.
2. **Un simple seuil d'inclinaison (environ 10°) fait presque aussi bien.** Les chutes de cette marche presque statique sont lentes : le corps
   penche longtemps avant de tomber. L'alarme apprise n'annonce pas plus de chutes ; elle sonne un peu moins souvent à tort (10 % contre 12 %).
3. **Ses chutes partent de côté** : l'alarme apprise pèse surtout l'inclinaison de côté et la vitesse qui sort des pieds. C'est là qu'il
   faudra agir.
4. **Ensuite (R-115) : le réflexe.** Quand l'alarme sonne, faire quelque chose : un pas de côté vers le point de capture, plier les genoux
   pour baisser le centre de masse, ou écarter les bras ; et compter les chutes évitées.

Film (sur le site) : une chute jamais vue de la moitié de jugement (variance large, condition 19) ; la lampe au-dessus de la tête, verte,
devient rouge quand l'alarme apprise sonne, 0,97 s avant la chute.
