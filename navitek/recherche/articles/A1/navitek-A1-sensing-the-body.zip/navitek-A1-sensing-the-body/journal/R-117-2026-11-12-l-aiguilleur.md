# R-117 — L'aiguilleur : le robot reconnaît-il, à ce qu'il sent, la condition où il marche ?
mots-cles: Navitek, N3, mélange d'experts, aiguilleur, reconnaissance, proprioception, centrale inertielle, appuis, pente, délai, sol mou, vent, sentir le corps, MuJoCo

> Ouvert le 12.11.2026 à 11:31 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42). Deuxième moitié d'un
> mélange d'experts (l'idée de Yoan) ; la première, les experts, tourne dans R-116. Prédictions écrites avant ; verdicts après. Tout est
> simulé.

## 1. La question

Un mélange d'experts a besoin d'un **aiguilleur** : quelque chose qui reconnaît la situation et choisit l'expert. **En marchant deux
secondes, N3 sent-il s'il est sur une pente, sur un sol mou, dans le vent, ou si ses commandes ou ses capteurs sont en retard ?** C'est
« sentir le corps » au sens propre : le corps dit dans quel monde il est.

## 2. Le dispositif

- **Six conditions** : le nominal, et les cinq de R-116 (la pente, le retard des capteurs, le délai de commande, le sol mou, le vent), chacune
  avec son axe tiré dans sa plage large, le reste au nominal, la vitesse visée dans l'étroite. **40 épisodes par condition** (graines 4201 à
  4206), la marche pré-entraînée de R-111 ; chaque épisode s'arrête à 2 s.
- **Ce que le robot sent, de 0,2 à 2 s, toutes les 0,04 s** (ce qu'une centrale inertielle et des capteurs de contact donnent) : l'inclinaison
  avant et de côté, et leurs vitesses (moyenne et écart-type de chacune) ; la vitesse du corps vers l'avant et de côté (moyenne, écart-type) ;
  la part du temps sur deux pieds ; le nombre de changements d'appui. 14 nombres par épisode.
- **L'aiguilleur** : une forêt d'arbres de décision (scikit-learn, 200 arbres, graine 117), apprise sur la moitié des épisodes (rang pair dans
  chaque condition), jugée sur l'autre moitié (rang impair).

## 3. Les prédictions (avec ma crédence)

- **H168 — il reconnaît** : au moins 70 % de bonnes réponses sur les épisodes jamais vus (le hasard : 17 %). Crédence 0,45.
- **H169 — la pente se sent le mieux** : c'est la condition la mieux reconnue (rappel le plus haut, ex æquo compris). Crédence 0,45.
- **H170 — le retard des capteurs se sent le moins** : c'est la condition la moins bien reconnue. Crédence 0,35.

## 4. Ce qui ne serait pas une preuve

Des mesures exactes (un vrai robot les aura bruitées) ; une condition à la fois, choisie parmi six connues ; deux secondes de marche.

## 5. Résultats (12.11, fini à 11:33, heure du fichier ; simulé ; `essai_n3_aiguilleur.py`, `resultats/n3-aiguilleur.json`)

240 épisodes de 2 s ; l'aiguilleur appris sur 120, jugé sur les 120 autres.

**Exactitude : 92,5 % (111 sur 120)** ; le hasard : 17 %.

| vraie condition → devinée | nominal | pente | retard des capteurs | délai de commande | sol mou | vent | rappel |
|---|---|---|---|---|---|---|---|
| nominal | **20** | 0 | 0 | 0 | 0 | 0 | 100 % |
| pente | 0 | **17** | 0 | 0 | 2 | 1 | 85 % |
| retard des capteurs | 0 | 0 | **19** | 1 | 0 | 0 | 95 % |
| délai de commande | 0 | 0 | 1 | **19** | 0 | 0 | 95 % |
| sol mou | 0 | 1 | 0 | 0 | **19** | 0 | 95 % |
| vent | 0 | 2 | 0 | 0 | 1 | **17** | 85 % |

**Ce qui pèse le plus** (importance dans la forêt) : l'écart-type de la vitesse de roulis (0,13), l'écart-type de la vitesse d'inclinaison
avant (0,11), l'écart-type de l'inclinaison avant (0,10), la vitesse moyenne vers l'avant (0,10), l'inclinaison avant moyenne (0,08), le
nombre de changements d'appui (0,07).

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H168 | au moins 70 % de bonnes réponses (0,45) | 92,5 % | **confirmée** |
| H169 | la pente, la mieux reconnue (0,45) | 85 % : ex æquo la moins bien reconnue, avec le vent | **réfutée** |
| H170 | le retard des capteurs, le moins bien reconnu (0,35) | 95 % : parmi les mieux reconnus | **réfutée** |

## 6. Ce que ça dit

1. **En deux secondes de marche, le corps dit dans quel monde il est** : 92,5 % de bonnes réponses, à partir de ce qu'une centrale inertielle
   et des capteurs de contact donnent. L'aiguilleur d'un mélange d'experts est à portée.
2. **Ce que le robot sent, c'est son tremblement** : les écarts-types des vitesses de roulis et d'inclinaison pèsent le plus. Un retard
   (des capteurs ou des commandes) fait osciller la boucle : il se sent très bien, contre ma prédiction.
3. **Ce qui se confond** : la pente, le vent et le sol mou, trois façons de pousser le corps de côté ou de le faire pencher d'une manière
   constante.
4. **Avec R-116** : si les experts battent le généraliste, l'aiguilleur peut les choisir ; un vrai mélange d'experts (aiguilleur appris +
   experts) sera l'essai suivant.
