# R-113 — Sentir la chute venir : le centre de gravité, le polygone d'appui et le point de capture
mots-cles: Navitek, N3, centre de gravité, centre de masse, polygone d'appui, point de capture, marche quasi statique, chute, prédiction, sentir le corps, MuJoCo

> Ouvert le 12.11.2026 à 10:17 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42 : « apprendre à sentir
> le corps avec le feedback visuel de la simulation, centre de gravité, équations de mouvement des humanoïdes »). Suite directe de R-112.
> Prédictions écrites avant ; verdicts après. Tout est simulé.

## 1. La question

R-112 a montré que la marche de N3 n'est pas un pendule : ses pas durent 0,75 s, et un pendule de 0,76 m diverge quinze fois pendant un seul
pas. **N3 garde-t-il donc son centre de masse au-dessus de ses pieds (une marche quasi statique) ?** Et si oui, **le point de capture
(ξ = x + ẋ / ω, là où il faudrait poser le pied pour s'arrêter) sort-il des pieds avant une chute, assez tôt pour la sentir venir ?** Un robot
qui lit son centre de masse et sa vitesse (une centrale inertielle, les angles des articulations, un modèle de son corps) pourrait sentir la
chute avant qu'elle arrive.

## 2. Les mesures

- **Le polygone d'appui** : l'enveloppe convexe des points de contact entre les pieds et le sol (au sol, en x et y), lue toutes les 0,04 s.
- **La distance au polygone** : négative dedans, positive dehors (en mètres) ; pour le centre de masse projeté au sol et pour ξ.
- **L'alarme** : ξ (ou le centre de masse) hors du polygone de plus de 3 cm pendant au moins 0,1 s ; son instant est le début de cette sortie.
- **La chute** : celle du juge de R-111 (torse incliné de plus de 40° ou centre de masse sous 60 % de sa hauteur). **L'avance de l'alarme** :
  l'instant de la chute moins celui de la première alarme.
- **La marche** : la marche pré-entraînée de R-111. **Les conditions** : les 10 conditions nominales du jeu de R-111 ; les 50 conditions de
  poussées de R-112 (graine 112) ; les 50 conditions étroites du diagnostic de R-111 (graine 2001), où elle tombait 23 fois.

## 3. Les prédictions (avec ma crédence)

- **H146 — quasi statique** : au nominal, de 2 à 10 s, le centre de masse projeté est dans le polygone d'appui au moins 80 % du temps.
  Crédence 0,60.
- **H147 — le point de capture aussi** : au nominal, ξ est dans le polygone au moins 70 % du temps. Crédence 0,55.
- **H148 — il annonce la chute** : parmi les épisodes qui tombent (poussées et étroites), dans au moins 80 % l'alarme de ξ sonne au moins
  0,3 s avant la chute. Crédence 0,50.
- **H149 — sans fausse alarme** : parmi les épisodes qui ne tombent pas, l'alarme de ξ sonne dans au plus 30 %. Crédence 0,40.
- **H150 — la vitesse compte** : l'alarme de ξ sonne plus tôt que celle du centre de masse seul (avance médiane plus grande, sur les
  chutes où les deux sonnent). Crédence 0,75.

## 3 bis. La deuxième mesure, prédite avant (commise à 10:22), après la première lecture

Première lecture (10:20, `n3-capture.json`) : au nominal, les pieds ne touchent le sol que par **2 points** dans 67 % des lectures (une
arête : le pied, un maillage rigide, est sur sa tranche), 1 point dans 12 %, 3 points ou plus dans 20 %. Le polygone des contacts est alors
un segment, et le centre de masse est forcément dehors : l'alarme sonne partout. Les verdicts de H146 à H150 sont écrits tels que mesurés
(§ 5). Pour la question posée (le corps au-dessus de ses pieds), une deuxième mesure : **le polygone des semelles** : pour chaque pied qui
touche, les sommets de son maillage à moins de 1 cm du plus bas (la semelle, comme une semelle souple qui s'écrase), projetés au sol ;
l'enveloppe convexe de tous. Le reste ne change pas (la marge de 3 cm, 3 lectures de suite, les mêmes 110 épisodes).

- **H151** (comme H146) : au nominal, le centre de masse est dans le polygone des semelles au moins 80 % du temps. Crédence 0,60.
- **H152** (comme H147) : ξ y est au moins 70 % du temps. Crédence 0,50.
- **H153** (comme H148) : l'alarme de ξ annonce au moins 80 % des chutes, 0,3 s ou plus avant. Crédence 0,50.
- **H154** (comme H149) : fausses alarmes dans au plus 30 % des épisodes qui ne tombent pas. Crédence 0,40.
- **H155** (comme H150) : l'alarme de ξ sonne plus tôt que celle du centre de masse (avance médiane). Crédence 0,75.

## 4. Ce qui ne serait pas une preuve

Le simulateur donne le centre de masse et la vitesse exacts ; un vrai robot devra les estimer (modèle des masses, centrale inertielle bruitée,
angles des servos) : R-111 a mesuré combien ces erreurs pèsent sur la marche, pas sur l'alarme. Une marche, un robot.

## 5. Résultats (12.11, 10:20 et 10:25, simulé ; `essai_n3_capture.py`, `resultats/n3-capture.json`)

La marche pré-entraînée de R-111 ; 110 épisodes : 10 nominaux, 50 sous poussées, 50 sous variance étroite. 28 chutes (5 sous poussées, 23 sous
variance étroite), 72 épisodes debout hors nominal. Aucun instant sans appui au nominal.

**Ce que touchent les pieds.** Au nominal, les pieds touchent le sol par 2 points dans 67 % des lectures (une arête), 1 point dans 12 %, 3 points
ou plus dans 20 %. Les pieds sont des maillages rigides : un pied à peine incliné ne porte que sur sa tranche.

| | mesure | prédit (crédence) | mesuré | verdict |
|---|---|---|---|---|
| H146 | contacts | centre de masse dans le polygone au moins 80 % du temps (0,60) | 14,6 % | **réfutée** (le polygone est surtout une arête) |
| H147 | contacts | ξ dans le polygone au moins 70 % (0,55) | 1,4 % | **réfutée** |
| H148 | contacts | l'alarme annonce au moins 80 % des chutes, 0,3 s avant (0,50) | 100 %, mais avec 2,4 à 8,4 s d'avance : l'alarme sonne dès le début | **à revoir** (vraie à la lettre ; voir H149) |
| H149 | contacts | fausses alarmes dans au plus 30 % (0,40) | 100 % | **réfutée** |
| H150 | contacts | ξ sonne plus tôt que le centre de masse (0,75) | avances médianes 5,68 et 5,66 s | **à revoir** (les deux sonnent au début : l'écart ne veut rien dire) |
| H151 | semelles | centre de masse dans le polygone au moins 80 % du temps (0,60) | **91 %** | **confirmée** |
| H152 | semelles | ξ dans le polygone au moins 70 % (0,50) | 58,5 % | **réfutée** |
| H153 | semelles | l'alarme annonce au moins 80 % des chutes, 0,3 s avant (0,50) | 100 %, avec 2,1 à 8,4 s d'avance | **à revoir** (voir H154) |
| H154 | semelles | fausses alarmes dans au plus 30 % (0,40) | 100 % | **réfutée** |
| H155 | semelles | ξ sonne plus tôt que le centre de masse (0,75) | avances médianes 5,38 et 5,36 s | **à revoir** |

## 6. Ce que ça dit

1. **N3 marche au-dessus de ses pieds** : son centre de masse reste au-dessus des semelles 91 % du temps (H151). C'est une marche presque
   statique, comme R-112 le laissait voir (des pas lents, le pendule qui ne s'applique pas).
2. **Ses pieds rigides portent surtout sur une arête** (2 points de contact dans 67 % des lectures). Pour le vrai N3, c'est un argument pour
   une **semelle souple** (caoutchouc) : elle écrase l'arête en surface, et l'appui redevient une semelle.
3. **Le point de capture sort des semelles 41 % du temps en marchant normalement** : à chaque transfert de poids, il passe d'un pied à l'autre
   par l'extérieur. Une alarme à seuil fixe (3 cm, 0,12 s) ne distingue pas un pas d'une chute : elle sonne partout (H149, H154). **Pour sentir
   la chute venir, le robot doit connaître sa propre marche.**
4. **Ensuite (R-114)** : une alarme qui apprend sa marche : quelques mesures que le robot peut lire (où est ξ par rapport aux semelles,
   l'inclinaison du torse et sa vitesse, le pied qui porte), un seuil appris sur une moitié des épisodes, jugé sur l'autre moitié.

Films (sur le site) : la chute annoncée (variance étroite, condition 21) : le polygone des semelles en blanc, le centre de masse en vert,
le point de capture en cyan, rouge quand l'alarme sonne. La première mesure (contacts seuls) est gardée telle qu'elle a tourné
(`resultats/n3-capture-contacts-seuls.json`).
