# Sensing the body in a simulated humanoid — open package

Yoan Maisonneuve, Navitek Robolabs, 2026. All results are from simulation (MuJoCo).

- `journal/` : the laboratory notebooks (French): hypotheses and credences written before each run, results and verdicts after.
- `navitek-sim/` : the N3 model (`n3.xml`, meshes in `n1-v1-gele/`), the scripts, and the raw results (`resultats/`).
- `historique-git.txt` : dated commits, to check that predictions came before results.
- `journal/ERREURS-extrait.md` : the mistakes we caught, and what we changed.

## Run

Python 3.12+ with: `pip install mujoco numpy cmaes scipy scikit-learn imageio imageio-ffmpeg`. Then, in `navitek-sim/`:

```
python -X utf8 essai_n3_pendule.py        # R-112 (then filmer_n3_pendule.py for the films)
python -X utf8 essai_n3_capture.py        # R-113
python -X utf8 essai_n3_alarme.py         # R-114
python -X utf8 essai_n3_reflexe.py        # R-115 (needs resultats/n3-alarme.json)
python -X utf8 essai_n3_aiguilleur.py     # R-117
```

## Licences

Code: MIT (`LICENSE`). Texts, notebooks, figures, data: CC BY 4.0 (`LICENCE-TEXTES-DONNEES.txt`).

Use of AI: the experiments, code and texts were produced with the assistance of Claude (Anthropic) under the author's direction.

---

Paquet ouvert : cahiers (en français), modèle, scripts, résultats bruts, historique daté, licences libres. Tout est simulé.
