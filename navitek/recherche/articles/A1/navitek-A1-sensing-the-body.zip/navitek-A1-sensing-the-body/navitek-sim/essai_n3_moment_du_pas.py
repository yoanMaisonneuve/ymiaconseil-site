"""R-107 — la marche qui change aussi le moment du pas : la phase du rythme avance quand le corps va trop vite. Simulé.

    python -X utf8 essai_n3_moment_du_pas.py jeu          # A (placement seul) et B (placement + moment), 2 graines, puis cartes à 8 moments
    python -X utf8 essai_n3_moment_du_pas.py video --cle B
Sortie : resultats/n3-moment-du-pas.json (et .mp4)."""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C
import essai_n3_marche as W
import essai_n3_genoux as G
import essai_n3_placement as P

RES = os.path.join(C.ICI, "resultats")
DT, CIBLE, DUREE, V_VISEE = 0.01, 5.0, 10.0, 0.3
FRACTIONS = [0.06, 0.18, 0.31, 0.43, 0.56, 0.68, 0.81, 0.93]
BAS_T, HAUT_T = -6.0, 6.0                                  # le gain du moment : rad/s de phase en plus par m/s d'écart de vitesse


def init():
    G.init()


def marcher(p, pl, kt, pousse=None, video=None):
    m, d = W._m, W._d
    kv, ky, a_f = pl
    T = float(p[0])
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    n_pose = int(round(DT / m.opt.timestep))
    c, chute, prec, v, phi, x0 = np.zeros(m.nu), None, d.subtree_com[1][:2].copy(), np.zeros(2), 0.0, None
    for k in range(int(DUREE / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            cm = d.subtree_com[1][:2].copy()
            v = (1 - a_f) * v + a_f * (cm - prec) / DT
            prec = cm
            w0 = 2 * np.pi / T
            w = w0 if t < 1.5 else float(np.clip(w0 + kt * (v[0] - V_VISEE), 0.6 * w0, 1.6 * w0))   # le moment du pas
            phi += w * DT
            t_eff = phi / w0                                   # le rythme lit un temps qui avance plus ou moins vite
            a, r, va, vr = W.attitude(d)
            pose = W.pose_marche(p, max(t_eff, 0.0) if t >= 1.5 else t, (a - CIBLE, r, va, vr))
            if t > 1.5:
                for cote, nom in (("g", "gauche"), ("d", "droite")):
                    autre = "droite" if nom == "gauche" else "gauche"
                    if not G.touche(d, nom) and G.touche(d, autre):
                        pose["hanche_tangage_" + cote] += kv * (v[0] - V_VISEE)
                        pose["hanche_roulis_" + cote] += ky * v[1]
            if x0 is None and t >= 2.0:
                x0 = float(cm[0])
            c = C.consigne(m, pose, W._sg)
        if pousse is not None:
            dn, tp, f = pousse
            ang = P.DIRECTIONS[dn]
            d.xfrc_applied[1, :3] = [f * np.cos(ang), f * np.sin(ang), 0.0] if tp <= t < tp + 0.1 else [0.0, 0.0, 0.0]
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0 and C.inclinaison(d) > 40:
            chute = t
            break
        if video is not None and k % int(0.04 / m.opt.timestep) == 0:
            video(d, t)
    d.xfrc_applied[:] = 0
    vit = (float(d.subtree_com[1][0]) - x0) / (DUREE - 2.0) if (x0 is not None and chute is None) else 0.0
    return {"tombe": chute is not None, "chute_s": chute, "vitesse_m_s": round(vit, 3)}


def decoder(u, cond):
    p = W.BAS + np.clip(u[:15], 0, 1) * (W.HAUT - W.BAS)
    pl = tuple(P.BAS_PL + np.clip(u[15:18], 0, 1) * (P.HAUT_PL - P.BAS_PL))
    kt = 0.0 if cond == "A" else float(BAS_T + np.clip(u[18], 0, 1) * (HAUT_T - BAS_T))
    return p, pl, kt


def evaluer(args):
    u, cond = args
    p, pl, kt = decoder(u, cond)
    libre = marcher(p, pl, kt)
    score = -5.0 if libre["tombe"] else -20.0 * max(0.0, 0.25 - libre["vitesse_m_s"]) - 4.0 * abs(libre["vitesse_m_s"] - V_VISEE)
    for pousse in P.ENTRAINEMENT:
        score += 0 if marcher(p, pl, kt, pousse)["tombe"] else 1
    return -score


def seuil(args):
    p, pl, kt, dn, tp, cle = args
    bas, haut = 0.0, 600.0
    for _ in range(7):
        mil = 0.5 * (bas + haut)
        if marcher(np.array(p), tuple(pl), kt, (dn, tp, mil))["tombe"]:
            haut = mil
        else:
            bas = mil
    return cle, dn, tp, bas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["jeu", "video"])
    ap.add_argument("--cle", default="B")
    a = ap.parse_args()
    init()
    f_res = os.path.join(RES, "n3-moment-du-pas.json")
    if a.mode == "jeu":
        from cmaes import CMA
        r93 = json.load(open(os.path.join(RES, "n3-placement-vitesse.json"), encoding="utf-8"))
        j = r93["jeux"][r93["meilleurs"]["B"]]
        u0 = np.concatenate([(np.array(j["parametres_liste"]) - W.BAS) / (W.HAUT - W.BAS), (np.array(j["placement"]) - P.BAS_PL) / (P.HAUT_PL - P.BAS_PL),
                             [(0.0 - BAS_T) / (HAUT_T - BAS_T)]])
        res = {"vitesse_visee_m_s": V_VISEE, "depart": "R-093, marche B (" + r93["meilleurs"]["B"] + ")", "jeux": {}}
        with mp.Pool(14, initializer=init) as pool:
            for cond in ("A", "B"):
                n = 18 if cond == "A" else 19
                for graine in (1, 2):
                    cma = CMA(mean=np.clip(u0[:n], 0.02, 0.98), sigma=0.15, population_size=14, seed=1070 + graine, bounds=np.array([[0, 1]] * n))
                    best, histo = (1e9, None), []
                    for g in range(40):
                        xs = [cma.ask() for _ in range(14)]
                        vals = pool.map(evaluer, [(np.concatenate([x, [0.5]])[:19], cond) for x in xs])
                        cma.tell(list(zip(xs, vals)))
                        i = int(np.argmin(vals))
                        if vals[i] < best[0]:
                            best = (vals[i], np.concatenate([xs[i], [0.5]])[:19])
                        histo.append(round(-best[0], 2))
                        print("%s g%d, génération %2d : meilleur %.2f" % (cond, graine, g + 1, -best[0]), flush=True)
                    p, pl, kt = decoder(best[1], cond)
                    r = marcher(p, pl, kt)
                    r.update(score=round(-best[0], 3), parametres_liste=[float(x) for x in p], placement=[float(x) for x in pl], gain_moment=round(kt, 3),
                             meilleur_par_generation=histo)
                    res["jeux"]["%s-g%d" % (cond, graine)] = r
                    print(cond, graine, json.dumps({k: v for k, v in r.items() if k not in ("parametres_liste", "meilleur_par_generation")}, ensure_ascii=False), flush=True)
                    json.dump(res, open(f_res, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            meilleurs = {cond: max([k for k in res["jeux"] if k.startswith(cond)], key=lambda k: res["jeux"][k]["score"]) for cond in ("A", "B")}
            res["meilleurs"] = meilleurs
            taches = []
            for cond, k in meilleurs.items():
                jj = res["jeux"][k]
                for dn in P.DIRECTIONS:
                    for fr in FRACTIONS:
                        taches.append((jj["parametres_liste"], jj["placement"], jj["gain_moment"], dn, 5.0 + fr * jj["parametres_liste"][0], cond))
            cartes = {}
            for cond, dn, tp, fN in pool.map(seuil, taches):
                cartes.setdefault(cond, {}).setdefault(dn, []).append([round(tp, 3), round(fN, 1)])
        M = float(np.sum(W._m.body_mass))
        res["cartes_N"] = cartes
        res["somme_dv_m_s"] = {c_: round(sum(f for dn in cartes[c_] for _, f in cartes[c_][dn]) * 0.1 / M, 3) for c_ in cartes}
        res["avant_min_N"] = {c_: min(f for _, f in cartes[c_]["avant"]) for c_ in cartes}
        print(json.dumps({k: res[k] for k in ("meilleurs", "somme_dv_m_s", "avant_min_N")}, ensure_ascii=False), flush=True)
        json.dump(res, open(f_res, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("fini", flush=True)
    else:
        import imageio.v2 as iio
        res = json.load(open(f_res, encoding="utf-8"))
        jj = res["jeux"][res["meilleurs"][a.cle]]
        rend, cam, im = mujoco.Renderer(W._m, 480, 640), mujoco.MjvCamera(), []

        def v(dd, t):
            cam.distance, cam.azimuth, cam.elevation = 3.6, 90, -8
            cam.lookat[:] = [dd.subtree_com[1][0], dd.subtree_com[1][1], 0.8]
            rend.update_scene(dd, camera=cam)
            im.append(rend.render().copy())
        r = marcher(np.array(jj["parametres_liste"]), tuple(jj["placement"]), jj["gain_moment"], video=v)
        iio.mimsave(os.path.join(RES, "n3-moment-du-pas-%s.mp4" % a.cle), im, fps=25, macro_block_size=1)
        print("film :", r, flush=True)


if __name__ == "__main__":
    main()
