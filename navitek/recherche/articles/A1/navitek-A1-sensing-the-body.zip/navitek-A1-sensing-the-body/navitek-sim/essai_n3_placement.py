"""R-091 — la marche qui place son pied sous le centre de gravité (Raibert), contre le même jeu sans placement. Simulé.

    python -X utf8 essai_n3_placement.py jeu                 # A (témoin) et B (placement), 2 graines chacun ; puis les cartes des poussées
    python -X utf8 essai_n3_placement.py video --cle B       # un film par processus
Sorties : resultats/n3-placement.json (et resultats/n3-placement-<cle>.mp4)."""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C
import essai_n3_marche as W
import essai_n3_genoux as G

RES = os.path.join(C.ICI, "resultats")
DT, CIBLE, DUREE, V_VISEE = 0.01, 5.0, 10.0, 0.3
P_MA = np.array(json.load(open(os.path.join(RES, "n3-marathon-g3.json"), encoding="utf-8"))["parametres_liste"])
DIRECTIONS = {"avant": 0.0, "gauche": np.pi / 2, "arriere": np.pi, "droite": -np.pi / 2}
# les 6 poussées du jeu : (direction, moment, force en N, pendant 0,1 s)
ENTRAINEMENT = [("avant", 4.0, 40.0), ("arriere", 4.6, 40.0), ("gauche", 5.3, 60.0), ("droite", 6.1, 60.0), ("avant", 6.9, 40.0), ("arriere", 7.6, 40.0)]
NOMS_PL = ["k_vitesse", "k_cote", "filtre"]
# R-093 : N3_VITESSE=exigee — la vitesse devient une exigence (sous 0,25 m/s, le score chute vite) ; chaque condition repart de son meilleur de R-091
EXIGEE = os.environ.get("N3_VITESSE") == "exigee"
SUFFIXE = "-vitesse" if EXIGEE else ""
BAS_PL, HAUT_PL = np.array([-40.0, -40.0, 0.05]), np.array([40.0, 40.0, 0.9])


def init():
    G.init()


def marcher(p, pl, pousse=None, video=None):
    """pl = (k_vitesse en ° par m/s, k_cote en ° par m/s, filtre) ; pousse = (direction, moment, force)."""
    m, d = W._m, W._d
    kv, ky, a_f = pl
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    x0 = None
    n_pose = int(round(DT / m.opt.timestep))
    c, chute, prec, v = np.zeros(m.nu), None, d.subtree_com[1][:2].copy(), np.zeros(2)
    for k in range(int(DUREE / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            a, r, va, vr = W.attitude(d)
            pose = W.pose_marche(p, t, (a - CIBLE, r, va, vr))
            cm = d.subtree_com[1][:2].copy()
            v = (1 - a_f) * v + a_f * (cm - prec) / DT
            prec = cm
            if t > 1.5:                                          # le placement : seulement la jambe en l'air
                for cote, nom in (("g", "gauche"), ("d", "droite")):
                    autre = "droite" if nom == "gauche" else "gauche"
                    if not G.touche(d, nom) and G.touche(d, autre):
                        pose["hanche_tangage_" + cote] += kv * (v[0] - V_VISEE)
                        pose["hanche_roulis_" + cote] += ky * v[1]
            if x0 is None and t >= 2.0:
                x0 = float(cm[0])
            c = C.consigne(m, pose, W._sg)
        if pousse is not None:
            dn, tp, f = pousse
            ang = DIRECTIONS[dn]
            d.xfrc_applied[1, :3] = [f * np.cos(ang), f * np.sin(ang), 0.0] if tp <= t < tp + 0.1 else [0.0, 0.0, 0.0]
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0 and C.inclinaison(d) > 40:
            chute = t
            break
        if video is not None and k % int(0.04 / m.opt.timestep) == 0:
            video(d, t)
    d.xfrc_applied[:] = 0
    vit = (float(d.subtree_com[1][0]) - x0) / (DUREE - 2.0) if (x0 is not None and chute is None) else 0.0
    return {"tombe": chute is not None, "chute_s": chute, "vitesse_m_s": round(vit, 3)}


def decoder(u, cond):
    p = W.BAS + np.clip(u[:15], 0, 1) * (W.HAUT - W.BAS)
    pl = (0.0, 0.0, 0.5) if cond == "A" else tuple(BAS_PL + np.clip(u[15:18], 0, 1) * (HAUT_PL - BAS_PL))
    return p, pl


def evaluer(args):
    u, cond = args
    p, pl = decoder(u, cond)
    libre = marcher(p, pl)
    if EXIGEE:
        score = -5.0 if libre["tombe"] else -20.0 * max(0.0, 0.25 - libre["vitesse_m_s"]) - 4.0 * abs(libre["vitesse_m_s"] - V_VISEE)
    else:
        score = -5.0 if libre["tombe"] else -8.0 * abs(libre["vitesse_m_s"] - V_VISEE)
    for pousse in ENTRAINEMENT:
        score += 0 if marcher(p, pl, pousse)["tombe"] else 1
    return -score


def seuil(args):
    p, pl, dn, tp, cle = args
    bas, haut = 0.0, 600.0
    for _ in range(7):
        mil = 0.5 * (bas + haut)
        if marcher(np.array(p), tuple(pl), (dn, tp, mil))["tombe"]:
            haut = mil
        else:
            bas = mil
    return cle, dn, tp, bas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["jeu", "video"])
    ap.add_argument("--cle", default="B")
    ap.add_argument("--generations", type=int, default=40)
    a = ap.parse_args()
    init()
    f_res = os.path.join(RES, "n3-placement%s.json" % SUFFIXE)
    if a.mode == "jeu":
        from cmaes import CMA
        u0 = np.concatenate([(P_MA - W.BAS) / (W.HAUT - W.BAS), [0.5, 0.5, 0.5]])
        res = {"vitesse_visee_m_s": V_VISEE, "entrainement": ENTRAINEMENT, "jeux": {}}
        with mp.Pool(14, initializer=init) as pool:
            for cond in ("A", "B"):
                n = 15 if cond == "A" else 18
                if EXIGEE:                                           # repartir du meilleur de R-091 pour cette condition
                    r91 = json.load(open(os.path.join(RES, "n3-placement.json"), encoding="utf-8"))
                    j91 = r91["jeux"][r91["meilleurs"][cond]]
                    u0 = np.concatenate([(np.array(j91["parametres_liste"]) - W.BAS) / (W.HAUT - W.BAS), (np.array(j91["placement"]) - BAS_PL) / (HAUT_PL - BAS_PL)])
                for graine in (1, 2):
                    cma = CMA(mean=np.clip(u0[:n], 0.02, 0.98), sigma=0.15, population_size=14, seed=910 + graine, bounds=np.array([[0, 1]] * n))
                    best, histo = (1e9, None), []
                    for g in range(a.generations):
                        xs = [cma.ask() for _ in range(14)]
                        vals = pool.map(evaluer, [(np.concatenate([x, [0.5, 0.5, 0.5]])[:18], cond) for x in xs])
                        cma.tell(list(zip(xs, vals)))
                        i = int(np.argmin(vals))
                        if vals[i] < best[0]:
                            best = (vals[i], np.concatenate([xs[i], [0.5, 0.5, 0.5]])[:18])
                        histo.append(round(-best[0], 2))
                        print("%s g%d, génération %2d : meilleur %.2f" % (cond, graine, g + 1, -best[0]), flush=True)
                    p, pl = decoder(best[1], cond)
                    r = marcher(p, pl)
                    r.update(score=round(-best[0], 3), parametres_liste=[float(x) for x in p], placement=[float(x) for x in pl],
                             placement_reglages=dict(zip(NOMS_PL, [round(float(x), 3) for x in pl])), meilleur_par_generation=histo)
                    res["jeux"]["%s-g%d" % (cond, graine)] = r
                    print(cond, graine, json.dumps({k: v for k, v in r.items() if k not in ("parametres_liste", "meilleur_par_generation")}, ensure_ascii=False), flush=True)
                    json.dump(res, open(f_res, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            meilleurs = {cond: max([k for k in res["jeux"] if k.startswith(cond)], key=lambda k: res["jeux"][k]["score"]) for cond in ("A", "B")}
            res["meilleurs"] = meilleurs
            T = float(P_MA[0])
            moments = [5.0 + 0.13 * T, 5.0 + 0.47 * T, 5.0 + 0.81 * T]
            taches = []
            for cond, k in meilleurs.items():
                pT = float(res["jeux"][k]["parametres_liste"][0])
                for dn in DIRECTIONS:
                    for fr in (0.13, 0.47, 0.81):
                        taches.append((res["jeux"][k]["parametres_liste"], res["jeux"][k]["placement"], dn, 5.0 + fr * pT, cond))
            cartes = {}
            for cond, dn, tp, fN in pool.map(seuil, taches):
                cartes.setdefault(cond, {}).setdefault(dn, []).append([round(tp, 3), round(fN, 1)])
        M = float(np.sum(W._m.body_mass))
        res["cartes_N"] = cartes
        res["somme_dv_m_s"] = {cond: round(sum(f for dn in cartes[cond] for _, f in cartes[cond][dn]) * 0.1 / M, 3) for cond in cartes}
        res["avant_min_N"] = {cond: min(f for _, f in cartes[cond]["avant"]) for cond in cartes}
        print(json.dumps({k: res[k] for k in ("meilleurs", "somme_dv_m_s", "avant_min_N")}, ensure_ascii=False), flush=True)
        json.dump(res, open(f_res, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    else:
        import imageio.v2 as iio
        res = json.load(open(f_res, encoding="utf-8"))
        k = res["meilleurs"][a.cle]
        p, pl = np.array(res["jeux"][k]["parametres_liste"]), tuple(res["jeux"][k]["placement"])
        # la même poussée vers l'avant pour les deux films : à mi-chemin entre les seuils de A et de B, au moment le plus faible de A
        tA = min(res["cartes_N"]["A"]["avant"], key=lambda x: x[1])
        fB = dict((round(t, 3), f) for t, f in res["cartes_N"]["B"]["avant"])
        tp = tA[0]
        force = 0.5 * (tA[1] + min(f for _, f in res["cartes_N"]["B"]["avant"]))
        rend, cam, im = mujoco.Renderer(W._m, 480, 640), mujoco.MjvCamera(), []

        def v(dd, t):
            cam.distance, cam.azimuth, cam.elevation = 3.6, 90, -8
            cam.lookat[:] = [dd.subtree_com[1][0], dd.subtree_com[1][1], 0.8]
            rend.update_scene(dd, camera=cam)
            im.append(rend.render().copy())
        r = marcher(p, pl, ("avant", tp, force), video=v)
        iio.mimsave(os.path.join(RES, "n3-placement%s-%s.mp4" % (SUFFIXE, a.cle)), im, fps=25, macro_block_size=1)
        print("film", k, "poussée avant", round(force, 1), "N à", tp, "s :", r, flush=True)


if __name__ == "__main__":
    main()
