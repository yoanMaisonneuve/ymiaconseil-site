# N1 version 1, gelée (09.11.2026)

Les 14 maillages, `assemblage.json` et `tranchage.json` de la CAO de N1 **version 1** (celle du 8 novembre), tirés de git (`a5b257f^`).

Pourquoi : la CAO de N1 est passée en version 2.2 le 9 novembre (le servo STS3215 n'a pas d'oreilles, R-047 ; les jambes se touchaient,
R-048). Les modèles de N2 et de N3 (`modele_n2.py`, `modele_n3.py`) sont « N1 agrandi » : ils ont été réglés et publiés sur la version 1
(R-040, R-042). Pour qu'ils restent reproductibles, ils lisent ce dossier, pas la CAO courante de N1.

Ne pas modifier. Si N2 ou N3 doivent passer sur la version 2.2, c'est une nouvelle étude, avec son cahier.
