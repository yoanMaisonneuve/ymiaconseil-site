"""Le banc de variance (R-111) : le catalogue des axes en code, le tirage des conditions (rejouable par graine), un épisode de marche de N3
dans une condition donnée, et le juge accordé par Yoan (12.11, 09:07). Simulé, MuJoCo sur processeur.

Une condition est un dictionnaire {"axes": {nom: valeur ou liste}, "graine": entier, "solveur": "normal" | "autre"} : avec elle, un épisode
se rejoue à l'identique (le bruit des capteurs, les poussées et les pertes de mesure sont tirés de sa graine)."""
import os
import sys

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.dirname(ICI)
if SIM not in sys.path:
    sys.path.insert(0, SIM)
import commun as C                # noqa: E402
import essai_n3_marche as W       # noqa: E402
import essai_n3_placement as P    # noqa: E402
import essai_n3_moment_du_pas as M  # noqa: E402

DUREE, DT, CIBLE = 10.0, 0.01, 5.0
# ---- le juge (accordé par Yoan le 12.11 à 09:07) -------------------------------------------------------------------------------------
JUGE = {"inclinaison_max_deg": 40.0, "hauteur_min": 0.60, "avance_min_m": 0.6, "derive_max_m": 0.5, "vol_max_s": 0.1}

# ---- le catalogue (banc_variance/CATALOGUE.md) ---------------------------------------------------------------------------------------
# type : "add" (la valeur s'ajoute au nominal), "log" (facteur tiré en log) ; par : "global", "corps" (une valeur par corps du robot),
# "corps3" (trois par corps), "articulation" (une par articulation), "segment" (cuisse, jambe du bas), "signe" (une valeur et un sens au hasard)
AXES = {
    # corps
    "masse":        dict(groupe="corps", type="add", nom=0.0, etroite=(-0.05, 0.05), large=(-0.2, 0.2), extreme=(-0.35, 0.35), borne=(-0.5, 1.0), par="corps"),
    "com":          dict(groupe="corps", type="add", nom=0.0, etroite=(-0.005, 0.005), large=(-0.02, 0.02), extreme=(-0.04, 0.04), borne=(-0.06, 0.06), par="corps3"),
    "longueurs":    dict(groupe="corps", type="add", nom=0.0, etroite=(-0.01, 0.01), large=(-0.05, 0.05), extreme=(-0.08, 0.08), borne=(-0.15, 0.15), par="segment"),
    "charge":       dict(groupe="corps", type="add", nom=0.0, etroite=(0.0, 0.05), large=(0.0, 0.2), extreme=(0.0, 0.35), borne=(0.0, 0.6), par="global"),
    "asymetrie":    dict(groupe="corps", type="add", nom=0.0, etroite=(0.0, 0.02), large=(0.0, 0.08), extreme=(0.0, 0.15), borne=(0.0, 0.3), par="signe"),
    # actionneurs
    "couple":       dict(groupe="actionneurs", type="add", nom=0.0, etroite=(-0.05, 0.05), large=(-0.2, 0.2), extreme=(-0.4, 0.4), borne=(-0.7, 1.0), par="global"),
    "gains":        dict(groupe="actionneurs", type="add", nom=0.0, etroite=(-0.08, 0.08), large=(-0.25, 0.25), extreme=(-0.5, 0.5), borne=(-0.7, 1.0), par="global"),
    "amortissement": dict(groupe="actionneurs", type="log", nom=1.0, etroite=(0.8, 1.25), large=(0.5, 2.0), extreme=(0.25, 4.0), borne=(0.1, 10.0), par="global"),
    "frottement_art": dict(groupe="actionneurs", type="add", nom=0.0, etroite=(0.0, 0.1), large=(0.0, 0.5), extreme=(0.0, 1.0), borne=(0.0, 3.0), par="global"),
    "baisse_pile":  dict(groupe="actionneurs", type="add", nom=0.0, etroite=(0.0, 0.03), large=(0.0, 0.15), extreme=(0.0, 0.3), borne=(0.0, 0.6), par="global"),
    "resolution":   dict(groupe="actionneurs", type="add", nom=0.0, etroite=(0.0, 0.1), large=(0.0, 0.5), extreme=(0.0, 1.0), borne=(0.0, 3.0), par="global"),
    "delai":        dict(groupe="delai", type="add", nom=0.0, etroite=(0.0, 0.01), large=(0.0, 0.04), extreme=(0.0, 0.08), borne=(0.0, 0.2), par="global"),
    # contact et terrain
    "frottement_sol": dict(groupe="frottement_sol", type="add", nom=0.6, etroite=(0.5, 0.8), large=(0.2, 1.5), extreme=(0.1, 2.0), borne=(0.05, 3.0), par="global"),
    "pente":        dict(groupe="terrain", type="add", nom=0.0, etroite=(0.0, 2.0), large=(0.0, 8.0), extreme=(0.0, 15.0), borne=(0.0, 25.0), par="global"),
    "relief":       dict(groupe="terrain", type="add", nom=0.0, etroite=(0.0, 0.005), large=(0.0, 0.02), extreme=(0.0, 0.04), borne=(0.0, 0.06), par="global"),
    "sol_mou":      dict(groupe="terrain", type="add", nom=0.02, etroite=(0.02, 0.03), large=(0.02, 0.08), extreme=(0.02, 0.15), borne=(0.01, 0.3), par="global"),
    # perturbations
    "poussees":     dict(groupe="perturbations", type="add", nom=0.0, etroite=(0.0, 20.0), large=(0.0, 60.0), extreme=(0.0, 100.0), borne=(0.0, 200.0), par="global"),
    "vent":         dict(groupe="perturbations", type="add", nom=0.0, etroite=(-3.0, 3.0), large=(-10.0, 10.0), extreme=(-20.0, 20.0), borne=(-40.0, 40.0), par="global"),
    # capteurs
    "bruit":        dict(groupe="capteurs", type="add", nom=0.0, etroite=(0.0, 0.2), large=(0.0, 1.0), extreme=(0.0, 3.0), borne=(0.0, 6.0), par="global"),
    "biais":        dict(groupe="capteurs", type="add", nom=0.0, etroite=(-0.2, 0.2), large=(-2.0, 2.0), extreme=(-5.0, 5.0), borne=(-10.0, 10.0), par="paire"),
    "retard_capteur": dict(groupe="capteurs", type="add", nom=0.0, etroite=(0.0, 0.005), large=(0.0, 0.02), extreme=(0.0, 0.05), borne=(0.0, 0.1), par="global"),
    "pertes":       dict(groupe="capteurs", type="add", nom=0.0, etroite=(0.0, 0.0), large=(0.0, 0.02), extreme=(0.0, 0.1), borne=(0.0, 0.3), par="global"),
    # conditions initiales
    "posture":      dict(groupe="initiales", type="add", nom=0.0, etroite=(-1.0, 1.0), large=(-5.0, 5.0), extreme=(-10.0, 10.0), borne=(-20.0, 20.0), par="articulation"),
    "vitesse_init": dict(groupe="initiales", type="add", nom=0.0, etroite=(-0.02, 0.02), large=(-0.1, 0.1), extreme=(-0.25, 0.25), borne=(-0.5, 0.5), par="paire"),
    "desequilibre": dict(groupe="initiales", type="add", nom=0.0, etroite=(-0.5, 0.5), large=(-3.0, 3.0), extreme=(-6.0, 6.0), borne=(-12.0, 12.0), par="paire"),
    # consignes
    "vitesse_visee": dict(groupe="consignes", type="add", nom=0.12, etroite=(0.10, 0.14), large=(0.06, 0.20), extreme=(0.03, 0.30), borne=(0.0, 0.5), par="global"),
}
GROUPES = ["corps", "actionneurs", "delai", "frottement_sol", "terrain", "perturbations", "capteurs", "initiales"]
NIVEAUX_RELIEF = [0.005, 0.01, 0.02, 0.03, 0.04, 0.06]       # les terrains précompilés (hauteur max des bosses)


def _taille(ax, nb_corps=18, nb_art=17):
    return {"global": None, "signe": None, "corps": nb_corps, "corps3": (nb_corps, 3), "segment": 2, "articulation": nb_art, "paire": 2}[ax["par"]]


def intervalle(nom, mode, f=None):
    """L'intervalle d'un axe : "nominal", "etroite", "large", "extreme", ou "echelle" (f fois l'écart de la plage large au nominal)."""
    ax = AXES[nom]
    if mode == "nominal":
        return ax["nom"], ax["nom"]
    if mode in ("etroite", "large", "extreme"):
        return ax[mode]
    lo, hi = ax["large"]
    if ax["type"] == "log":
        a, b = ax["nom"] * (lo / ax["nom"]) ** f, ax["nom"] * (hi / ax["nom"]) ** f
    else:
        a, b = ax["nom"] - f * (ax["nom"] - lo), ax["nom"] + f * (hi - ax["nom"])
    return max(a, ax["borne"][0]), min(b, ax["borne"][1])


def _uniforme(rng, ax, lo, hi, taille):
    if ax["type"] == "log":
        return np.exp(rng.uniform(np.log(lo), np.log(hi), taille))
    return rng.uniform(lo, hi, taille)


def tirer_axe(rng, nom, mode, f=None):
    """Une valeur (ou un tableau) pour un axe. Modes en plus : "hors" (entre la plage large et l'extrême), "coin" (un bord de la plage
    large), "bord" (le bord de l'intervalle "echelle" f : la sonde du curriculum)."""
    ax = AXES[nom]
    taille = _taille(ax)
    if mode == "hors":
        (llo, lhi), (elo, ehi) = ax["large"], ax["extreme"]
        bas, haut = max(0.0, (llo - elo) if ax["type"] != "log" else np.log(llo / elo)), max(0.0, (ehi - lhi) if ax["type"] != "log" else np.log(ehi / lhi))
        cote_haut = rng.uniform() < (haut / (bas + haut) if bas + haut > 0 else 0.5)
        lo, hi = (lhi, ehi) if cote_haut else (elo, llo)
        v = _uniforme(rng, ax, lo, hi, taille)
    elif mode in ("coin", "bord"):
        lo, hi = ax["large"] if mode == "coin" else intervalle(nom, "echelle", f)
        cote = rng.integers(0, 2, taille) if taille is not None else rng.integers(0, 2)
        v = np.where(cote == 1, hi, lo) if taille is not None else (hi if cote == 1 else lo)
        if lo == hi == ax["nom"]:
            v = np.full(taille, ax["nom"]) if taille is not None else ax["nom"]
    else:
        lo, hi = intervalle(nom, mode, f)
        v = _uniforme(rng, ax, lo, hi, taille) if hi > lo else (np.full(taille, lo) if taille is not None else lo)
    if ax["par"] == "signe":                                   # une amplitude et un sens
        v = float(v) * (1.0 if rng.uniform() < 0.5 else -1.0)
    if isinstance(v, np.ndarray):
        return [round(float(x), 6) for x in v.ravel()]
    return round(float(v), 6)


def tirer_condition(rng, regle, solveur="normal"):
    """regle : {axe: (mode, f)} pour chaque axe ; un axe absent est au nominal."""
    axes = {}
    for nom in AXES:
        mode, f = regle.get(nom, ("nominal", None))
        axes[nom] = tirer_axe(rng, nom, mode, f)
    return {"axes": axes, "graine": int(rng.integers(0, 2 ** 31 - 1)), "solveur": solveur}


def regle_regime(regime, f=None, sans_groupe=None, largeurs=None):
    """R0 : rien ne varie ; R1 : étroite ; R2 : large ; « echelle » : f fois la large ; R3 : la largeur courante de chaque axe (curriculum)."""
    r = {}
    for nom, ax in AXES.items():
        if regime == "R0":
            r[nom] = ("nominal", None)
        elif regime == "R1":
            r[nom] = ("etroite", None)
        elif regime == "R2":
            r[nom] = ("large", None)
        elif regime == "echelle":
            r[nom] = ("echelle", f) if f > 0 else ("nominal", None)
        elif regime == "R3":
            r[nom] = ("echelle", largeurs[nom])
        if sans_groupe is not None and ax["groupe"] == sans_groupe:
            r[nom] = ("nominal", None)
    return r


# ---- le monde : les modèles (un par terrain), les mesures du juge -------------------------------------------------------------------
_monde = {}


def _compiler(relief, graine):
    spec = mujoco.MjSpec.from_file(os.path.join(SIM, "n3.xml"))
    if relief > 0:
        rng = np.random.default_rng(graine)
        for i in range(19):                                    # des dalles de 0,3 m, de x = −0,6 à 5,1 m, y de −1,05 à 1,05 m
            for j in range(7):
                x, y = -0.6 + 0.15 + 0.3 * i, -1.05 + 0.15 + 0.3 * j
                if abs(x) < 0.45 and abs(y) < 0.45:
                    continue                                   # le départ reste plat
                h = float(rng.uniform(0.0, relief))
                if h < 1e-4:
                    continue
                spec.worldbody.add_geom(type=mujoco.mjtGeom.mjGEOM_BOX, size=[0.15, 0.15, h / 2], pos=[x, y, h / 2],
                                        rgba=[0.55, 0.55, 0.6, 1])
    m = spec.compile()
    nb = lambda b: mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_BODY, b) or ""
    ng = lambda g: mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, g) or ""
    monde = [g for g in range(m.ngeom) if m.geom_bodyid[g] == 0]
    pieds = {c: [g for g in range(m.ngeom) if "pied" in ng(g) and nb(m.geom_bodyid[g]).startswith("jambe-" + c)] for c in ("gauche", "droite")}
    corps_robot = list(range(1, m.nbody))
    gauche = [b for b in corps_robot if "gauche" in nb(b)]
    droite = [b for b in corps_robot if "droit" in nb(b)]
    act_g = [i for i in range(m.nu) if "gauche" in (mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i) or "")]
    act_d = [i for i in range(m.nu) if "droit" in (mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i) or "")]
    cuisses = [b for b in corps_robot if nb(b) in ("jambe-gauche-genou", "jambe-droite-genou")]
    jambes = [b for b in corps_robot if nb(b) in ("jambe-gauche-cheville-tangage", "jambe-droite-cheville-tangage")]
    sauve = {k: getattr(m, k).copy() for k in ("body_mass", "body_inertia", "body_ipos", "body_pos", "actuator_forcerange", "actuator_gainprm",
                                                  "actuator_biasprm", "dof_damping", "dof_frictionloss", "geom_friction", "geom_solref")}
    sauve["opt"] = (m.opt.timestep, m.opt.integrator, m.opt.cone, m.opt.iterations, m.opt.gravity.copy())
    return dict(m=m, d=mujoco.MjData(m), monde=set(monde), monde_l=monde, pieds={c: set(v) for c, v in pieds.items()}, pieds_l=pieds,
                corps=corps_robot, gauche=gauche, droite=droite, act_g=act_g, act_d=act_d, cuisses=cuisses, jambes=jambes, sauve=sauve)


def preparer():
    """Une fois par processus : les signes et les noms (W.init), puis un modèle par niveau de relief (deux tirages de dalles chacun)."""
    W.init()
    _monde["plat"] = _compiler(0.0, 0)
    for k, r in enumerate(NIVEAUX_RELIEF):
        for v in (0, 1):
            _monde["relief-%d-%d" % (k, v)] = _compiler(r, 1000 + 10 * k + v)
    m0 = _monde["plat"]
    mujoco.mj_resetData(m0["m"], m0["d"])
    mujoco.mj_forward(m0["m"], m0["d"])
    _monde["h0"] = float(m0["d"].subtree_com[1][2])
    _monde["masse"] = float(np.sum(m0["m"].body_mass))


def _choisir_modele(relief, rng):
    if relief <= 1e-4:
        return _monde["plat"]
    k = min(range(len(NIVEAUX_RELIEF)), key=lambda i: abs(NIVEAUX_RELIEF[i] - relief))
    return _monde["relief-%d-%d" % (k, int(rng.integers(0, 2)))]


def _restaurer(w):
    m, s = w["m"], w["sauve"]
    for k, v in s.items():
        if k != "opt":
            getattr(m, k)[:] = v
    m.opt.timestep, m.opt.integrator, m.opt.cone, m.opt.iterations, g = s["opt"]
    m.opt.gravity[:] = g


def _appliquer(w, a, solveur):
    """Les axes qui changent le modèle lui-même."""
    m = w["m"]
    corps = w["corps"]
    f = np.array(a["masse"])
    m.body_mass[corps] *= (1 + f)
    m.body_inertia[corps] *= (1 + f)[:, None]
    s = a["asymetrie"]
    m.body_mass[w["gauche"]] *= (1 + s)
    m.body_inertia[w["gauche"]] *= (1 + s)
    m.body_mass[w["droite"]] *= (1 - s)
    m.body_inertia[w["droite"]] *= (1 - s)
    if a["charge"] > 0:
        r = (m.body_mass[1] + a["charge"] * _monde["masse"]) / m.body_mass[1]
        m.body_mass[1] *= r
        m.body_inertia[1] *= r
    m.body_ipos[corps] += np.array(a["com"]).reshape(-1, 3)
    l_cuisse, l_jambe = a["longueurs"]
    m.body_pos[w["cuisses"]] *= (1 + l_cuisse)
    m.body_pos[w["jambes"]] *= (1 + l_jambe)
    m.actuator_forcerange[:] *= (1 + a["couple"])
    g = 1 + a["gains"]
    m.actuator_gainprm[:, 0] *= g
    m.actuator_biasprm[:, 1:3] *= g
    m.actuator_gainprm[w["act_g"], 0] *= (1 + s)
    m.actuator_biasprm[w["act_g"], 1] *= (1 + s)
    m.actuator_gainprm[w["act_d"], 0] *= (1 - s)
    m.actuator_biasprm[w["act_d"], 1] *= (1 - s)
    m.dof_damping[6:] *= a["amortissement"]
    m.dof_frictionloss[6:] = a["frottement_art"]
    for g_ in w["monde_l"] + w["pieds_l"]["gauche"] + w["pieds_l"]["droite"]:
        m.geom_friction[g_, 0] = a["frottement_sol"]
    for g_ in w["monde_l"] + w["pieds_l"]["gauche"] + w["pieds_l"]["droite"]:   # MuJoCo fait la moyenne des deux surfaces : les deux
        m.geom_solref[g_] = [a["sol_mou"], 1.0]
    if a["pente"] > 0:
        rng = np.random.default_rng(int(a["_graine_pente"]))
        phi = rng.uniform(0, 2 * np.pi)
        th = np.radians(a["pente"])
        m.opt.gravity[:] = 9.81 * np.array([np.sin(th) * np.cos(phi), np.sin(th) * np.sin(phi), -np.cos(th)])
    if solveur == "autre":
        m.opt.timestep, m.opt.integrator, m.opt.cone, m.opt.iterations = 0.001, mujoco.mjtIntegrator.mjINT_EULER, mujoco.mjtCone.mjCONE_ELLIPTIC, 50


def _touche(w, d, cote):
    pi, mo = w["pieds"][cote], w["monde"]
    for x in d.contact[:d.ncon]:
        if (x.geom1 in pi and x.geom2 in mo) or (x.geom2 in pi and x.geom1 in mo):
            return True
    return False


def decoder(u):
    """u (19 nombres entre 0 et 1) → la politique : le rythme (15), le placement du pied (3), la cadence (1). Comme R-107."""
    u = np.clip(np.asarray(u, float), 0, 1)
    p = W.BAS + u[:15] * (W.HAUT - W.BAS)
    pl = P.BAS_PL + u[15:18] * (P.HAUT_PL - P.BAS_PL)
    kt = M.BAS_T + u[18] * (M.HAUT_T - M.BAS_T)
    return p, pl, kt


def rouler(u, cond, video=None):
    """Un épisode de 10 s : la condition appliquée, la marche de R-107 conduite par la politique u, jugé. Rejouable à l'identique."""
    a = dict(cond["axes"])
    rng = np.random.default_rng(int(cond["graine"]))
    a["_graine_pente"] = int(rng.integers(0, 2 ** 31 - 1))
    w = _choisir_modele(a["relief"], rng)
    m, d = w["m"], w["d"]
    _restaurer(w)
    _appliquer(w, a, cond.get("solveur", "normal"))
    p, (kv, ky, a_f), kt = decoder(u)
    T = float(p[0])
    v_vise = a["vitesse_visee"]
    # l'état de départ
    mujoco.mj_resetData(m, d)
    art = m.actuator_trnid[:, 0]
    for i, off in enumerate(a["posture"][:m.nu]):
        d.qpos[m.jnt_qposadr[art[i]]] += np.radians(off)
    tg, rl = np.radians(a["desequilibre"])
    qd, res = np.zeros(4), np.zeros(4)
    mujoco.mju_euler2Quat(qd, np.array([rl, tg, 0.0]), "xyz")
    mujoco.mju_mulQuat(res, qd, d.qpos[3:7].copy())
    d.qpos[3:7] = res
    d.qvel[0], d.qvel[1] = a["vitesse_init"]
    mujoco.mj_forward(m, d)
    h0 = _monde["h0"]
    x0, y0 = float(d.subtree_com[1][0]), float(d.subtree_com[1][1])
    fr0 = m.actuator_forcerange.copy()
    # les poussées : instants, durées, forces
    n_p = int(np.ceil(a["poussees"] / 30.0)) if a["poussees"] > 0 else 0
    poussees = [(float(rng.uniform(2.5, 9.0)), float(rng.uniform(0.5, 1.0) * a["poussees"]), float(rng.uniform(0, 2 * np.pi))) for _ in range(n_p)]
    biais = np.array(a["biais"])
    q_pas = np.radians(a["resolution"]) if a["resolution"] > 0 else 0.0
    n_pose = int(round(DT / m.opt.timestep))
    w0 = 2 * np.pi / T
    phi, v, prec_cm = 0.0, np.zeros(2), d.subtree_com[1][:2].copy()
    file_mes, mes_tenue = [], None                             # les mesures des capteurs, avec retard et pertes
    file_cmd, c_appli, c_prec = [], np.zeros(m.nu), None       # les consignes, avec délai
    chute, vol, derive, energie, glisse, douceur, n_douceur = None, 0.0, 0.0, 0.0, 0.0, 0.0, 0
    pic = np.zeros(m.nu)
    pos_pieds = {c: None for c in ("gauche", "droite")}
    xs2 = None
    n = int(DUREE / m.opt.timestep)
    for k in range(n):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            # ---- les capteurs ----
            att = np.array(W.attitude(d))
            att[:2] += biais
            if a["bruit"] > 0:
                att[:2] += rng.normal(0, a["bruit"], 2)
                att[2:] += rng.normal(0, 5 * a["bruit"], 2)
            cm = d.subtree_com[1][:2].copy()
            v = (1 - a_f) * v + a_f * (cm - prec_cm) / DT
            prec_cm = cm
            v_mes = v + (rng.normal(0, 0.02 * a["bruit"], 2) if a["bruit"] > 0 else 0.0)
            file_mes.append((t, att, v_mes))
            while len(file_mes) > 1 and file_mes[1][0] <= t - a["retard_capteur"] + 1e-9:
                file_mes.pop(0)
            if mes_tenue is None or rng.uniform() >= a["pertes"]:
                mes_tenue = (file_mes[0][1], file_mes[0][2])
            att_m, v_m = mes_tenue
            # ---- la politique (R-107) ----
            wv = w0 if t < 1.5 else float(np.clip(w0 + kt * (v_m[0] - v_vise), 0.6 * w0, 1.6 * w0))
            phi += wv * DT
            t_eff = phi / w0
            pose = W.pose_marche(p, max(t_eff, 0.0) if t >= 1.5 else t, (att_m[0] - CIBLE, att_m[1], att_m[2], att_m[3]))
            tg_ = {c: _touche(w, d, c) for c in ("gauche", "droite")}
            if t > 1.5:
                for cote, nom in (("g", "gauche"), ("d", "droite")):
                    autre = "droite" if nom == "gauche" else "gauche"
                    if not tg_[nom] and tg_[autre]:
                        pose["hanche_tangage_" + cote] += kv * (v_m[0] - v_vise)
                        pose["hanche_roulis_" + cote] += ky * v_m[1]
            c = C.consigne(m, pose, W._sg)
            if q_pas > 0:
                c = np.round(c / q_pas) * q_pas
            if c_prec is not None:
                douceur += float(np.mean(np.abs(c - c_prec))) / DT
                n_douceur += 1
            c_prec = c
            file_cmd.append((t, c))
            # la pile qui baisse
            m.actuator_forcerange[:] = fr0 * (1.0 - a["baisse_pile"] * t / DUREE)
            # ---- les mesures du juge ----
            if not tg_["gauche"] and not tg_["droite"] and t > 0.3:
                vol += DT
            for cote in ("gauche", "droite"):
                pp = d.xpos[m.geom_bodyid[next(iter(w["pieds"][cote]))]][:2].copy()
                if tg_[cote] and pos_pieds[cote] is not None:
                    glisse += float(np.linalg.norm(pp - pos_pieds[cote]))
                pos_pieds[cote] = pp
            derive = max(derive, abs(float(d.subtree_com[1][1]) - y0))
            energie += float(np.sum(np.abs(d.actuator_force * d.actuator_velocity))) * DT
            if xs2 is None and t >= 2.0:
                xs2 = float(d.subtree_com[1][0])
        while len(file_cmd) > 1 and file_cmd[1][0] <= t - a["delai"] + 1e-9:
            file_cmd.pop(0)
        c_appli = file_cmd[0][1]
        # les forces extérieures : les poussées et le vent
        fx, fy = 0.0, a["vent"]
        for (tp, fp, ang) in poussees:
            if tp <= t < tp + 0.1:
                fx += fp * np.cos(ang)
                fy += fp * np.sin(ang)
        d.xfrc_applied[1, :2] = [fx, fy]
        d.ctrl[:] = c_appli
        mujoco.mj_step(m, d)
        if k % 20 == 0:
            pic = np.maximum(pic, np.abs(d.actuator_force))
            if C.inclinaison(d) > JUGE["inclinaison_max_deg"] or d.subtree_com[1][2] < JUGE["hauteur_min"] * h0:
                chute = t
                break
        if video is not None and k % max(1, int(0.04 / m.opt.timestep)) == 0:
            video(d)
    d.xfrc_applied[:] = 0
    avance = float(d.subtree_com[1][0]) - x0
    v_moy = (float(d.subtree_com[1][0]) - xs2) / (DUREE - 2.0) if (xs2 is not None and chute is None) else 0.0
    reussi = chute is None and avance >= JUGE["avance_min_m"] and derive <= JUGE["derive_max_m"] and vol <= JUGE["vol_max_s"]
    duree = chute if chute is not None else DUREE
    masse = float(np.sum(m.body_mass))
    return {"reussi": bool(reussi), "tombe": chute is not None, "chute_s": None if chute is None else round(chute, 2),
            "avance_m": round(avance, 3), "derive_m": round(derive, 3), "vol_s": round(vol, 2),
            "erreur_suivi_m_s": round(abs(v_moy - v_vise), 3) if chute is None else None,
            "energie_J": round(energie, 1), "cout_transport": round(energie / (masse * 9.81 * max(avance, 0.05)), 2),
            "pic_couple_Nm": round(float(np.max(pic)), 1), "pic_couple_kg_300mm": round(float(np.max(pic)) / (9.81 * 0.3), 1),
            "douceur_deg_s": round(np.degrees(douceur / max(n_douceur, 1)), 1), "glissement_m": round(glisse, 3), "duree_s": round(duree, 2)}


def note_entrainement(r):
    """Le plaisir du jeu, le même pour tous les régimes : le juge, plus des marches vers lui (avancer, rester debout)."""
    survie = (r["chute_s"] if r["tombe"] else DUREE) / DUREE
    return (1.0 * r["reussi"] + 0.5 * min(max(r["avance_m"], 0.0) / JUGE["avance_min_m"], 1.0) * (not r["tombe"]) + 0.3 * survie
            - 0.2 * max(0.0, r["derive_m"] - JUGE["derive_max_m"]) - 0.5 * max(0.0, r["vol_s"] - JUGE["vol_max_s"]))
