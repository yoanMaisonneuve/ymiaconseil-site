# Catalogue des axes de variation — banc de variance (R-111)

> Écrit le 12.11.2026 à 06:03 (heure lue), pour la mission de Yoan du 12.11 à 06:00. Robot : **N3** (`navitek-sim/n3.xml`, 1,5 m,
> 26,5 kg, 17 articulations, hanche à 135° depuis 04:37). Valeurs nominales lues dans le modèle : actionneurs de position kp 800, kv 25,
> ±200 N·m ; amortissement articulaire 0,5, armature 0,05, frottement sec 0 ; frottement au sol 0,6 ; pas de 0,5 ms, intégrateur
> `implicitfast` ; torse 10,1 kg.

Chaque axe a trois plages : **étroite** (la tolérance d'un bon atelier), **large** (ce qu'un robot imprimé rencontre vraiment),
**extrême** (au-delà, réservée à l'évaluation hors plages). Un tirage prend une valeur uniforme dans la plage (les deux sens quand c'est ±).

## 1. Corps

| Axe | Paramètre MuJoCo | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|---|
| masse des segments | `body_mass` (et l'inertie au même rapport), chaque corps tiré à part | ±5 % | ±20 % | ±35 % | pièces imprimées (remplissage, densité 0,63 à 1,34 g/cm³ mesurés sur N0) ; les 900 g par actionneur sont estimés |
| centre de masse décalé | `body_ipos`, chaque corps | ±0,5 cm | ±2 cm | ±4 cm | fils, pile, vis ; la CAO ne les place pas |
| longueurs | `body_pos` des cuisses et des jambes du bas | ±1 % | ±5 % | ±8 % | tolérances d'impression et de montage ; N3 n'est pas encore dessiné |
| charge ajoutée | masse ajoutée au torse | 0 à 5 % | 0 à 20 % | 0 à 35 % de la masse | un sac, une pile plus grosse, un objet porté |
| asymétrie gauche-droite *(ajouté)* | masses et gains d'un côté +x %, de l'autre −x % | 2 % | 8 % | 15 % | R-073 à R-084 : le côté gauche de N3 est déjà plus faible |

## 2. Actionneurs

| Axe | Paramètre | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|---|
| couple max | `actuator_forcerange` | ±5 % | ±20 % | ±40 % | dispersion des moteurs, tension de pile |
| délai de commande | tampon de consignes | 0 à 10 ms | 0 à 40 ms | 0 à 80 ms | bus série (STS3215), calcul, Wi-Fi |
| gains | `actuator_gainprm` / `biasprm` (kp, kv) | ±8 % | ±25 % | ±50 % | réglage des servos, échauffement |
| frottement et amortissement | `dof_frictionloss` (0 → jusqu'à 0,5 N·m), `dof_damping` × | ×0,8 à 1,25 | ×0,5 à 2 | ×0,25 à 4 | réducteurs imprimés, graisse, usure |
| baisse de pile pendant l'épisode *(ajouté)* | couple max qui baisse en ligne droite | 0 à 3 % | 0 à 15 % | 0 à 30 % | une LiPo qui se vide sous charge |
| résolution des servos *(ajouté)* | consignes arrondies | 0,1° | 0,5° | 1° | STS3215 : 0,088° ; SG90 (N0) : environ 1° |

## 3. Contact et terrain

| Axe | Paramètre | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|---|
| frottement au sol | `geom_friction` du sol et des pieds | 0,5 à 0,8 | 0,2 à 1,5 | 0,1 à 2,0 | carrelage mouillé, bois, tapis, caoutchouc |
| pente | gravité inclinée (plan équivalent), direction au hasard | 0 à 2° | 0 à 8° | 0 à 15° | rampes, trottoirs ; 8° est une rampe d'accès |
| sol irrégulier et marches | terrains précompilés : bosses de hauteur au hasard, une marche | 0,5 cm | 2 cm | 4 cm | seuils de porte, tapis, gravier |
| sol mou | `solref` du sol (constante de temps) | 0,02 à 0,03 s | 0,02 à 0,08 s | 0,02 à 0,15 s | tapis épais, gazon, sable |

## 4. Perturbations

| Axe | Paramètre | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|---|
| poussées au hasard | impulsions de 0,1 s sur le torse, direction et instant au hasard | 1 poussée ≤ 20 N | 2 ≤ 60 N | 3 ≤ 100 N | une personne, un animal, un choc |
| force latérale continue | force constante sur le torse | ±3 N | ±10 N | ±20 N | vent, un câble qui tire |

## 5. Capteurs (ce que la commande lit : l'attitude du torse, ses vitesses, la vitesse du corps)

| Axe | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|
| bruit | 0,2° et 1°/s | 1° et 5°/s | 3° et 15°/s | centrale inertielle bon marché |
| biais | ±0,2° | ±2° | ±5° | montage de la centrale |
| retard | 0 à 5 ms | 0 à 20 ms | 0 à 50 ms | filtrage, lecture série |
| mesures perdues | 0 % | 2 % | 10 % | paquets perdus (la dernière valeur est gardée) |

## 6. Conditions initiales

| Axe | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|
| posture | ±1° par articulation | ±5° | ±10° | le robot n'est jamais posé pile |
| vitesse initiale du corps | ±0,02 m/s | ±0,1 m/s | ±0,25 m/s | il part d'un mouvement |
| déjà déséquilibré | torse incliné de ±0,5° | ±3° | ±6° | il part en penchant |

## 7. Consignes

| Axe | Étroite | Large | Extrême | Pourquoi |
|---|---|---|---|---|
| vitesse visée | 0,10 à 0,14 m/s | 0,06 à 0,20 m/s | 0,03 à 0,30 m/s | la commande de R-107 lit une vitesse visée (placement du pied, cadence) |

Les directions (tourner, reculer) ne sont pas dans la v1 : la commande de R-107 ne sait que marcher droit ; R-076 à R-079 montrent que
tourner demande une autre commande.

## 8. Le solveur (évaluation seulement, jamais à l'entraînement)

Un autre réglage physique, pour voir si la politique a appris le mouvement ou les manies du simulateur : pas de 1 ms au lieu de 0,5 ms,
intégrateur `Euler`, cône de frottement elliptique, moins d'itérations du solveur.

## 9. Axes jugés inutiles (et pourquoi)

- **La valeur de la gravité** : constante sur Terre ; seule son inclinaison (la pente) compte, et elle est dans le catalogue.
- **La traînée de l'air** : à 0,15 m/s, négligeable devant les poussées.
- **La température, le magnétisme** : MuJoCo ne les modélise pas ; leurs effets passent par le couple et le frottement, déjà variés.
- **L'éclairage, les textures** : aucune caméra dans la boucle de commande.
- **Le jeu mécanique (backlash)** : utile pour un vrai robot imprimé, mais MuJoCo n'a pas de jeu natif ; à modéliser plus tard (une zone
  morte dans la transmission), pas dans la v1.

## 10. Ce que la v1 ne varie pas, alors qu'il faudrait

- la géométrie des pieds (longueur, semelle) ; la forme des pièces ; les contacts entre pièces (désactivés dans le modèle).
