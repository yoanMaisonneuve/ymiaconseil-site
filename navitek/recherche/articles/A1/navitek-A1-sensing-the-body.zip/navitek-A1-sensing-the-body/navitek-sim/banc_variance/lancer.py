"""R-111 — le lanceur du banc de variance : le jeu d'évaluation (tiré une fois, avant tout entraînement), les configurations, les
entraînements (CMA-ES, le même pour tous), le curriculum automatique, les évaluations. Reprend où il s'est arrêté.

    python -X utf8 lancer.py jeu            # tire et fige le jeu d'évaluation (graine 111), écrit les configurations
    python -X utf8 lancer.py tout           # entraîne et évalue tout ce qui manque (principal, largeurs, ablation)
    python -X utf8 lancer.py tout --seulement principal
Sorties : banc_variance/eval/jeu_evaluation.json, banc_variance/configs/*.json, banc_variance/resultats/<nom>.json."""
import argparse
import json
import platform
import multiprocessing as mp
import os
import time

import numpy as np

import banc as B

ICI = os.path.dirname(os.path.abspath(__file__))
D_EVAL, D_CONF, D_RES = (os.path.join(ICI, x) for x in ("eval", "configs", "resultats"))
GENERATIONS, POPULATION, EPISODES = 50, 16, 8
SIGMA_PRE = 0.15                                              # le pré-entraînement (parti de R-107 B-g1)
SIGMA = 0.02                                                  # E56 : calibré (calibrer_pas.py) ; à 0,15, aucun candidat ne passait le nominal
LARGEURS = [0.25, 0.5, 1.5, 2.0]
R107 = os.path.join(B.SIM, "resultats", "n3-moment-du-pas.json")


F_PRE = os.path.join(D_RES, "pre_entrainement.json")


def depart():
    """E54 : le point de départ commun est la marche pré-entraînée au nominal (si elle existe), sinon la marche B-g1 de R-107."""
    if os.path.exists(F_PRE):
        return np.array(json.load(open(F_PRE, encoding="utf-8"))["politique"])
    j = json.load(open(R107, encoding="utf-8"))["jeux"]["B-g1"]
    return np.concatenate([(np.array(j["parametres_liste"]) - B.W.BAS) / (B.W.HAUT - B.W.BAS),
                           (np.array(j["placement"]) - B.P.BAS_PL) / (B.P.HAUT_PL - B.P.BAS_PL),
                           [(j["gain_moment"] - B.M.BAS_T) / (B.M.HAUT_T - B.M.BAS_T)]])


# ---- le jeu d'évaluation, figé avant tout entraînement --------------------------------------------------------------------------------
def jeu_evaluation():
    rng = np.random.default_rng(111)
    jeu = []
    for _ in range(10):                                       # nominal : seule la vitesse visée varie, dans l'étroite
        r = B.regle_regime("R0")
        r["vitesse_visee"] = ("etroite", None)
        jeu.append(dict(B.tirer_condition(rng, r), jeu="nominal"))
    for _ in range(100):                                      # dans les plages larges
        jeu.append(dict(B.tirer_condition(rng, B.regle_regime("R2")), jeu="dans"))
    noms = [n for n in B.AXES if n != "vitesse_visee"]
    for _ in range(100):                                      # hors plages : deux axes entre la large et l'extrême
        r = B.regle_regime("R2")
        for n in rng.choice(noms, 2, replace=False):
            r[str(n)] = ("hors", None)
        jeu.append(dict(B.tirer_condition(rng, r), jeu="hors"))
    for _ in range(100):                                      # combinaisons : trois axes à un coin de la plage large en même temps
        r = B.regle_regime("R2")
        for n in rng.choice(noms, 3, replace=False):
            r[str(n)] = ("coin", None)
        jeu.append(dict(B.tirer_condition(rng, r), jeu="coins"))
    for _ in range(50):                                       # un autre solveur, dans les plages
        jeu.append(dict(B.tirer_condition(rng, B.regle_regime("R2"), solveur="autre"), jeu="solveur"))
    return jeu


def configurations():
    cf = []
    for g in (1, 2, 3):
        for reg in ("R0", "R1", "R2", "R3"):
            cf.append(dict(nom="%s-g%d" % (reg, g), lot="principal", regime=reg, graine=g))
    for g in (1, 2, 3):
        for f in LARGEURS:
            cf.append(dict(nom="largeur-%.2f-g%d" % (f, g), lot="largeurs", regime="echelle", f=f, graine=g))
    for g in (1, 2, 3):
        for grp in B.GROUPES:
            cf.append(dict(nom="sans-%s-g%d" % (grp, g), lot="ablation", regime="R2", sans_groupe=grp, graine=g))
    for c in cf:
        c.update(generations=GENERATIONS, population=POPULATION, episodes=EPISODES, sigma=SIGMA, depart="la marche pré-entraînée au nominal (E54), partie de R-107 B-g1",
                 algorithme="CMA-ES (bibliothèque cmaes)", budget_episodes=GENERATIONS * POPULATION * EPISODES)
    return cf


# ---- les tâches des processus -------------------------------------------------------------------------------------------------------
def _tache(args):
    u, cond = args
    r = B.rouler(u, cond)
    return B.note_entrainement(r), bool(r["reussi"])


def _eval(args):
    u, cond = args
    r = B.rouler(u, cond)
    r["jeu"] = cond["jeu"]
    return r


def entrainer(pool, cfg, journal):
    from cmaes import CMA
    rng_c = np.random.default_rng(cfg["graine"])
    u0 = depart()
    cma = CMA(mean=np.clip(u0, 0.0, 1.0), sigma=cfg["sigma"], population_size=cfg["population"], seed=1110 + cfg["graine"],
              bounds=np.array([[0, 1]] * len(u0)))
    largeurs = {n: 0.25 for n in B.AXES}                       # R3 : chaque axe part près de l'étroite
    s_max = {}
    for n, ax in B.AXES.items():
        lo, hi = ax["large"]
        elo, ehi = ax["extreme"]
        if ax["type"] == "log":
            dl, de = max(np.log(hi / ax["nom"]), np.log(ax["nom"] / lo)), max(np.log(ehi / ax["nom"]), np.log(ax["nom"] / elo))
        else:
            dl, de = max(hi - ax["nom"], ax["nom"] - lo), max(ehi - ax["nom"], ax["nom"] - elo)
        s_max[n] = de / dl if dl > 0 else 1.0
    tampons = {n: [] for n in B.AXES}
    histo, histo_larg, meilleur = [], [], (-1e9, None, -1)
    for gen in range(cfg["generations"]):
        rng = np.random.default_rng(np.random.SeedSequence([1110 + cfg["graine"], gen]))
        if cfg["regime"] == "R3":
            regle = B.regle_regime("R3", largeurs=largeurs)
            conds, sondes = [], []
            for e in range(cfg["episodes"]):
                if e < cfg["episodes"] - 2:
                    conds.append(B.tirer_condition(rng, regle))
                    sondes.append(None)
                else:                                          # deux sondes : un axe au bord de sa largeur courante
                    n = str(rng.choice(list(B.AXES)))
                    r_ = dict(regle)
                    r_[n] = ("bord", largeurs[n])
                    conds.append(B.tirer_condition(rng, r_))
                    sondes.append(n)
        else:
            regle = B.regle_regime(cfg["regime"], f=cfg.get("f"), sans_groupe=cfg.get("sans_groupe"))
            conds = [B.tirer_condition(rng, regle) for _ in range(cfg["episodes"])]
            sondes = [None] * cfg["episodes"]
        xs = [cma.ask() for _ in range(cfg["population"])]
        if cfg["regime"] == "R0":                              # rien ne varie : les 8 épisodes sont identiques ; on en joue un, compté 8 fois
            res = pool.map(_tache, [(x, conds[0]) for x in xs])
            notes = [r[0] for r in res]
            reussites = [[r[1]] * cfg["episodes"] for r in res]
        else:
            res = pool.map(_tache, [(x, c) for x in xs for c in conds], chunksize=2)
            ne = cfg["episodes"]
            notes = [float(np.mean([res[i * ne + e][0] for e in range(ne)])) for i in range(len(xs))]
            reussites = [[res[i * ne + e][1] for e in range(ne)] for i in range(len(xs))]
        cma.tell([(x, -nt) for x, nt in zip(xs, notes)])
        i = int(np.argmax(notes))
        if notes[i] > meilleur[0]:
            meilleur = (notes[i], [float(v) for v in xs[i]], gen)
        taux = float(np.mean(reussites))
        if cfg["regime"] == "R3":
            for e, n in enumerate(sondes):
                if n is None:
                    continue
                tampons[n].append(float(np.mean([reussites[k][e] for k in range(len(xs))])))
                if len(tampons[n]) >= 2:
                    moy = float(np.mean(tampons[n]))
                    if moy >= 0.8:
                        largeurs[n] = min(largeurs[n] * 1.25, s_max[n])
                    elif moy < 0.5:
                        largeurs[n] = max(largeurs[n] * 0.8, 0.1)
                    tampons[n] = []
            histo_larg.append({n: round(v, 3) for n, v in largeurs.items()})
        histo.append({"gen": gen, "note_moy": round(float(np.mean(notes)), 3), "note_max": round(float(np.max(notes)), 3), "reussite": round(taux, 3)})
        journal("%s génération %2d : note moyenne %.3f, meilleure %.3f, réussite %.0f %%" % (cfg["nom"], gen + 1, np.mean(notes), np.max(notes), 100 * taux))
    moyenne = getattr(cma, "mean", None)
    if moyenne is None:
        moyenne = cma._mean
    return {"config": cfg, "politique_moyenne": [float(v) for v in np.clip(moyenne, 0, 1)], "meilleur_candidat": meilleur[1],
            "meilleur_note": round(meilleur[0], 3), "meilleur_generation": meilleur[2], "historique": histo,
            "largeurs_curriculum": histo_larg[-1] if histo_larg else None, "largeurs_curriculum_histo": histo_larg[::5] if histo_larg else None}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["jeu", "pre", "tout"])
    ap.add_argument("--generations", type=int, default=100)
    ap.add_argument("--seulement", default=None)
    ap.add_argument("--noms", default=None)                 # une liste de configurations, séparées par des virgules
    ap.add_argument("--processus", type=int, default=14)
    ap.add_argument("--fumee", type=int, default=0)         # essai de fumée : N générations, écrit dans resultats-fumee/, ne compte pour rien
    a = ap.parse_args()
    for dd in (D_EVAL, D_CONF, D_RES):
        os.makedirs(dd, exist_ok=True)
    f_jeu = os.path.join(D_EVAL, "jeu_evaluation.json")
    if a.mode == "jeu":
        if os.path.exists(f_jeu):
            print("le jeu d'évaluation existe déjà : on ne le retire pas", flush=True)
        else:
            jeu = jeu_evaluation()
            json.dump(jeu, open(f_jeu, "w", encoding="utf-8"), ensure_ascii=False)
            print("jeu d'évaluation :", len(jeu), "conditions", flush=True)
        for c in configurations():
            json.dump(c, open(os.path.join(D_CONF, c["nom"] + ".json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("configurations :", len(configurations()), flush=True)
        return
    jeu = json.load(open(f_jeu, encoding="utf-8"))
    f_log = os.path.join(ICI, "resultats-fumee" if a.fumee else "resultats", "banc.log")
    os.makedirs(os.path.dirname(f_log), exist_ok=True)
    def journal(txt):
        ligne = time.strftime("%H:%M:%S ") + txt
        print(ligne, flush=True)
        with open(f_log, "a", encoding="utf-8") as fh:
            fh.write(ligne + "\n")
    if a.mode == "pre":                                       # E54 : apprendre à marcher au nominal, le même départ pour tous
        from cmaes import CMA
        assert not os.path.exists(F_PRE), "le pré-entraînement existe déjà"
        j = json.load(open(R107, encoding="utf-8"))["jeux"]["B-g1"]
        u0 = np.concatenate([(np.array(j["parametres_liste"]) - B.W.BAS) / (B.W.HAUT - B.W.BAS),
                             (np.array(j["placement"]) - B.P.BAS_PL) / (B.P.HAUT_PL - B.P.BAS_PL), [(j["gain_moment"] - B.M.BAS_T) / (B.M.HAUT_T - B.M.BAS_T)]])
        cma = CMA(mean=np.clip(u0, 0.02, 0.98), sigma=SIGMA_PRE, population_size=POPULATION, seed=1100, bounds=np.array([[0, 1]] * len(u0)))
        regle = B.regle_regime("R0")
        regle["vitesse_visee"] = ("etroite", None)
        histo = []
        with mp.Pool(14, initializer=B.preparer) as pool:
            for gen in range(a.generations):
                rng = np.random.default_rng(np.random.SeedSequence([1100, gen]))
                conds = [B.tirer_condition(rng, regle) for _ in range(4)]
                xs = [cma.ask() for _ in range(POPULATION)]
                res = pool.map(_tache, [(x, c) for x in xs for c in conds])
                notes = [float(np.mean([res[i * 4 + e][0] for e in range(4)])) for i in range(len(xs))]
                cma.tell([(x, -nt) for x, nt in zip(xs, notes)])
                histo.append(round(float(np.max(notes)), 3))
                journal("pré-entraînement génération %3d : note moyenne %.3f, meilleure %.3f, réussite %.0f %%" % (gen + 1, np.mean(notes), np.max(notes),
                        100 * np.mean([r[1] for r in res])))
            moy = getattr(cma, "mean", None)
            moy = np.clip(moy if moy is not None else cma._mean, 0, 1)
            nominal = [c for c in jeu if c["jeu"] == "nominal"]
            ev = pool.map(_eval, [(moy, c) for c in nominal])
        json.dump({"politique": [float(v) for v in moy], "generations": a.generations, "historique": histo, "evaluation_nominal": ev,
                   "reussite_nominal": round(float(np.mean([e["reussi"] for e in ev])), 3), "avance_moyenne_m": round(float(np.mean([e["avance_m"] for e in ev])), 3)},
                  open(F_PRE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        journal("pré-entraînement fini : réussite au nominal %.0f %%, avance moyenne %.2f m" % (100 * np.mean([e["reussi"] for e in ev]), np.mean([e["avance_m"] for e in ev])))
        return

    noms = a.noms.split(",") if a.noms else None
    d_res = os.path.join(ICI, "resultats-fumee") if a.fumee else D_RES
    os.makedirs(d_res, exist_ok=True)
    with mp.Pool(a.processus, initializer=B.preparer) as pool:
        for cfg in configurations():
            if a.seulement and cfg["lot"] != a.seulement:
                continue
            if noms and cfg["nom"] not in noms:
                continue
            if a.fumee:
                cfg = dict(cfg, generations=a.fumee)
            f_res = os.path.join(d_res, cfg["nom"] + ".json")
            if os.path.exists(f_res):
                continue
            t0 = time.time()
            res = entrainer(pool, cfg, journal)
            u = res["politique_moyenne"]
            ev = pool.map(_eval, [(u, c) for c in jeu], chunksize=4)
            res["evaluation"] = ev
            res["evaluation_resume"] = {j: round(float(np.mean([e["reussi"] for e in ev if e["jeu"] == j])), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")}
            res["minutes"] = round((time.time() - t0) / 60, 1)
            res["machine"] = platform.node()
            json.dump(res, open(f_res, "w", encoding="utf-8"), ensure_ascii=False)
            journal("%s fini en %.1f min ; évaluation : %s" % (cfg["nom"], res["minutes"], res["evaluation_resume"]))
    journal("fini")


if __name__ == "__main__":
    main()
