"""R-117 — l'aiguilleur : à partir de ce que N3 sent pendant ses 2 premières secondes de marche (inclinaisons et leurs vitesses, vitesse du
corps, appuis), reconnaître la condition parmi six (nominal, pente, retard des capteurs, délai de commande, sol mou, vent). Simulé.

40 épisodes par condition (graines 4201 à 4206), la marche pré-entraînée de R-111 ; chaque épisode est arrêté à 2 s (une exception levée par
le rappel vidéo, rattrapée ; banc.py n'est pas modifié). Apprendre : rang pair ; juger : rang impair. Forêt de 200 arbres, graine 117.

Les règles de verdict, fixées ici avant de lancer :
  H168  exactitude sur les épisodes jamais vus >= 0,70
  H169  la pente a le rappel le plus haut (ex æquo compris)
  H170  le retard des capteurs a le rappel le plus bas (ex æquo compris)

    python -X utf8 essai_n3_aiguilleur.py      → resultats/n3-aiguilleur.json"""
import json
import multiprocessing as mp
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ICI, "banc_variance"))
import banc as B  # noqa: E402

CONDITIONS = ["nominal", "pente", "retard_capteur", "delai", "sol_mou", "vent"]
FIN = 2.0


class Assez(Exception):
    pass


def regle(n):
    r = B.regle_regime("R0")
    r["vitesse_visee"] = ("etroite", None)
    if n != "nominal":
        r[n] = ("large", None)
    return r


def _episode(args):
    u, cond = args
    lec = []

    def cb(d):
        w = next(x for x in B._monde.values() if isinstance(x, dict) and x.get("d") is d)
        a, r, va, vr = B.W.attitude(d)
        lec.append([float(d.time), a, r, va, vr, float(d.subtree_com[1][0]), float(d.subtree_com[1][1]),
                    float(B._touche(w, d, "gauche")), float(B._touche(w, d, "droite"))])
        if d.time >= FIN:
            raise Assez()
    try:
        B.rouler(u, cond, video=cb)
    except Assez:
        pass
    L = np.array(lec)
    L = L[L[:, 0] >= 0.2]
    vx, vy = np.gradient(L[:, 5], L[:, 0]), np.gradient(L[:, 6], L[:, 0])
    deux = (L[:, 7] + L[:, 8]) >= 2
    appui = L[:, 7] * 1 + L[:, 8] * 2
    return [float(f) for f in (L[:, 1].mean(), L[:, 1].std(), L[:, 2].mean(), L[:, 2].std(), L[:, 3].mean(), L[:, 3].std(),
                               L[:, 4].mean(), L[:, 4].std(), vx.mean(), vx.std(), vy.mean(), vy.std(), deux.mean(), np.sum(np.diff(appui) != 0))]


def main():
    B.preparer()
    u = np.array(json.load(open(os.path.join(ICI, "banc_variance", "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    taches, y, rang = [], [], []
    for k, n in enumerate(CONDITIONS):
        rng = np.random.default_rng(4201 + k)
        for i in range(40):
            taches.append((u, B.tirer_condition(rng, regle(n))))
            y.append(n)
            rang.append(i)
    with mp.Pool(2, initializer=B.preparer) as pool:
        X = np.array(pool.map(_episode, taches))
    y, rang = np.array(y), np.array(rang)
    A, J = rang % 2 == 0, rang % 2 == 1
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import confusion_matrix
    f = RandomForestClassifier(n_estimators=200, random_state=117).fit(X[A], y[A])
    p = f.predict(X[J])
    exact = float(np.mean(p == y[J]))
    rappel = {n: float(np.mean(p[y[J] == n] == n)) for n in CONDITIONS}
    cm = confusion_matrix(y[J], p, labels=CONDITIONS).tolist()
    noms_f = ["incl. avant moy", "incl. avant é-t", "roulis moy", "roulis é-t", "vit. avant moy", "vit. avant é-t", "vit. roulis moy",
              "vit. roulis é-t", "vitesse x moy", "vitesse x é-t", "vitesse y moy", "vitesse y é-t", "part sur deux pieds", "changements d'appui"]
    imp = sorted(zip(noms_f, f.feature_importances_), key=lambda t: -t[1])
    hmax, hmin = max(rappel.values()), min(rappel.values())
    verdicts = {"H168": {"exactitude": round(exact, 3), "verdict": "confirmée" if exact >= 0.70 else "réfutée"},
                "H169": {"rappel_pente": round(rappel["pente"], 3), "verdict": "confirmée" if rappel["pente"] >= hmax else "réfutée"},
                "H170": {"rappel_retard_capteur": round(rappel["retard_capteur"], 3), "verdict": "confirmée" if rappel["retard_capteur"] <= hmin else "réfutée"}}
    print("exactitude %.0f %% (hasard 17 %%)" % (100 * exact), flush=True)
    print("rappels :", {n: round(v, 2) for n, v in rappel.items()}, flush=True)
    print("confusion (lignes = vrai, colonnes = deviné) :", CONDITIONS, flush=True)
    for n, row in zip(CONDITIONS, cm):
        print("  %-15s %s" % (n, row), flush=True)
    print("importance :", [(n, round(v, 3)) for n, v in imp[:6]], flush=True)
    print("verdicts :", json.dumps(verdicts, ensure_ascii=False), flush=True)
    json.dump({"conditions": CONDITIONS, "exactitude": exact, "rappels": rappel, "confusion": cm, "importance": imp, "verdicts": verdicts,
               "mesures": X.tolist(), "etiquettes": y.tolist(), "rang": rang.tolist()},
              open(os.path.join(ICI, "resultats", "n3-aiguilleur.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("écrit resultats/n3-aiguilleur.json", flush=True)


if __name__ == "__main__":
    main()
