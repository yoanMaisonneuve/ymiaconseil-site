"""R-113 — sentir la chute venir : le centre de masse et le point de capture (ξ = c + v / ω) par rapport au polygone d'appui (l'enveloppe des
contacts pieds-sol), lus toutes les 0,04 s dans la marche pré-entraînée de R-111 ; au nominal, sous poussées (R-112), sous variance étroite
(diagnostic de R-111). L'alarme : hors du polygone de plus de 3 cm pendant au moins 3 lectures de suite (0,12 s). Simulé.

Deux mesures du polygone d'appui (cahier § 3 bis) : « contacts » (l'enveloppe des points de contact ; la première, à 10:20) et « semelles »
(pour chaque pied qui touche, les sommets de son maillage à moins de 1 cm du plus bas, projetés au sol ; la deuxième, prédite à 10:22).

    python -X utf8 essai_n3_capture.py        → resultats/n3-capture.json, deux films (une chute annoncée, une poussée rattrapée)"""
import json
import math
import multiprocessing as mp
import os
import sys

import mujoco
import numpy as np
from scipy.spatial import ConvexHull

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ICI, "banc_variance"))
import banc as B  # noqa: E402

D_BANC = os.path.join(ICI, "banc_variance")
MARGE, N_SUITE, T_DEBUT = 0.03, 3, 1.0
OMEGA = math.sqrt(9.81 / 0.7617)                              # R-112 : z0 mesuré dans la marche pré-entraînée


def _monde_de(d):
    return next(w for w in B._monde.values() if w["d"] is d)


def appuis(w, d):
    pi, mo = set(w["pieds"]["gauche"]) | set(w["pieds"]["droite"]), set(w["monde"])
    return [d.contact[i].pos[:2].copy() for i in range(d.ncon)
            if (d.contact[i].geom1 in pi and d.contact[i].geom2 in mo) or (d.contact[i].geom2 in pi and d.contact[i].geom1 in mo)]


SEMELLE = 0.01
_verts = {}


def semelles(w, d):
    """Les sommets des semelles des pieds qui touchent : à moins de SEMELLE du plus bas sommet du pied, projetés au sol."""
    m, mo, out = w["m"], set(w["monde"]), []
    for cote in ("gauche", "droite"):
        pi = set(w["pieds"][cote])
        if not any((d.contact[i].geom1 in pi and d.contact[i].geom2 in mo) or (d.contact[i].geom2 in pi and d.contact[i].geom1 in mo) for i in range(d.ncon)):
            continue
        for g in w["pieds"][cote]:
            cle = (id(m), g)
            if cle not in _verts:
                mid = m.geom_dataid[g]
                _verts[cle] = m.mesh_vert[m.mesh_vertadr[mid]:m.mesh_vertadr[mid] + m.mesh_vertnum[mid]].copy()
            V = d.geom_xpos[g] + _verts[cle] @ d.geom_xmat[g].reshape(3, 3).T
            out.extend(V[V[:, 2] <= V[:, 2].min() + SEMELLE][:, :2])
    return out


def _seg(p, a, b):
    ab = b - a
    t = 0.0 if ab @ ab < 1e-12 else float(np.clip((p - a) @ ab / (ab @ ab), 0, 1))
    return float(np.linalg.norm(p - (a + t * ab)))


def distance(p, pts):
    """Distance signée de p au polygone d'appui (négative dedans) ; 1 m s'il n'y a aucun appui (en l'air)."""
    if len(pts) == 0:
        return 1.0, []
    P = np.array(pts)
    if len(P) >= 3:
        try:
            h = ConvexHull(P)
            V = P[h.vertices]
            d_bord = min(_seg(p, V[i], V[(i + 1) % len(V)]) for i in range(len(V)))
            dedans = all((V[(i + 1) % len(V)] - V[i])[0] * (p - V[i])[1] - (V[(i + 1) % len(V)] - V[i])[1] * (p - V[i])[0] >= 0 for i in range(len(V)))
            return (-d_bord if dedans else d_bord), V
        except Exception:
            pass
    i, j = max(((i, j) for i in range(len(P)) for j in range(len(P))), key=lambda ij: np.linalg.norm(P[ij[0]] - P[ij[1]]))
    return _seg(p, P[i], P[j]), P[[i, j]]


def _episode(args):
    u, cond = args
    serie = []

    def cb(d):
        w = _monde_de(d)
        m = w["m"]
        mujoco.mj_subtreeVel(m, d)                             # ne touche que subtree_linvel et subtree_angmom (lus par les capteurs seulement)
        c = d.subtree_com[1][:2].copy()
        xi = c + d.subtree_linvel[1][:2] / OMEGA
        pts = appuis(w, d)
        dc, _ = distance(c, pts)
        dx, _ = distance(xi, pts)
        sem = semelles(w, d)
        sc_, _ = distance(c, sem)
        sx_, _ = distance(xi, sem)
        serie.append((float(d.time), dc, dx, len(pts), sc_, sx_))
    r = B.rouler(u, cond, video=cb)
    return {"resultat": {k: r[k] for k in ("reussi", "tombe", "chute_s", "avance_m")}, "serie": serie}


def alarme(serie, col):
    """Le début de la première sortie de plus de MARGE pendant N_SUITE lectures de suite, après T_DEBUT."""
    k = 0
    for i, s in enumerate(serie):
        if s[0] >= T_DEBUT and s[col] > MARGE:
            k += 1
            if k >= N_SUITE:
                return serie[i - N_SUITE + 1][0]
        else:
            k = 0
    return None


def filmer(u, cond, chemin):
    import imageio.v2 as iio
    rg = np.random.default_rng(int(cond["graine"]))
    rg.integers(0, 2 ** 31 - 1)
    w = B._choisir_modele(cond["axes"]["relief"], rg)
    m = w["m"]
    rgba0 = m.geom_rgba.copy()
    m.geom_rgba[m.geom_bodyid != 0, 3] = 0.3
    off0 = (m.vis.global_.offwidth, m.vis.global_.offheight)
    m.vis.global_.offwidth, m.vis.global_.offheight = 1280, 960
    rend, cam = mujoco.Renderer(m, 960, 1280), mujoco.MjvCamera()
    LIME, CYAN, ROUGE, BLANC = (np.array(x, np.float32) for x in ([0.72, 0.95, 0.18, 1], [0.10, 0.85, 1.0, 1], [1.0, 0.18, 0.12, 1], [1, 1, 1, 0.9]))
    frames, etat = [], {"k": 0}

    def g_(sc):
        if sc.ngeom >= sc.maxgeom:
            return None
        sc.ngeom += 1
        return sc.geoms[sc.ngeom - 1]

    def trait(sc, a, b, rgba, larg):
        g = g_(sc)
        if g is not None:
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_CAPSULE, np.zeros(3), np.zeros(3), np.eye(3).flatten(), rgba)
            mujoco.mjv_connector(g, mujoco.mjtGeom.mjGEOM_CAPSULE, larg, np.array(a, float), np.array(b, float))

    def disque(sc, xy, rgba, r, z):
        g = g_(sc)
        if g is not None:
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_CYLINDER, np.array([r, 0.004, 0.0]), np.array([xy[0], xy[1], z]), np.eye(3).flatten(), rgba)

    def cb(d):
        mujoco.mj_subtreeVel(m, d)
        c3 = d.subtree_com[1].copy()
        xi = c3[:2] + d.subtree_linvel[1][:2] / OMEGA
        pts = semelles(w, d)
        _, V = distance(c3[:2], pts)
        dx, _ = distance(xi, pts)
        etat["k"] = etat["k"] + 1 if (d.time >= T_DEBUT and dx > MARGE) else 0
        cam.distance, cam.azimuth, cam.elevation = 2.9, 215, -24
        cam.lookat[:] = [c3[0], c3[1], 0.66]
        rend.update_scene(d, camera=cam)
        sc = rend.scene
        V = list(V)
        for i in range(len(V)):                                  # le polygone d'appui (blanc)
            a, b = V[i], V[(i + 1) % len(V)]
            if len(V) > 2 or i == 0:
                trait(sc, [a[0], a[1], 0.014], [b[0], b[1], 0.014], BLANC, 0.006)
        trait(sc, c3, [c3[0], c3[1], 0.008], LIME, 0.012)       # le centre de masse et son fil
        disque(sc, c3[:2], LIME, 0.06, 0.012)
        alarme_ = etat["k"] >= N_SUITE
        trait(sc, [c3[0], c3[1], 0.016], [xi[0], xi[1], 0.016], ROUGE if alarme_ else CYAN, 0.012)
        disque(sc, xi, ROUGE if alarme_ else CYAN, 0.07 if alarme_ else 0.055, 0.018)   # le point de capture : rouge quand l'alarme sonne
        g = g_(sc)
        if g is not None:
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_SPHERE, np.array([0.05] * 3), c3, np.eye(3).flatten(), LIME)
        frames.append(rend.render().copy())
    try:
        r = B.rouler(u, cond, video=cb)
    finally:
        m.geom_rgba[:] = rgba0
        m.vis.global_.offwidth, m.vis.global_.offheight = off0
    iio.mimsave(chemin, frames, fps=25, macro_block_size=1)
    return {k: r[k] for k in ("reussi", "tombe", "chute_s", "avance_m")}


def main():
    B.preparer()
    u = np.array(json.load(open(os.path.join(D_BANC, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    jeu = json.load(open(os.path.join(D_BANC, "eval", "jeu_evaluation.json"), encoding="utf-8"))
    lots = {"nominal": [c for c in jeu if c["jeu"] == "nominal"]}
    rng = np.random.default_rng(112)
    r = B.regle_regime("R0")
    r["poussees"] = ("large", None)
    r["vitesse_visee"] = ("etroite", None)
    lots["poussees"] = [B.tirer_condition(rng, r) for _ in range(50)]
    rng = np.random.default_rng(2001)
    lots["etroite"] = [B.tirer_condition(rng, B.regle_regime("R1")) for _ in range(50)]
    taches, cles = [], []
    for k, cs in lots.items():
        for i, c in enumerate(cs):
            taches.append((u, c))
            cles.append((k, i))
    with mp.Pool(3, initializer=B.preparer) as pool:
        res = pool.map(_episode, taches)
    def resumer(cc, cx):
        eps = []
        for (k, i), x in zip(cles, res):
            s_ = x["serie"]
            a_xi, a_cm = alarme(s_, cx), alarme(s_, cc)
            t_chute = x["resultat"]["chute_s"]
            dedans = [q for q in s_ if 2.0 <= q[0] <= 10.0]
            eps.append({"lot": k, "i": i, **x["resultat"], "alarme_xi": a_xi, "alarme_cm": a_cm,
                        "avance_xi": (t_chute - a_xi) if (t_chute is not None and a_xi is not None and a_xi <= t_chute) else None,
                        "avance_cm": (t_chute - a_cm) if (t_chute is not None and a_cm is not None and a_cm <= t_chute) else None,
                        "part_cm_dedans": round(float(np.mean([q[cc] <= 0 for q in dedans])), 3) if dedans else None,
                        "part_xi_dedans": round(float(np.mean([q[cx] <= 0 for q in dedans])), 3) if dedans else None,
                        "part_sans_appui": round(float(np.mean([q[3] == 0 for q in dedans])), 3) if dedans else None})
        nom = [e for e in eps if e["lot"] == "nominal"]
        chutes = [e for e in eps if e["lot"] != "nominal" and e["tombe"]]
        debout = [e for e in eps if e["lot"] != "nominal" and not e["tombe"]]
        deux = [e for e in chutes if e["avance_xi"] is not None and e["avance_cm"] is not None]
        r_ = {"nominal_part_cm_dedans": round(float(np.mean([e["part_cm_dedans"] for e in nom])), 3),
              "nominal_part_xi_dedans": round(float(np.mean([e["part_xi_dedans"] for e in nom])), 3),
              "nominal_part_sans_appui": round(float(np.mean([e["part_sans_appui"] for e in nom])), 3),
              "chutes": len(chutes), "debout": len(debout),
              "part_chutes_annoncees_0_3s": float(np.mean([(e["avance_xi"] is not None and e["avance_xi"] >= 0.3) for e in chutes])) if chutes else None,
              "part_fausses_alarmes": float(np.mean([e["alarme_xi"] is not None for e in debout])) if debout else None,
              "chutes_deux_alarmes": len(deux),
              "avance_mediane_xi_s": float(np.median([e["avance_xi"] for e in deux])) if deux else None,
              "avance_mediane_cm_s": float(np.median([e["avance_cm"] for e in deux])) if deux else None,
              "avances_xi": sorted(round(e["avance_xi"], 2) for e in chutes if e["avance_xi"] is not None),
              "chutes_sans_alarme_xi": sum(e["alarme_xi"] is None or e["avance_xi"] is None for e in chutes)}
        return r_, eps, chutes, debout
    resume_c, eps_c, _, _ = resumer(1, 2)
    resume, eps, chutes, debout = resumer(4, 5)
    print("contacts :", json.dumps(resume_c, ensure_ascii=False), flush=True)
    print("semelles :", json.dumps(resume, ensure_ascii=False), flush=True)
    # les films : la chute la mieux annoncée (avance la plus proche de 1 s), et une poussée rattrapée où l'alarme n'a pas sonné
    films = {}
    cand = sorted([e for e in chutes if e["avance_xi"] is not None], key=lambda e: abs(e["avance_xi"] - 1.0))
    if cand:
        e = cand[0]
        films["chute"] = dict(e=e["lot"] + ":" + str(e["i"]), **filmer(u, lots[e["lot"]][e["i"]], os.path.join(ICI, "resultats", "n3-capture-chute.mp4")))
    cand = [e for e in debout if e["lot"] == "poussees" and e["alarme_xi"] is None and e["reussi"]]
    if cand:
        e = cand[0]
        films["rattrapee"] = dict(e=e["lot"] + ":" + str(e["i"]), **filmer(u, lots[e["lot"]][e["i"]], os.path.join(ICI, "resultats", "n3-capture-rattrapee.mp4")))
    print("films", films, flush=True)
    json.dump({"resume_semelles": resume, "resume_contacts": resume_c, "episodes_semelles": eps, "episodes_contacts": eps_c, "films": films,
               "semelle_m": SEMELLE, "marge_m": MARGE, "lectures_de_suite": N_SUITE, "omega": OMEGA,
               "series_nominal_0": res[0]["serie"]}, open(os.path.join(ICI, "resultats", "n3-capture.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1, default=float)
    print("écrit resultats/n3-capture.json", flush=True)


if __name__ == "__main__":
    main()
