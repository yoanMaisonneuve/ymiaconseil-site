"""R-115 — le réflexe : quand l'inclinaison du torse dépasse 9,8° pendant 0,12 s (l'alarme de R-114), un geste proportionnel s'ajoute à la
marche (hanches et chevilles de côté, hanches d'avant en arrière, s'accroupir, épaules), appris par CMA-ES sur une moitié des épisodes de
R-114, jugé sur l'autre moitié. Le geste passe par la même chaîne de commande que la marche (on enveloppe commun.consigne pendant
l'épisode ; banc.py n'est pas modifié). Simulé.

    python -X utf8 essai_n3_reflexe.py        → resultats/n3-reflexe.json, un film (une chute évitée)"""
import json
import math
import multiprocessing as mp
import os
import sys

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import essai_n3_alarme as Al  # noqa: E402

Cap, B = Al.Cap, Al.B
SEUIL, MAINTIEN, N_PAS, CIBLE = 9.8, 0.7, 12, 5.0
BORNES = np.array([[-3, 3], [-3, 3], [-3, 3], [0, 30], [-5, 5]], float)   # k1 hanches, k2 chevilles, k3 tangage, c accroupi, k5 épaules
_orig = B.C.consigne
_etat = {"k": 0, "actif": False, "g": None, "fois": 0}
_par_m = {}


def gains(x):
    return BORNES[:, 0] + np.clip(np.asarray(x, float), 0, 1) * (BORNES[:, 1] - BORNES[:, 0])


def _consigne(m, pose, sg=None):
    """La commande de la marche, plus le réflexe quand l'alarme d'inclinaison sonne."""
    g = _etat["g"]
    if g is not None:
        if not _par_m:
            _par_m.update({id(w["m"]): w for w in B._monde.values() if isinstance(w, dict) and "m" in w})
        d = _par_m[id(m)]["d"]
        a, r, va, vr = B.W.attitude(d)
        incl = math.hypot(a, r)
        if not _etat["actif"]:
            _etat["k"] = _etat["k"] + 1 if (d.time >= 1.0 and incl > SEUIL) else 0
            if _etat["k"] >= N_PAS:
                _etat["actif"] = True
                _etat["fois"] += 1
        elif incl < MAINTIEN * SEUIL:
            _etat["actif"], _etat["k"] = False, 0
        if _etat["actif"]:
            k1, k2, k3, c, k5 = g
            pose = dict(pose)
            for s in ("g", "d"):
                pose["hanche_roulis_" + s] = pose.get("hanche_roulis_" + s, 0.0) + k1 * r
                pose["cheville_roulis_" + s] = pose.get("cheville_roulis_" + s, 0.0) + k2 * r
                pose["hanche_tangage_" + s] = pose.get("hanche_tangage_" + s, 0.0) + k3 * (a - CIBLE) - c
                pose["genou_" + s] = pose.get("genou_" + s, 0.0) + 2 * c
                pose["cheville_tangage_" + s] = pose.get("cheville_tangage_" + s, 0.0) - c
                pose["epaule_roulis_" + s] = pose.get("epaule_roulis_" + s, 0.0) + k5 * r
    return _orig(m, pose, sg)


def jouer(u, cond, g, video=None):
    _etat.update(k=0, actif=False, g=g, fois=0)
    B.C.consigne = _consigne
    try:
        r = B.rouler(u, cond, video=video)
    finally:
        B.C.consigne = _orig
        _etat["g"] = None
    return {"tombe": bool(r["tombe"]), "chute_s": r["chute_s"], "avance_m": r["avance_m"], "reflexes": _etat["fois"]}


def _tache(args):
    u, cond, g = args
    return jouer(u, cond, g)


def main():
    B.preparer()
    u = np.array(json.load(open(os.path.join(Cap.D_BANC, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    al = json.load(open(os.path.join(ICI, "resultats", "n3-alarme.json"), encoding="utf-8"))
    lots = {}                                                  # les mêmes conditions que R-114 (mêmes graines, même ordre de tirage)
    for nom, graine, regle in (("etroite", 3001, B.regle_regime("R1")), ("large", 3002, B.regle_regime("R2")), ("poussees", 3003, None), ("nominal", 3004, None)):
        rng = np.random.default_rng(graine)
        if regle is None:
            regle = B.regle_regime("R0")
            regle["vitesse_visee"] = ("etroite", None)
            if nom == "poussees":
                regle["poussees"] = ("large", None)
        lots[nom] = [B.tirer_condition(rng, regle) for _ in range(30 if nom == "nominal" else 100)]
    eps = al["episodes"]
    A = [e for e in eps if e["apprendre"]]
    J = [e for e in eps if not e["apprendre"]]
    rs = np.random.default_rng(3115)
    ch = [e for e in A if e["tombe"]]
    de = [e for e in A if not e["tombe"]]
    L = [ch[i] for i in rs.choice(len(ch), 40, replace=False)] + [de[i] for i in rs.choice(len(de), 20, replace=False)]
    condL = [lots[e["lot"]][e["i"]] for e in L]
    condJ = [lots[e["lot"]][e["i"]] for e in J]
    from cmaes import CMA
    x0 = (0 - BORNES[:, 0]) / (BORNES[:, 1] - BORNES[:, 0])   # aucun réflexe
    cma = CMA(mean=x0, sigma=0.2, population_size=8, seed=1150, bounds=np.array([[0, 1]] * 5))
    histo, meilleur = [], (1e9, None)
    with mp.Pool(3, initializer=B.preparer) as pool:
        zero = pool.map(_tache, [(u, c, gains(x0)) for c in condL])
        print("sans réflexe (gains nuls), apprentissage : %d chutes sur %d" % (sum(z["tombe"] for z in zero), len(zero)), flush=True)
        for gen in range(12):
            xs = [cma.ask() for _ in range(8)]
            res = pool.map(_tache, [(u, c, gains(x)) for x in xs for c in condL], chunksize=4)
            notes = [sum(res[i * len(condL) + k]["tombe"] for k in range(len(condL))) for i in range(len(xs))]
            cma.tell([(x, float(n)) for x, n in zip(xs, notes)])
            i = int(np.argmin(notes))
            if notes[i] < meilleur[0]:
                meilleur = (notes[i], [float(v) for v in xs[i]])
            histo.append({"gen": gen + 1, "chutes_min": int(min(notes)), "chutes_moy": round(float(np.mean(notes)), 2)})
            print("génération %2d : chutes sur %d — meilleure %d, moyenne %.1f" % (gen + 1, len(condL), min(notes), np.mean(notes)), flush=True)
        moy = np.clip(getattr(cma, "mean", None) if getattr(cma, "mean", None) is not None else cma._mean, 0, 1)
        # le réflexe retenu : la moyenne de CMA et le meilleur candidat, rejoués sur l'apprentissage ; on garde le moins de chutes
        r_moy = pool.map(_tache, [(u, c, gains(moy)) for c in condL])
        n_moy = sum(z["tombe"] for z in r_moy)
        retenu = ("moyenne", moy) if n_moy <= meilleur[0] else ("meilleur candidat", np.array(meilleur[1]))
        g = gains(retenu[1])
        print("retenu : %s, %d chutes à l'apprentissage ; gains %s" % (retenu[0], min(n_moy, meilleur[0]), np.round(g, 2).tolist()), flush=True)
        jz = pool.map(_tache, [(u, c, gains(x0)) for c in condJ])
        jr = pool.map(_tache, [(u, c, g) for c in condJ])
    tombaient = [k for k, e in enumerate(J) if jz[k]["tombe"]]
    tenaient = [k for k, e in enumerate(J) if not jz[k]["tombe"]]
    evitees = [k for k in tombaient if not jr[k]["tombe"]]
    causees = [k for k in tenaient if jr[k]["tombe"]]
    accord = sum(jz[k]["tombe"] == e["tombe"] for k, e in enumerate(J))
    out = {"gains": {"k1_hanches": g[0], "k2_chevilles": g[1], "k3_tangage": g[2], "c_accroupi_deg": g[3], "k5_epaules": g[4]},
           "retenu": retenu[0], "historique": histo,
           "apprendre": {"episodes": len(condL), "chutes_sans": int(sum(z["tombe"] for z in zero)), "chutes_avec": int(min(n_moy, meilleur[0]))},
           "juger": {"episodes": len(J), "tombaient": len(tombaient), "evitees": len(evitees), "part_evitees": round(len(evitees) / len(tombaient), 3),
                     "tenaient": len(tenaient), "causees": len(causees), "part_causees": round(len(causees) / len(tenaient), 3),
                     "accord_avec_R114": accord},
           "detail_juger": [{"lot": e["lot"], "i": e["i"], "sans": jz[k], "avec": jr[k]} for k, e in enumerate(J)]}
    j = out["juger"]
    print("jugé : %d chutes évitées sur %d (%.0f %%) ; %d chutes causées sur %d (%.0f %%) ; accord du témoin avec R-114 : %d sur %d"
          % (j["evitees"], j["tombaient"], 100 * j["part_evitees"], j["causees"], j["tenaient"], 100 * j["part_causees"], accord, len(J)), flush=True)
    # le film : une chute jamais vue évitée par le réflexe (sinon, la première chute jamais vue)
    k = evitees[0] if evitees else (tombaient[0] if tombaient else 0)
    e = J[k]
    out["film"] = {"episode": "%s:%d" % (e["lot"], e["i"]), **filmer(u, condJ[k], g, os.path.join(ICI, "resultats", "n3-reflexe.mp4")),
                   "evitee": k in evitees}
    print("film", out["film"], flush=True)
    json.dump(out, open(os.path.join(ICI, "resultats", "n3-reflexe.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=float)
    print("écrit resultats/n3-reflexe.json", flush=True)


def filmer(u, cond, g, chemin):
    """Le film : la lampe au-dessus de la tête, verte, devient rouge tant que le réflexe agit ; semelles, centre de masse, point de capture."""
    import imageio.v2 as iio
    rg = np.random.default_rng(int(cond["graine"]))
    rg.integers(0, 2 ** 31 - 1)
    w = B._choisir_modele(cond["axes"]["relief"], rg)
    m = w["m"]
    rgba0 = m.geom_rgba.copy()
    m.geom_rgba[m.geom_bodyid != 0, 3] = 0.3
    off0 = (m.vis.global_.offwidth, m.vis.global_.offheight)
    m.vis.global_.offwidth, m.vis.global_.offheight = 1280, 960
    rend, cam = mujoco.Renderer(m, 960, 1280), mujoco.MjvCamera()
    LIME, CYAN, ROUGE, BLANC, VERT = (np.array(x, np.float32) for x in ([0.72, 0.95, 0.18, 1], [0.10, 0.85, 1.0, 1], [1.0, 0.18, 0.12, 1], [1, 1, 1, 0.9], [0.2, 0.85, 0.35, 1]))
    frames = []

    def g_(sc):
        if sc.ngeom >= sc.maxgeom:
            return None
        sc.ngeom += 1
        return sc.geoms[sc.ngeom - 1]

    def objet(sc, typ, taille, pos, rgba):
        gg = g_(sc)
        if gg is not None:
            mujoco.mjv_initGeom(gg, typ, np.array(taille, float), np.array(pos, float), np.eye(3).flatten(), rgba)

    def trait(sc, a, b, rgba, larg):
        gg = g_(sc)
        if gg is not None:
            mujoco.mjv_initGeom(gg, mujoco.mjtGeom.mjGEOM_CAPSULE, np.zeros(3), np.zeros(3), np.eye(3).flatten(), rgba)
            mujoco.mjv_connector(gg, mujoco.mjtGeom.mjGEOM_CAPSULE, larg, np.array(a, float), np.array(b, float))

    def cb(d):
        mujoco.mj_subtreeVel(m, d)
        c3 = d.subtree_com[1].copy()
        xi = c3[:2] + d.subtree_linvel[1][:2] / Cap.OMEGA
        _, V = Cap.distance(c3[:2], Cap.semelles(w, d))
        cam.distance, cam.azimuth, cam.elevation = 3.0, 215, -22
        cam.lookat[:] = [c3[0], c3[1], 0.72]
        rend.update_scene(d, camera=cam)
        sc = rend.scene
        V = list(V)
        for i in range(len(V)):
            if len(V) > 2 or i == 0:
                a_, b_ = V[i], V[(i + 1) % len(V)]
                trait(sc, [a_[0], a_[1], 0.014], [b_[0], b_[1], 0.014], BLANC, 0.006)
        trait(sc, c3, [c3[0], c3[1], 0.008], LIME, 0.012)
        objet(sc, mujoco.mjtGeom.mjGEOM_SPHERE, [0.05] * 3, c3, LIME)
        objet(sc, mujoco.mjtGeom.mjGEOM_CYLINDER, [0.055, 0.004, 0], [xi[0], xi[1], 0.018], CYAN)
        actif = _etat["actif"]
        objet(sc, mujoco.mjtGeom.mjGEOM_SPHERE, [0.07 if actif else 0.05] * 3, [c3[0], c3[1], 1.72], ROUGE if actif else VERT)
        frames.append(rend.render().copy())
    try:
        r = jouer(u, cond, g, video=cb)
    finally:
        m.geom_rgba[:] = rgba0
        m.vis.global_.offwidth, m.vis.global_.offheight = off0
    iio.mimsave(chemin, frames, fps=25, macro_block_size=1)
    return r


if __name__ == "__main__":
    main()
