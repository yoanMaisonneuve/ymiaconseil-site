"""R-115 — le témoin du film : le même épisode (variance étroite, condition 13) sans réflexe (gains nuls) ; la lampe s'allume quand l'alarme
sonne, mais rien ne bouge en plus. Simulé."""
import json
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import essai_n3_reflexe as R  # noqa: E402

if __name__ == "__main__":
    R.B.preparer()
    u = np.array(json.load(open(os.path.join(R.Cap.D_BANC, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    rng = np.random.default_rng(3001)
    lot = [R.B.tirer_condition(rng, R.B.regle_regime("R1")) for _ in range(100)]
    x0 = (0 - R.BORNES[:, 0]) / (R.BORNES[:, 1] - R.BORNES[:, 0])
    f = R.filmer(u, lot[13], R.gains(x0), os.path.join(ICI, "resultats", "n3-reflexe-temoin.mp4"))
    print("film n3-reflexe-temoin.mp4", f, flush=True)
