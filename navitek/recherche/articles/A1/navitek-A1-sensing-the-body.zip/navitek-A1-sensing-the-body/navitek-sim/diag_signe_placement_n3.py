"""R-112 — vérifier le sens du placement du pied dans N3, deux façons : (1) le montage des actionneurs de hanche (gear, signe de la commande) ;
(2) dynamiquement : N3 debout, la consigne de tangage de la hanche gauche augmentée de +10° puis -10° par la vraie chaîne de commande
(commun.consigne), le pied gauche soulevé du sol par le seul mouvement : où va-t-il en x ? Simulé, aucun apprentissage."""
import os
import sys

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ICI, "banc_variance"))
import banc as B  # noqa: E402


def main():
    B.preparer()
    w = B._monde["plat"]
    m, d = w["m"], w["d"]
    sg = B.W._sg
    for i, n in enumerate(B.C.noms(m)):
        k = B.C.court(n)
        if k.startswith("hanche_tangage") or k.startswith("hanche_roulis"):
            print(k, "gear", m.actuator_gear[i][:1], "signe de la commande", sg.get(k, 1), "biais", m.actuator_biasprm[i][:3], "joint",
                  mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_JOINT, m.actuator_trnid[i, 0]), flush=True)
    # la dynamique : on suspend le torse (le robot en l'air, jambes libres), on commande la pose, et on regarde où va le pied
    for val in (-10.0, 10.0):
        B._restaurer(w)
        mujoco.mj_resetData(m, d)
        pose = {}
        pose["hanche_tangage_g"] = val
        c = B.C.consigne(m, pose, sg)
        for _ in range(4000):                                # 2 s, le torse tenu en place par une force qui annule la gravité
            d.qpos[:3] = [0.0, 0.0, 1.2]
            d.qpos[3:7] = [1, 0, 0, 0]
            d.qvel[:6] = 0.0
            d.ctrl[:] = c
            mujoco.mj_step(m, d)
        pg = np.mean([d.geom_xpos[g] for g in w["pieds"]["gauche"]], axis=0)
        pd = np.mean([d.geom_xpos[g] for g in w["pieds"]["droite"]], axis=0)
        print("pose hanche_tangage_g %+.0f° : pied gauche x %+.3f m (le droit %+.3f m) ; tronc en x %+.3f" % (val, pg[0], pd[0], d.qpos[0]), flush=True)


if __name__ == "__main__":
    main()
