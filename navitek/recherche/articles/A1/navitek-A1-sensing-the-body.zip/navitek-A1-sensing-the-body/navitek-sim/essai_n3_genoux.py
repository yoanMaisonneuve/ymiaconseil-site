"""R-081 — N3 plie les genoux : les fentes avant (A), marcher en fente (B), des marches à trois hauteurs d'épaules (C). Tout est simulé.

    python -X utf8 essai_n3_genoux.py hauteurs|marche-fente|fentes [--video]
Le mode est aussi lu dans N3_GENOUX (les processus de calcul le relisent au chargement). Sorties : resultats/n3-genoux.json,
resultats/n3-genoux-<mode>*.json, et avec --video resultats/n3-genoux-<mode>.mp4."""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C
import essai_n3_marche as W

RES = os.path.join(C.ICI, "resultats")
MODE = os.environ.get("N3_GENOUX", "hauteurs")
CIBLE_H = float(os.environ.get("N3_HAUTEUR", "0.90"))
CIBLE_T = float(os.environ.get("N3_TORSE", "5.0"))       # R-082 C (H61) : −6, 0, +6, +12
DT = 0.01
_s = {}


def init():
    W.init()
    m, d = W._m, W._d
    nom = lambda t, i: mujoco.mj_id2name(m, t, i) or ""
    _s["sol"] = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, "sol")
    _s["pieds"] = {c: {g for g in range(m.ngeom) if "pied" in nom(mujoco.mjtObj.mjOBJ_GEOM, g)
                       and nom(mujoco.mjtObj.mjOBJ_BODY, m.geom_bodyid[g]).startswith("jambe-" + c)} for c in ("gauche", "droite")}
    _s["corps_pied"] = {c: m.geom_bodyid[next(iter(_s["pieds"][c]))] for c in _s["pieds"]}
    _s["cheville"] = {c: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, "jambe-%s-cheville-tangage" % c) for c in _s["pieds"]}
    art = m.actuator_trnid[:, 0]
    _s["genoux"] = [int(m.jnt_qposadr[art[W._idx["genou_" + c]]]) for c in ("g", "d")]
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    _s["h_com"] = float(d.subtree_com[1][2])
    _s["h_ch"] = {c: float(d.xanchor[_s["cheville"][c]][2]) for c in _s["pieds"]}


def touche(d, c):
    return any((x.geom1 == _s["sol"] and x.geom2 in _s["pieds"][c]) or (x.geom2 == _s["sol"] and x.geom1 in _s["pieds"][c]) for x in d.contact[:d.ncon])


class Observateur:
    """Le genou, la levée des chevilles, la hauteur du centre de masse, le glissement des pieds (toutes les 0,05 s, comme R-079)."""

    def __init__(self, T):
        self.T, self.gen, self.lev, self.hz, self.gl, self.prec, self.t, self.av = T, [], [], [], 0.0, {}, [], []

    def voir(self, d, t):
        self.t.append(t)
        at = W.attitude(d)
        self.av.append(at[0])
        self.ro = getattr(self, "ro", [])
        self.ro.append(at[1])
        self.gen.append(float(np.degrees(np.max(np.abs(d.qpos[_s["genoux"]])))))
        self.lev.append(max(float(d.xanchor[_s["cheville"][c]][2]) - _s["h_ch"][c] for c in _s["pieds"]))
        self.hz.append(float(d.subtree_com[1][2]) / _s["h_com"])
        for c in _s["pieds"]:
            p = d.xpos[_s["corps_pied"][c]][:2].copy()
            if touche(d, c):
                if c in self.prec:
                    self.gl += float(np.linalg.norm(p - self.prec[c]))
                self.prec[c] = p
            else:
                self.prec.pop(c, None)

    def resume(self, dist):
        t, lev, hz = np.array(self.t), np.array(self.lev), np.array(self.hz)
        cycles = [(lev[(t >= a) & (t < a + self.T)], hz[(t >= a) & (t < a + self.T)]) for a in np.arange(2.0, t[-1] - self.T + 1e-9, self.T)] if len(t) else []
        levee = float(np.mean([c[0].max() for c in cycles if len(c[0])])) if cycles else 0.0
        creux = float(np.mean([1.0 - c[1].min() for c in cycles if len(c[1])])) if cycles else 0.0
        return {"genou_max_deg": round(max(self.gen), 1) if self.gen else 0.0, "genou_moyen_deg": round(float(np.mean(self.gen)), 1) if self.gen else 0.0,
                "levee_cheville_cm": round(100 * levee, 1), "hauteur_com": round(float(np.mean(hz)), 3) if len(hz) else 0.0,
                "creux_par_pas": round(creux, 3), "torse_deg": round(float(np.mean(self.av)), 2) if self.av else 0.0, "torse_oscille_deg": round(float(np.std(self.av)), 2) if self.av else None, "roulis_oscille_deg": round(float(np.std(getattr(self, 'ro', [0.0]))), 2), "glissement_m": round(self.gl, 2), "glissement_par_m": round(self.gl / dist, 2) if dist > 0.05 else None}


# ---- B et C : des marches ---------------------------------------------------------------------------------------------------------------
def bornes():
    if MODE == "marche-fente":
        b, h = W.BAS.copy(), W.HAUT.copy()
        b[0], h[0] = 2.0, 4.0           # la période
        b[1], h[1] = 10.0, 40.0         # l'amplitude des hanches
        b[3], h[3] = 10.0, 60.0         # le genou de base
        b[4], h[4] = 20.0, 70.0         # l'amplitude du genou
        return b, h
    return W.BAS, W.HAUT


def marcher(p, trace=False, video=None, duree=None):
    m, d = W._m, W._d
    duree = duree or (20.0 if MODE == "marche-fente" else 12.0)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    x0 = float(d.subtree_com[1][0])
    ob = Observateur(float(p[0]))
    c, chute = np.zeros(m.nu), None
    n_pose, n_obs = int(round(DT / m.opt.timestep)), int(round(0.05 / m.opt.timestep))
    for k in range(int(duree / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            a_, r_, va_, vr_ = W.attitude(d)
            fb = (a_ - CIBLE_T, r_, va_, vr_) if MODE == "basse" else (a_, r_, va_, vr_)     # R-082 : le torse visé (+5° par défaut)
            c = C.consigne(m, W.pose_marche(p, t, fb), W._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if t >= 2.0 and k % n_obs == 0:
            ob.voir(d, t)
        if k % 20 == 0 and C.inclinaison(d) > 40:
            chute = t
            break
        if video is not None and k % int(0.05 / m.opt.timestep) == 0:
            video(d)
    x, y = float(d.subtree_com[1][0]) - x0, float(d.subtree_com[1][1])
    r = ob.resume(max(x, 0.0)) if ob.t else {"genou_max_deg": 0, "levee_cheville_cm": 0, "hauteur_com": 1, "creux_par_pas": 0, "glissement_par_m": None}
    if chute is not None:
        score = chute / duree - 6.0
    elif MODE == "marche-fente":
        score = x - 0.3 * abs(y) + 3.0 * min(r["creux_par_pas"], 0.15)
    elif MODE == "basse":                            # R-082 : des exigences, pas des primes
        gpm = r["glissement_par_m"] if r["glissement_par_m"] is not None else 5.0
        tz = r.get("torse_deg", 0.0)
        score = (x - 0.3 * abs(y) - 0.5 * max(0.0, 100 * r["hauteur_com"] - 100 * CIBLE_H - 1.0)
                 - 0.3 * (max(0.0, CIBLE_T - 3.0 - tz) + max(0.0, tz - CIBLE_T - 3.0)) - 0.3 * max(0.0, 6.0 - r["levee_cheville_cm"]) - 0.5 * gpm)
    else:
        gpm = r["glissement_par_m"] if r["glissement_par_m"] is not None else 5.0
        score = (x - 0.3 * abs(y) + 2.0 * min(r["levee_cheville_cm"] / 100, 0.08) - 0.5 * gpm
                 - 0.1 * max(0.0, abs(100 * r["hauteur_com"] - 100 * CIBLE_H) - 1.0))
    if not trace:
        return -score
    return dict(r, avance_m=round(x, 3), derive_m=round(y, 3), tombe=chute is not None, chute_s=chute, score=round(score, 4))


# ---- A : les fentes ------------------------------------------------------------------------------------------------------------------
F_NOMS = ["hanche_devant", "genou_devant", "hanche_derriere", "genou_derriere", "t_descente", "g_tangage", "g_tangage_v", "torse", "transfert"]
F_BAS = np.array([20.0, 40.0, 0.0, 30.0, 0.8, 0.0, 0.0, 2.0, -15.0])          # R-082 : le torse de +2 à +15° (R-081 : de −5)
COTES = os.environ.get("N3_FENTES", "dg")          # R-082 : « g » la gauche seule ; « dg » enchaînées, 9 réglages par côté
F_HAUT = np.array([60.0, 100.0, 30.0, 90.0, 2.5, 3.0, 0.5, 15.0, 15.0])


def mj(s):
    s = min(max(s, 0.0), 1.0)
    return 10 * s ** 3 - 15 * s ** 4 + 6 * s ** 5


def jambe(pose, cote, hanche_flex, genou, plat=True):
    """hanche_flex > 0 : la cuisse devant (le signe des consignes : − pour fléchir, mesuré dans R-073) ; le pied à plat si plat."""
    h = -hanche_flex
    pose["hanche_tangage_" + cote] = h
    pose["genou_" + cote] = genou
    if plat:
        pose["cheville_tangage_" + cote] = -(genou + h)


def sequence(q):
    """Les poses clés (temps de fin, jambe de devant, réglages des deux jambes, transfert) : droite puis gauche."""
    ev = []
    t = 1.0
    for i_cote, dev in enumerate(COTES):
        qq = q[9 * i_cote:9 * i_cote + 9] if len(q) > 9 else q
        hd, gd, hr, gr, td = qq[0], qq[1], qq[2], qq[3], qq[4]
        arr = "g" if dev == "d" else "d"
        for duree, nom, poses in ((0.6, "lever", {dev: (30.0, 50.0), arr: (0.0, 0.0)}), (0.6, "poser", {dev: (hd, 10.0), arr: (0.0, 0.0)}),
                                  (td, "descendre", {dev: (hd, gd), arr: (-hr, gr)}), (1.0, "tenir", {dev: (hd, gd), arr: (-hr, gr)}),
                                  (td, "remonter", {dev: (hd, 10.0), arr: (0.0, 0.0)}), (0.6, "relever", {dev: (30.0, 50.0), arr: (0.0, 0.0)}),
                                  (0.6, "ramener", {dev: (0.0, 0.0), arr: (0.0, 0.0)}), (0.5, "pause", {dev: (0.0, 0.0), arr: (0.0, 0.0)})):
            ev.append((t, t + duree, dev, nom, poses, qq))
            t += duree
    return ev, t + 0.5


def fentes(q, trace=False, video=None):
    m, d = W._m, W._d
    ev, fin = sequence(q)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    c, chute = np.zeros(m.nu), None
    prec = {"d": (0.0, 0.0), "g": (0.0, 0.0)}
    bas = {"d": {"creux": 0.0, "genou_dev": 0.0, "genou_arr": 0.0, "fini": False}, "g": {"creux": 0.0, "genou_dev": 0.0, "genou_arr": 0.0, "fini": False}}
    n_pose = int(round(DT / m.opt.timestep))
    art = m.actuator_trnid[:, 0]
    adr = {cc: int(m.jnt_qposadr[art[W._idx["genou_" + cc]]]) for cc in ("g", "d")}
    for k in range(int(fin / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            a, r, va, vr = W.attitude(d)
            pose = {}
            cur = None
            qq = q[:9]
            for (t0, t1, dev, nom, poses, qq_) in ev:
                if t0 <= t < t1:
                    cur = (t0, t1, dev, nom, poses)
                    qq = qq_
                    break
            if cur is None:
                for cc in ("g", "d"):
                    jambe(pose, cc, 0.0, 0.0)
            else:
                t0, t1, dev, nom, poses = cur
                s = mj((t - t0) / (t1 - t0))
                for cc in ("g", "d"):
                    h0, g0 = prec[cc]
                    h1, g1 = poses[cc]
                    jambe(pose, cc, h0 + s * (h1 - h0), g0 + s * (g1 - g0))
                    if s >= 1.0 - 1e-9:
                        prec[cc] = (h1, g1)
                # le poids sur la jambe d'appui pendant que l'autre est en l'air
                en_air = nom in ("lever", "poser", "relever", "ramener")
                tr = qq[8] * (1 if dev == "d" else -1) * (np.sin(np.pi * (t - t0) / (t1 - t0)) if nom in ("lever", "ramener") else 1.0) if en_air else 0.0
                for cc in ("g", "d"):
                    pose["hanche_roulis_" + cc] = tr
                    pose["cheville_roulis_" + cc] = -tr
                if nom in ("descendre", "tenir", "remonter"):
                    hz = float(d.subtree_com[1][2]) / _s["h_com"]
                    bas[dev]["creux"] = max(bas[dev]["creux"], 1.0 - hz)
                    arr = "g" if dev == "d" else "d"
                    bas[dev]["genou_dev"] = max(bas[dev]["genou_dev"], abs(float(np.degrees(d.qpos[adr[dev]]))))
                    bas[dev]["genou_arr"] = max(bas[dev]["genou_arr"], abs(float(np.degrees(d.qpos[adr[arr]]))))
                if nom == "pause" and t >= t1 - 0.02:
                    bas[dev]["fini"] = float(d.subtree_com[1][2]) / _s["h_com"] >= 0.93
            corr = qq[5] * (a - qq[7]) + qq[6] * va
            for cc in ("g", "d"):
                pose["cheville_tangage_" + cc] = pose.get("cheville_tangage_" + cc, 0.0) + corr
            c = C.consigne(m, pose, W._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0 and C.inclinaison(d) > 40:
            chute = t
            break
        if video is not None and k % int(0.05 / m.opt.timestep) == 0:
            video(d)
    score = -6.0 + (chute or 0) / fin if chute is not None else sum((1.0 + 5.0 * min(b["creux"], 0.2)) * (1.0 if b["fini"] else 0.3) for b in bas.values())
    if not trace:
        return -score
    return {"tombe": chute is not None, "chute_s": chute, "duree_s": round(fin, 1),
            "fente_droite": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in bas["d"].items()},
            "fente_gauche": {k: (round(v, 3) if isinstance(v, float) else v) for k, v in bas["g"].items()}, "score": round(score, 4)}


# ---- R-082 D : la chute rattrapée -----------------------------------------------------------------------------------------------------
R_NOMS = ["seuil", "genou_leve", "hanche_pas", "genou_fente", "bras_ouverts", "g_tangage", "g_tangage_v", "transfert", "duree_pas", "torse_fente"]
R_BAS = np.array([5.0, 40.0, 20.0, 40.0, 0.0, 0.0, 0.0, -15.0, 0.3, 0.0])
R_HAUT = np.array([25.0, 100.0, 60.0, 100.0, 90.0, 3.0, 0.5, 15.0, 1.0, 15.0])
BRAS_FORCES = os.environ.get("N3_BRAS")             # « bas » : les bras le long du corps (H63)
CP = os.environ.get("N3_RATTRAPE") == "cp"          # R-082 D' (Yoan, 15:06) : plier le genou d'appui, poser le pied au point de capture
if CP:
    R_NOMS = R_NOMS[:2] + ["gain_capture"] + R_NOMS[3:] + ["genou_appui_plie"]
    R_BAS = np.concatenate([R_BAS[:2], [0.6], R_BAS[3:], [0.0]])
    R_HAUT = np.concatenate([R_HAUT[:2], [1.6], R_HAUT[3:], [45.0]])


def rattraper(q, trace=False, video=None):
    """Se laisser tomber vers l'avant ; au seuil, lever le genou, poser le pied en fente, ouvrir les bras ; se relever ; l'autre côté."""
    seuil, gk, hp, gf, bras, gt, gtv, tr_max, tp, tf = q[:10]
    kd0 = float(q[10]) if CP else 5.0          # D' : le genou d'appui plie dès la chute sentie
    gain_cp, hp_fixe = (hp, None) if CP else (None, hp)
    if BRAS_FORCES == "bas":
        bras = 0.0
    m, d = W._m, W._d
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    n_pose = int(round(DT / m.opt.timestep))
    art = m.actuator_trnid[:, 0]
    adr = {cc: int(m.jnt_qposadr[art[W._idx["genou_" + cc]]]) for cc in ("g", "d")}
    cotes = [{"cote": c, "declenche_s": None, "rattrape": False, "genou_dev": 0.0, "creux": 0.0} for c in ("d", "g")]
    i_c, etat, t0, chute, c, cible = 0, "attente", 0.5, None, np.zeros(m.nu), 0.0
    com_prec = None
    duree_max = 40.0
    for k in range(int(duree_max / m.opt.timestep)):
        t = k * m.opt.timestep
        if i_c >= 2:
            break
        if k % n_pose == 0:
            a, r, va, vr = W.attitude(d)
            com = d.subtree_com[1].copy()
            vx = 0.0 if com_prec is None else (com[0] - com_prec[0]) / DT
            com_prec = com
            dev = cotes[i_c]["cote"]
            arr = "g" if dev == "d" else "d"
            pose, u = {}, t - t0
            jambe(pose, "g", 0.0, 5.0)
            jambe(pose, "d", 0.0, 5.0)
            ouv = 0.0
            if etat == "attente" and u >= 1.0:
                etat, t0, u = "pencher", t, 0.0
            if etat == "pencher":
                cible = min(25.0, 25.0 * u / 3.0)              # il se laisse tomber : la cible du torse avance
                pose["epaule_tangage_g"] = pose["epaule_tangage_d"] = -20.0 * min(1.0, u / 1.0)
                if a >= seuil:                                 # il sent qu'il tombe
                    cotes[i_c]["declenche_s"] = round(t, 2)
                    if CP:                                     # le point de capture : où le corps s'en va (Pratt et coll., 2006)
                        jd = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, "jambe-%s-hanche-tangage" % ("droite" if dev == "d" else "gauche"))
                        jc = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, "jambe-%s-cheville-tangage" % ("droite" if dev == "d" else "gauche"))
                        hanche_, cheville_ = d.xanchor[jd], d.xanchor[jc]
                        L_ = float(np.linalg.norm(hanche_ - cheville_))
                        x_cp = (com[0] - hanche_[0]) + vx / np.sqrt(9.81 / max(com[2], 0.2))
                        phi = float(np.degrees(np.arcsin(np.clip(gain_cp * x_cp / L_, -0.9, 0.9))))
                        hp = phi + a                       # l'angle de hanche : la jambe sous le point de capture, le torse penché compté
                        cotes[i_c]["point_capture_cm"] = round(100 * x_cp, 1)
                        cotes[i_c]["hanche_pas_deg"] = round(hp, 1)
                    etat, t0, u = "lever", t, 0.0
                elif u > 4.0:
                    etat, t0, u = "rate", t, 0.0
            if etat in ("lever", "poser", "descendre", "tenir", "remonter", "ramener"):
                phases = [("lever", tp / 2), ("poser", tp / 2), ("descendre", 0.6), ("tenir", 1.0), ("remonter", 0.8), ("ramener", 0.6)]
                noms = [x[0] for x in phases]
                dur = dict(phases)
                if u >= dur[etat]:
                    nxt = noms.index(etat) + 1
                    etat, t0, u = (noms[nxt] if nxt < len(noms) else "pause"), t, 0.0
            if etat in ("lever", "poser", "descendre", "tenir", "remonter", "ramener"):
                dur = {"lever": tp / 2, "poser": tp / 2, "descendre": 0.6, "tenir": 1.0, "remonter": 0.8, "ramener": 0.6}[etat]
                sv = mj(u / dur)
                cible = 25.0 + (tf - 25.0) * (sv if etat == "lever" else 1.0) if etat != "ramener" else tf * (1 - sv)
                if etat == "lever":
                    jambe(pose, dev, 45.0 * sv, gk * sv)
                    jambe(pose, arr, 0.0, 5.0 + (kd0 - 5.0) * sv)   # D' : le bassin descend, le pied d'appui se déleste
                    ouv = bras * sv
                elif etat == "poser":
                    jambe(pose, dev, 45.0 + (hp - 45.0) * sv, gk + (10.0 - gk) * sv)
                    jambe(pose, arr, 0.0, kd0)
                    ouv = bras
                elif etat in ("descendre", "tenir"):
                    s2 = sv if etat == "descendre" else 1.0
                    jambe(pose, dev, hp, 10.0 + (gf - 10.0) * s2)
                    jambe(pose, arr, 0.0, kd0 + (40.0 - kd0) * s2)
                    ouv = bras
                elif etat == "remonter":
                    jambe(pose, dev, hp, gf + (10.0 - gf) * sv)
                    jambe(pose, arr, 0.0, 40.0 - 35.0 * sv)
                    ouv = bras * (1 - sv)
                else:
                    jambe(pose, dev, hp * (1 - sv) + 30.0 * np.sin(np.pi * sv), 10.0 + 40.0 * np.sin(np.pi * sv))
                tr = tr_max * (1 if dev == "d" else -1) * (1.0 if etat in ("lever", "poser", "ramener") else 0.0)
                for cc in ("g", "d"):
                    pose["hanche_roulis_" + cc] = tr
                    pose["cheville_roulis_" + cc] = -tr
                if etat in ("descendre", "tenir", "remonter"):
                    cotes[i_c]["creux"] = max(cotes[i_c]["creux"], 1.0 - float(d.subtree_com[1][2]) / _s["h_com"])
                    cotes[i_c]["genou_dev"] = max(cotes[i_c]["genou_dev"], abs(float(np.degrees(d.qpos[adr[dev]]))))
            if etat == "pause":
                cible = 0.0
                if u >= 0.8:
                    cotes[i_c]["rattrape"] = float(d.subtree_com[1][2]) / _s["h_com"] >= 0.93
                    i_c, etat, t0 = i_c + 1, "attente", t
            if etat == "rate":
                i_c, etat, t0 = i_c + 1, "attente", t
            pose["epaule_roulis_g"], pose["epaule_roulis_d"] = -ouv, ouv
            g1, g2 = (1.5, 0.2) if etat == "pencher" else (gt, gtv)   # E46 : la penchée est imposée, il suit sa cible
            corr = g1 * (a - cible) + g2 * va
            for cc in ("g", "d"):
                pose["cheville_tangage_" + cc] = pose.get("cheville_tangage_" + cc, 0.0) + corr
            c = C.consigne(m, pose, W._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0 and C.inclinaison(d) > 45:
            chute = t
            break
        if video is not None and k % int(0.05 / m.opt.timestep) == 0:
            video(d)
    n_ok = sum(x["rattrape"] for x in cotes)
    n_dec = sum(x["declenche_s"] is not None for x in cotes)
    # E46 : un côté non déclenché coûte 3 ; une chute après avoir essayé, 2 (avant : ne pas jouer valait mieux que tomber)
    score = -3.0 * (2 - n_dec) + 0.5 * n_dec + n_ok * (1.0 + 2.0 * min(max(x["creux"] for x in cotes), 0.2)) - (2.0 if chute is not None else 0.0)
    r = {"tombe": chute is not None, "chute_s": chute, "cotes": cotes, "rattrapes": n_ok, "score": round(score, 4)}
    return r if trace else -score


def f(u):
    if MODE == "fentes":                           # R-082 : bornes répétées pour chaque côté (« dg » : 18 réglages)
        return fentes(np.tile(F_BAS, len(COTES)) + np.clip(u, 0, 1) * (np.tile(F_HAUT, len(COTES)) - np.tile(F_BAS, len(COTES))))
    if MODE == "rattrape":
        return rattraper(R_BAS + np.clip(u, 0, 1) * (R_HAUT - R_BAS))
    b, h = bornes()
    return marcher(b + np.clip(u, 0, 1) * (h - b))


def main():
    from cmaes import CMA
    import imageio.v2 as iio
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["hauteurs", "marche-fente", "fentes", "basse", "rattrape"])
    ap.add_argument("--generations", type=int, default=0)
    ap.add_argument("--video", action="store_true")
    a = ap.parse_args()
    assert a.mode == MODE, "lancer avec N3_GENOUX=%s" % a.mode
    init()
    f_res = os.path.join(RES, "n3-genoux.json")
    res = json.load(open(f_res, encoding="utf-8")) if os.path.exists(f_res) else {}
    u0, sig = None, 0.3
    if MODE == "fentes":
        n = 9 * len(COTES)
        b, h, gens, pop = np.tile(F_BAS, len(COTES)), np.tile(F_HAUT, len(COTES)), a.generations or 30, 16
        if COTES == "dg":                            # R-082 A2 : partir de la droite (R-081) et de la gauche (A1)
            qd = json.load(open(os.path.join(RES, "n3-genoux-fentes.json"), encoding="utf-8"))["parametres_liste"]
            qg = json.load(open(os.path.join(RES, "n3-genoux-fentes-g.json"), encoding="utf-8"))["parametres_liste"]
            u0, sig = np.clip((np.array(qd + qg) - b) / (h - b), 0.02, 0.98), 0.15
    elif MODE == "rattrape":
        b, h, gens, pop = R_BAS, R_HAUT, a.generations or 30, 16
    elif MODE == "basse":                            # R-082 B : partir de la marche de R-081 à 85 %
        (b, h), gens, pop = bornes(), a.generations or 60, 28
        p0 = np.array(json.load(open(os.path.join(RES, "n3-genoux-hauteurs-85.json"), encoding="utf-8"))["parametres_liste"])
        u0, sig = np.clip((p0 - b) / (h - b), 0.02, 0.98), 0.2
    else:
        (b, h), gens, pop = bornes(), a.generations or (40 if MODE == "marche-fente" else 50), 28
    cma = CMA(mean=np.full(len(b), 0.5) if u0 is None else u0, sigma=sig, population_size=pop, seed=81, bounds=np.array([[0, 1]] * len(b)))
    best, reussites = (1e9, None), []
    with mp.Pool(14, initializer=init) as pool:
        for g in range(gens):
            xs = [cma.ask() for _ in range(pop)]
            vals = pool.map(f, xs)
            cma.tell(list(zip(xs, vals)))
            if MODE == "rattrape":
                reussites.append(int(sum(v <= -2.0 for v in vals)))
            i = int(np.argmin(vals))
            if vals[i] < best[0]:
                best = (vals[i], xs[i])
            print("%s %s, génération %2d : meilleur %.3f" % (MODE, CIBLE_H if MODE in ("hauteurs", "basse") else COTES, g + 1, -best[0]), flush=True)
    q = b + best[1] * (h - b)
    cle = MODE + ("-%d" % round(100 * CIBLE_H) if MODE in ("hauteurs", "basse") else ("" if COTES == "dg" and MODE != "fentes" else ""))
    if MODE == "basse" and os.environ.get("N3_TORSE"):
        cle += "-t%+d" % round(CIBLE_T)
    if MODE == "rattrape":
        cle = "rattrape" + ("-cp" if CP else "") + ("-bras-bas" if BRAS_FORCES == "bas" else "")
    if MODE == "fentes" and os.environ.get("N3_FENTES"):
        cle = "fentes-" + COTES                     # R-082 : fentes-g, fentes-dg
    r = fentes(q, trace=True) if MODE == "fentes" else (rattraper(q, trace=True) if MODE == "rattrape" else marcher(q, trace=True))
    if MODE == "basse":                              # H61 : tient-il 30 s ?
        r30 = marcher(q, trace=True, duree=30.0)
        r["tenue_30s"] = {k: r30.get(k) for k in ("tombe", "chute_s", "torse_deg", "torse_oscille_deg", "roulis_oscille_deg", "avance_m")}
    if MODE == "rattrape":
        r["reglages"] = dict(zip(R_NOMS, [round(float(v), 2) for v in q]))
        r["reussites_par_generation"] = reussites
        r["repetitions_reussies"] = int(sum(reussites))
        r["premiere_reussite_generation"] = next((i + 1 for i, x in enumerate(reussites) if x > 0), None)
    r["parametres_liste"] = [float(v) for v in q]
    if MODE == "fentes":
        r["reglages"] = dict(zip([c + "_" + n for c in COTES for n in F_NOMS] if len(q) > 9 else F_NOMS, [round(float(v), 2) for v in q]))
    json.dump(r, open(os.path.join(RES, "n3-genoux-%s.json" % cle), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    res[cle] = {k: v for k, v in r.items() if k != "parametres_liste"}
    json.dump(res, open(f_res, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(cle, json.dumps(res[cle], ensure_ascii=False), flush=True)
    if a.video:
        rend = mujoco.Renderer(W._m, 480, 640)
        cam = mujoco.MjvCamera()
        im = []

        def v(dd):
            cam.distance, cam.azimuth, cam.elevation = 3.6, 90, -8      # de côté : on voit le genou
            cam.lookat[:] = [dd.subtree_com[1][0], dd.subtree_com[1][1], 0.75]
            rend.update_scene(dd, camera=cam)
            im.append(rend.render().copy())
        (fentes if MODE == "fentes" else (rattraper if MODE == "rattrape" else marcher))(q, video=v)
        iio.mimsave(os.path.join(RES, "n3-genoux-%s.mp4" % cle), im, fps=20, macro_block_size=1)
        print("vidéo écrite")


if __name__ == "__main__":
    main()
