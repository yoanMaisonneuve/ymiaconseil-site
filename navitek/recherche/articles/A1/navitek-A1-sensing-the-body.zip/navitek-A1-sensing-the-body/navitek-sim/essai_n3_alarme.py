"""R-114 — une alarme qui apprend sa marche : trois alarmes (l'inclinaison seule, le point de capture seul, une régression logistique sur
sept mesures), réglées sur une moitié des épisodes pour au plus 10 % de fausses alarmes, jugées sur l'autre moitié. Simulé.

Les épisodes : la marche pré-entraînée de R-111 ; 100 sous variance étroite (graine 3001), 100 large (3002), 100 sous poussées (3003),
30 nominaux (3004). Dans chaque lot, rang pair : apprendre ; rang impair : juger. Une lecture toutes les 0,04 s ; on ignore la première seconde.
Une alarme sonne quand son signal dépasse son seuil 3 lectures de suite ; son instant est la première des trois.

    python -X utf8 essai_n3_alarme.py        → resultats/n3-alarme.json, un film (une chute annoncée)"""
import json
import math
import multiprocessing as mp
import os
import sys

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import essai_n3_capture as Cap  # noqa: E402

B = Cap.B
T_DEBUT, N_SUITE, HORIZON, AVANCE_MIN, FA_MAX = 1.0, 3, 1.0, 0.3, 0.10
NOMS = ["|inclinaison avant|", "|inclinaison de côté|", "|vitesse avant|", "|vitesse de côté|", "ξ aux semelles", "centre de masse aux semelles", "pieds qui touchent"]


def mesures(w, d):
    a, r, va, vr = B.W.attitude(d)
    mujoco.mj_subtreeVel(w["m"], d)
    c = d.subtree_com[1][:2].copy()
    xi = c + d.subtree_linvel[1][:2] / Cap.OMEGA
    sem = Cap.semelles(w, d)
    dx, _ = Cap.distance(xi, sem)
    dc, _ = Cap.distance(c, sem)
    pieds = sum(B._touche(w, d, cote) for cote in ("gauche", "droite"))
    return [abs(a), abs(r), abs(va), abs(vr), dx, dc, float(pieds)]


def _episode(args):
    u, cond = args
    serie = []

    def cb(d):
        w = Cap._monde_de(d)
        serie.append([float(d.time)] + mesures(w, d))
    r = B.rouler(u, cond, video=cb)
    return {"tombe": bool(r["tombe"]), "chute_s": r["chute_s"], "serie": serie}


def sonne(t, sig, seuil):
    k = 0
    for i in range(len(t)):
        if t[i] >= T_DEBUT and sig[i] > seuil:
            k += 1
            if k >= N_SUITE:
                return float(t[i - N_SUITE + 1])
        else:
            k = 0
    return None


def regler(eps, signal):
    """Le plus petit seuil qui garde les fausses alarmes de la moitié d'apprentissage sous FA_MAX."""
    debout = [e for e in eps if not e["tombe"]]
    vals = np.concatenate([signal(e)[np.array(e["t"]) >= T_DEBUT] for e in eps])
    for q in np.linspace(0.5, 0.99999, 400):
        s = float(np.quantile(vals, q))
        if np.mean([sonne(e["t"], signal(e), s) is not None for e in debout]) <= FA_MAX:
            return s
    return float(vals.max())


def juger(eps, signal, seuil):
    chutes = [e for e in eps if e["tombe"]]
    debout = [e for e in eps if not e["tombe"]]
    av = []
    for e in chutes:
        a = sonne(e["t"], signal(e), seuil)
        av.append(None if (a is None or a > e["chute_s"]) else e["chute_s"] - a)
    annonces = [x for x in av if x is not None and x >= AVANCE_MIN]
    return {"chutes": len(chutes), "debout": len(debout), "annoncees_0_3s": len(annonces),
            "part_annoncees": round(len(annonces) / len(chutes), 3) if chutes else None,
            "fausses_alarmes": round(float(np.mean([sonne(e["t"], signal(e), seuil) is not None for e in debout])), 3) if debout else None,
            "avance_mediane_s": round(float(np.median(annonces)), 2) if annonces else None, "avances": [None if x is None else round(x, 2) for x in av]}


def main():
    B.preparer()
    u = np.array(json.load(open(os.path.join(Cap.D_BANC, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    lots = {}
    for nom, graine, regle in (("etroite", 3001, B.regle_regime("R1")), ("large", 3002, B.regle_regime("R2")), ("poussees", 3003, None), ("nominal", 3004, None)):
        rng = np.random.default_rng(graine)
        if regle is None:
            regle = B.regle_regime("R0")
            regle["vitesse_visee"] = ("etroite", None)
            if nom == "poussees":
                regle["poussees"] = ("large", None)
        lots[nom] = [B.tirer_condition(rng, regle) for _ in range(30 if nom == "nominal" else 100)]
    taches, cles = [], []
    for k, cs in lots.items():
        for i, c in enumerate(cs):
            taches.append((u, c))
            cles.append((k, i))
    with mp.Pool(3, initializer=B.preparer) as pool:
        res = pool.map(_episode, taches)
    eps = []
    for (k, i), x in zip(cles, res):
        S = np.array(x["serie"])
        eps.append({"lot": k, "i": i, "apprendre": i % 2 == 0, "tombe": x["tombe"], "chute_s": x["chute_s"], "t": S[:, 0].tolist(), "X": S[:, 1:]})
    A = [e for e in eps if e["apprendre"]]
    J = [e for e in eps if not e["apprendre"]]
    print("apprendre : %d épisodes, %d chutes ; juger : %d épisodes, %d chutes" % (len(A), sum(e["tombe"] for e in A), len(J), sum(e["tombe"] for e in J)), flush=True)
    # (c) la régression logistique : les lectures à moins de HORIZON d'une chute contre toutes les autres
    from sklearn.linear_model import LogisticRegression
    from sklearn.preprocessing import StandardScaler
    Xs, ys = [], []
    for e in A:
        t = np.array(e["t"])
        m = t >= T_DEBUT
        y = np.zeros(len(t))
        if e["tombe"]:
            y = ((e["chute_s"] - t) <= HORIZON) & ((e["chute_s"] - t) >= 0)
        Xs.append(e["X"][m])
        ys.append(np.asarray(y, float)[m])
    X, y = np.vstack(Xs), np.concatenate(ys)
    sc = StandardScaler().fit(X)
    lr = LogisticRegression(class_weight="balanced", max_iter=2000).fit(sc.transform(X), y)
    sig = {"inclinaison": lambda e: np.hypot(e["X"][:, 0], e["X"][:, 1]),
           "point de capture": lambda e: e["X"][:, 4],
           "apprise": lambda e: lr.predict_proba(sc.transform(e["X"]))[:, 1]}
    out = {"apprendre": {}, "juger": {}, "seuils": {}}
    for nom, f0 in sig.items():
        cache = {id(e): f0(e) for e in eps}                    # le signal de chaque épisode, calculé une fois
        f = lambda e, cache=cache: cache[id(e)]
        s = regler(A, f)
        out["seuils"][nom] = s
        out["apprendre"][nom] = {k: v for k, v in juger(A, f, s).items() if k != "avances"}
        out["juger"][nom] = juger(J, f, s)
        j = out["juger"][nom]
        print("%-17s seuil %.4g | jugé : %d/%d chutes annoncées 0,3 s avant (%.0f %%), fausses alarmes %.0f %%, avance médiane %s s"
              % (nom, s, j["annoncees_0_3s"], j["chutes"], 100 * (j["part_annoncees"] or 0), 100 * (j["fausses_alarmes"] or 0), j["avance_mediane_s"]), flush=True)
    out["logistique"] = {"noms": NOMS, "moyennes": sc.mean_.tolist(), "echelles": sc.scale_.tolist(), "coefficients": lr.coef_[0].tolist(),
                         "constante": float(lr.intercept_[0])}
    print("poids (mesures centrées réduites) :", {n: round(c, 2) for n, c in zip(NOMS, lr.coef_[0])}, flush=True)
    # le film : une chute jugée (jamais vue), annoncée par l'alarme apprise, avec l'avance la plus proche de la médiane
    j = out["juger"]["apprise"]
    chutes_j = [e for e in J if e["tombe"]]
    cand = [(e, a) for e, a in zip(chutes_j, j["avances"]) if a is not None and a >= AVANCE_MIN]
    film = None
    if cand:
        e, a = min(cand, key=lambda ea: abs(ea[1] - (j["avance_mediane_s"] or 0)))
        film = {"episode": "%s:%d" % (e["lot"], e["i"]), "avance_s": a, **filmer(u, lots[e["lot"]][e["i"]], out["logistique"], out["seuils"]["apprise"],
                                                                                    os.path.join(ICI, "resultats", "n3-alarme-chute.mp4"))}
        print("film", film, flush=True)
    out["film"] = film
    out["episodes"] = [{k: v for k, v in e.items() if k not in ("t", "X")} for e in eps]
    json.dump(out, open(os.path.join(ICI, "resultats", "n3-alarme.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=float)
    print("écrit resultats/n3-alarme.json", flush=True)


def filmer(u, cond, lg, tau, chemin):
    """Le film : le corps à demi transparent, les semelles, le centre de masse, le point de capture ; une lampe au-dessus de la tête, verte,
    qui devient rouge quand l'alarme apprise sonne (3 lectures de suite au-dessus du seuil)."""
    import imageio.v2 as iio
    rg = np.random.default_rng(int(cond["graine"]))
    rg.integers(0, 2 ** 31 - 1)
    w = B._choisir_modele(cond["axes"]["relief"], rg)
    m = w["m"]
    rgba0 = m.geom_rgba.copy()
    m.geom_rgba[m.geom_bodyid != 0, 3] = 0.3
    off0 = (m.vis.global_.offwidth, m.vis.global_.offheight)
    m.vis.global_.offwidth, m.vis.global_.offheight = 1280, 960
    rend, cam = mujoco.Renderer(m, 960, 1280), mujoco.MjvCamera()
    LIME, CYAN, ROUGE, BLANC, VERT = (np.array(x, np.float32) for x in ([0.72, 0.95, 0.18, 1], [0.10, 0.85, 1.0, 1], [1.0, 0.18, 0.12, 1], [1, 1, 1, 0.9], [0.2, 0.85, 0.35, 1]))
    mu, sd, co, b0 = (np.array(lg["moyennes"]), np.array(lg["echelles"]), np.array(lg["coefficients"]), lg["constante"])
    frames, etat = [], {"k": 0}

    def g_(sc):
        if sc.ngeom >= sc.maxgeom:
            return None
        sc.ngeom += 1
        return sc.geoms[sc.ngeom - 1]

    def trait(sc, a, b, rgba, larg):
        g = g_(sc)
        if g is not None:
            mujoco.mjv_initGeom(g, mujoco.mjtGeom.mjGEOM_CAPSULE, np.zeros(3), np.zeros(3), np.eye(3).flatten(), rgba)
            mujoco.mjv_connector(g, mujoco.mjtGeom.mjGEOM_CAPSULE, larg, np.array(a, float), np.array(b, float))

    def objet(sc, typ, taille, pos, rgba):
        g = g_(sc)
        if g is not None:
            mujoco.mjv_initGeom(g, typ, np.array(taille, float), np.array(pos, float), np.eye(3).flatten(), rgba)

    def cb(d):
        x = mesures(w, d)
        p = 1 / (1 + math.exp(-(b0 + float(((np.array(x) - mu) / sd) @ co))))
        etat["k"] = etat["k"] + 1 if (d.time >= T_DEBUT and p > tau) else 0
        alarme = etat["k"] >= N_SUITE
        c3 = d.subtree_com[1].copy()
        xi = c3[:2] + d.subtree_linvel[1][:2] / Cap.OMEGA
        _, V = Cap.distance(c3[:2], Cap.semelles(w, d))
        cam.distance, cam.azimuth, cam.elevation = 3.0, 215, -22
        cam.lookat[:] = [c3[0], c3[1], 0.72]
        rend.update_scene(d, camera=cam)
        sc = rend.scene
        V = list(V)
        for i in range(len(V)):
            if len(V) > 2 or i == 0:
                a_, b_ = V[i], V[(i + 1) % len(V)]
                trait(sc, [a_[0], a_[1], 0.014], [b_[0], b_[1], 0.014], BLANC, 0.006)
        trait(sc, c3, [c3[0], c3[1], 0.008], LIME, 0.012)
        objet(sc, mujoco.mjtGeom.mjGEOM_SPHERE, [0.05] * 3, c3, LIME)
        objet(sc, mujoco.mjtGeom.mjGEOM_CYLINDER, [0.055, 0.004, 0], [xi[0], xi[1], 0.018], CYAN)
        tete = np.array([c3[0], c3[1], 1.72])                   # au-dessus de la tête, à hauteur fixe
        objet(sc, mujoco.mjtGeom.mjGEOM_SPHERE, [0.07 if alarme else 0.05] * 3, tete, ROUGE if alarme else VERT)   # la lampe
        frames.append(rend.render().copy())
    try:
        r = B.rouler(u, cond, video=cb)
    finally:
        m.geom_rgba[:] = rgba0
        m.vis.global_.offwidth, m.vis.global_.offheight = off0
    iio.mimsave(chemin, frames, fps=25, macro_block_size=1)
    return {k: r[k] for k in ("reussi", "tombe", "chute_s", "avance_m")}


if __name__ == "__main__":
    main()
