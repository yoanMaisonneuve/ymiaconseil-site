"""R-112 — les trois films dans la même condition de poussée (la marche apprise, avec le gain du pendule, sans placement), avec le feedback
visuel du centre de gravité (voir essai_n3_pendule.filmer). Chaque film rejoue son épisode à l'identique. Simulé."""
import json
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import essai_n3_pendule as E  # noqa: E402

if __name__ == "__main__":
    E.B.preparer()
    r = json.load(open(os.path.join(ICI, "resultats", "n3-pendule.json"), encoding="utf-8"))
    k = r["film_condition"]
    cond = r["poussees_conditions"][k]
    u = np.array(json.load(open(os.path.join(ICI, "banc_variance", "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    kvp = r["marches"]["pré-entraînement (R-111)"]["kv_pendule"]          # la valeur exacte (le JSON des variantes l'arrondit)
    kyp = r["marches"]["pré-entraînement (R-111)"]["ky"] if r["roulis_en_miroir"] else r["ky_vers_plus_y"]["g"] * abs(kvp)
    variantes = {"apprise": u, "pendule": E.avec_gains(u, kvp, kyp), "sans placement": E.avec_gains(u, 0.0, 0.0)}
    films = {}
    for nom, fic in (("apprise", "n3-pendule-apprise.mp4"), ("pendule", "n3-pendule-avec-pendule.mp4"), ("sans placement", "n3-pendule-sans-placement.mp4")):
        f = E.filmer(variantes[nom], cond, os.path.join(ICI, "resultats", fic), r["omega"])
        f["rejoue_a_l_identique"] = all(f[x] == r["poussees_detail"][nom][k][x] for x in ("reussi", "tombe", "chute_s", "avance_m"))
        films[nom] = f
        print("film", fic, f, flush=True)
    r["films"] = films
    json.dump(r, open(os.path.join(ICI, "resultats", "n3-pendule.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=float)
