"""R-112 — le pendule dans la marche apprise : la valeur du pendule inversé linéaire pour le gain de placement du pied, contre les gains
trouvés par essais (R-107, le pré-entraînement de R-111, les entraînements de R-111) ; puis la marche pré-entraînée jouée telle quelle, avec
les gains du pendule, et sans placement : au nominal et sous poussées. Simulé.

    python -X utf8 essai_n3_pendule.py          # mesures, comparaisons, 3 variantes × 60 épisodes, 2 films
Sortie : resultats/n3-pendule.json, resultats/n3-pendule-avec-pendule.mp4, resultats/n3-pendule-sans-placement.mp4"""
import glob
import json
import math
import multiprocessing as mp
import os
import sys

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ICI, "banc_variance"))
import banc as B  # noqa: E402

D_BANC = os.path.join(ICI, "banc_variance")
G = 9.81


def _indice(m, cle):
    for i, n in enumerate(B.C.noms(m)):
        if B.C.court(n) == cle:
            return i
    raise KeyError(cle)


def pied(w, d, cote):
    return np.mean([d.geom_xpos[g] for g in w["pieds"][cote]], axis=0)


def verifier_signes():
    """La cinématique seule : où va le pied quand la pose de hanche (convention de la commande) passe de -10° à +10°."""
    w = B._monde["plat"]
    m = w["m"]
    d = mujoco.MjData(m)
    sg = B.W._sg
    out = {}
    for cote, s in (("gauche", "g"), ("droite", "d")):
        for art in ("hanche_tangage", "hanche_roulis"):
            cle = "%s_%s" % (art, s)
            i = _indice(m, cle)
            qadr = m.jnt_qposadr[m.actuator_trnid[i, 0]]
            pos = {}
            for val in (-10.0, 10.0):
                mujoco.mj_resetData(m, d)
                d.qpos[qadr] += np.radians(val) * sg.get(cle, 1)
                mujoco.mj_forward(m, d)
                pos[val] = pied(w, d, cote)
            dp = pos[10.0] - pos[-10.0]
            out[cle] = {"dx_m": round(float(dp[0]), 4), "dy_m": round(float(dp[1]), 4)}
    # le pied devant quand la pose de tangage devient plus négative ?
    s_t = {s: -np.sign(out["hanche_tangage_%s" % s]["dx_m"]) for s in ("g", "d")}   # signe du kv qui avance le pied quand v est trop grand
    s_r = {s: np.sign(out["hanche_roulis_%s" % s]["dy_m"]) for s in ("g", "d")}      # signe du ky qui porte le pied vers +y quand v_y > 0
    return out, s_t, s_r


def mesurer_constantes(u, cond):
    """z0 (hauteur moyenne du centre de masse) et L (de l'axe de la hanche à la semelle, en appui simple), de 2 à 10 s."""
    w = B._monde["plat"]
    m = w["m"]
    ih = {s: m.actuator_trnid[_indice(m, "hanche_tangage_%s" % s), 0] for s in ("g", "d")}
    z, L = [], []

    def cb(d):
        if d.time < 2.0:
            return
        z.append(float(d.subtree_com[1][2]))
        tg, td = B._touche(w, d, "gauche"), B._touche(w, d, "droite")
        for s, cote, appui, autre in (("g", "gauche", tg, td), ("d", "droite", td, tg)):
            if appui and not autre:                            # la semelle est au sol (z = 0, le sol plat) : L = hauteur de l'axe
                L.append(float(d.xanchor[ih[s]][2]))
    r = B.rouler(u, cond, video=cb)
    return float(np.mean(z)), float(np.mean(L)), len(L), r


def gains(u):
    p, (kv, ky, a_f), kt = B.decoder(u)
    return {"kv": float(kv), "ky": float(ky), "filtre": float(a_f), "T": float(p[0]), "kt": float(kt)}


def avec_gains(u, kv, ky):
    u = np.array(u, float).copy()
    u[15] = (kv - B.P.BAS_PL[0]) / (B.P.HAUT_PL[0] - B.P.BAS_PL[0])
    u[16] = (ky - B.P.BAS_PL[1]) / (B.P.HAUT_PL[1] - B.P.BAS_PL[1])
    return np.clip(u, 0, 1)


def _jouer(args):
    u, cond = args
    r = B.rouler(u, cond)
    return {k: r[k] for k in ("reussi", "tombe", "chute_s", "avance_m", "derive_m", "vol_s")}


def filmer(u, cond, chemin, omega):
    import imageio.v2 as iio
    w = B._monde["plat"]
    rend, cam = mujoco.Renderer(w["m"], 480, 640), mujoco.MjvCamera()
    frames, prec = [], {"c": None, "v": np.zeros(2)}

    def disque(sc, xy, rgba, r):
        if sc.ngeom >= sc.maxgeom:
            return
        mujoco.mjv_initGeom(sc.geoms[sc.ngeom], mujoco.mjtGeom.mjGEOM_CYLINDER, np.array([r, 0.003, 0.0]),
                            np.array([xy[0], xy[1], 0.004]), np.eye(3).flatten(), np.array(rgba, dtype=np.float32))
        sc.ngeom += 1

    def cb(d):
        c = d.subtree_com[1].copy()
        if prec["c"] is not None:
            prec["v"] = 0.6 * prec["v"] + 0.4 * (c[:2] - prec["c"][:2]) / 0.04
        prec["c"] = c
        cam.distance, cam.azimuth, cam.elevation = 3.4, 70, -22
        cam.lookat[:] = [c[0], c[1], 0.55]
        rend.update_scene(d, camera=cam)
        disque(rend.scene, c[:2], (0.83, 0.66, 0.26, 1.0), 0.045)                      # le centre de masse, au sol (doré)
        disque(rend.scene, c[:2] + prec["v"] / omega, (0.95, 0.42, 0.11, 1.0), 0.035)  # le point de capture (orange)
        frames.append(rend.render().copy())
    r = B.rouler(u, cond, video=cb)
    iio.mimsave(chemin, frames, fps=25, macro_block_size=1)
    return {k: r[k] for k in ("reussi", "tombe", "chute_s", "avance_m")}


def main():
    B.preparer()
    jeu = json.load(open(os.path.join(D_BANC, "eval", "jeu_evaluation.json"), encoding="utf-8"))
    nominal = [c for c in jeu if c["jeu"] == "nominal"]
    rng = np.random.default_rng(112)
    regle = B.regle_regime("R0")
    regle["poussees"] = ("large", None)
    regle["vitesse_visee"] = ("etroite", None)
    poussees = [B.tirer_condition(rng, regle) for _ in range(50)]

    signes, s_t, s_r = verifier_signes()
    miroir_roulis = s_r["g"] != s_r["d"]
    print("signes :", signes, "| kv qui avance le pied :", s_t, "| ky vers +y :", s_r, "| roulis en miroir :", miroir_roulis, flush=True)

    u_pre = np.array(json.load(open(os.path.join(D_BANC, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    z0, L, n_L, r0 = mesurer_constantes(u_pre, nominal[0])
    omega = math.sqrt(G / z0)
    print("z0 %.3f m, L %.3f m (%d mesures), omega %.2f /s ; la marche : %s" % (z0, L, n_L, omega, {k: r0[k] for k in ("reussi", "avance_m")}), flush=True)

    def kv_pendule(T):
        Ts = T / 2.0
        return float(s_t["g"] * (180 / math.pi) * (1 / math.tanh(omega * Ts)) / (omega * L))

    marches = {}
    j107 = json.load(open(os.path.join(ICI, "resultats", "n3-moment-du-pas.json"), encoding="utf-8"))["jeux"]["B-g1"]
    p107 = j107["parametres_liste"]
    marches["R-107 B-g1"] = {"kv": float(j107["placement"][0]), "ky": float(j107["placement"][1]), "filtre": float(j107["placement"][2]),
                             "T": float(p107[0]), "kt": float(j107["gain_moment"])}
    marches["pré-entraînement (R-111)"] = gains(u_pre)
    for f in sorted(glob.glob(os.path.join(D_BANC, "resultats", "*-g*.json"))):
        r = json.load(open(f, encoding="utf-8"))
        if "politique_moyenne" in r:
            marches[r["config"]["nom"] + " (R-111)"] = gains(r["politique_moyenne"])
    for nom, g in marches.items():
        g["kv_pendule"] = kv_pendule(g["T"])
        g["rapport"] = g["kv"] / g["kv_pendule"]
        g["meme_signe"] = bool(np.sign(g["kv"]) == np.sign(g["kv_pendule"]))
        print("%-28s kv %+6.1f  pendule %+6.1f  rapport %.2f  ky %+6.1f  T %.2f s" % (nom, g["kv"], g["kv_pendule"], g["rapport"], g["ky"], g["T"]), flush=True)

    gp = marches["pré-entraînement (R-111)"]
    kvp = gp["kv_pendule"]
    kyp = gp["ky"] if miroir_roulis else float(s_r["g"] * abs(kvp))
    variantes = {"apprise": u_pre, "pendule": avec_gains(u_pre, kvp, kyp), "sans placement": avec_gains(u_pre, 0.0, 0.0)}
    res = {}
    with mp.Pool(2, initializer=B.preparer) as pool:
        for nom, u in variantes.items():
            rn = pool.map(_jouer, [(u, c) for c in nominal])
            rp = pool.map(_jouer, [(u, c) for c in poussees])
            res[nom] = {"nominal": sum(x["reussi"] for x in rn), "poussees": sum(x["reussi"] for x in rp),
                        "chutes_poussees": sum(x["tombe"] for x in rp), "detail_poussees": rp}
            print("%-15s nominal %d/10, poussées %d/50 (chutes %d)" % (nom, res[nom]["nominal"], res[nom]["poussees"], res[nom]["chutes_poussees"]), flush=True)

    # le film : la première condition de poussée où le pendule réussit et où la marche sans placement tombe
    k = next((i for i in range(50) if res["pendule"]["detail_poussees"][i]["reussi"] and res["sans placement"]["detail_poussees"][i]["tombe"]),
             next((i for i in range(50) if res["pendule"]["detail_poussees"][i]["reussi"]), 0))
    films = {}
    for nom, fic in (("pendule", "n3-pendule-avec-pendule.mp4"), ("sans placement", "n3-pendule-sans-placement.mp4")):
        films[nom] = filmer(variantes[nom], poussees[k], os.path.join(ICI, "resultats", fic), omega)
        films[nom]["rejoue_a_l_identique"] = all(films[nom][x] == res[nom]["detail_poussees"][k][x] for x in ("reussi", "tombe", "chute_s", "avance_m"))
        print("film", fic, films[nom], flush=True)

    out = {"signes": signes, "kv_qui_avance_le_pied": {k_: int(v) for k_, v in s_t.items()}, "ky_vers_plus_y": {k_: int(v) for k_, v in s_r.items()},
           "roulis_en_miroir": bool(miroir_roulis), "z0_m": round(z0, 4), "L_m": round(L, 4), "n_mesures_L": n_L, "omega": round(omega, 3),
           "marches": marches, "variantes": {"kv_pendule": round(kvp, 2), "ky_pendule": round(kyp, 2), "ky_garde_appris": bool(miroir_roulis)},
           "resultats": {n: {k_: v for k_, v in r.items() if k_ != "detail_poussees"} for n, r in res.items()},
           "poussees_detail": {n: r["detail_poussees"] for n, r in res.items()}, "film_condition": k, "films": films,
           "poussees_conditions": poussees}
    json.dump(out, open(os.path.join(ICI, "resultats", "n3-pendule.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1, default=float)
    print("écrit resultats/n3-pendule.json", flush=True)


if __name__ == "__main__":
    main()
