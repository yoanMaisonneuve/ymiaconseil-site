# R-112, premier passage : la variante « pendule » avec le mauvais signe (E55)

Archivé le 12.11.2026 à 09:54 (heure lue), par la session.

**Ce qui s'est passé.** Le script `essai_n3_pendule.py` calculait le signe du gain du pendule par `s_t = -signe(dx)`, où dx est le
déplacement du pied quand la pose de tangage de hanche passe de -10° à +10°. Mesuré : dx = -0,225 m (le pied recule quand la pose
augmente ; vérifié aussi dans la dynamique, `diag_signe_placement_n3.py` : -10° met le pied à +0,132 m, +10° à -0,092 m). Le gain qui
avance le pied quand le corps va trop vite est donc **négatif** : s_t = signe(dx) = -1. Le script a pris +1. La variante « pendule » a donc
joué kv = +24,8 (presque le kv appris, +24,7) et ky = +24,8 : elle ne teste pas le pendule.

**Ce qui reste valable dans ce passage** : les mesures (z0 = 0,762 m, L = 0,650 m, omega = 3,59 /s), les gains appris lus, la marche
apprise (nominal 10/10, poussées 45/50) et la marche sans placement (nominal 10/10, poussées 41/50). Ils sont rejoués à l'identique dans
le passage corrigé.

**Ce qui est faux** : la colonne « pendule » (nominal 8/10, poussées 34/50) et le signe de kv_pendule dans `n3-pendule.json`.

Fichiers : `n3-pendule.json`, `n3-pendule-sortie.log`, les deux films, et le script tel qu'il était (`essai_n3_pendule-avec-le-defaut.py`).
