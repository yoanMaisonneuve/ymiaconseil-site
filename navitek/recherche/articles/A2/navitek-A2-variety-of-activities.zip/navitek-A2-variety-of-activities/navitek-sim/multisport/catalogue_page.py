"""La page du catalogue des exercices (pour le cell) : CATALOGUE-EXERCICES.md → catalogue.html, plus les résultats de R-124 en tête.
    python -X utf8 catalogue_page.py"""
import html
import io
import json
import os
import re

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(os.path.dirname(ICI), "resultats")


def inline(t):
    t = html.escape(t)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\*(.+?)\*", r"<i>\1</i>", t)
    t = re.sub(r"`(.+?)`", r"<code>\1</code>", t)
    return t


def convertir(md):
    out, lignes, i = [], md.splitlines(), 0
    while i < len(lignes):
        l = lignes[i]
        if l.startswith("# "):
            out.append("<h1>%s</h1>" % inline(l[2:]))
        elif l.startswith("## "):
            out.append("<h2>%s</h2>" % inline(l[3:]))
        elif l.startswith("> "):
            bloc = []
            while i < len(lignes) and lignes[i].startswith(">"):
                bloc.append(lignes[i][1:].strip())
                i += 1
            out.append('<p class="meta">%s</p>' % inline(" ".join(bloc)))
            continue
        elif l.startswith("|"):
            rows = []
            while i < len(lignes) and lignes[i].startswith("|"):
                rows.append([c.strip() for c in lignes[i].strip().strip("|").split("|")])
                i += 1
            tete, corps = rows[0], [r for r in rows[2:]]
            t = '<div class="tableau"><table><thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>' % (
                "".join("<th>%s</th>" % inline(c) for c in tete),
                "".join("<tr>%s</tr>" % "".join(("<th scope=\"row\">%s</th>" if k == 0 else "<td>%s</td>") % inline(c) for k, c in enumerate(r)) for r in corps))
            out.append(t)
            continue
        elif re.match(r"^\d+\. ", l):
            items = []
            while i < len(lignes) and (re.match(r"^\d+\. ", lignes[i]) or lignes[i].startswith("   ")):
                if re.match(r"^\d+\. ", lignes[i]):
                    items.append(re.sub(r"^\d+\. ", "", lignes[i]))
                else:
                    items[-1] += " " + lignes[i].strip()
                i += 1
            out.append("<ol>%s</ol>" % "".join("<li>%s</li>" % inline(x) for x in items))
            continue
        elif l.strip():
            par = [l]
            i += 1
            while i < len(lignes) and lignes[i].strip() and not lignes[i].startswith(("#", "|", ">")) and not re.match(r"^\d+\. ", lignes[i]):
                par.append(lignes[i])
                i += 1
            out.append("<p>%s</p>" % inline(" ".join(par)))
            continue
        i += 1
    return "\n".join(out)


def main():
    md = io.open(os.path.join(ICI, "CATALOGUE-EXERCICES.md"), encoding="utf-8").read()
    r = json.load(open(os.path.join(RES, "n3-chaque-exercice.json"), encoding="utf-8"))
    tete = ('<div class="bref"><p><b>Premiers tests (R-124, simulé, le 12.11 au soir).</b> 13 exercices de 7 disciplines, chacun appris seul, '
            'puis joué avec le socle appris sur chacun des autres :</p><ul>'
            '<li><b>Les exercices difficiles apprennent les faciles</b> ; les faciles n\'apprennent pas les difficiles.</li>'
            '<li><b>Un exercice impossible seul devient possible grâce à un autre</b> : le danseur grâce à l\'avion ; le coup de pied de côté '
            'grâce à l\'arabesque, aux cercles de hanche ou au patineur.</li>'
            '<li><b>Les meilleurs professeurs viennent de trois disciplines</b> : l\'avion (yoga), les cercles de hanche (échauffement), le '
            'patineur (patin) : chacun fait réussir 58 % des autres exercices.</li>'
            '<li><b>Être fort sous les poussées n\'est pas être polyvalent</b> (corrélation −0,11) ; et deux spécialistes ne tiennent plus '
            'debout sur deux pieds.</li></ul></div>'
            '<figure><img src="fig-r124-matrice.png" alt="La matrice de transfert : en ligne le socle appris, en colonne l\'exercice joué"><figcaption>'
            'La matrice de transfert (R-124) : en ligne, l\'exercice sur lequel le socle a été appris ; en colonne, l\'exercice joué ; le chiffre, '
            'la réussite sur 10 épisodes.</figcaption></figure>')
    corps = convertir(md)
    corps = corps.replace("</h1>", "</h1>" + tete, 1)
    page = PAGE.replace("{corps}", corps)
    io.open(os.path.join(ICI, "catalogue.html"), "w", encoding="utf-8").write(page)
    print("catalogue.html écrit", len(page))


PAGE = """<title>Catalogue des exercices</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Newsreader:opsz,wght@6..72,600&family=Lora:ital,wght@0,400;0,600;1,400&family=JetBrains+Mono:wght@400&display=swap">
<style>
:root{--papier:#fbfaf7;--teinte:#f2efe8;--encre:#2a2620;--pale:#5f5a50;--ligne:#e2ded5;--navy:#0b1f3a;--or:#d4a843;
  --display:'Newsreader',Georgia,serif;--corps:'Lora',Georgia,serif;--mono:'JetBrains Mono',ui-monospace,Consolas,monospace;color-scheme:light}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--papier:#11161f;--teinte:#19202c;--encre:#e7e3da;--pale:#a9a397;--ligne:#2b3342;--navy:#c9d6ea;color-scheme:dark}}
:root[data-theme="dark"]{--papier:#11161f;--teinte:#19202c;--encre:#e7e3da;--pale:#a9a397;--ligne:#2b3342;--navy:#c9d6ea;color-scheme:dark}
*{box-sizing:border-box}
body{margin:0;background:var(--papier);color:var(--encre);font-family:var(--corps);font-size:16.5px;line-height:1.6}
.page{max-width:920px;margin:0 auto;padding-inline:16px;padding-block:28px 56px}
h1{font-family:var(--display);color:var(--navy);font-size:clamp(26px,6vw,38px);line-height:1.15;margin:0 0 12px;text-wrap:balance}
h2{font-family:var(--display);color:var(--navy);font-size:clamp(20px,4.5vw,26px);margin:38px 0 8px;padding-top:14px;border-top:1px solid var(--ligne);text-wrap:balance}
.meta{color:var(--pale);font-size:14.5px}
.bref{background:var(--teinte);border-left:3px solid var(--or);padding:12px 16px;margin:16px 0;border-radius:2px}
.bref ul{margin:6px 0 0;padding-left:20px}.bref li{margin:6px 0}
figure{margin:18px 0}figure img{width:100%;height:auto;display:block;border:1px solid var(--ligne);border-radius:3px;background:#fff}
figcaption{font-size:14px;color:var(--pale);margin-top:6px}
.tableau{overflow-x:auto;margin:12px 0;border:1px solid var(--ligne);border-radius:4px}
table{border-collapse:collapse;width:100%;min-width:560px;font-size:14.5px;line-height:1.4}
th,td{padding:8px 9px;border-bottom:1px solid var(--ligne);text-align:left;vertical-align:top}
thead th{background:var(--teinte);font-family:var(--mono);font-size:11.5px;letter-spacing:.05em;text-transform:uppercase;color:var(--pale);font-weight:400}
tbody th{font-weight:600;color:var(--navy)}
tbody tr:last-child td,tbody tr:last-child th{border-bottom:0}
code{font-family:var(--mono);font-size:13px;background:var(--teinte);padding:1px 4px;border-radius:3px;overflow-wrap:anywhere}
</style>
<div class="page">
{corps}
</div>
"""

if __name__ == "__main__":
    main()
