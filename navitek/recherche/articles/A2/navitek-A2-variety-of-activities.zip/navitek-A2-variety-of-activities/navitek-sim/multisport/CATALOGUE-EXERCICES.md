# Catalogue des exercices par discipline : ce que chacun apprend au corps, et ce que N3 peut en faire

> Écrit le 12.11.2026 à partir de 21:24, par la session, sur la demande de Yoan du 12.11 à 21:23 (« Commence par faire la liste de tous les
> exercices par discipline et teste comme un chercheur ce qu'on apprend de chaque pour le mouvement, l'équilibre ») et son idée de 21:17
> (I-016 : le modèle norvégien, la multidiscipline avant la spécialisation). Les disciplines sont les siennes ; deux sont ajoutées (marquées).

## Ce que le corps apprend : les capacités (les codes du tableau)

| code | capacité | ce que ça veut dire pour un robot |
|---|---|---|
| **S2** | équilibre statique sur deux pieds | garder le centre de masse au-dessus du polygone des deux pieds |
| **S1** | équilibre sur une jambe | tenir sur un seul appui, le pied libre en l'air |
| **TP** | transfert de poids | porter le centre de masse d'un pied à l'autre, ou d'avant en arrière, sans tomber |
| **DY** | équilibre dynamique | rester debout pendant que le corps bouge (la jambe libre balance, les appuis changent) |
| **RC** | rattrapage | se remettre d'une poussée, d'un faux pas ; le pas de rattrapage |
| **TR** | contrôle du tronc | tenir le torse à une inclinaison voulue (gainage) |
| **CB** | coordination et contrepoids | les bras et la jambe libre qui équilibrent le reste |
| **RY** | rythme | répéter un geste à une cadence, garder le temps |
| **PU** | puissance | une impulsion, un saut, une frappe |
| **AM** | amplitude | aller loin dans une articulation (flexion profonde, jambe haute) |
| **OR** | orientation | tourner, pivoter, changer de direction |
| **SO** | le sol | tomber sans casse, rouler, se relever |
| **GL** | la glisse | avancer et tenir sur un sol qui glisse |

**Ce que N3 peut faire** (le modèle simulé : 17 articulations, hanches à deux axes, genoux, chevilles à deux axes, épaules à deux axes, coudes,
cou ; **pas de rotation de la hanche ni de la taille, pas de poignets ni de mains qui saisissent, pas d'orteils**, des pieds rigides, des servos
en position de 200 N·m, une hanche qui plie à 135°) : **oui** (faisable tel quel), **adapté** (faisable en changeant le geste, dit comment),
**non** (pas avec ce corps, dit pourquoi). **Déjà** : un cahier l'a déjà joué.

## 1. Yoga

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la montagne (tadasana) | debout, immobile, le poids réparti | S2, TR | oui |
| le flamant (posture de l'échassier) | sur une jambe, l'autre genou levé devant | S1, TR | **déjà** (R-073) |
| l'arbre | sur une jambe, le pied libre contre l'autre jambe, genou ouvert | S1, AM | **déjà** (R-073) |
| l'avion | sur une jambe, le torse penché, la jambe libre tendue derrière | S1, TR, CB | **déjà** (R-073) |
| le danseur | sur une jambe, la jambe libre pliée derrière, le torse penché | S1, TR, AM | **déjà** (R-073) |
| le guerrier III | le torse à l'horizontale, la jambe libre tendue derrière | S1, TR, CB | **déjà** (R-073, raté) |
| la chaise | les deux pieds, accroupi à mi-hauteur, les bras devant | S2, TR, AM | oui (comme le squat, R-088) |
| le guerrier I et II | une grande fente, les bras levés ou de côté | S2, TP, AM | adapté : pas de rotation de hanche, fente droite |
| le chien tête en bas | les mains et les pieds au sol, les fesses en haut | SO, AM | **déjà** (l'ours, R-096) |
| la planche | sur les mains et les pieds, le corps droit | TR, SO | **déjà** (la pompe, R-095) |
| la posture de l'enfant | assis sur les talons, le torse sur les cuisses | SO, AM | oui (R-108 a tenu « assis sur les cuisses ») |
| le pont | sur le dos, les hanches levées | SO, TR | adapté : sur le dos, les pieds au sol |

## 2. Soccer

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| le tir du coup de pied | la jambe recule, frappe, revient | S1, DY, PU, CB | **déjà** (R-087) ; au répertoire de R-123 |
| la passe de l'intérieur du pied | la jambe frappe pied tourné | S1, DY | non : pas de rotation de hanche (pied tourné) ; adapté en passe du cou-de-pied |
| la conduite de balle | marcher en poussant le ballon | DY, RY | adapté : le ballon existe (R-087), la marche aussi |
| le jonglage | toucher le ballon du pied sans qu'il tombe | S1, DY, RY | adapté : un toucher sur place, sur une jambe |
| l'amorti | arrêter le ballon de la semelle | S1, DY | adapté |
| les feintes et crochets | changer de direction balle au pied | OR, TP | adapté : le virage par les pas (R-076) |
| le gardien : plongeon | tomber de côté pour arrêter | SO, PU | adapté : la chute contrôlée de côté |

## 3. Athlétisme

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| les montées de genou | sur place, un genou haut puis l'autre | S1, DY, RY | au répertoire de R-123 (sur une jambe) |
| les talons-fesses | le talon monte vers la fesse | S1, DY, RY, AM | oui |
| le skipping (pas A) | une montée de genou en avançant, rebond | DY, RY, PU | adapté : sans rebond (pas de saut fiable) |
| la fente avant, la fente marchée | un grand pas, le genou arrière vers le sol | TP, AM, S2 | **déjà** (11.11, fentes) |
| la position de départ (debout ou accroupie) | penché, prêt à partir | TR, PU | oui |
| le départ, l'accélération | passer de l'arrêt à la course | DY, PU | adapté : la marche qui accélère (R-107) |
| les sauts (bondissements, saut en longueur) | une impulsion, un vol, une réception | PU, DY | adapté : l'impulsion (11.11, essai_n3_impulsion) |
| les haies (le passage de la jambe) | la jambe d'attaque haute, la jambe de retour de côté | S1, AM, DY | adapté : le geste sur place |
| le lancer (poids, javelot) | l'élan, le transfert, le bras | TP, CB, PU | adapté : sans prise, le bras et le transfert |

## 4. Haltérophilie

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| le squat (accroupi chargé) | descendre et remonter avec une charge | S2, TR, AM | **déjà** (R-088) ; la charge : une masse ajoutée au torse |
| le soulevé de terre | le torse penché, le dos droit, remonter | TR, S2 | adapté : sans saisie, une masse au torse |
| le développé au-dessus de la tête | les bras levés avec une charge | S2, CB | adapté : une masse aux mains (avant-bras) |
| l'arraché, l'épaulé-jeté | une charge du sol au-dessus de la tête, très vite | PU, TR, S2 | non : il faut saisir la barre |
| la fente chargée | la fente avec une masse | TP, S2 | adapté |

## 5. Football (canadien et américain)

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la position à trois appuis | accroupi, une main au sol | S2, TR | adapté : comme l'ours, une main |
| le départ de la ligne | sortir de la position basse | PU, DY | adapté |
| le pas chassé latéral | se déplacer de côté sans croiser | TP, DY, RY | **déjà** (la marche de côté, 11.11) |
| la marche arrière du demi défensif | reculer vite | DY | **déjà** (R-079 ; elle dérive, R-122) |
| le changement de direction | planter un pied, repartir | OR, PU, TP | adapté |
| l'encaissement d'un plaquage | rester debout sous une poussée | RC, S2 | **déjà** (les poussées, R-091, R-115) |

## 6. Baseball

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la position du frappeur | les pieds écartés, les genoux fléchis | S2 | oui |
| l'élan du frappeur | le pas d'appel, le transfert, la rotation | TP, CB, OR | adapté : pas de rotation de la taille ; le transfert et les bras |
| le lancer du lanceur | le genou levé, l'enjambée, le bras | S1, TP, CB | adapté : le genou levé et l'enjambée (sans la rotation) |
| le receveur accroupi | accroupi profond, longtemps | S2, AM | oui (le squat profond, R-088) |
| la course entre les buts | courir, tourner le coin | DY, OR | adapté : la marche, le virage |

## 7. Hockey

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la position de base | genoux fléchis, torse penché | S2, TR | oui |
| la poussée du patineur | une jambe pousse de côté, l'autre glisse | GL, TP, S1 | adapté : un sol qui glisse (frottement bas) |
| le croisé | une jambe passe par-dessus l'autre dans le virage | OR, TP | non : il faut tourner la hanche |
| l'arrêt en chasse-neige | les pieds s'écartent, freinent | GL, S2 | adapté |
| le patinage à reculons | les pieds en sablier | GL, RY | adapté |
| le maniement du bâton | — | — | non : pas de mains |

## 8. Patin (artistique et de vitesse)

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la glisse sur un pied | glisser, le pied libre en l'air | GL, S1 | adapté : sol glissant |
| l'appui du patineur de vitesse | penché, la jambe libre tendue derrière | S1, TR | au répertoire de R-123 (sans glisse) |
| la poussée et le retour | la jambe pousse de côté, revient | GL, TP, RY | adapté |
| la pirouette | tourner sur un pied | OR, S1 | non : pas de rotation de la hanche |

## 9. Vélo

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| pédaler | les jambes tournent en cercle, en alternance | RY, CB | adapté : sur le dos, les jambes pédalent en l'air (pas de vélo dans la simulation) |
| l'équilibre à basse vitesse | — | — | non : pas de vélo, pas de mains |

## 10. Gymnastique

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la balance (avant) | sur une jambe, le torse et la jambe libre à l'horizontale | S1, TR, AM | comme l'avion et le guerrier (R-073) |
| la roulade | rouler sur le dos, se relever | SO | adapté : se retourner (R-103), la chaîne assise (R-104) |
| la réception d'un saut | atterrir, amortir, rester debout | RC, PU, S2 | adapté : tomber de 10 à 20 cm sur les pieds |
| le saut groupé, le saut extension | sauter, genoux à la poitrine | PU | adapté : l'impulsion (11.11) |
| la chandelle | sur les épaules, les jambes en l'air | SO, TR | adapté |
| le pont | sur les mains et les pieds, le ventre en haut | AM, SO | adapté : le crabe (R-109) |
| la roue | — | — | non : il faut porter le corps sur les mains de côté |

## 11. Danse (tous les types)

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| ballet : le plié | les genoux fléchis, le dos droit | S2, AM, TR | oui |
| ballet : le relevé | monter sur la pointe des pieds | S2 | adapté : les chevilles lèvent le talon (pied rigide) |
| ballet : le tendu, le dégagé | la jambe glisse et se tend | S1, TP | oui |
| ballet : le développé | la jambe se lève tendue devant | S1, AM | au répertoire de R-123 |
| ballet : l'arabesque, l'attitude | la jambe derrière, tendue ou pliée | S1, TR | au répertoire de R-123 (l'arabesque) |
| ballet : la pirouette | tourner sur un pied | OR, S1 | non (rotation de hanche) |
| salsa : le pas de base | avant, arrière, sur le temps | TP, RY | oui |
| valse : le pas à trois temps | trois transferts de poids, le premier marqué | TP, RY | oui (sans le tour) |
| tango : la marche | une marche lente, le poids d'un pied à l'autre | TP, DY | oui |
| hip-hop : le rebond, le pas touché | les genoux rebondissent, un pied touche à côté | RY, TP | oui |
| hip-hop : le break au sol | — | SO | non (il faut les mains et les rotations) |
| gigue québécoise | des frappes rapides des pieds sur le temps | RY, TP, DY | adapté : frappes plus lentes |
| danse contemporaine : la chute et la reprise | se laisser tomber, se relever | SO, RC | adapté : la chaîne du sol (R-104) |
| danse sociale : le balancement | le poids d'un côté à l'autre, avec les bras | TP, CB, RY | oui |

## 12. Les échauffements (de tous ces sports)

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| la marche sur place | lever un pied puis l'autre | RY, TP | oui |
| le balancier de la jambe (avant-arrière) | la jambe libre balance | S1, DY, AM | au répertoire de R-123 |
| le balancier latéral | la jambe libre balance de côté | S1, DY | oui |
| les cercles de hanche | la jambe libre fait des cercles | S1, DY, AM | au répertoire de R-123 |
| les cercles de bras | les bras tournent | CB | oui |
| les sauts écartés (jumping jacks) | sauter en écartant jambes et bras | PU, RY | adapté : sans saut, écarter et rapprocher |
| les squats de mise en route | descendre, remonter, lentement | S2, AM | **déjà** (R-088) |
| les fentes de mise en route | une fente, l'autre | TP, AM | **déjà** (11.11) |
| les rotations du tronc | — | — | non : pas de taille |
| les flexions latérales | se pencher de côté | TR | adapté : par le roulis des hanches |
| les rotations des chevilles | la cheville trace un cercle | AM | oui (le pied libre) |

## 13. Ajoutés : arts martiaux (karaté, judo) et basketball

| exercice | le geste | entraîne | N3 |
|---|---|---|---|
| karaté : le coup de pied de côté | la jambe libre frappe de côté | S1, PU, AM | au répertoire de R-123 |
| karaté : le coup de pied de face | la jambe frappe devant | S1, PU | oui (comme le tir) |
| karaté : la posture du cavalier | les pieds très écartés, accroupi | S2, AM | oui |
| judo : la chute arrière, la chute de côté (ukemi) | tomber sans se blesser | SO | adapté |
| judo : tenir sous une poussée | rester debout, abaisser le centre | RC, S2 | **déjà** (les poussées) |
| basketball : la position défensive, le pas glissé | accroupi, se déplacer de côté | TP, DY | **déjà** (la marche de côté) |
| basketball : le pivot | tourner sur un pied d'appui | OR | non : pas de rotation de hanche |
| basketball : le saut de lancer | sauter, retomber | PU, RC | adapté : l'impulsion |

## Ce que N3 ne peut pas faire, et ce qu'il faudrait

**Tourner sur un pied** (pirouette, pivot, croisé, passe intérieure) demande une **rotation de la hanche** (un axe de lacet) : N3 n'en a
pas. **Tourner le haut du corps** (élan du frappeur, rotations du tronc) demande une **taille** qui tourne. **Saisir** (barres, bâton, vélo)
demande des **mains**. Ce sont les trois manques de N3 pour le multisport ; le premier est le plus utile (il servirait aussi à la marche).

## Le premier essai : ce qu'on apprend de chaque exercice (R-124)

Chaque exercice faisable, **appris seul** (le socle d'équilibre de R-073, réglé pour lui), puis mesuré de deux façons :
1. **par une batterie commune**, la même pour tous, inspirée des tests d'éducation physique européens (Eurofit) : tenir sur une jambe,
   tenir sous une poussée de côté sur une jambe et sur deux pieds, transférer le poids d'un pied à l'autre ;
2. **par ce qu'il apporte aux autres** : son socle joué sur tous les autres exercices (une matrice de transfert ; la ligne d'un exercice dit
   ce qu'il apprend au corps, la colonne dit d'où vient ce qu'il demande).
