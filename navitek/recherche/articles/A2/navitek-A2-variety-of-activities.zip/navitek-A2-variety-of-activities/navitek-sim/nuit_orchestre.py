"""La nuit du 12 au 13.11.2026 : enchaîne, sans la session, (1) la fin de l'étape 1 de R-123 (attend que les 6 socles soient écrits),
(2) l'étape 2 de R-123 (la spécialisation, et ses verdicts), (3) R-125, les 1000 essais. Chaque script reprend où il s'est arrêté.
Lancé détaché, en priorité basse (la méditation de 3 h 10 passe avant).    python -X utf8 nuit_orchestre.py"""
import json
import os
import subprocess
import sys
import time

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")
LOG = os.path.join(RES, "nuit-orchestre.log")


def dire(txt):
    with open(LOG, "a", encoding="utf-8") as fh:
        fh.write(time.strftime("%H:%M:%S ") + txt + "\n")


def lancer(args, sortie):
    dire("lance : " + " ".join(args))
    with open(os.path.join(RES, sortie), "a", encoding="utf-8") as fh:
        r = subprocess.run([sys.executable, "-X", "utf8"] + args, cwd=ICI, stdout=fh, stderr=subprocess.STDOUT)
    dire("fini (code %d) : %s" % (r.returncode, " ".join(args)))
    return r.returncode


def main():
    f_enf = os.path.join(RES, "n3-multisport-enfance.json")
    dire("attend la fin de l'enfance de R-123")
    while True:
        try:
            if len(json.load(open(f_enf, encoding="utf-8"))) >= 6:
                break
        except (OSError, ValueError):
            pass
        time.sleep(30)
    time.sleep(20)
    if not os.path.exists(os.path.join(RES, "n3-multisport-verdicts.json")):
        lancer(["essai_n3_multisport.py", "specialisation"], "n3-multisport-specialisation-sortie.log")
    lancer(["essai_n3_nuit_1000.py", "--processus", "14"], "n3-nuit-1000-sortie.log")
    dire("la nuit est finie")


if __name__ == "__main__":
    main()
