"""R-121 — le curriculum du nombre : à chaque épisode, k axes distincts parmi les 25 de R-111 (tous sauf la vitesse visée) dans leur plage
large, les autres au nominal, la vitesse visée dans l'étroite ; k part de 1, monte de 1 après deux générations de suite à au moins 80 % de
réussite des candidats, descend de 1 après deux de suite sous 30 % (entre 1 et 25). Même départ, même CMA-ES, mêmes graines, même note que
R-111 ; évalué sur le jeu de 360 conditions. Le tirage par épisode et la montée de k passent par des enveloppes dans le processus principal
(banc.py et lancer.py ne sont pas modifiés). Simulé.

Les règles de verdict, fixées ici avant de lancer :
  H181  k final >= 5 pour au moins 2 graines sur 3
  H182  réussite au nominal (3 graines ensemble) >= 0,80
  H183  réussite « dans » de CN − celle de U1 (R-120) >= 0,05

Attend la fin de R-120 (resultats-r120/verdicts.json).

    python -X utf8 curriculum_nombre.py        → resultats-r121/CN-g{1,2,3}.json, resultats-r121/verdicts.json"""
import json
import multiprocessing as mp
import os
import time

import numpy as np

import banc as B
import lancer as L

ICI = os.path.dirname(os.path.abspath(__file__))
D_OUT = os.path.join(ICI, "resultats-r121")
AXES_U = [n for n in B.AXES if n != "vitesse_visee"]
_tirer, _regle = B.tirer_condition, B.regle_regime
ETAT = {"k": 1, "haut": 0, "bas": 0, "histo": []}


def tirer_cn(rng, regle, solveur="normal"):
    if regle.get("_cn"):
        noms = [str(n) for n in rng.choice(AXES_U, ETAT["k"], replace=False)]
        r = _regle("R0")
        r["vitesse_visee"] = ("etroite", None)
        for n in noms:
            r[n] = ("large", None)
        c = _tirer(rng, r, solveur)
        c["axes_cn"] = noms
        return c
    return _tirer(rng, regle, solveur)


def regle_cn(regime, f=None, sans_groupe=None, largeurs=None):
    return {"_cn": True} if regime == "CN" else _regle(regime, f=f, sans_groupe=sans_groupe, largeurs=largeurs)


def journal(txt):
    """Le journal de lancer.entrainer ; il lit aussi la réussite de chaque génération pour faire monter ou descendre k."""
    ligne = time.strftime("%H:%M:%S ") + txt + "  [k = %d]" % ETAT["k"]
    print(ligne, flush=True)
    with open(os.path.join(D_OUT, "journal.log"), "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")
    if "réussite" in txt:
        taux = float(txt.rsplit("réussite", 1)[1].strip().rstrip("%").strip()) / 100
        ETAT["haut"] = ETAT["haut"] + 1 if taux >= 0.8 else 0
        ETAT["bas"] = ETAT["bas"] + 1 if taux < 0.3 else 0
        if ETAT["haut"] >= 2 and ETAT["k"] < len(AXES_U):
            ETAT["k"], ETAT["haut"] = ETAT["k"] + 1, 0
        elif ETAT["bas"] >= 2 and ETAT["k"] > 1:
            ETAT["k"], ETAT["bas"] = ETAT["k"] - 1, 0
        ETAT["histo"].append(ETAT["k"])


def main():
    os.makedirs(D_OUT, exist_ok=True)
    while not os.path.exists(os.path.join(ICI, "resultats-r120", "verdicts.json")):
        time.sleep(30)
    B.tirer_condition, B.regle_regime = tirer_cn, regle_cn
    jeu = json.load(open(os.path.join(ICI, "eval", "jeu_evaluation.json"), encoding="utf-8"))
    with mp.Pool(3, initializer=B.preparer) as pool:
        for g in (1, 2, 3):
            f = os.path.join(D_OUT, "CN-g%d.json" % g)
            if os.path.exists(f):
                continue
            ETAT.update(k=1, haut=0, bas=0, histo=[])
            cfg = dict(nom="CN-g%d" % g, lot="r121", regime="CN", graine=g, generations=L.GENERATIONS, population=L.POPULATION,
                       episodes=L.EPISODES, sigma=L.SIGMA)
            t0 = time.time()
            res = L.entrainer(pool, cfg, journal)
            ev = pool.map(L._eval, [(res["politique_moyenne"], c) for c in jeu], chunksize=4)
            res["evaluation"] = ev
            res["evaluation_resume"] = {j: round(float(np.mean([e["reussi"] for e in ev if e["jeu"] == j])), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")}
            res["k_final"], res["k_histo"] = ETAT["k"], list(ETAT["histo"])
            res["minutes"] = round((time.time() - t0) / 60, 1)
            json.dump(res, open(f, "w", encoding="utf-8"), ensure_ascii=False)
            journal("%s fini en %.1f min ; k final %d ; évaluation : %s" % (cfg["nom"], res["minutes"], ETAT["k"], res["evaluation_resume"]))
    taux = lambda runs, j, k="reussi": float(np.mean([e[k] for r in runs for e in r["evaluation"] if e["jeu"] == j]))
    C = [json.load(open(os.path.join(D_OUT, "CN-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    U = [json.load(open(os.path.join(ICI, "resultats-r120", "U1-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    kf = [r["k_final"] for r in C]
    v = {"H181": {"k_final": kf}, "H182": {"nominal_CN": taux(C, "nominal")}, "H183": {"dans_CN": taux(C, "dans"), "dans_U1": taux(U, "dans")}}
    v["H181"]["verdict"] = "confirmée" if sum(k >= 5 for k in kf) >= 2 else "réfutée"
    v["H182"]["verdict"] = "confirmée" if v["H182"]["nominal_CN"] >= 0.80 else "réfutée"
    v["H183"]["verdict"] = "confirmée" if v["H183"]["dans_CN"] - v["H183"]["dans_U1"] >= 0.05 else "réfutée"
    v["tableau"] = {nom: {j: round(taux(runs, j), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")} | {"chutes_dans": round(taux(runs, "dans", "tombe"), 3)}
                    for nom, runs in (("U1", U), ("CN", C))}
    json.dump(v, open(os.path.join(D_OUT, "verdicts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    journal("verdicts : " + json.dumps(v, ensure_ascii=False))


if __name__ == "__main__":
    main()
