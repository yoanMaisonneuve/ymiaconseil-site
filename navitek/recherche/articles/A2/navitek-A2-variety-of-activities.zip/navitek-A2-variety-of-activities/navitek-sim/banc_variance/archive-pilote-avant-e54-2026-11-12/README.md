# Le passage pilote du banc de variance (R-111), gardé

12.11.2026 : lancé à 09:15, arrêté à 09:18 (heures du journal), archivé à 09:18 (heure lue). Un seul entraînement fini (R0, graine 1) : réussite
10 % au nominal, 0 % partout ailleurs. Défaut E54 : le point de départ (la marche B-g1 de R-107) ne passait pas le juge, même au nominal ;
elle va assez vite à la vitesse visée de 0,3 m/s, mais en sautillant (0,55 s sans appui ; le juge en permet 0,1). Après 50 générations, elle
ne sautille plus mais plafonne à 0,58-0,76 m, au seuil du juge (0,6 m). Tous les régimes partaient d'un plancher : la comparaison n'aurait
rien dit. Corrigé (le juge n'a pas changé) : un pré-entraînement au nominal, le même pour tous, jusqu'à une marche qui passe le juge avec de
la marge ; tous les régimes partent de lui. Les résultats valides sont ceux du passage suivant.
