# R-119 : attendre la fin de R-118 (essai_n3_melange.py), puis lancer piege_recompense.py, détaché, en priorité basse.
# Lancé par la session le 12.11.2026 (une tâche de fond de la session est coupée au bout de 2 h ; ce calcul en dure plus).
$sim = "C:\Users\Utilisateur\Documents\openClaude\recherche\agents\cyborg-robotique-V1.0\navitek-sim"
$log = Join-Path $sim "resultats\n3-melange-sortie.log"
while ($true) {
    if (Test-Path $log) {
        $t = Get-Content $log -Raw -Encoding UTF8
        if ($t -match "écrit resultats/n3-melange.json" -or $t -match "Traceback") { break }
    }
    Start-Sleep -Seconds 30
}
$dir = Join-Path $sim "banc_variance"
$p = Start-Process python -ArgumentList '-X', 'utf8', 'piege_recompense.py' -WorkingDirectory $dir `
    -RedirectStandardOutput (Join-Path $dir "resultats-r119-sortie.log") -RedirectStandardError (Join-Path $dir "resultats-r119-erreurs.log") `
    -WindowStyle Hidden -PassThru
$p.PriorityClass = 'BelowNormal'
