"""R-119 — le piège de la récompense : le régime R2 de R-111 entraîné avec la note « marcher » (pas de crédit pour le temps debout ; l'avance
comptée même en cas de chute ; −0,5 par chute), mêmes graines, même départ, même CMA-ES ; évalué sur le jeu de 360 conditions de R-111.
Les entraînements utilisent lancer.entrainer ; la note est remplacée dans chaque processus (banc.py n'est pas modifié). Simulé.

Les règles de verdict, fixées ici avant de lancer (les chiffres de R2 et R0 viennent de resultats/ de R-111, graines 1 à 3) :
  H174  réussite au nominal de R2-marcher (3 graines ensemble) >= 0,80
  H175  réussite « dans » de R2-marcher − celle de R0 >= 0,10
  H176  part des chutes « dans » de R2-marcher > celle de R2 (note de R-111)

    python -X utf8 piege_recompense.py        → resultats-r119/R2-marcher-g{1,2,3}.json, resultats-r119/verdicts.json"""
import json
import multiprocessing as mp
import os
import time

import numpy as np

import banc as B
import lancer as L

ICI = os.path.dirname(os.path.abspath(__file__))
D_OUT = os.path.join(ICI, "resultats-r119")


def note_marcher(r):
    return (1.0 * r["reussi"] + 0.5 * min(max(r["avance_m"], 0.0) / B.JUGE["avance_min_m"], 1.0) - 0.5 * r["tombe"]
            - 0.2 * max(0.0, r["derive_m"] - B.JUGE["derive_max_m"]) - 0.5 * max(0.0, r["vol_s"] - B.JUGE["vol_max_s"]))


def _init():
    B.preparer()
    B.note_entrainement = note_marcher


def journal(txt):
    ligne = time.strftime("%H:%M:%S ") + txt
    print(ligne, flush=True)
    with open(os.path.join(D_OUT, "journal.log"), "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")


def main():
    os.makedirs(D_OUT, exist_ok=True)
    jeu = json.load(open(os.path.join(ICI, "eval", "jeu_evaluation.json"), encoding="utf-8"))
    with mp.Pool(3, initializer=_init) as pool:
        for g in (1, 2, 3):
            f = os.path.join(D_OUT, "R2-marcher-g%d.json" % g)
            if os.path.exists(f):
                continue
            cfg = dict(nom="R2-marcher-g%d" % g, lot="r119", regime="R2", graine=g, generations=L.GENERATIONS, population=L.POPULATION,
                       episodes=L.EPISODES, sigma=L.SIGMA, note="marcher")
            t0 = time.time()
            res = L.entrainer(pool, cfg, journal)
            ev = pool.map(L._eval, [(res["politique_moyenne"], c) for c in jeu], chunksize=4)
            res["evaluation"] = ev
            res["evaluation_resume"] = {j: round(float(np.mean([e["reussi"] for e in ev if e["jeu"] == j])), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")}
            res["minutes"] = round((time.time() - t0) / 60, 1)
            json.dump(res, open(f, "w", encoding="utf-8"), ensure_ascii=False)
            journal("%s fini en %.1f min ; évaluation : %s" % (cfg["nom"], res["minutes"], res["evaluation_resume"]))
    taux = lambda runs, j, k="reussi": float(np.mean([e[k] for r in runs for e in r["evaluation"] if e["jeu"] == j]))
    M = [json.load(open(os.path.join(D_OUT, "R2-marcher-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    R2 = [json.load(open(os.path.join(ICI, "resultats", "R2-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    R0 = [json.load(open(os.path.join(ICI, "resultats", "R0-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    v = {"H174": {"nominal_R2_marcher": taux(M, "nominal")}, "H175": {"dans_R2_marcher": taux(M, "dans"), "dans_R0": taux(R0, "dans")},
         "H176": {"chutes_dans_R2_marcher": taux(M, "dans", "tombe"), "chutes_dans_R2": taux(R2, "dans", "tombe")}}
    v["H174"]["verdict"] = "confirmée" if v["H174"]["nominal_R2_marcher"] >= 0.80 else "réfutée"
    v["H175"]["verdict"] = "confirmée" if v["H175"]["dans_R2_marcher"] - v["H175"]["dans_R0"] >= 0.10 else "réfutée"
    v["H176"]["verdict"] = "confirmée" if v["H176"]["chutes_dans_R2_marcher"] > v["H176"]["chutes_dans_R2"] else "réfutée"
    v["tableau"] = {nom: {j: round(taux(runs, j), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")} | {"chutes_dans": round(taux(runs, "dans", "tombe"), 3),
                    "avance_nominal_m": round(taux(runs, "nominal", "avance_m"), 3)} for nom, runs in (("R0", R0), ("R2", R2), ("R2-marcher", M))}
    json.dump(v, open(os.path.join(D_OUT, "verdicts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    journal("verdicts : " + json.dumps(v, ensure_ascii=False))


if __name__ == "__main__":
    main()
