"""R-120 — une difficulté à la fois : le régime U1 (à chaque épisode, un seul des 25 axes de R-111 tiré dans sa plage large, les autres au
nominal, la vitesse visée dans l'étroite), entraîné comme R-111 (lancer.entrainer : même départ, même CMA-ES, mêmes graines, même note),
évalué sur le jeu de 360 conditions de R-111. Le tirage par épisode passe par une enveloppe de banc.tirer_condition dans le processus
principal (banc.py et lancer.py ne sont pas modifiés). Simulé.

Les règles de verdict, fixées ici avant de lancer (R0 : resultats/ de R-111, graines 1 à 3) :
  H177  réussite au nominal de U1 >= 0,80
  H178  réussite « dans » de U1 − celle de R0 >= 0,05
  H179  réussite « coins » de U1 − celle de R0 >= 0,10
  H180  part des chutes « dans » de U1 < celle de R0

Attend la fin de R-119 (resultats-r119/verdicts.json) avant de commencer, pour ne pas lui prendre ses processeurs.

    python -X utf8 une_a_la_fois.py        → resultats-r120/U1-g{1,2,3}.json, resultats-r120/verdicts.json"""
import json
import multiprocessing as mp
import os
import time

import numpy as np

import banc as B
import lancer as L

ICI = os.path.dirname(os.path.abspath(__file__))
D_OUT = os.path.join(ICI, "resultats-r120")
AXES_U = [n for n in B.AXES if n != "vitesse_visee"]
_tirer = B.tirer_condition


def tirer_u1(rng, regle, solveur="normal"):
    if regle.get("_u1"):
        n = str(rng.choice(AXES_U))
        r = B.regle_regime("R0")
        r["vitesse_visee"] = ("etroite", None)
        r[n] = ("large", None)
        c = _tirer(rng, r, solveur)
        c["axe_u1"] = n
        return c
    return _tirer(rng, regle, solveur)


_regle = B.regle_regime


def regle_u1(regime, f=None, sans_groupe=None, largeurs=None):
    if regime == "U1":
        return {"_u1": True}
    return _regle(regime, f=f, sans_groupe=sans_groupe, largeurs=largeurs)


def journal(txt):
    ligne = time.strftime("%H:%M:%S ") + txt
    print(ligne, flush=True)
    with open(os.path.join(D_OUT, "journal.log"), "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")


def main():
    os.makedirs(D_OUT, exist_ok=True)
    while not os.path.exists(os.path.join(ICI, "resultats-r119", "verdicts.json")):
        time.sleep(30)
    B.tirer_condition, B.regle_regime = tirer_u1, regle_u1
    jeu = json.load(open(os.path.join(ICI, "eval", "jeu_evaluation.json"), encoding="utf-8"))
    with mp.Pool(3, initializer=B.preparer) as pool:
        for g in (1, 2, 3):
            f = os.path.join(D_OUT, "U1-g%d.json" % g)
            if os.path.exists(f):
                continue
            cfg = dict(nom="U1-g%d" % g, lot="r120", regime="U1", graine=g, generations=L.GENERATIONS, population=L.POPULATION,
                       episodes=L.EPISODES, sigma=L.SIGMA)
            t0 = time.time()
            res = L.entrainer(pool, cfg, journal)
            ev = pool.map(L._eval, [(res["politique_moyenne"], c) for c in jeu], chunksize=4)
            res["evaluation"] = ev
            res["evaluation_resume"] = {j: round(float(np.mean([e["reussi"] for e in ev if e["jeu"] == j])), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")}
            res["minutes"] = round((time.time() - t0) / 60, 1)
            json.dump(res, open(f, "w", encoding="utf-8"), ensure_ascii=False)
            journal("%s fini en %.1f min ; évaluation : %s" % (cfg["nom"], res["minutes"], res["evaluation_resume"]))
    taux = lambda runs, j, k="reussi": float(np.mean([e[k] for r in runs for e in r["evaluation"] if e["jeu"] == j]))
    U = [json.load(open(os.path.join(D_OUT, "U1-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    R0 = [json.load(open(os.path.join(ICI, "resultats", "R0-g%d.json" % g), encoding="utf-8")) for g in (1, 2, 3)]
    v = {"H177": {"nominal_U1": taux(U, "nominal")}, "H178": {"dans_U1": taux(U, "dans"), "dans_R0": taux(R0, "dans")},
         "H179": {"coins_U1": taux(U, "coins"), "coins_R0": taux(R0, "coins")},
         "H180": {"chutes_dans_U1": taux(U, "dans", "tombe"), "chutes_dans_R0": taux(R0, "dans", "tombe")}}
    v["H177"]["verdict"] = "confirmée" if v["H177"]["nominal_U1"] >= 0.80 else "réfutée"
    v["H178"]["verdict"] = "confirmée" if v["H178"]["dans_U1"] - v["H178"]["dans_R0"] >= 0.05 else "réfutée"
    v["H179"]["verdict"] = "confirmée" if v["H179"]["coins_U1"] - v["H179"]["coins_R0"] >= 0.10 else "réfutée"
    v["H180"]["verdict"] = "confirmée" if v["H180"]["chutes_dans_U1"] < v["H180"]["chutes_dans_R0"] else "réfutée"
    v["tableau"] = {nom: {j: round(taux(runs, j), 3) for j in ("nominal", "dans", "hors", "coins", "solveur")} | {"chutes_dans": round(taux(runs, "dans", "tombe"), 3)}
                    for nom, runs in (("R0", R0), ("U1", U))}
    json.dump(v, open(os.path.join(D_OUT, "verdicts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    journal("verdicts : " + json.dumps(v, ensure_ascii=False))


if __name__ == "__main__":
    main()
