"""R-111 — le diagnostic de E56 (prédictions D1 à D4 dans le cahier, § 6 ter, écrites avant) : la marche pré-entraînée, telle quelle, sous
variance étroite et large ; chaque axe seul, à l'étroite et à la large ; et les candidats tirés autour d'elle selon le pas initial.

    python -X utf8 diagnostic.py
Sortie : resultats/diagnostic_e56.json"""
import json
import multiprocessing as mp
import os

import numpy as np

import banc as B

ICI = os.path.dirname(os.path.abspath(__file__))


def _jouer(args):
    u, cond = args
    r = B.rouler(u, cond)
    return {k: r[k] for k in ("reussi", "tombe", "chute_s", "avance_m", "derive_m", "vol_s")}


def main():
    u = np.array(json.load(open(os.path.join(ICI, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    lots = {}
    rng = np.random.default_rng(2001)
    lots["etroite"] = [B.tirer_condition(rng, B.regle_regime("R1")) for _ in range(50)]
    rng = np.random.default_rng(2002)
    lots["large"] = [B.tirer_condition(rng, B.regle_regime("R2")) for _ in range(50)]
    for i, n in enumerate(B.AXES):
        for mode in ("etroite", "large"):
            rng = np.random.default_rng(np.random.SeedSequence([2003, i, mode == "large"]))
            r = B.regle_regime("R0")
            r["vitesse_visee"] = ("etroite", None)
            r[n] = (mode, None)
            lots["%s:%s" % (n, mode)] = [B.tirer_condition(rng, r) for _ in range(10)]
    rng = np.random.default_rng(2004)
    r = B.regle_regime("R0")
    r["vitesse_visee"] = ("etroite", None)
    nominaux = [B.tirer_condition(rng, r) for _ in range(4)]
    taches, cles = [], []
    for k, conds in lots.items():
        for c in conds:
            taches.append((u, c))
            cles.append(k)
    rs = np.random.default_rng(2005)
    for sigma in (0.02, 0.05, 0.10, 0.15):
        for j in range(32):
            x = np.clip(u + sigma * rs.standard_normal(len(u)), 0, 1)
            taches.append((x, nominaux[j % 4]))
            cles.append("pas:%.2f" % sigma)
    with mp.Pool(14, initializer=B.preparer) as pool:
        res = pool.map(_jouer, taches, chunksize=2)
    out = {}
    for k, r in zip(cles, res):
        o = out.setdefault(k, {"n": 0, "reussis": 0, "chutes": 0, "avance": []})
        o["n"] += 1
        o["reussis"] += int(r["reussi"])
        o["chutes"] += int(r["tombe"])
        o["avance"].append(r["avance_m"])
    for k, o in out.items():
        o["taux"] = round(o["reussis"] / o["n"], 3)
        o["avance_moy"] = round(float(np.mean(o["avance"])), 3)
        del o["avance"]
    json.dump(out, open(os.path.join(ICI, "resultats", "diagnostic_e56.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for k in ("etroite", "large"):
        print("%-8s %d/%d réussis, %d chutes, avance %.2f m" % (k, out[k]["reussis"], out[k]["n"], out[k]["chutes"], out[k]["avance_moy"]), flush=True)
    print("un axe seul (étroite | large) :", flush=True)
    for n in B.AXES:
        a, b = out["%s:etroite" % n], out["%s:large" % n]
        print("  %-16s %2d/10 (chutes %2d)  |  %2d/10 (chutes %2d)" % (n, a["reussis"], a["chutes"], b["reussis"], b["chutes"]), flush=True)
    for s in ("0.02", "0.05", "0.10", "0.15"):
        o = out["pas:%s" % s]
        print("pas %s : %d/32 candidats passent le nominal" % (s, o["reussis"]), flush=True)


if __name__ == "__main__":
    main()
