"""R-111 — les verdicts des prédictions H135 à H141, calculés à partir de rapport/rapport.json (rapport.py), avec des règles écrites
le 12.11.2026 à 09:40 (heure lue), AVANT le premier résultat du banc, et commises avant lui. Le verdict porte sur les taux mesurés
(3 graines mises ensemble) ; à côté, on dit si l'écart dépasse les intervalles de confiance à 95 % (Wilson).

    python -X utf8 verdicts.py        # écrit rapport/verdicts_calcules.json et les affiche

Les règles :
  H135  nominal : R0 - R2 <= 10 points                                   -> confirmée, sinon réfutée
  H136  dans les plages : R2 >= R0 + 20 et R3 >= R0 + 20                 -> confirmée ; un seul des deux -> partielle ; aucun -> réfutée
  H137  hors plages : R3 > R2 > R1 > R0 (strict)                         -> confirmée ; seul le haut inversé (R2 >= R3 > R1 > R0
        ou R3 > R2, R2 > R0, R1 entre) : voir ci-dessous -> partielle ; sinon réfutée
        partielle si R2 et R3 dépassent tous deux R1 et R0, et R1 > R0, sans l'ordre exact entre R2 et R3
  H138  perte entre le nominal et l'autre solveur : celle de R0 est la plus grande des quatre -> confirmée, sinon réfutée
  H139  dans les plages, selon la largeur (0 = R0 ... 2) : le meilleur à 0,5 ou 1 ; et à 2, au moins 10 points sous le meilleur
        -> les deux : confirmée ; un seul : partielle ; aucun : réfutée
  H140  les trois premiers de l'ablation (réussite perdue dans les plages) parmi frottement au sol, poussées et vent, délai,
        pente et terrain -> les trois : confirmée ; deux : partielle ; un ou aucun : réfutée
  H141  R2 > R0 sur dans, hors, coins et solveur -> les quatre : confirmée ; trois : partielle ; sinon réfutée
"""
import json
import os

ICI = os.path.dirname(os.path.abspath(__file__))
D_RAP = os.path.join(ICI, "rapport")


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--essai", default=None)                 # un rapport factice : rien n'est écrit
    a = ap.parse_args()
    rap = json.load(open(a.essai or os.path.join(D_RAP, "rapport.json"), encoding="utf-8"))
    R = rap["regimes"]
    t = lambda reg, j: R[reg][j]["taux"]
    ic = lambda reg, j: R[reg][j]["ic95"]
    separes = lambda a, b, j: ic(a, j)[0] > ic(b, j)[1] or ic(b, j)[0] > ic(a, j)[1]
    pts = lambda x: "%+d points" % round(100 * x)
    out = []

    d = t("R0", "nominal") - t("R2", "nominal")
    out.append({"code": "H135", "verdict": "confirmée" if d <= 0.10 else "réfutée",
                "mesure": "nominal : R0 %d %%, R2 %d %% (R0 - R2 = %s)%s" % (100 * t("R0", "nominal"), 100 * t("R2", "nominal"), pts(d),
                                                                             ", écart hors des intervalles" if separes("R0", "R2", "nominal") else ", dans les intervalles")})

    g2, g3 = t("R2", "dans") - t("R0", "dans"), t("R3", "dans") - t("R0", "dans")
    n = (g2 >= 0.20) + (g3 >= 0.20)
    out.append({"code": "H136", "verdict": ["réfutée", "partielle", "confirmée"][n],
                "mesure": "dans les plages : R0 %d %%, R2 %d %% (%s), R3 %d %% (%s)" % (100 * t("R0", "dans"), 100 * t("R2", "dans"), pts(g2),
                                                                                      100 * t("R3", "dans"), pts(g3))})

    h = {r: t(r, "hors") for r in ("R0", "R1", "R2", "R3")}
    if h["R3"] > h["R2"] > h["R1"] > h["R0"]:
        v = "confirmée"
    elif min(h["R2"], h["R3"]) > h["R1"] > h["R0"]:
        v = "partielle"
    else:
        v = "réfutée"
    out.append({"code": "H137", "verdict": v, "mesure": "hors plages : " + ", ".join("%s %d %%" % (r, 100 * h[r]) for r in ("R3", "R2", "R1", "R0"))})

    pertes = {r: t(r, "nominal") - t(r, "solveur") for r in ("R0", "R1", "R2", "R3")}
    pire = max(pertes, key=pertes.get)
    out.append({"code": "H138", "verdict": "confirmée" if pire == "R0" else "réfutée",
                "mesure": "perte du nominal à l'autre solveur : " + ", ".join("%s %s" % (r, pts(-pertes[r])) for r in pertes)})

    L = rap["largeurs"]
    xs = sorted(L, key=float)
    dans = {x: L[x]["dans"]["taux"] for x in xs}
    best = max(dans, key=dans.get)
    c1 = float(best) in (0.5, 1.0)
    c2 = "2.0" in dans and dans[best] - dans["2.0"] >= 0.10
    out.append({"code": "H139", "verdict": ["réfutée", "partielle", "confirmée"][c1 + c2],
                "mesure": "dans les plages selon la largeur : " + ", ".join("%s : %d %%" % (x.replace(".0", "").replace(".", ","), 100 * dans[x]) for x in xs)
                          + " ; le meilleur à %s" % best.replace(".0", "").replace(".", ",")})

    A = rap["ablation"]
    rang = sorted(A, key=lambda g: -A[g]["perte_dans"])
    ens = {"frottement_sol", "perturbations", "delai", "terrain"}
    n = sum(g in ens for g in rang[:3])
    out.append({"code": "H140", "verdict": "confirmée" if n == 3 else "partielle" if n == 2 else "réfutée",
                "mesure": "classement (réussite perdue dans les plages) : " + ", ".join("%s %s" % (g, pts(A[g]["perte_dans"])) for g in rang)})

    jeux = ("dans", "hors", "coins", "solveur")
    n = sum(t("R2", j) > t("R0", j) for j in jeux)
    out.append({"code": "H141", "verdict": "confirmée" if n == 4 else "partielle" if n == 3 else "réfutée",
                "mesure": "R2 contre R0 : " + ", ".join("%s %d %% contre %d %%%s" % (j, 100 * t("R2", j), 100 * t("R0", j), " (hors des intervalles)" if separes("R2", "R0", j) else "")
                                                         for j in jeux)})
    if not a.essai:
        json.dump(out, open(os.path.join(D_RAP, "verdicts_calcules.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for o in out:
        print(o["code"], o["verdict"], "—", o["mesure"], flush=True)


if __name__ == "__main__":
    main()
