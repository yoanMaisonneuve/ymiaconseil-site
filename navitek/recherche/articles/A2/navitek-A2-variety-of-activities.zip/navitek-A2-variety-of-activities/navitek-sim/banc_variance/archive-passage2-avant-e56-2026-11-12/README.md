# R-111, deuxième passage : arrêté à 10:05 (E56)

Archivé le 12.11.2026 à 10:05 (heure lue), par la session.

**Ce qui a tourné.** Le pré-entraînement au nominal (09:29 à 09:43 ; 100 % au nominal, 0,89 m ; gardé, il reste valable :
`resultats/pre_entrainement.json`), puis le banc à partir de 09:43 : R0-g1 (2,2 min ; nominal 100 %, dans 0 %, hors 0 %, coins 1 %,
solveur 0 %), R1-g1 (15,8 min ; **0 % partout, même au nominal** ; aucun candidat n'a réussi pendant ses 50 générations), R2-g1 en cours
(0 % de réussite des candidats à la génération 21). Arrêté par la session.

**Pourquoi l'arrêt.** Le banc devait comparer des régimes qui partent d'une marche qui passe le juge. Avec le pas initial de CMA-ES à 0,15
(sur des réglages ramenés entre 0 et 1), la population s'éloigne de la marche pré-entraînée ; au nominal (R0), elle la retrouve ; sous
variance (R1), elle ne la retrouve pas et la moyenne dérive vers une non-marche. Les résultats seraient au plancher pour tous les régimes
avec variance, et le banc aurait pris environ 10 h au lieu de 3 h 30 (15,8 min par entraînement avec variance). Le diagnostic chiffré
suit dans le cahier R-111, § 6 ter.

Fichiers : R0-g1.json, R1-g1.json, banc.log, lancer-sortie.log.
