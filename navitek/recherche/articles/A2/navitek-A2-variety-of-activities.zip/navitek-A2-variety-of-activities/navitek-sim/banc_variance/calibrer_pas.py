"""R-111 — calibrer le pas initial de CMA-ES (E56) : la règle, fixée ici avant de lancer : le plus grand pas, parmi 0,025,
0,03, 0,035 et 0,04, où au moins la moitié de 64 candidats tirés autour de la marche pré-entraînée passent encore le nominal ; sinon 0,02.

    python -X utf8 calibrer_pas.py      → resultats/calibrage_pas.json"""
import json
import multiprocessing as mp
import os

import numpy as np

import banc as B

ICI = os.path.dirname(os.path.abspath(__file__))


def _jouer(args):
    u, cond = args
    return bool(B.rouler(u, cond)["reussi"])


if __name__ == "__main__":
    u = np.array(json.load(open(os.path.join(ICI, "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    rng = np.random.default_rng(2006)
    r = B.regle_regime("R0")
    r["vitesse_visee"] = ("etroite", None)
    nominaux = [B.tirer_condition(rng, r) for _ in range(8)]
    pas = (0.025, 0.03, 0.035, 0.04)
    taches = []
    for s in pas:
        for j in range(64):
            taches.append((np.clip(u + s * rng.standard_normal(len(u)), 0, 1), nominaux[j % 8]))
    with mp.Pool(14, initializer=B.preparer) as pool:
        res = pool.map(_jouer, taches, chunksize=2)
    out = {("%.3f" % s): int(sum(res[i * 64:(i + 1) * 64])) for i, s in enumerate(pas)}
    choisi = max([s for s in pas if out["%.3f" % s] >= 32], default=0.02)
    json.dump({"reussis_sur_64": out, "pas_choisi": choisi}, open(os.path.join(ICI, "resultats", "calibrage_pas.json"), "w", encoding="utf-8"), indent=1)
    print(out, "→ pas choisi", choisi, flush=True)
