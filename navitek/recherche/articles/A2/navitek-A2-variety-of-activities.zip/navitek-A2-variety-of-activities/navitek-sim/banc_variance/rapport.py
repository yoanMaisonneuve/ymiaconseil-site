"""R-111 — le rapport du banc de variance : régimes × jeux d'évaluation (intervalles de Wilson à 95 %), la courbe réussite contre largeur,
le classement des axes (ablation), le curriculum, les mesures secondaires, et les films du meilleur et du pire cas de chaque régime.

    python -X utf8 rapport.py            # tableaux et figures (ce qui est fini)
    python -X utf8 rapport.py --films    # et les films (8 : meilleur et pire cas des 4 régimes)
Sorties : banc_variance/rapport/rapport.json, courbe-largeur.png, ablation.png, films/*.mp4."""
import argparse
import glob
import json
import math
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
D_RES, D_RAP = os.path.join(ICI, "resultats"), os.path.join(ICI, "rapport")
JEUX = ["nominal", "dans", "hors", "coins", "solveur"]
REGIMES = ["R0", "R1", "R2", "R3"]


def wilson(k, n, z=1.96):
    if n == 0:
        return (None, None, None)
    p = k / n
    den = 1 + z * z / n
    c = (p + z * z / (2 * n)) / den
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (round(p, 3), round(max(0.0, c - h), 3), round(min(1.0, c + h), 3))


def charger():
    res = {}
    for f in glob.glob(os.path.join(D_RES, "*.json")):
        r = json.load(open(f, encoding="utf-8"))
        if isinstance(r, dict) and "config" in r and "evaluation" in r:    # les entraînements seulement (pas le pré-entraînement ni le diagnostic)
            res[r["config"]["nom"]] = r
    return res


def taux(runs, jeu):
    ep = [e for r in runs for e in r["evaluation"] if e["jeu"] == jeu]
    k = sum(e["reussi"] for e in ep)
    p, lo, hi = wilson(k, len(ep))
    par_graine = [float(np.mean([e["reussi"] for e in r["evaluation"] if e["jeu"] == jeu])) for r in runs]
    return {"taux": p, "ic95": [lo, hi], "n": len(ep), "graines": [round(x, 3) for x in par_graine]}


def secondaires(runs):
    ep = [e for r in runs for e in r["evaluation"]]
    debout = [e for e in ep if not e["tombe"]]
    pics = [e["pic_couple_Nm"] for e in ep]
    return {"chutes": round(float(np.mean([e["tombe"] for e in ep])), 3),
            "erreur_suivi_m_s": round(float(np.mean([e["erreur_suivi_m_s"] for e in debout])), 3) if debout else None,
            "energie_J": round(float(np.mean([e["energie_J"] for e in ep])), 0),
            "cout_transport": round(float(np.median([e["cout_transport"] for e in ep])), 2),
            "pic_couple_Nm_moyen": round(float(np.mean(pics)), 1), "pic_couple_Nm_max": round(float(np.max(pics)), 1),
            "pic_couple_kg_300mm_max": round(float(np.max(pics)) / (9.81 * 0.3), 1),
            "douceur_deg_s": round(float(np.mean([e["douceur_deg_s"] for e in ep])), 1),
            "glissement_m": round(float(np.mean([e["glissement_m"] for e in ep])), 3),
            "avance_m": round(float(np.mean([e["avance_m"] for e in ep])), 3)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--films", action="store_true")
    a = ap.parse_args()
    os.makedirs(D_RAP, exist_ok=True)
    res = charger()
    rap = {"fini": sorted(res), "regimes": {}, "largeurs": {}, "ablation": {}, "curriculum": None}
    groupe = lambda prefixe: [res[k] for k in sorted(res) if k.startswith(prefixe + "-g")]
    for reg in REGIMES:
        runs = groupe(reg)
        if runs:
            rap["regimes"][reg] = {"graines": len(runs), **{j: taux(runs, j) for j in JEUX}, "secondaires": secondaires(runs),
                                   "minutes": [r["minutes"] for r in runs]}
    # la courbe de largeur : 0 = R0, 1 = R2
    for f, nom in [(0.0, "R0"), (0.25, "largeur-0.25"), (0.5, "largeur-0.50"), (1.0, "R2"), (1.5, "largeur-1.50"), (2.0, "largeur-2.00")]:
        runs = groupe(nom)
        if runs:
            rap["largeurs"][str(f)] = {j: taux(runs, j) for j in JEUX} | {"graines": len(runs)}
    # l'ablation : R2 moins un groupe ; la perte de réussite par rapport à R2
    r2 = groupe("R2")
    for grp in ["corps", "actionneurs", "delai", "frottement_sol", "terrain", "perturbations", "capteurs", "initiales"]:
        runs = groupe("sans-" + grp)
        if runs and r2:
            d = {j: taux(runs, j) for j in JEUX}
            d["perte_dans"] = round(rap["regimes"]["R2"]["dans"]["taux"] - d["dans"]["taux"], 3)
            d["perte_hors"] = round(rap["regimes"]["R2"]["hors"]["taux"] - d["hors"]["taux"], 3)
            d["graines"] = len(runs)
            rap["ablation"][grp] = d
    r3 = groupe("R3")
    if r3:
        noms = list(r3[0]["largeurs_curriculum"])
        rap["curriculum"] = {n: round(float(np.mean([r["largeurs_curriculum"][n] for r in r3])), 3) for n in noms}
    json.dump(rap, open(os.path.join(D_RAP, "rapport.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    # les figures
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    if rap["largeurs"]:
        fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=150)
        xs = sorted(float(f) for f in rap["largeurs"])
        for j, coul in zip(["nominal", "dans", "hors", "coins", "solveur"], ["#7a8699", "#0b1f3a", "#d62828", "#a8841f", "#3a7d44"]):
            ys = [rap["largeurs"][str(x)][j]["taux"] for x in xs]
            lo = [rap["largeurs"][str(x)][j]["ic95"][0] for x in xs]
            hi = [rap["largeurs"][str(x)][j]["ic95"][1] for x in xs]
            ax.plot(xs, ys, "o-", color=coul, label=j)
            ax.fill_between(xs, lo, hi, color=coul, alpha=0.12)
        ax.set_xlabel("largeur de la variance à l'entraînement (fois la plage large)")
        ax.set_ylabel("taux de réussite (jeu jamais vu)")
        ax.set_ylim(0, 1)
        ax.grid(alpha=0.3)
        ax.legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(D_RAP, "courbe-largeur.png"))
        plt.close(fig)
    if rap["ablation"]:
        fig, ax = plt.subplots(figsize=(7.2, 3.8), dpi=150)
        items = sorted(rap["ablation"].items(), key=lambda kv: -kv[1]["perte_dans"])
        ax.barh([k for k, _ in items][::-1], [v["perte_dans"] for _, v in items][::-1], color="#0b1f3a")
        ax.set_xlabel("réussite perdue (dans les plages) quand on retire le groupe à l'entraînement")
        ax.axvline(0, color="#999", lw=0.8)
        fig.tight_layout()
        fig.savefig(os.path.join(D_RAP, "ablation.png"))
        plt.close(fig)
    print(json.dumps({k: {j: v[j]["taux"] for j in JEUX} for k, v in rap["regimes"].items()}, ensure_ascii=False), flush=True)
    if a.films:
        films(res, rap)


def films(res, rap):
    import sys
    import imageio.v2 as iio
    import mujoco
    sys.path.insert(0, ICI)
    import banc as B
    B.preparer()
    jeu = json.load(open(os.path.join(ICI, "eval", "jeu_evaluation.json"), encoding="utf-8"))
    os.makedirs(os.path.join(D_RAP, "films"), exist_ok=True)
    choix = {}
    for reg in REGIMES:
        runs = [res[k] for k in sorted(res) if k.startswith(reg + "-g")]
        if not runs:
            continue
        cands = [(r, i, e) for r in runs for i, e in enumerate(r["evaluation"]) if e["jeu"] in ("dans", "hors", "coins")]
        meilleur = max(cands, key=lambda t: (t[2]["reussi"], t[2]["avance_m"] if not t[2]["tombe"] else -9))
        pire = min(cands, key=lambda t: (t[2]["reussi"], t[2]["chute_s"] if t[2]["tombe"] else 99.0, t[2]["avance_m"]))   # la chute la plus précoce (corrigé : le tri prenait la plus tardive)
        for cle, (r, i, e) in (("meilleur", meilleur), ("pire", pire)):
            cond = jeu[i]
            frames = []
            rg = np.random.default_rng(int(cond["graine"]))      # le même tirage que dans B.rouler : la pente, puis le terrain
            rg.integers(0, 2 ** 31 - 1)
            w = B._choisir_modele(cond["axes"]["relief"], rg)
            rend, cam = mujoco.Renderer(w["m"], 480, 640), mujoco.MjvCamera()

            def v(dd, rend=rend, cam=cam, frames=frames):
                cam.distance, cam.azimuth, cam.elevation = 3.6, 70, -12
                cam.lookat[:] = [dd.subtree_com[1][0], dd.subtree_com[1][1], 0.7]
                rend.update_scene(dd, camera=cam)
                frames.append(rend.render().copy())
            rr = B.rouler(r["politique_moyenne"], cond, video=v)
            nom = "%s-%s.mp4" % (reg, cle)
            rend.close()                                       # fermer avant d.en ouvrir un autre (sinon les films suivants sont noirs)
            iio.mimsave(os.path.join(D_RAP, "films", nom), frames, fps=25, macro_block_size=1)
            choix["%s-%s" % (reg, cle)] = {"politique": r["config"]["nom"], "condition": i, "jeu": e["jeu"], "resultat": {k: rr[k] for k in ("reussi", "tombe", "chute_s", "avance_m")},
                                         "rejoue_a_l_identique": all(rr[k] == e[k] for k in ("reussi", "tombe", "chute_s", "avance_m"))}
            print(nom, choix["%s-%s" % (reg, cle)], flush=True)
    json.dump(choix, open(os.path.join(D_RAP, "films.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
