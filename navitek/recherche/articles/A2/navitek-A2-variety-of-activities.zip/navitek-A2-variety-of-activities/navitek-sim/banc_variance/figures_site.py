"""R-111 — deux figures pour la page de recherche du site, lisibles sur un téléphone (texte d'environ 13 px à 360 px de large) :
la courbe de largeur et l'ablation (réussite au nominal quand on retire un groupe). Lit rapport/rapport.json.

    python -X utf8 figures_site.py      → rapport/fig-r111-largeur.png, rapport/fig-r111-ablation.png"""
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

ICI = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(ICI, "rapport")
NOM_GRP = {"corps": "corps", "actionneurs": "actionneurs", "delai": "délai", "frottement_sol": "frottement", "terrain": "terrain",
           "perturbations": "poussées, vent", "capteurs": "capteurs", "initiales": "départ"}
plt.rcParams.update({"font.size": 17, "font.family": "DejaVu Serif"})


def main():
    r = json.load(open(os.path.join(D, "rapport.json"), encoding="utf-8"))
    L = r["largeurs"]
    xs = sorted(L, key=float)
    fig, ax = plt.subplots(figsize=(6.4, 5.0), dpi=150)
    for j, nom, coul in (("nominal", "nominal", "#7a8699"), ("coins", "coins", "#a8841f"), ("dans", "tout ensemble", "#0b1f3a")):
        y = [100 * L[x][j]["taux"] for x in xs]
        lo = [100 * L[x][j]["ic95"][0] for x in xs]
        hi = [100 * L[x][j]["ic95"][1] for x in xs]
        X = [float(x) for x in xs]
        ax.plot(X, y, "o-", color=coul, lw=2.6, ms=7, label=nom)
        ax.fill_between(X, lo, hi, color=coul, alpha=0.15)
    ax.set_xlabel("largeur de la variance (× la plage large)")
    ax.set_ylabel("réussite (%)")
    ax.set_ylim(0, 105)
    ax.set_xticks([0, 0.5, 1, 1.5, 2])
    ax.set_xticklabels(["0", "0,5", "1", "1,5", "2"])
    ax.grid(alpha=0.3)
    ax.legend(loc="upper right", fontsize=15, frameon=False)
    fig.tight_layout()
    fig.savefig(os.path.join(D, "fig-r111-largeur.png"))
    plt.close(fig)
    A = r["ablation"]
    items = sorted(A.items(), key=lambda kv: kv[1]["nominal"]["taux"])
    fig, ax = plt.subplots(figsize=(6.4, 5.0), dpi=150)
    noms = [NOM_GRP.get(g, g) for g, _ in items]
    vals = [100 * v["nominal"]["taux"] for _, v in items]
    ax.barh(noms, vals, color=["#c4471c" if g == "terrain" else "#0b1f3a" for g, _ in items])
    for i, v in enumerate(vals):
        ax.text(v + 2, i, "%d %%" % round(v), va="center", fontsize=15)
    ax.set_xlim(0, 115)
    ax.set_xlabel("réussite au nominal (%)")
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(os.path.join(D, "fig-r111-ablation.png"))
    plt.close(fig)
    print("figures écrites")


if __name__ == "__main__":
    main()
