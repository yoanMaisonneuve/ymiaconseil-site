"""R-073 — N3 joue au yoga sur une jambe (la gauche) : cinq poses apprises en jouant (CMA-ES), chaque essai gardé. Tout est simulé.

    python -X utf8 essai_n3_yoga.py [--poses flamant arbre avion danseur guerrier] [--generations 20] [--video]
Sorties : resultats/n3-yoga.json (le meilleur de chaque pose, mesuré), resultats/n3-yoga-essais.jsonl (tous les essais),
resultats/n3-yoga.mp4 (avec --video : les cinq poses à la suite)."""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C
import essai_n3_marche as W

RES = os.path.join(C.ICI, "resultats")
DT_POSE = 0.01
T_POIDS, T_LEVER, T_FIN = 2.0, 3.5, 13.5
# hanche : flexion (+ = la cuisse devant) et abduction (+ = la jambe vers l'extérieur) ; genou : + = plié ; torse : + = penché vers l'avant
POSES = {
    "flamant": {"torse": 0.0, "hanche_flex": 45.0, "hanche_abd": 0.0, "genou": 90.0, "bras": "bas"},
    "arbre": {"torse": 0.0, "hanche_flex": 20.0, "hanche_abd": 30.0, "genou": 110.0, "bras": "cotes"},
    "avion": {"torse": 20.0, "hanche_flex": -40.0, "hanche_abd": 0.0, "genou": 0.0, "bras": "cotes"},
    "danseur": {"torse": 30.0, "hanche_flex": -60.0, "hanche_abd": 0.0, "genou": 100.0, "bras": "danseur"},
    "guerrier": {"torse": 70.0, "hanche_flex": 0.0, "hanche_abd": 0.0, "genou": 0.0, "bras": "devant"},
}
BRAS = {"bas": {}, "cotes": {"epaule_roulis_g": -80.0, "epaule_roulis_d": 80.0},
        "danseur": {"epaule_tangage_g": -80.0, "epaule_tangage_d": 45.0}, "devant": {"epaule_tangage_g": -90.0, "epaule_tangage_d": -90.0}}
# les 7 réglages appris : transfert de poids (roulis des hanches, °), genou d'appui, gains de la cheville (tangage, sa vitesse, roulis, sa
# vitesse), écart à la cible du torse
NOMS = ["transfert", "genou_appui", "g_tangage", "g_tangage_v", "g_roulis", "g_roulis_v", "ecart_torse"]
BAS = np.array([-20.0, 0.0, 0.0, 0.0, -3.0, -0.5, -10.0])
HAUT = np.array([20.0, 30.0, 3.0, 0.5, 3.0, 0.5, 10.0])
_s = {}


def init():
    W.init()
    m = W._m
    d = mujoco.MjData(m)
    j = lambda n: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, n)
    _s["cheville_g"], _s["cheville_d"] = j("jambe-gauche-cheville-tangage"), j("jambe-droite-cheville-tangage")
    _s["sol"] = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, "sol")
    nom = lambda t, i: mujoco.mj_id2name(m, t, i) or ""
    _s["pied_d"] = {g for g in range(m.ngeom) if "pied" in nom(mujoco.mjtObj.mjOBJ_GEOM, g)
                    and nom(mujoco.mjtObj.mjOBJ_BODY, m.geom_bodyid[g]).startswith("jambe-droite")}
    _s["jambe_d"] = [g for g in range(m.ngeom) if nom(mujoco.mjtObj.mjOBJ_BODY, m.geom_bodyid[g]).startswith("jambe-droite")]

    def bout_g(pose):                                # la cheville gauche, pour le sens de la hanche gauche
        mujoco.mj_resetData(m, d)
        c = C.consigne(m, pose, W._sg)
        art = m.actuator_trnid[:, 0]
        for i in range(m.nu):
            d.qpos[m.jnt_qposadr[art[i]]] = c[i]
        mujoco.mj_kinematics(m, d)
        return d.xanchor[_s["cheville_g"]].copy()

    def bout(pose):                                  # où va la cheville droite pour une consigne donnée (le sens mesuré, pas supposé)
        mujoco.mj_resetData(m, d)
        c = C.consigne(m, pose, W._sg)
        art = m.actuator_trnid[:, 0]
        for i in range(m.nu):
            d.qpos[m.jnt_qposadr[art[i]]] = c[i]
        mujoco.mj_kinematics(m, d)
        return d.xanchor[_s["cheville_d"]].copy()
    o = bout({})
    _s["s_flex_g"] = 1.0 if (bout_g({"hanche_tangage_g": 30.0}) - bout_g({}))[0] > 0 else -1.0
    _s["s_flex"] = 1.0 if (bout({"hanche_tangage_d": 30.0}) - o)[0] > 0 else -1.0
    _s["s_abd"] = 1.0 if (bout({"hanche_roulis_d": 20.0}) - o)[1] < 0 else -1.0
    _s["s_genou"] = 1.0 if (bout({"genou_d": 40.0}) - o)[2] > 0 else -1.0
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    _s["h_com"] = float(d.subtree_com[1][2])


def min_jerk(s):
    s = min(max(s, 0.0), 1.0)
    return 10 * s ** 3 - 15 * s ** 4 + 6 * s ** 5


def consignes(nom, q, t, fb):
    P = POSES[nom]
    tr, kg, gt, gtv, gr, grv, ec = q
    avant, roulis, va, vr = fb
    a = min_jerk(t / T_POIDS)
    b = min_jerk((t - T_POIDS) / (T_LEVER - T_POIDS))
    cible = P["torse"] + ec
    pose = {"hanche_roulis_g": a * tr, "hanche_roulis_d": a * tr, "cheville_roulis_g": -a * tr + gr * roulis + grv * vr,
            "cheville_roulis_d": -a * tr, "genou_g": a * kg,
            # le torse se penche par la hanche d'appui ; la cheville d'appui corrige l'écart à la cible
            "hanche_tangage_g": _s["s_flex_g"] * b * P["torse"],
            "cheville_tangage_g": gt * (avant - b * cible) + gtv * va,
            "hanche_tangage_d": _s["s_flex"] * b * P["hanche_flex"], "hanche_roulis_d": a * tr + _s["s_abd"] * b * P["hanche_abd"],
            "genou_d": _s["s_genou"] * b * P["genou"]}
    for k, v in BRAS[P["bras"]].items():
        pose[k] = b * v
    return pose, b * cible          # 11.11 (E44) : la cible qui monte avec le geste ; avant, la chute se jugeait contre la cible finale dès 0,5 s


def jouer(nom, q, trace=False, video=None):
    m, d = W._m, W._d
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    n_pose = int(round(DT_POSE / m.opt.timestep))
    c, chute, sens, cible = np.zeros(m.nu), None, None, 0.0
    bal, rou, err, couple, levier = [], [], [], 0.0, []
    for k in range(int(T_FIN / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            fb = W.attitude(d)
            pose, cible = consignes(nom, q, t, fb)
            c = C.consigne(m, pose, W._sg)
            if t >= T_LEVER:
                ch = d.xanchor[_s["cheville_g"]]
                bal.append(float(np.linalg.norm(d.subtree_com[1][:2] - ch[:2]))), rou.append(fb[1]), err.append(fb[0] - cible)
                couple = max(couple, abs(float(d.actuator_force[W._idx["cheville_tangage_g"]])))
                if trace and abs(t - 8.5) < 1e-6:
                    levier.append(max(float(np.linalg.norm(d.geom_xpos[g][:2] - ch[:2])) for g in _s["jambe_d"]))
            # la chute : le corps descend, le torse s'éloigne de sa cible, ou le pied levé se repose
            pose_pied = t >= T_LEVER and any(
                (x.geom1 == _s["sol"] and x.geom2 in _s["pied_d"]) or (x.geom2 == _s["sol"] and x.geom1 in _s["pied_d"]) for x in d.contact[:d.ncon])
            if t > 0.5 and (d.subtree_com[1][2] < 0.65 * _s["h_com"] or abs(fb[0] - cible) > 35 or abs(fb[1]) > 35 or pose_pied):
                chute = t
                sens = "pied reposé" if pose_pied else ("avant" if fb[0] - cible > 0 else "arrière") if abs(fb[0] - cible) >= abs(fb[1]) else (
                    "gauche" if fb[1] > 0 else "droite")
                break
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if video is not None and k % int(0.05 / m.opt.timestep) == 0:
            video(d)
    tenu = (min(chute, T_FIN) if chute is not None else T_FIN) - T_LEVER
    tenu = max(0.0, tenu)
    b_cm = 100 * float(np.std(bal)) if len(bal) > 5 else 99.0
    r_sd = float(np.std(rou)) if len(rou) > 5 else 99.0
    score = tenu - 0.05 * b_cm - 0.05 * r_sd - 0.02 * (float(np.mean(np.abs(err))) if err else 50.0)
    r = {"pose": nom, "tenu_s": round(tenu, 2), "tombe": chute is not None, "chute_s": chute, "sens": sens, "balancement_cm": round(b_cm, 2),
         "roulis_ecart_type_deg": round(r_sd, 2), "ecart_torse_deg": round(float(np.mean(np.abs(err))), 2) if err else None,
         "couple_cheville_Nm": round(couple, 1), "score": round(score, 4)}
    if trace:
        r["levier_cm"] = round(100 * levier[0], 1) if levier else None
    return r


def essai(a):
    nom, gen, uu = a
    q = BAS + np.clip(uu, 0, 1) * (HAUT - BAS)
    r = jouer(nom, q)
    r.update(generation=gen, reglages=[round(float(v), 3) for v in q])
    return r


def main():
    from cmaes import CMA
    ap = argparse.ArgumentParser()
    ap.add_argument("--poses", nargs="+", default=list(POSES))
    ap.add_argument("--generations", type=int, default=20)
    ap.add_argument("--video", action="store_true")
    a = ap.parse_args()
    init()
    print("sens mesurés : flexion %+d, abduction %+d, genou %+d, flexion gauche %+d" % (_s["s_flex"], _s["s_abd"], _s["s_genou"], _s["s_flex_g"]), flush=True)
    journal = open(os.path.join(RES, "n3-yoga-essais.jsonl"), "w", encoding="utf-8")
    res = {"poses": POSES, "reglages": NOMS, "resultats": []}
    with mp.Pool(14, initializer=init) as pool:
        for nom in a.poses:
            cma = CMA(mean=np.full(len(BAS), 0.5), sigma=0.25, population_size=16, seed=73, bounds=np.array([[0, 1]] * len(BAS)))
            best, gens = (-1e9, None), []
            for g in range(a.generations):
                xs = [cma.ask() for _ in range(16)]
                R = pool.map(essai, [(nom, g + 1, x) for x in xs])
                cma.tell([(x, -r["score"]) for x, r in zip(xs, R)])
                for r in R:
                    journal.write(json.dumps(r, ensure_ascii=False) + "\n")
                i = int(np.argmax([r["score"] for r in R]))
                if R[i]["score"] > best[0]:
                    best = (R[i]["score"], xs[i])
                gens.append(float(np.median([r["tenu_s"] for r in R])))
                print("%s, génération %2d : tenu médian %.1f s, le meilleur %.2f" % (nom, g + 1, gens[-1], best[0]), flush=True)
            q = BAS + best[1] * (HAUT - BAS)
            r = jouer(nom, q, trace=True)
            r.update(reglages=dict(zip(NOMS, [round(float(v), 3) for v in q])), reglages_liste=[float(v) for v in q], tenu_median_par_generation=gens)
            res["resultats"].append(r)
            print(json.dumps({k: v for k, v in r.items() if k not in ("reglages_liste", "tenu_median_par_generation")}, ensure_ascii=False), flush=True)
    journal.close()
    json.dump(res, open(os.path.join(RES, "n3-yoga.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if a.video:
        import imageio.v2 as iio
        rend = mujoco.Renderer(W._m, 480, 640)
        cam = mujoco.MjvCamera()
        im = []

        def v(d):
            cam.distance, cam.azimuth, cam.elevation = 3.4, 150, -10
            cam.lookat[:] = [d.subtree_com[1][0], d.subtree_com[1][1], 0.8]
            rend.update_scene(d, camera=cam)
            im.append(rend.render().copy())
        for r in res["resultats"]:
            jouer(r["pose"], np.array(r["reglages_liste"]), video=v)
        iio.mimsave(os.path.join(RES, "n3-yoga.mp4"), im, fps=20, macro_block_size=1)
        print("vidéo écrite")


if __name__ == "__main__":
    main()
