"""R-125 — l'analyse des 1000 essais : intervalles (bootstrap, 2000 tirages) par k, corrélation de Spearman entre k et la réussite sur les
tests, le détail par activité de test, l'apport de chaque activité du bassin avec son intervalle, et la figure.
    python -X utf8 analyse_nuit_1000.py      → resultats/n3-nuit-1000-analyse.json, resultats/fig-r125-courbe.png, fig-r125-apport.png"""
import json
import os

import numpy as np

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resultats")
L = [json.loads(l) for l in open(os.path.join(RES, "n3-nuit-1000.jsonl"), encoding="utf-8") if l.strip()]
rng = np.random.default_rng(1251)
K = sorted({x["k"] for x in L})
TEST = list(L[0]["test"])


def ic(v, n=2000):
    v = np.asarray(v, float)
    b = [rng.choice(v, len(v)).mean() for _ in range(n)]
    return [round(float(np.percentile(b, 2.5)), 6), round(float(np.percentile(b, 97.5)), 6)]


courbe = {}
for k in K:
    t = [x["test_moy"] for x in L if x["k"] == k]
    o = [x["propres"] for x in L if x["k"] == k]
    courbe[k] = {"n": len(t), "test": round(float(np.mean(t)), 6), "test_ic95": ic(t), "propres": round(float(np.mean(o)), 6), "propres_ic95": ic(o),
                 "par_test": {a: round(float(np.mean([x["test"][a] for x in L if x["k"] == k])), 3) for a in TEST}}
from scipy.stats import spearmanr
rho, p = spearmanr([x["k"] for x in L], [x["test_moy"] for x in L])
rho2, p2 = spearmanr([x["k"] for x in L if x["k"] <= 11], [x["test_moy"] for x in L if x["k"] <= 11])
BASSIN = sorted({a for x in L for a in x["repertoire"]})
apport = {}
for act in BASSIN:
    d = []
    for k in (2, 3, 4, 6, 8, 11):
        avec = [x["test_moy"] for x in L if x["k"] == k and act in x["repertoire"]]
        sans = [x["test_moy"] for x in L if x["k"] == k and act not in x["repertoire"]]
        if avec and sans:
            d.append((np.mean(avec) - np.mean(sans), len(avec), len(sans), np.var(avec, ddof=1) / len(avec) + np.var(sans, ddof=1) / len(sans)))
    m = float(np.mean([x[0] for x in d]))
    se = float(np.sqrt(np.sum([x[3] for x in d])) / len(d))
    apport[act] = {"apport": round(m, 6), "ic95": [round(m - 1.96 * se, 6), round(m + 1.96 * se, 6)]}
seul = {a: round(float(np.mean([x["test_moy"] for x in L if x["k"] == 1 and x["repertoire"] == [a]])), 3) for a in BASSIN}
out = {"courbe": courbe, "spearman_tout": {"rho": round(float(rho), 3), "p": float(p)}, "spearman_k_jusqu_a_11": {"rho": round(float(rho2), 3), "p": float(p2)},
       "apport": apport, "k1_par_activite": seul}
json.dump(out, open(os.path.join(RES, "n3-nuit-1000-analyse.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
for k in K:
    c = courbe[k]
    print("k=%2d n=%3d test %.3f [%.3f, %.3f] propres %.3f | %s" % (k, c["n"], c["test"], *c["test_ic95"], c["propres"], c["par_test"]))
print("Spearman (tout) rho %.3f p %.2g ; (k <= 11) rho %.3f p %.2g" % (rho, p, rho2, p2))
print("apport :", sorted(((a, v["apport"], v["ic95"]) for a, v in apport.items()), key=lambda t: -t[1]))
print("seul (k=1) :", seul)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
plt.rcParams.update({"font.size": 17, "font.family": "DejaVu Serif"})
fig, ax = plt.subplots(figsize=(6.4, 5.0), dpi=150)
ys = [100 * courbe[k]["test"] for k in K]
lo = [100 * courbe[k]["test_ic95"][0] for k in K]
hi = [100 * courbe[k]["test_ic95"][1] for k in K]
ax.fill_between(K, lo, hi, color="#16355e", alpha=0.15)
ax.plot(K, ys, "o-", color="#0b1f3a", lw=2.6, ms=7, label="activités jamais vues")
ax.plot(K, [100 * courbe[k]["propres"] for k in K], "s--", color="#a8841f", lw=2, ms=6, label="ses propres activités")
ax.set_xlabel("activités pratiquées (même temps)")
ax.set_ylabel("réussite (%)")
ax.set_xticks(K)
ax.set_ylim(0, 55)
ax.grid(alpha=0.3)
ax.legend(fontsize=14, frameon=False, loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(RES, "fig-r125-courbe.png"))
plt.close(fig)
NOMS = {"flamant": "flamant", "arbre": "arbre", "avion": "avion", "guerrier": "guerrier", "developpe": "développé", "balancier": "balancier",
        "cercles": "cercles", "tir": "tir", "talons": "talons-fesses", "face": "pied de face", "haie": "haie", "attitude": "attitude",
        "lateral": "balancier lat.", "poussee": "poussée patin", "balance": "balance avant"}
it = sorted(apport.items(), key=lambda kv: kv[1]["apport"])
fig, ax = plt.subplots(figsize=(6.4, 6.0), dpi=150)
v = [100 * x[1]["apport"] for x in it]
e = [[100 * (x[1]["apport"] - x[1]["ic95"][0]) for x in it], [100 * (x[1]["ic95"][1] - x[1]["apport"]) for x in it]]
ax.barh([NOMS.get(x[0], x[0]) for x in it], v, xerr=e, color=["#c4471c" if val > 0 else "#7a8699" for val in v], capsize=3)
ax.axvline(0, color="#333", lw=1)
ax.set_xlabel("apport à l'inconnu (points)")
ax.grid(axis="x", alpha=0.3)
fig.tight_layout()
fig.savefig(os.path.join(RES, "fig-r125-apport.png"))
print("figures écrites")
