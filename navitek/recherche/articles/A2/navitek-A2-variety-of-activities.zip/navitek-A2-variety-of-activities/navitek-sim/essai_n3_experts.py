"""R-116 — les experts : cinq marches spécialisées (une par condition) contre une marche généraliste, la même quantité d'expérience (4 800
épisodes chacun des deux camps), parties de la marche pré-entraînée de R-111. Simulé.

Les conditions : un axe dans sa plage large (pente, retard des capteurs, délai de commande, sol mou, vent), les autres au nominal, la vitesse
visée dans l'étroite. CMA-ES : pas 0,02, population 8, 6 épisodes par candidat ; spécialistes 20 générations, généraliste 100.
Le jugement : 20 tirages jamais vus par condition (graines 4101 à 4105), le juge de R-111.

Les règles de verdict, fixées ici avant de lancer :
  H164  au moins 4 spécialistes sur 5 réussissent au moins 16 sur 20 sur leur condition
  H165  sur au moins 4 conditions sur 5, le généraliste réussit moins que le spécialiste (strictement)
  H166  en moyenne sur les 5 spécialistes, (réussite sur les 4 autres conditions) − (celle de la marche de départ sur ces 4) <= 0
  H167  (moyenne des experts sur leur condition) − (moyenne du généraliste sur les 5) >= 15 points

    python -X utf8 essai_n3_experts.py      → resultats/n3-experts.json"""
import json
import multiprocessing as mp
import os
import sys
import time

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ICI, "banc_variance"))
import banc as B  # noqa: E402

AXES5 = ["pente", "retard_capteur", "delai", "sol_mou", "vent"]
SIGMA, POP, EPI, GEN_SPE, GEN_GEN = 0.02, 8, 6, 20, 100


def regle_axe(n):
    r = B.regle_regime("R0")
    r["vitesse_visee"] = ("etroite", None)
    r[n] = ("large", None)
    return r


def _tache(args):
    x, cond = args
    r = B.rouler(x, cond)
    return B.note_entrainement(r), bool(r["reussi"])


def _juger(args):
    x, cond = args
    return bool(B.rouler(x, cond)["reussi"])


def journal(txt):
    ligne = time.strftime("%H:%M:%S ") + txt
    print(ligne, flush=True)


def entrainer(pool, u0, axes, generations, graine, nom):
    from cmaes import CMA
    cma = CMA(mean=np.clip(u0, 0, 1), sigma=SIGMA, population_size=POP, seed=graine, bounds=np.array([[0, 1]] * len(u0)))
    histo = []
    for gen in range(generations):
        rng = np.random.default_rng(np.random.SeedSequence([graine, gen]))
        conds = [B.tirer_condition(rng, regle_axe(str(rng.choice(axes)))) for _ in range(EPI)]
        xs = [cma.ask() for _ in range(POP)]
        res = pool.map(_tache, [(x, c) for x in xs for c in conds], chunksize=2)
        notes = [float(np.mean([res[i * EPI + e][0] for e in range(EPI)])) for i in range(POP)]
        cma.tell([(x, -n) for x, n in zip(xs, notes)])
        taux = float(np.mean([r[1] for r in res]))
        histo.append({"gen": gen + 1, "note_moy": round(float(np.mean(notes)), 3), "reussite": round(taux, 3)})
        if (gen + 1) % 5 == 0 or gen == 0:
            journal("%s génération %3d : note moyenne %.3f, réussite des candidats %.0f %%" % (nom, gen + 1, np.mean(notes), 100 * taux))
    moy = getattr(cma, "mean", None)
    moy = moy if moy is not None else cma._mean
    return [float(v) for v in np.clip(moy, 0, 1)], histo


def main():
    B.preparer()
    u0 = np.array(json.load(open(os.path.join(ICI, "banc_variance", "resultats", "pre_entrainement.json"), encoding="utf-8"))["politique"])
    jeu = {}
    for k, n in enumerate(AXES5):
        rng = np.random.default_rng(4101 + k)
        jeu[n] = [B.tirer_condition(rng, regle_axe(n)) for _ in range(20)]
    pol, histos = {"départ": [float(v) for v in u0]}, {}
    with mp.Pool(3, initializer=B.preparer) as pool:
        for k, n in enumerate(AXES5):
            pol["spécialiste " + n], histos["spécialiste " + n] = entrainer(pool, u0, [n], GEN_SPE, 4161 + k, "spécialiste " + n)
        pol["généraliste"], histos["généraliste"] = entrainer(pool, u0, AXES5, GEN_GEN, 4170, "généraliste")
        noms = list(pol)
        taches = [(np.array(pol[p]), c) for p in noms for n in AXES5 for c in jeu[n]]
        res = pool.map(_juger, taches, chunksize=4)
    table, i = {}, 0
    for p in noms:
        table[p] = {}
        for n in AXES5:
            table[p][n] = int(sum(res[i:i + 20]))
            i += 20
    for p in noms:
        journal("%-28s " % p + "  ".join("%s %2d/20" % (n, table[p][n]) for n in AXES5))
    spe = {n: table["spécialiste " + n][n] for n in AXES5}
    h164 = sum(spe[n] >= 16 for n in AXES5)
    h165 = sum(table["généraliste"][n] < spe[n] for n in AXES5)
    diffs = []
    for n in AXES5:
        autres = [m for m in AXES5 if m != n]
        diffs.append(np.mean([table["spécialiste " + n][m] for m in autres]) / 20 - np.mean([table["départ"][m] for m in autres]) / 20)
    h166 = float(np.mean(diffs))
    h167 = float(np.mean([spe[n] for n in AXES5]) / 20 - np.mean([table["généraliste"][n] for n in AXES5]) / 20)
    verdicts = {"H164": {"specialistes_au_moins_16": int(h164), "verdict": "confirmée" if h164 >= 4 else "réfutée"},
                "H165": {"conditions_ou_le_generaliste_fait_moins": int(h165), "verdict": "confirmée" if h165 >= 4 else "réfutée"},
                "H166": {"ecart_moyen_sur_les_autres": round(h166, 3), "verdict": "confirmée" if h166 <= 0 else "réfutée"},
                "H167": {"ecart_experts_moins_generaliste": round(h167, 3), "verdict": "confirmée" if h167 >= 0.15 else "réfutée"}}
    journal("verdicts : " + json.dumps(verdicts, ensure_ascii=False))
    json.dump({"axes": AXES5, "table_sur_20": table, "politiques": pol, "historiques": histos, "verdicts": verdicts,
               "reglages": {"sigma": SIGMA, "population": POP, "episodes": EPI, "generations_specialiste": GEN_SPE, "generations_generaliste": GEN_GEN}},
              open(os.path.join(ICI, "resultats", "n3-experts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    journal("écrit resultats/n3-experts.json")


if __name__ == "__main__":
    main()
