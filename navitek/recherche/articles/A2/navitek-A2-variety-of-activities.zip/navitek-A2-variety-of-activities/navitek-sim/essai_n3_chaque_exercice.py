"""R-124 — ce qu'on apprend de chaque exercice : (1) la matrice de transfert : le socle appris sur chaque exercice seul (étape 0 de R-123,
resultats/n3-multisport-calibrage.json) joué sur chacun des 13 exercices, 10 épisodes ; (2) une batterie commune de poussées (sur une jambe,
le flamant, et sur deux pieds), quatre directions, de 10 à 120 N. Simulé.

Les règles de verdict, fixées ici avant de lancer :
  H193  famille droite (flamant, arbre, developpe, cote) : moyenne hors diagonale de la réussite >= 0,70
  H194  socles des penchés (avion, danseur, guerrier, arabesque, patineur) : réussite moyenne sur les autres penchés > sur les droits
  H195  l'exercice à la plus haute moyenne de ligne (les 12 autres, réussite) est dynamique (genoux, balancier, cercles, tir)
  H196  |corrélation de Pearson| entre la note de batterie et la moyenne de ligne (réussite) < 0,5
  H197  la plus haute moyenne de ligne est celle du flamant

    python -X utf8 essai_n3_chaque_exercice.py      → resultats/n3-chaque-exercice.json"""
import json
import os

import mujoco
import numpy as np

import commun as C
import essai_n3_marche as W
import essai_n3_multisport as M
import essai_n3_yoga as Y

RES = os.path.join(C.ICI, "resultats")
FORCES = [10.0, 20.0, 30.0, 40.0, 60.0, 80.0, 100.0, 120.0]
DIRS = {"avant": (1.0, 0.0), "arriere": (-1.0, 0.0), "gauche": (0.0, 1.0), "droite": (0.0, -1.0)}
FAMILLES = {"droite": ["flamant", "arbre", "developpe", "cote"], "penchee": ["avion", "danseur", "guerrier", "arabesque", "patineur"],
            "dynamique": ["genoux", "balancier", "cercles", "tir"]}


def debout(u, graine, pousse=None):
    """Sur deux pieds : pas de transfert, pas de jambe levée, la même correction aux deux chevilles ; une poussée à 5 s."""
    q = M.BAS + np.clip(np.asarray(u, float), 0, 1) * (M.HAUT - M.BAS)
    tr, kg, gt, gtv, gr, grv, ec = q
    m, d = W._m, W._d
    rng = np.random.default_rng(int(graine))
    mujoco.mj_resetData(m, d)
    art = m.actuator_trnid[:, 0]
    for i in range(m.nu):
        d.qpos[m.jnt_qposadr[art[i]]] += np.radians(rng.uniform(-1.0, 1.0))
    mujoco.mj_forward(m, d)
    n_pose = int(round(Y.DT_POSE / m.opt.timestep))
    c, chute = np.zeros(m.nu), None
    for k in range(int(10.0 / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            avant, roulis, va, vr = W.attitude(d)
            a = Y.min_jerk(t / Y.T_POIDS)
            pose = {}
            for s in ("g", "d"):
                pose["genou_" + s] = a * kg
                pose["cheville_tangage_" + s] = gt * (avant - ec) + gtv * va
                pose["cheville_roulis_" + s] = gr * roulis + grv * vr
            c = C.consigne(m, pose, W._sg)
            if t > 0.5 and (d.subtree_com[1][2] < 0.65 * Y._s["h_com"] or abs(avant - ec) > 35 or abs(roulis) > 35):
                chute = t
                break
        d.xfrc_applied[1, :3] = 0.0
        if pousse is not None and 5.0 <= t < 5.1:
            d.xfrc_applied[1, 0], d.xfrc_applied[1, 1] = pousse
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
    d.xfrc_applied[:] = 0.0
    return chute is None


def flamant_pousse(u, graine, pousse):
    """Le flamant (R-073), une poussée de 0,1 s sur le torse 3 s après le lever ; tenu jusqu'au bout ?"""
    orig = M.jouer
    m, d = W._m, W._d
    t_p = Y.T_LEVER + 3.0
    step0 = mujoco.mj_step

    def pas(mm, dd):
        t = dd.time
        dd.xfrc_applied[1, :3] = 0.0
        if t_p <= t < t_p + 0.1:
            dd.xfrc_applied[1, 0], dd.xfrc_applied[1, 1] = pousse
        step0(mm, dd)
    mujoco.mj_step = pas
    try:
        r = orig("flamant", u, graine)
    finally:
        mujoco.mj_step = step0
        d.xfrc_applied[:] = 0.0
    return r["reussi"]


def _matrice(a):
    socle, act, graine = a
    return M.jouer(act, socle, graine)["reussi"]


def _batterie(a):
    socle, posture, dirn, f, graine = a
    v = np.array(DIRS[dirn]) * f
    return bool(debout(socle, graine, tuple(v)) if posture == "deux_pieds" else flamant_pousse(socle, graine, tuple(v)))


def main():
    import multiprocessing as mp
    cal = json.load(open(os.path.join(RES, "n3-multisport-calibrage.json"), encoding="utf-8"))["calibrage"]
    acts = list(M.ACT)
    socles = {x: cal[x]["socle_seul"] for x in acts}
    with mp.Pool(15, initializer=Y.init) as pool:
        taches = [(socles[i], j, g) for i in acts for j in acts for g in M.graines_eval(j)]
        R = pool.map(_matrice, taches, chunksize=4)
        mat = {}
        k = 0
        for i in acts:
            mat[i] = {}
            for j in acts:
                mat[i][j] = round(float(np.mean(R[k:k + 10])), 2)
                k += 10
        print("matrice faite", flush=True)
        taches = [(socles[i], p, dn, f, 5000 + n) for i in acts for p in ("une_jambe", "deux_pieds") for dn in DIRS for n, f in enumerate(FORCES)]
        B = pool.map(_batterie, taches, chunksize=4)
    bat = {}
    k = 0
    for i in acts:
        bat[i] = {}
        for p in ("une_jambe", "deux_pieds"):
            bat[i][p] = {}
            for dn in DIRS:
                ok = B[k:k + len(FORCES)]
                k += len(FORCES)
                tenue = 0.0
                for f, o in zip(FORCES, ok):                   # la plus forte poussée tenue, avec toutes les plus faibles tenues aussi
                    if not o:
                        break
                    tenue = f
                bat[i][p][dn] = tenue
        bat[i]["somme"] = sum(bat[i][p][dn] for p in ("une_jambe", "deux_pieds") for dn in DIRS)
    ligne = {i: round(float(np.mean([mat[i][j] for j in acts if j != i])), 3) for i in acts}
    fam = FAMILLES
    dr = [mat[i][j] for i in fam["droite"] for j in fam["droite"] if i != j]
    pp = [mat[i][j] for i in fam["penchee"] for j in fam["penchee"] if i != j]
    pd = [mat[i][j] for i in fam["penchee"] for j in fam["droite"]]
    meilleur = max(ligne, key=ligne.get)
    xs, ys = [bat[i]["somme"] for i in acts], [ligne[i] for i in acts]
    r = float(np.corrcoef(xs, ys)[0, 1]) if np.std(xs) > 0 and np.std(ys) > 0 else float("nan")
    ver = {"H193": {"moyenne_droites": round(float(np.mean(dr)), 3), "verdict": "confirmée" if np.mean(dr) >= 0.70 else "réfutée"},
           "H194": {"penchees_sur_penchees": round(float(np.mean(pp)), 3), "penchees_sur_droites": round(float(np.mean(pd)), 3),
                    "verdict": "confirmée" if np.mean(pp) > np.mean(pd) else "réfutée"},
           "H195": {"meilleur": meilleur, "verdict": "confirmée" if meilleur in fam["dynamique"] else "réfutée"},
           "H196": {"r": round(r, 3), "verdict": "confirmée" if (r == r and abs(r) < 0.5) else "réfutée"},
           "H197": {"meilleur": meilleur, "verdict": "confirmée" if meilleur == "flamant" else "réfutée"}}
    out = {"activites": acts, "matrice_reussite": mat, "moyenne_ligne": ligne, "batterie_N": bat, "verdicts": ver}
    json.dump(out, open(os.path.join(RES, "n3-chaque-exercice.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("ligne :", ligne, flush=True)
    print("batterie (somme) :", {i: bat[i]["somme"] for i in acts}, flush=True)
    print("verdicts :", json.dumps(ver, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
