"""R-124 — la figure de la matrice de transfert (lisible sur téléphone : gros texte ; un clic l'agrandit sur le site).
    python -X utf8 figure_chaque_exercice.py   → resultats/fig-r124-matrice.png"""
import json
import os

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resultats")
COURT = {"flamant": "flamant", "arbre": "arbre", "avion": "avion", "danseur": "danseur", "guerrier": "guerrier", "developpe": "développé",
         "arabesque": "arabesque", "cote": "pied côté", "genoux": "genoux", "balancier": "balancier", "cercles": "cercles", "tir": "tir",
         "patineur": "patineur"}
r = json.load(open(os.path.join(RES, "n3-chaque-exercice.json"), encoding="utf-8"))
A = r["activites"]
M = np.array([[100 * r["matrice_reussite"][i][j] for j in A] for i in A])
plt.rcParams.update({"font.size": 17, "font.family": "DejaVu Serif"})
fig, ax = plt.subplots(figsize=(10.5, 10), dpi=130)
ax.imshow(M, cmap="Blues", vmin=0, vmax=100)
for i in range(len(A)):
    for j in range(len(A)):
        v = int(round(M[i, j]))
        ax.text(j, i, str(v) if v else "·", ha="center", va="center", fontsize=14, color="white" if v > 60 else "#333")
ax.set_xticks(range(len(A)))
ax.set_yticks(range(len(A)))
ax.set_xticklabels([COURT[a] for a in A], rotation=60, ha="right")
ax.set_yticklabels([COURT[a] for a in A])
ax.set_xlabel("l'exercice joué")
ax.set_ylabel("le socle appris sur…")
fig.tight_layout()
fig.savefig(os.path.join(RES, "fig-r124-matrice.png"))
print("figure écrite")
