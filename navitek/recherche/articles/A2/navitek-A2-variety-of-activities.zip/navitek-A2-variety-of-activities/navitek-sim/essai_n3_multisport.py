"""R-123 — le modèle norvégien : un socle d'équilibre commun (les 7 réglages de R-073) appris sur un répertoire varié (MULTI), sur une seule
activité (SPÉ) ou pas du tout (RIEN), puis la spécialisation sur des activités jamais vues. Le cadre, les gestes de yoga et le juge viennent de
essai_n3_yoga.py (R-073) ; les autres activités sont écrites ici dans le même cadre. Simulé.

    python -X utf8 essai_n3_multisport.py calibrage        → resultats/n3-multisport-calibrage.json (l'étape 0 et le choix des activités)
    python -X utf8 essai_n3_multisport.py enfance          → resultats/n3-multisport-enfance.json (l'étape 1)
    python -X utf8 essai_n3_multisport.py specialisation   → resultats/n3-multisport-specialisation.json (l'étape 2) et les verdicts

Les règles, fixées ici avant de lancer (cahier R-123, § 2 et § 3) :
  écartée          : apprise seule, l'activité ne tient pas 5 s en moyenne (10 épisodes)
  pas de test      : le socle de départ la tient déjà 9,5 s en moyenne
  test             : tir, patineur, genoux si elles passent ; sinon, dans l'ordre, cote, balancier, arabesque (3 en tout)
  SPÉ, graine k    : la k-ième activité du répertoire d'entraînement (dans l'ordre de ACT)
  H188  réussite après spécialisation (moyenne activités de test × graines) : MULTI > SPÉ
  H189  idem : MULTI > RIEN
  H190  avant toute pratique, temps tenu moyen sur les activités de test : MULTI > SPÉ et MULTI > RIEN
  H191  médiane (activité, graine) des générations pour atteindre 90 % de la meilleure note finale de la courbe : MULTI < SPÉ
  H192  sur sa propre activité, SPÉ tient au moins aussi longtemps que MULTI (moyenne des 3 graines MULTI), pour au moins 2 graines sur 3"""
import argparse
import json
import os
import time

import mujoco
import numpy as np

import commun as C
import essai_n3_marche as W
import essai_n3_yoga as Y

RES = os.path.join(C.ICI, "resultats")
NOMS, BAS, HAUT = Y.NOMS, Y.BAS, Y.HAUT
U0 = np.full(len(BAS), 0.5)


def statique(torse, flex, abd, genou, bras):
    return lambda s: {"torse": torse, "hanche_flex": flex, "hanche_abd": abd, "genou": genou, "bras": bras}


def trajet(points, torse=0.0, bras="bas"):
    """Des points (s, flexion, abduction, genou), reliés par des courbes douces ; tenu au dernier point."""
    def f(s):
        for (s0, *a), (s1, *b) in zip(points, points[1:]):
            if s < s1:
                u = Y.min_jerk((s - s0) / (s1 - s0)) if s1 > s0 else 1.0
                v = [x + u * (y - x) for x, y in zip(a, b)]
                return {"torse": torse, "hanche_flex": v[0], "hanche_abd": v[1], "genou": v[2], "bras": bras}
        _, fl, ab, ge = points[-1]
        return {"torse": torse, "hanche_flex": fl, "hanche_abd": ab, "genou": ge, "bras": bras}
    return f


def periodique(fl0, afl, ab0, aab, genou, periode, bras="bas", torse=0.0):
    """Un geste qui se répète : la flexion et l'abduction de la hanche oscillent autour de (fl0, ab0)."""
    def f(s):
        u = min(1.0, s / 1.0)                              # l'oscillation monte en 1 s
        w = 2 * np.pi * s / periode
        return {"torse": torse, "hanche_flex": fl0 + u * afl * np.sin(w), "hanche_abd": ab0 + u * aab * np.cos(w) - u * aab,
                "genou": genou, "bras": bras}
    return f


# le répertoire (l'ordre compte : la règle de choix et SPÉ le lisent)
ACT = {
    "flamant": statique(0.0, 45.0, 0.0, 90.0, "bas"),                                  # yoga (R-073)
    "arbre": statique(0.0, 20.0, 30.0, 110.0, "cotes"),
    "avion": statique(20.0, -40.0, 0.0, 0.0, "cotes"),
    "danseur": statique(30.0, -60.0, 0.0, 100.0, "danseur"),
    "guerrier": statique(70.0, 0.0, 0.0, 0.0, "devant"),
    "developpe": statique(0.0, 60.0, 0.0, 0.0, "cotes"),                               # danse
    "arabesque": statique(25.0, -45.0, 0.0, 0.0, "devant"),
    "cote": statique(10.0, 0.0, 45.0, 0.0, "cotes"),                                   # arts martiaux : le coup de pied de côté
    "genoux": periodique(45.0, 35.0, 0.0, 0.0, 90.0, 1.2),                              # athlétisme : les montées de genou
    "balancier": periodique(15.0, 35.0, 0.0, 0.0, 15.0, 1.6, bras="cotes"),             # échauffement : le balancier de la jambe
    "cercles": periodique(25.0, 20.0, 15.0, 15.0, 60.0, 2.0, bras="cotes"),             # échauffement : les cercles de hanche
    "tir": trajet([(0.0, 20.0, 0.0, 60.0), (2.0, 20.0, 0.0, 60.0), (2.5, -30.0, 0.0, 90.0), (2.8, 70.0, 0.0, 0.0),
                   (4.0, 30.0, 0.0, 60.0)], bras="cotes"),                              # soccer : le tir
    "patineur": statique(35.0, -25.0, 30.0, 10.0, "devant"),                            # patin et hockey : l'appui du patineur
}
TEST_PREF = ["tir", "patineur", "genoux"]
TEST_SECOURS = ["cote", "balancier", "arabesque"]


def consignes(act, q, t, fb):
    """Les consignes de R-073 (essai_n3_yoga.consignes), avec un geste qui peut changer dans le temps (s : le temps depuis le lever)."""
    P = ACT[act](max(0.0, t - Y.T_LEVER))
    tr, kg, gt, gtv, gr, grv, ec = q
    avant, roulis, va, vr = fb
    a = Y.min_jerk(t / Y.T_POIDS)
    b = Y.min_jerk((t - Y.T_POIDS) / (Y.T_LEVER - Y.T_POIDS))
    cible = P["torse"] + ec
    s_ = Y._s
    pose = {"hanche_roulis_g": a * tr, "hanche_roulis_d": a * tr, "cheville_roulis_g": -a * tr + gr * roulis + grv * vr,
            "cheville_roulis_d": -a * tr, "genou_g": a * kg,
            "hanche_tangage_g": s_["s_flex_g"] * b * P["torse"],
            "cheville_tangage_g": gt * (avant - b * cible) + gtv * va,
            "hanche_tangage_d": s_["s_flex"] * b * P["hanche_flex"], "hanche_roulis_d": a * tr + s_["s_abd"] * b * P["hanche_abd"],
            "genou_d": s_["s_genou"] * b * P["genou"]}
    for k, v in Y.BRAS[P["bras"]].items():
        pose[k] = b * v
    return pose, b * cible


def jouer(act, u, graine, video=None):
    """Un épisode : le juge et la note de R-073 ; une petite variation de départ tirée de la graine."""
    q = BAS + np.clip(np.asarray(u, float), 0, 1) * (HAUT - BAS)
    m, d = W._m, W._d
    s_ = Y._s
    rng = np.random.default_rng(int(graine))
    mujoco.mj_resetData(m, d)
    art = m.actuator_trnid[:, 0]
    for i in range(m.nu):
        d.qpos[m.jnt_qposadr[art[i]]] += np.radians(rng.uniform(-1.0, 1.0))
    d.qvel[0], d.qvel[1] = rng.uniform(-0.02, 0.02, 2)
    mujoco.mj_forward(m, d)
    n_pose = int(round(Y.DT_POSE / m.opt.timestep))
    c, chute, cible = np.zeros(m.nu), None, 0.0
    bal, rou, err = [], [], []
    for k in range(int(Y.T_FIN / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % n_pose == 0:
            fb = W.attitude(d)
            pose, cible = consignes(act, q, t, fb)
            c = C.consigne(m, pose, W._sg)
            if t >= Y.T_LEVER:
                ch = d.xanchor[s_["cheville_g"]]
                bal.append(float(np.linalg.norm(d.subtree_com[1][:2] - ch[:2])))
                rou.append(fb[1])
                err.append(fb[0] - cible)
            pied = t >= Y.T_LEVER and any((x.geom1 == s_["sol"] and x.geom2 in s_["pied_d"]) or (x.geom2 == s_["sol"] and x.geom1 in s_["pied_d"])
                                          for x in d.contact[:d.ncon])
            if t > 0.5 and (d.subtree_com[1][2] < 0.65 * s_["h_com"] or abs(fb[0] - cible) > 35 or abs(fb[1]) > 35 or pied):
                chute = t
                break
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if video is not None and k % int(0.05 / m.opt.timestep) == 0:
            video(d)
    tenu = max(0.0, (min(chute, Y.T_FIN) if chute is not None else Y.T_FIN) - Y.T_LEVER)
    b_cm = 100 * float(np.std(bal)) if len(bal) > 5 else 99.0
    r_sd = float(np.std(rou)) if len(rou) > 5 else 99.0
    note = tenu - 0.05 * b_cm - 0.05 * r_sd - 0.02 * (float(np.mean(np.abs(err))) if err else 50.0)
    return {"tenu": round(tenu, 3), "note": round(note, 4), "reussi": chute is None}


def _ep(a):
    act, u, graine = a
    return jouer(act, u, graine)


def evaluer(pool, act, u, graines):
    R = pool.map(_ep, [(act, u, g) for g in graines])
    return {"tenu": round(float(np.mean([r["tenu"] for r in R])), 3), "reussite": round(float(np.mean([r["reussi"] for r in R])), 3),
            "note": round(float(np.mean([r["note"] for r in R])), 4)}


def apprendre(pool, u0, plan, generations, pop, sigma, graine, journal=None, nom=""):
    """CMA-ES sur le socle. plan(gen) -> la liste des (activité, graine d'épisode) que joue chaque candidat à cette génération."""
    from cmaes import CMA
    cma = CMA(mean=np.clip(np.asarray(u0, float), 0, 1), sigma=sigma, population_size=pop, seed=graine, bounds=np.array([[0, 1]] * len(BAS)))
    courbe = []
    for gen in range(generations):
        eps = plan(gen)
        xs = [cma.ask() for _ in range(pop)]
        R = pool.map(_ep, [(a, x, g) for x in xs for a, g in eps], chunksize=2)
        n = len(eps)
        notes = [float(np.mean([R[i * n + e]["note"] for e in range(n)])) for i in range(pop)]
        cma.tell([(x, -v) for x, v in zip(xs, notes)])
        courbe.append({"gen": gen + 1, "note_max": round(max(notes), 4), "note_moy": round(float(np.mean(notes)), 4),
                       "reussite": round(float(np.mean([r["reussi"] for r in R])), 3)})
        if journal:
            journal("%s génération %2d : note moyenne %.2f, meilleure %.2f, réussite %.0f %%" % (nom, gen + 1, np.mean(notes), max(notes), 100 * courbe[-1]["reussite"]))
    moy = getattr(cma, "mean", None)
    moy = moy if moy is not None else cma._mean
    return [float(v) for v in np.clip(moy, 0, 1)], courbe


def journal(txt):
    ligne = time.strftime("%H:%M:%S ") + txt
    print(ligne, flush=True)
    with open(os.path.join(RES, "n3-multisport.log"), "a", encoding="utf-8") as fh:
        fh.write(ligne + "\n")


def graines_eval(act):
    k = list(ACT).index(act)
    return [910000 + 100 * k + i for i in range(10)]


def main():
    import multiprocessing as mp
    ap = argparse.ArgumentParser()
    ap.add_argument("etape", choices=["calibrage", "enfance", "specialisation"])
    a = ap.parse_args()
    Y.init()
    f_cal, f_enf, f_spe = (os.path.join(RES, "n3-multisport-%s.json" % x) for x in ("calibrage", "enfance", "specialisation"))
    with mp.Pool(15, initializer=Y.init) as pool:
        if a.etape == "calibrage":
            cal = {}
            for k, act in enumerate(ACT):
                depart = evaluer(pool, act, U0, graines_eval(act))
                u, courbe = apprendre(pool, U0, lambda gen, act=act: [(act, 800000 + 1000 * k + 10 * gen + e) for e in range(2)], 15, 12, 0.25, 1230 + k)
                seul = evaluer(pool, act, u, graines_eval(act))
                cal[act] = {"depart": depart, "appris_seul": seul, "socle_seul": u}
                journal("calibrage %-10s départ : tenu %.1f s (réussite %.0f %%) ; appris seul : tenu %.1f s (réussite %.0f %%)"
                        % (act, depart["tenu"], 100 * depart["reussite"], seul["tenu"], 100 * seul["reussite"]))
            gardees = [x for x in ACT if cal[x]["appris_seul"]["tenu"] >= 5.0]
            testables = [x for x in gardees if cal[x]["depart"]["tenu"] < 9.5]
            test = [x for x in TEST_PREF if x in testables]
            for x in TEST_SECOURS:
                if len(test) < 3 and x in testables and x not in test:
                    test.append(x)
            entr = [x for x in gardees if x not in test]
            choix = {"ecartees": [x for x in ACT if x not in gardees], "test": test, "entrainement": entr}
            journal("choix : " + json.dumps(choix, ensure_ascii=False))
            json.dump({"calibrage": cal, "choix": choix}, open(f_cal, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        elif a.etape == "enfance":
            ch = json.load(open(f_cal, encoding="utf-8"))["choix"]
            entr = ch["entrainement"]
            enf = {}
            for g in (1, 2, 3):
                plan_m = lambda gen, g=g: [(entr[e % len(entr)], 700000 + 10000 * g + 100 * gen + e) for e in range(10)]
                u, courbe = apprendre(pool, U0, plan_m, 30, 12, 0.25, 1300 + g, journal, "MULTI-g%d" % g)
                enf["MULTI-g%d" % g] = {"socle": u, "courbe": courbe, "activites": entr}
                act = entr[(g - 1) % len(entr)]
                plan_s = lambda gen, g=g, act=act: [(act, 700000 + 10000 * g + 100 * gen + e) for e in range(10)]
                u, courbe = apprendre(pool, U0, plan_s, 30, 12, 0.25, 1300 + g, journal, "SPÉ-g%d (%s)" % (g, act))
                enf["SPE-g%d" % g] = {"socle": u, "courbe": courbe, "activites": [act]}
                json.dump(enf, open(f_enf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        else:
            ch = json.load(open(f_cal, encoding="utf-8"))["choix"]
            enf = json.load(open(f_enf, encoding="utf-8"))
            socles = {k: v["socle"] for k, v in enf.items()}
            socles.update({"RIEN-g%d" % g: [float(x) for x in U0] for g in (1, 2, 3)})
            spe = json.load(open(f_spe, encoding="utf-8")) if os.path.exists(f_spe) else {}
            for act in ch["test"]:
                for nom, u0 in sorted(socles.items()):
                    cle = "%s|%s" % (act, nom)
                    if cle in spe:
                        continue
                    g = int(nom[-1])
                    avant = evaluer(pool, act, u0, graines_eval(act))
                    plan = lambda gen, act=act, g=g: [(act, 600000 + 10000 * g + 100 * gen + e) for e in range(3)]
                    u, courbe = apprendre(pool, u0, plan, 15, 12, 0.15, 1400 + g)
                    apres = evaluer(pool, act, u, [x + 50 for x in graines_eval(act)])
                    spe[cle] = {"avant": avant, "apres": apres, "courbe": courbe, "socle_final": u}
                    journal("spécialisation %-9s depuis %-7s : avant %.1f s (%.0f %%) ; après %.1f s (%.0f %%)"
                            % (act, nom, avant["tenu"], 100 * avant["reussite"], apres["tenu"], 100 * apres["reussite"]))
                    json.dump(spe, open(f_spe, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            # les verdicts
            reg = lambda k: k.split("|")[1].split("-")[0]
            moy = lambda r, champ, sous: float(np.mean([v[sous][champ] for k, v in spe.items() if reg(k) == r]))
            v = {r: {"avant_tenu": moy(r, "tenu", "avant"), "apres_reussite": moy(r, "reussite", "apres"), "apres_tenu": moy(r, "tenu", "apres")}
                 for r in ("MULTI", "SPE", "RIEN")}

            def gens90(c):
                fin = max(x["note_max"] for x in c)
                cible = 0.9 * fin if fin > 0 else fin
                return next(x["gen"] for x in c if x["note_max"] >= cible)
            vit = {r: float(np.median([gens90(x["courbe"]) for k, x in spe.items() if reg(k) == r])) for r in ("MULTI", "SPE", "RIEN")}
            propre = []
            for g in (1, 2, 3):
                act = enf["SPE-g%d" % g]["activites"][0]
                s_sp = evaluer(pool, act, enf["SPE-g%d" % g]["socle"], graines_eval(act))["tenu"]
                s_mu = float(np.mean([evaluer(pool, act, enf["MULTI-g%d" % h]["socle"], graines_eval(act))["tenu"] for h in (1, 2, 3)]))
                propre.append({"activite": act, "SPE": s_sp, "MULTI": round(s_mu, 3)})
            ver = {"H188": "confirmée" if v["MULTI"]["apres_reussite"] > v["SPE"]["apres_reussite"] else "réfutée",
                   "H189": "confirmée" if v["MULTI"]["apres_reussite"] > v["RIEN"]["apres_reussite"] else "réfutée",
                   "H190": "confirmée" if v["MULTI"]["avant_tenu"] > max(v["SPE"]["avant_tenu"], v["RIEN"]["avant_tenu"]) else "réfutée",
                   "H191": "confirmée" if vit["MULTI"] < vit["SPE"] else "réfutée",
                   "H192": "confirmée" if sum(p["SPE"] >= p["MULTI"] for p in propre) >= 2 else "réfutée"}
            out = {"par_regime": v, "generations_90": vit, "propre_activite": propre, "verdicts": ver}
            journal("verdicts : " + json.dumps(out, ensure_ascii=False))
            json.dump(out, open(os.path.join(RES, "n3-multisport-verdicts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
