"""R-118 — le mélange complet : l'aiguilleur de R-117 (réappris à l'identique) choisit, d'après 2 s de marche, la marche de départ ou un
spécialiste de R-116 ; l'épisode est rejoué depuis le début avec la marche choisie. Comparé, sur 120 épisodes jamais vus (6 conditions × 20,
graines 4301 à 4306), à la marche de départ, au généraliste et à l'aiguilleur parfait. Simulé.

Les règles de verdict, fixées ici avant de lancer (et avant de connaître R-116) :
  H171  réussite(aiguilleur appris) >= 0,90 × réussite(aiguilleur parfait)
  H172  réussite(aiguilleur appris) − réussite(généraliste) >= 0,10
  H173  réussite(aiguilleur appris) − réussite(marche de départ) >= 0,20

    python -X utf8 essai_n3_melange.py      → resultats/n3-melange.json"""
import json
import multiprocessing as mp
import os
import sys

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
import essai_n3_aiguilleur as Ai  # noqa: E402

B = Ai.B


def _sentir(args):
    return Ai._episode(args)


def _juger(args):
    u, cond = args
    return bool(B.rouler(u, cond)["reussi"])


def main():
    B.preparer()
    ai = json.load(open(os.path.join(ICI, "resultats", "n3-aiguilleur.json"), encoding="utf-8"))
    ex = json.load(open(os.path.join(ICI, "resultats", "n3-experts.json"), encoding="utf-8"))
    from sklearn.ensemble import RandomForestClassifier
    X, y, rang = np.array(ai["mesures"]), np.array(ai["etiquettes"]), np.array(ai["rang"])
    A = rang % 2 == 0
    foret = RandomForestClassifier(n_estimators=200, random_state=117).fit(X[A], y[A])
    J = rang % 2 == 1
    assert abs(float(np.mean(foret.predict(X[J]) == y[J])) - ai["exactitude"]) < 1e-9, "l'aiguilleur réappris diffère de R-117"
    pol = {n: np.array(v) for n, v in ex["politiques"].items()}
    marche = lambda c: pol["départ"] if c == "nominal" else pol["spécialiste " + c]
    conds, vraies = [], []
    for k, n in enumerate(Ai.CONDITIONS):
        rng = np.random.default_rng(4301 + k)
        for _ in range(20):
            conds.append(B.tirer_condition(rng, Ai.regle(n)))
            vraies.append(n)
    with mp.Pool(3, initializer=B.preparer) as pool:
        mes = np.array(pool.map(_sentir, [(pol["départ"], c) for c in conds]))
        choix = foret.predict(mes)
        taches = []
        for c, v, ch in zip(conds, vraies, choix):
            taches += [(pol["départ"], c), (pol["généraliste"], c), (marche(v), c), (marche(ch), c)]
        res = pool.map(_juger, taches, chunksize=4)
    R = np.array(res).reshape(-1, 4)
    noms = ["départ", "généraliste", "aiguilleur parfait", "aiguilleur appris"]
    taux = {n: float(R[:, i].mean()) for i, n in enumerate(noms)}
    par_cond = {c: {n: int(R[np.array(vraies) == c, i].sum()) for i, n in enumerate(noms)} for c in Ai.CONDITIONS}
    exact = float(np.mean(choix == np.array(vraies)))
    v = {"H171": {"rapport": round(taux["aiguilleur appris"] / taux["aiguilleur parfait"], 3) if taux["aiguilleur parfait"] > 0 else None},
         "H172": {"ecart": round(taux["aiguilleur appris"] - taux["généraliste"], 3)},
         "H173": {"ecart": round(taux["aiguilleur appris"] - taux["départ"], 3)}}
    v["H171"]["verdict"] = "confirmée" if (v["H171"]["rapport"] is not None and v["H171"]["rapport"] >= 0.90) else "réfutée"
    v["H172"]["verdict"] = "confirmée" if v["H172"]["ecart"] >= 0.10 else "réfutée"
    v["H173"]["verdict"] = "confirmée" if v["H173"]["ecart"] >= 0.20 else "réfutée"
    print("aiguilleur sur ces 120 épisodes : %.0f %% de bonnes réponses" % (100 * exact), flush=True)
    print("réussite :", {n: round(t, 3) for n, t in taux.items()}, flush=True)
    for c in Ai.CONDITIONS:
        print("  %-15s %s" % (c, par_cond[c]), flush=True)
    print("verdicts :", json.dumps(v, ensure_ascii=False), flush=True)
    json.dump({"exactitude_aiguilleur": exact, "reussite": taux, "par_condition_sur_20": par_cond, "verdicts": v,
               "choix": choix.tolist(), "vraies": vraies}, open(os.path.join(ICI, "resultats", "n3-melange.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("écrit resultats/n3-melange.json", flush=True)


if __name__ == "__main__":
    main()
