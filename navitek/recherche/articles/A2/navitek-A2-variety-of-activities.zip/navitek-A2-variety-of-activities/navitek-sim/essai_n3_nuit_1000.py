"""R-125 — la nuit des 1000 essais : des répertoires de k activités tirés au hasard dans un bassin de 15, le même budget d'apprentissage
(480 épisodes), jugés sur 5 activités jamais pratiquées. Le cadre, le socle et le juge : essai_n3_multisport.py (R-123), avec 7 activités
ajoutées. Reprend où il s'est arrêté (un essai fini est une ligne de resultats/n3-nuit-1000.jsonl). Simulé.

    python -X utf8 essai_n3_nuit_1000.py [--essais N] [--processus 14]      → resultats/n3-nuit-1000.jsonl, puis n3-nuit-1000-verdicts.json

Les règles de verdict, fixées ici avant de lancer (cahier R-125, § 3) :
  H198  moyenne(test, k=8) − moyenne(test, k=1) >= 0,10
  H199  pour k de 3 à 8 : moyenne sur k de [moyenne(test, 3 familles) − moyenne(test, 1 ou 2 familles)] > 0 (k sans l'une des deux : ignoré)
  H200  [moyenne(k=3) − moyenne(k=1)] > [moyenne(k=15) − moyenne(k=8)]
  H201  l'activité au plus grand apport (moyenne sur k de 2 à 11 de [test avec − test sans]) est l'avion ou les cercles
  H202  max(test, k=1) > médiane(test, k=8)
  H203  moyenne(propres, k=1) > moyenne(propres, k=8)"""
import argparse
import json
import os
import time

import numpy as np

import essai_n3_multisport as M
import essai_n3_yoga as Y

RES = M.RES
F_ESSAIS = os.path.join(RES, "n3-nuit-1000.jsonl")


def oscille_genou(fl, ab, g0, ag, periode, bras="bas"):
    def f(s):
        u = min(1.0, s / 1.0)
        return {"torse": 0.0, "hanche_flex": fl, "hanche_abd": ab, "genou": g0 + u * ag * np.sin(2 * np.pi * s / periode), "bras": bras}
    return f


AJOUTS = {
    "talons": oscille_genou(5.0, 0.0, 70.0, 45.0, 1.2),                                          # athlétisme : talons-fesses
    "face": M.trajet([(0.0, 40.0, 0.0, 90.0), (2.0, 40.0, 0.0, 90.0), (2.25, 75.0, 0.0, 5.0), (2.7, 40.0, 0.0, 90.0)], bras="cotes"),  # karaté
    "haie": M.statique(10.0, 25.0, 45.0, 95.0, "cotes"),                                         # athlétisme : la jambe de retour de la haie
    "attitude": M.statique(15.0, -35.0, 0.0, 90.0, "cotes"),                                     # ballet : l'attitude derrière
    "lateral": M.periodique(10.0, 0.0, 15.0, 15.0, 10.0, 1.6, bras="cotes"),                     # échauffement : le balancier latéral
    "poussee": M.periodique(-25.0, 0.0, 30.0, 12.0, 10.0, 1.4, bras="devant", torse=35.0),       # patin : la poussée du patineur
    "balance": M.statique(45.0, -50.0, 0.0, 0.0, "cotes"),                                       # gymnastique : la balance avant
}
TEST = ["patineur", "genoux", "arabesque", "cote", "danseur"]
BASSIN = ["flamant", "arbre", "avion", "guerrier", "developpe", "balancier", "cercles", "tir", "talons", "face", "haie", "attitude", "lateral",
          "poussee", "balance"]
FAMILLE = {"flamant": "droite", "arbre": "droite", "developpe": "droite", "haie": "droite", "talons": "droite",
           "avion": "penchee", "guerrier": "penchee", "attitude": "penchee", "balance": "penchee",
           "balancier": "mouvement", "cercles": "mouvement", "tir": "mouvement", "face": "mouvement", "lateral": "mouvement", "poussee": "mouvement"}
PLAN_K = [(1, 45), (2, 155), (3, 155), (4, 155), (6, 155), (8, 155), (11, 120), (15, 60)]
GEN, POP, EPI = 10, 8, 6


def installer():
    """Dans chaque processus : le cadre de R-123, et le répertoire agrandi."""
    Y.init()
    M.ACT.update(AJOUTS)


def plan_essais():
    essais, n = [], 0
    for k, combien in PLAN_K:
        for i in range(combien):
            rng = np.random.default_rng(125000 + 1000 * k + i)
            if k == 1:
                rep = [BASSIN[i % len(BASSIN)]]
            else:
                rep = sorted(str(x) for x in rng.choice(BASSIN, k, replace=False))
            essais.append({"n": n, "k": k, "repertoire": rep, "graine": 125000 + 1000 * k + i})
            n += 1
    return essais


def un_essai(pool, e):
    rep, g = e["repertoire"], e["graine"]

    def plan(gen):
        rng = np.random.default_rng(np.random.SeedSequence([g, gen]))
        return [(str(rng.choice(rep)), int(rng.integers(0, 2 ** 31 - 1))) for _ in range(EPI)]
    u, courbe = M.apprendre(pool, M.U0, plan, GEN, POP, 0.25, g)
    taches = [(a, u, 990000 + 10 * j + r) for j, a in enumerate(TEST) for r in range(4)]
    taches += [(a, u, 980000 + 10 * j + r) for j, a in enumerate(rep) for r in range(2)]
    R = pool.map(M._ep, taches)
    nt = 4 * len(TEST)
    test = {a: float(np.mean([R[4 * j + r]["reussi"] for r in range(4)])) for j, a in enumerate(TEST)}
    propres = float(np.mean([r["reussi"] for r in R[nt:]]))
    return dict(e, socle=u, test=test, test_moy=round(float(np.mean(list(test.values()))), 4),
                test_tenu=round(float(np.mean([r["tenu"] for r in R[:nt]])), 3), propres=round(propres, 4),
                familles=len({FAMILLE[a] for a in rep}), courbe_reussite=[c["reussite"] for c in courbe])


def verdicts(L):
    par_k = {}
    for x in L:
        par_k.setdefault(x["k"], []).append(x)
    moy = lambda k, champ="test_moy": float(np.mean([x[champ] for x in par_k[k]])) if k in par_k else float("nan")
    ecarts = []
    for k in (3, 4, 6, 8):
        a = [x["test_moy"] for x in par_k.get(k, []) if x["familles"] == 3]
        b = [x["test_moy"] for x in par_k.get(k, []) if x["familles"] < 3]
        if a and b:
            ecarts.append(float(np.mean(a) - np.mean(b)))
    apport = {}
    for act in BASSIN:
        d = []
        for k in (2, 3, 4, 6, 8, 11):
            avec = [x["test_moy"] for x in par_k.get(k, []) if act in x["repertoire"]]
            sans = [x["test_moy"] for x in par_k.get(k, []) if act not in x["repertoire"]]
            if avec and sans:
                d.append(float(np.mean(avec) - np.mean(sans)))
        apport[act] = round(float(np.mean(d)), 4) if d else None
    candidats = [a for a in apport if apport[a] is not None]
    meilleur = max(candidats, key=lambda a: apport[a]) if candidats else None
    k1 = [x["test_moy"] for x in par_k.get(1, [])]
    k8 = [x["test_moy"] for x in par_k.get(8, [])]
    v = {"courbe": {k: {"test": round(moy(k), 4), "propres": round(moy(k, "propres"), 4), "n": len(par_k[k])} for k in sorted(par_k)},
         "apport": apport, "ecarts_familles": [round(x, 4) for x in ecarts]}
    v["H198"] = "confirmée" if moy(8) - moy(1) >= 0.10 else "réfutée"
    v["H199"] = "confirmée" if ecarts and float(np.mean(ecarts)) > 0 else "réfutée"
    v["H200"] = "confirmée" if (moy(3) - moy(1)) > (moy(15) - moy(8)) else "réfutée"
    v["H201"] = "confirmée" if meilleur in ("avion", "cercles") else "réfutée"
    v["H201_meilleur"] = meilleur
    v["H202"] = "confirmée" if k1 and k8 and max(k1) > float(np.median(k8)) else "réfutée"
    v["H203"] = "confirmée" if moy(1, "propres") > moy(8, "propres") else "réfutée"
    return v


def main():
    import multiprocessing as mp
    ap = argparse.ArgumentParser()
    ap.add_argument("--essais", type=int, default=None)
    ap.add_argument("--processus", type=int, default=14)
    a = ap.parse_args()
    installer()
    essais = plan_essais()
    if a.essais:
        essais = essais[:a.essais]
    faits = set()
    if os.path.exists(F_ESSAIS):
        for l in open(F_ESSAIS, encoding="utf-8"):
            if l.strip():
                faits.add(json.loads(l)["n"])
    t0 = time.time()
    with mp.Pool(a.processus, initializer=installer) as pool:
        for e in essais:
            if e["n"] in faits:
                continue
            r = un_essai(pool, e)
            with open(F_ESSAIS, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(r, ensure_ascii=False) + "\n")
            faits.add(e["n"])
            print("%s essai %4d (k=%2d) %-60s test %.2f propres %.2f [%d faits, %.0f s]" % (
                time.strftime("%H:%M:%S"), e["n"], e["k"], ",".join(e["repertoire"])[:60], r["test_moy"], r["propres"], len(faits),
                time.time() - t0), flush=True)
    L = [json.loads(l) for l in open(F_ESSAIS, encoding="utf-8") if l.strip()]
    if len(L) >= len(essais):
        v = verdicts(L)
        json.dump(v, open(os.path.join(RES, "n3-nuit-1000-verdicts.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(time.strftime("%H:%M:%S") + " fini ; verdicts : " + json.dumps({k: v[k] for k in v if k.startswith("H")}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    main()
