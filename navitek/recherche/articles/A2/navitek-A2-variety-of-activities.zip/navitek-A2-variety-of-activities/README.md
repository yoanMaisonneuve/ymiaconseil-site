# Variety of conditions or variety of activities? What helps a simulated humanoid balance in situations it has never practised — open package

Yoan Maisonneuve, Navitek Robolabs, 2026. All results are from simulation (MuJoCo).

- `journal/` : the laboratory notebooks (French): hypotheses and credences written before each run, results and verdicts after.
- `navitek-sim/` : the N3 model (`n3.xml`, meshes in `n1-v1-gele/`), the scripts, and the raw results (`resultats/`).
- `historique-git.txt` : dated commits, to check that predictions came before results.
- `journal/ERREURS-extrait.md` : the mistakes we caught, and what we changed.

## Run

Python 3.12+ with: `pip install mujoco numpy cmaes scipy scikit-learn imageio imageio-ffmpeg`. Then, in `navitek-sim/`:

```
python -X utf8 banc_variance/lancer.py --help   # R-111: variety of conditions (3 regimes x 3 seeds), then rapport.py, verdicts.py
python -X utf8 essai_n3_experts.py         # R-116: five specialists vs one generalist
python -X utf8 essai_n3_melange.py         # R-118: one difficulty at a time, mixed
python -X utf8 banc_variance/piege_recompense.py   # R-119
python -X utf8 banc_variance/une_a_la_fois.py      # R-120
python -X utf8 banc_variance/curriculum_nombre.py  # R-121
python -X utf8 essai_n3_multisport.py --help   # R-123: multisport childhood vs single sport
python -X utf8 essai_n3_chaque_exercice.py # R-124: what each exercise teaches (transfer matrix)
python -X utf8 nuit_orchestre.py          # R-125: 1,000 randomised curricula (hours)
python -X utf8 analyse_nuit_1000.py       # R-125: intervals, contributions, figures
```

## Licences

Code: MIT (`LICENSE`). Texts, notebooks, figures, data: CC BY 4.0 (`LICENCE-TEXTES-DONNEES.txt`).

Use of AI: the experiments, code and texts were produced with the assistance of Claude (Anthropic) under the author's direction.

---

Paquet ouvert : cahiers (en français), modèle, scripts, résultats bruts, historique daté, licences libres. Tout est simulé.
