# R-121 — Le curriculum du nombre : une difficulté, puis deux, puis trois
mots-cles: Navitek, N3, curriculum, variance, nombre de difficultés, apprendre comme un enfant, généralisation, CMA-ES, MuJoCo

> Ouvert le 12.11.2026 à 14:46 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42). L'idée de Yoan
> (I-015, 04:49) : apprendre comme un enfant de 6 à 12 mois, dans l'ordre. Le curriculum de R-111 élargissait **toutes** les difficultés à la
> fois et ne s'est jamais élargi ; ici, on ajoute **le nombre** de difficultés, une à la fois. Prédictions écrites avant ; verdicts après.
> Tout est simulé.

## 1. La question

**En commençant par une difficulté par épisode, et en en ajoutant une chaque fois qu'il réussit, jusqu'où N3 monte-t-il, et tient-il mieux
quand toutes les difficultés arrivent ensemble ?**

## 2. Le dispositif

- **Le régime CN** : à chaque épisode, **k** des 25 axes de R-111 (tous sauf la vitesse visée), tirés au hasard et distincts, sont mis dans
  leur plage large ; les autres au nominal ; la vitesse visée dans l'étroite. **k commence à 1.** Après chaque génération : si la réussite
  des candidats est d'au moins 80 % deux générations de suite, k monte de 1 (jusqu'à 25 : c'est le jeu « dans les plages ») ; sous 30 %
  deux générations de suite, k descend de 1 (pas sous 1).
- **Le reste ne change pas** : le départ, CMA-ES (pas 0,02, population 16, 8 épisodes, 50 générations), les graines 1, 2, 3, la note de
  R-111, le jeu d'évaluation de 360 conditions.
- **Comparé à** R0 et R2 de R-111, et à U1 de R-120 (une difficulté à la fois, sans montée).

## 3. Les prédictions (avec ma crédence)

- **H181 — il monte** : k atteint au moins 5 à la fin, pour au moins 2 graines sur 3. Crédence 0,40.
- **H182 — il garde la marche** : au nominal, au moins 80 % de réussite. Crédence 0,70.
- **H183 — il tient mieux tout ensemble que U1** : dans les plages larges, au moins 5 points de plus que U1. Crédence 0,30.

## 4. Ce qui ne serait pas une preuve

La même petite marche ; 50 générations ; une règle de montée choisie par nous (80 %, deux de suite).

## 5. Résultats (12.11, de 17:45 à 20:01, simulé ; `banc_variance/curriculum_nombre.py`, `banc_variance/resultats-r121/`)

| graine | difficultés à la fois, au plus | à la fin | générations à 3 ou plus | nominal | tout ensemble | coins |
|---|---|---|---|---|---|---|
| 1 | **5** | 5 | 38 sur 50 | 100 % | 1 % | 1 % |
| 2 | 3 | 3 | 4 | 100 % | 0 % | 10 % |
| 3 | 3 | 3 | 11 | 100 % | 0 % | 2 % |

| 3 graines ensemble | nominal | dans les plages (tout ensemble) | coins | chutes dans les plages |
|---|---|---|---|---|
| U1 (R-120, une difficulté à la fois) | 100 % | 0,7 % | 3,0 % | 93,7 % |
| **CN (le curriculum du nombre)** | **100 %** | **0,3 %** | **4,3 %** | **91,7 %** |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H181 | k atteint au moins 5 pour au moins 2 graines sur 3 (0,40) | 5, 3, 3 : une graine sur trois | **réfutée** |
| H182 | il garde la marche au nominal, au moins 80 % (0,70) | 100 % | **confirmée** |
| H183 | tout ensemble, au moins 5 points de plus que U1 (0,30) | 0,3 % contre 0,7 % | **réfutée** |

## 6. Ce que ça dit

1. **L'ordre d'un enfant fonctionne au début** : N3 apprend une difficulté, puis deux, puis trois à la fois, sans perdre sa marche ; une graine
   monte jusqu'à cinq. **Puis il plafonne** : trois à cinq difficultés à la fois, c'est le maximum de cette marche de 19 réglages en 50
   générations.
2. **Tout ensemble (25 difficultés), il reste au plancher**, comme U1, R0 et les régimes de R-111. Le petit gain aux coins (4,3 % contre 2,3 %
   sans variance) ressemble à celui de la variance étroite (R-111).
3. **Ce que la journée dit, mis bout à bout** : la variance aide quand elle est apprenable (R-116), monte par étapes (R-121), mais cette marche
   n'a pas la place de tout tenir à la fois. La prochaine marche doit être plus grande.
