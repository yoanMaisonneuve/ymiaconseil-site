# R-123 — Le modèle norvégien : la multidiscipline d'abord, la spécialisation ensuite
mots-cles: Navitek, N3, multisport, multidiscipline, modèle norvégien, transfert, socle commun, équilibre, yoga, soccer, danse, athlétisme, patin, échauffement, CMA-ES, MuJoCo

> Ouvert le 12.11.2026 à 21:21 (heure lue), par la session, sur la correction de Yoan du 12.11 à 21:17 : « Pour moi variance est la variété
> des types d'activités, yoga, soccer, athlétisme, haltérophilie, football, baseball, hockey, patin, vélo, gymnastique, danse [...] le modèle
> norvégien de l'éducation physique appliqué à la robotique : on développe la multidiscipline qui nous rend meilleurs plus tard quand on se
> spécialise. On apprend plus en faisant des expériences variées. » (I-016). Prédictions écrites avant ; verdicts après. Tout est simulé.

## 1. La question

**Un robot qui a pratiqué beaucoup d'activités différentes apprend-il une activité nouvelle plus vite et mieux qu'un robot qui n'en a
pratiqué qu'une ?** C'est un transfert : ce qui passe d'une activité à l'autre, c'est le **sens de l'équilibre**, commun à toutes.

## 2. Le dispositif

- **Le socle commun** : les 7 réglages d'équilibre de R-073 (le transfert du poids vers la jambe d'appui, le genou d'appui, les gains de la
  cheville sur l'inclinaison avant et de côté et leurs vitesses, la cible du torse). Les mêmes pour toutes les activités ; chaque activité
  ne fixe que son geste (où vont la jambe libre, le torse, les bras).
- **Le répertoire** (sur la jambe gauche, la droite fait le geste ; tout ce que N3 peut faire debout sur une jambe ; il n'a ni taille qui
  tourne, ni poignets : pas de bâton, de batte, de vélo) :
  - yoga : le flamant, l'arbre, l'avion, le danseur, le guerrier (R-073) ;
  - danse : le développé (la jambe tendue devant), l'arabesque (la jambe tendue derrière, le torse penché) ;
  - arts martiaux : le coup de pied de côté ;
  - athlétisme et échauffements : les montées de genou, le balancier de la jambe, les cercles de hanche ;
  - soccer : le tir (la jambe recule, frappe, revient) ;
  - patin et hockey : l'appui du patineur (le torse penché, la jambe libre tendue en arrière et de côté).
  Un épisode : 2 s pour porter le poids, 1,5 s pour lever, puis 10 s à tenir le geste ; le juge de R-073 (chute si le centre de masse
  descend sous 65 %, si le torse s'écarte de plus de 35° de sa cible, ou si le pied libre touche le sol). La note : le temps tenu, moins de
  petites pénalités (le balancement, le roulis, l'écart du torse) ; **réussi = tenu les 10 s**. Une petite variation de départ par épisode
  (±1° aux articulations, ±0,02 m/s), tirée d'une graine.
- **Étape 0, le calibrage (avant les étapes 1 et 2)** : chaque activité jouée avec le socle de départ (le milieu des plages, « rien
  appris »), et apprise seule (CMA-ES, 15 générations × 12 candidats × 2 épisodes). **Règle fixée ici** : une activité que même son propre
  apprentissage ne tient pas 5 s en moyenne est écartée ; une activité que le socle de départ tient déjà 9,5 s en moyenne ne peut pas être
  une activité de test. **Les activités de test** (jamais vues avant la spécialisation) : le tir (soccer), l'appui du patineur (patin), les
  montées de genou (athlétisme), si elles passent la règle ; sinon, dans l'ordre, le coup de pied de côté, le balancier, l'arabesque.
  Les autres activités retenues forment le **répertoire d'entraînement**.
- **Étape 1, l'enfance** (le même budget : 30 générations × 12 candidats × 10 épisodes) :
  - **MULTI** : le socle appris sur tout le répertoire d'entraînement (chaque candidat joue chaque activité, à tour de rôle) ;
  - **SPÉ** : le socle appris sur **une seule** activité (la spécialisation précoce ; une activité différente par graine : les trois
    premières du répertoire d'entraînement dans l'ordre ci-dessus) ;
  - **RIEN** : le socle de départ, sans enfance.
  3 graines chacun.
- **Étape 2, la spécialisation** : pour chaque activité de test et chaque socle (MULTI, SPÉ, RIEN × 3 graines), CMA-ES part du socle et
  apprend l'activité (15 générations × 12 candidats × 3 épisodes, pas 0,15). Mesuré : **avant toute pratique** (le socle tel quel, 10
  épisodes), **après** (la moyenne de CMA-ES, 10 épisodes neufs), et la courbe d'apprentissage.

## 3. Les prédictions (avec ma crédence)

- **H188 — la multidiscipline rend meilleur après la spécialisation** : sur les activités de test, après la même spécialisation, MULTI réussit
  plus souvent que SPÉ (moyenne des activités et des graines). Crédence 0,55.
- **H189 — et mieux que rien** : MULTI réussit plus souvent que RIEN après la spécialisation. Crédence 0,60.
- **H190 — dès le premier essai** : avant toute pratique, MULTI tient plus longtemps que SPÉ et que RIEN sur les activités de test.
  Crédence 0,65.
- **H191 — plus vite** : MULTI atteint 90 % de sa note finale en moins de générations que SPÉ (médiane). Crédence 0,50.
- **H192 — le spécialiste reste le meilleur dans son sport** : sur sa propre activité, SPÉ tient au moins aussi longtemps que MULTI.
  Crédence 0,60.

## 4. Ce qui ne serait pas une preuve

Un socle de 7 réglages (l'équilibre sur une jambe), pas un cerveau ; des activités toutes sur une jambe, debout ; des gestes écrits à la main ;
un seul robot simulé. Le modèle norvégien parle d'enfants et d'années ; ici, de minutes de calcul.

## 5. Résultats (12.11, de 21:22 à 22:18, simulé ; `essai_n3_multisport.py`, `resultats/n3-multisport-*.json`)

**Étape 0, le calibrage** (détail dans R-124) : appris seuls, 8 exercices sur 13 tiennent 10 s dans 100 % des épisodes ; le danseur, le
guerrier, le coup de pied de côté, le balancier et le tir non (écartés par la règle). **Le choix, par la règle écrite avant** : le tir étant
écarté, les activités de test sont **le patineur, les montées de genou et l'arabesque** ; le répertoire d'entraînement : le flamant, l'arbre,
l'avion, le développé, les cercles de hanche. SPÉ, graines 1, 2, 3 : le flamant, l'arbre, l'avion.

**Étape 1, l'enfance** (30 générations × 12 × 10 épisodes) : à la fin, les candidats MULTI réussissent 100 %, 79 % et 82 % de leurs épisodes
(cinq exercices) ; les spécialistes 100 % (flamant), 56 % (arbre), 92 % (avion).

**Étape 2, la spécialisation** (temps tenu moyen sur 10 épisodes, réussite) :

| activité de test | socle | avant toute pratique (3 graines) | après 15 générations |
|---|---|---|---|
| patineur | MULTI | 1,3 · 0,6 · **7,4 s (70 %)** | 100 % · 100 % · 100 % |
| patineur | SPÉ | 0,0 · 0,2 · 1,2 s | 100 % · 100 % · 100 % |
| patineur | RIEN | 0,0 · 0,0 · 0,0 s | **0 % · 100 % · 10 %** |
| montées de genou | MULTI | 10 s (100 %) ×3 | 100 % ×3 |
| montées de genou | SPÉ | 10 s (100 %) ×3 | 100 % ×3 |
| montées de genou | RIEN | 0,1 s ×3 | 100 % ×3 |
| arabesque | MULTI | 10 s (100 %) ×3 | 100 % ×3 |
| arabesque | SPÉ | 0,4 · 0,5 · 10 s (l'avion) | 100 % ×3 |
| arabesque | RIEN | 0,0 s ×3 | 100 % ×3 |

| | MULTI | SPÉ | RIEN |
|---|---|---|---|
| avant toute pratique, tenu moyen | **7,7 s** | 4,7 s | 0,03 s |
| après la spécialisation, réussite | 100 % | 100 % | 79 % |
| générations pour atteindre 90 % de la note finale (médiane) | 1 | 1 | 3 |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H188 | après la spécialisation, MULTI réussit plus souvent que SPÉ (0,55) | 100 % et 100 % : égalité (plafond) | **réfutée** |
| H189 | MULTI réussit plus souvent que RIEN (0,60) | 100 % contre 79 % | **confirmée** |
| H190 | avant toute pratique, MULTI tient plus longtemps que SPÉ et RIEN (0,65) | 7,7 s, 4,7 s, 0,03 s | **confirmée** |
| H191 | MULTI atteint 90 % de sa note finale plus vite que SPÉ (0,50) | 1 génération l'un et l'autre (plafond) | **réfutée** |
| H192 | sur son propre sport, SPÉ tient au moins autant que MULTI (0,60) | 10 s et 10 s, pour les trois | **confirmée** (égalité ; MULTI avait aussi pratiqué ces sports) |

## 6. Ce que ça dit

1. **L'enfant multisport arrive le plus prêt devant une activité nouvelle** : 7,7 s tenues avant toute pratique, contre 4,7 s pour le
   spécialiste et rien pour celui qui n'a rien pratiqué. C'est ce que dit le modèle norvégien, ici mesuré sur un socle d'équilibre.
2. **Avoir une enfance compte plus que son contenu, une fois qu'on s'entraîne** : MULTI et SPÉ apprennent toutes les activités de test à 100 %
   en 15 générations ; sans enfance, le patineur n'est appris que par une graine sur trois.
3. **Le plafond cache la différence** : après la spécialisation, les trois activités de test sont trop faciles pour départager MULTI et SPÉ.
   Pour mesurer l'effet sur la spécialisation elle-même, il faut des activités plus dures, ou moins de pratique : c'est l'objet de R-125
   (1000 répertoires tirés au hasard, jugés sur cinq activités jamais vues, dont deux que personne n'apprend seul).
4. **La multidiscipline n'a rien coûté** sur les sports du spécialiste (10 s partout), mais MULTI les avait pratiqués aussi.
