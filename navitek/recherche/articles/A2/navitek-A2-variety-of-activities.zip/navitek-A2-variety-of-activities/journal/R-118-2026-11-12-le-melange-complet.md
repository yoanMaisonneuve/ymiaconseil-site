# R-118 — Le mélange complet : l'aiguilleur choisit l'expert
mots-cles: Navitek, N3, mélange d'experts, MoE, aiguilleur, spécialiste, généraliste, sentir le corps, MuJoCo

> Ouvert le 12.11.2026 à 11:35 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42). L'idée de Yoan (le
> MoE), assemblée : les experts de R-116 et l'aiguilleur de R-117. Prédictions écrites **avant de connaître les résultats de R-116** (qui
> tourne encore) ; verdicts après. Tout est simulé.

## 1. La question

**Un robot qui sent dans quel monde il marche, puis prend la marche faite pour ce monde, fait-il mieux qu'une marche pour tous ?**

## 2. Le dispositif

- **Les conditions jamais vues** : les six de R-117 (nominal, pente, retard des capteurs, délai de commande, sol mou, vent), 20 tirages chacune
  (graines 4301 à 4306) : 120 épisodes que ni les experts, ni le généraliste, ni l'aiguilleur n'ont vus.
- **L'aiguilleur** : la forêt de R-117, réapprise à l'identique (mêmes mesures, même moitié, même graine). Dans chaque épisode, N3 marche
  d'abord 2 s avec la marche de départ ; l'aiguilleur lit ces 2 s et choisit : « nominal » → la marche de départ ; sinon le spécialiste
  de la condition reconnue. **Puis l'épisode est rejoué depuis le début avec la marche choisie** (une approximation : un vrai robot changerait
  de marche en route, à 2 s).
- **Les comparaisons**, sur les mêmes 120 épisodes : la marche de départ ; le généraliste de R-116 ; les experts avec l'aiguilleur parfait
  (la vraie condition) ; les experts avec l'aiguilleur appris. Le juge de R-111.

## 3. Les prédictions (avec ma crédence)

- **H171 — l'aiguilleur appris vaut presque le parfait** : sa réussite moyenne atteint au moins 90 % de celle de l'aiguilleur parfait.
  Crédence 0,60.
- **H172 — le mélange bat la marche pour tous** : avec l'aiguilleur appris, les experts dépassent le généraliste d'au moins 10 points en
  moyenne sur les 120 épisodes. Crédence 0,45.
- **H173 — et la marche de départ** : ils dépassent la marche de départ d'au moins 20 points. Crédence 0,50.

## 4. Ce qui ne serait pas une preuve

Un changement de marche par rejeu (pas en route) ; six conditions connues, une à la fois ; des mesures exactes.

## 5. Résultats (12.11, de 13:02 à 13:07, simulé ; `essai_n3_melange.py`, `resultats/n3-melange.json`)

L'aiguilleur réappris donne exactement les réponses de R-117 sur ses épisodes de jugement (vérifié par le script). Sur les 120 épisodes
jamais vus de R-118, il choisit juste dans **94 %** des cas.

| réussites sur 20 | marche de départ | généraliste (R-116) | experts, aiguilleur parfait | experts, aiguilleur appris |
|---|---|---|---|---|
| nominal | 20 | 20 | 20 | 20 |
| pente | 5 | 6 | 5 | 6 |
| retard des capteurs | 9 | **19** | 11 | 11 |
| délai de commande | 7 | **20** | 13 | 14 |
| sol mou | 10 | 20 | 20 | 20 |
| vent | 8 | 10 | 9 | 9 |
| **sur 120** | **49 %** | **79 %** | **65 %** | **67 %** |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H171 | l'aiguilleur appris atteint au moins 90 % de la réussite du parfait (0,60) | 103 % (67 % contre 65 %) | **confirmée** |
| H172 | le mélange dépasse le généraliste d'au moins 10 points (0,45) | 12,5 points de **moins** | **réfutée** |
| H173 | le mélange dépasse la marche de départ d'au moins 20 points (0,50) | +17,5 points | **réfutée** (de peu) |

## 6. Ce que ça dit

1. **Le mélange d'experts fonctionne** : le robot sent dans quel monde il marche, choisit sa marche, et gagne 17,5 points sur la marche de
   départ. L'aiguilleur appris vaut le parfait (ses rares erreurs tombent sur un expert qui marche aussi).
2. **Mais la marche pour tous fait mieux** (79 % contre 67 %), sur des conditions qu'aucun n'avait vues : R-116 se confirme. Ici, à
   expérience égale, la variance des expériences mélangées l'emporte sur la division en experts.
3. **Ce qui reste à essayer** pour l'idée du MoE : des experts aussi bien entraînés que le généraliste (100 générations chacun), et des
   conditions combinées (où un seul généraliste pourrait ne plus suffire, comme R2 dans R-111).
