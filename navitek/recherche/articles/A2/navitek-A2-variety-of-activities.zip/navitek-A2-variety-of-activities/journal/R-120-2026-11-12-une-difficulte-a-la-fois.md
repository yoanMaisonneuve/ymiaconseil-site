# R-120 — Une difficulté à la fois : la variance qu'on peut apprendre, contre la variance empilée
mots-cles: Navitek, N3, variance, curriculum, une difficulté à la fois, généralisation, randomisation du domaine, CMA-ES, MuJoCo

> Ouvert le 12.11.2026 à 13:10 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42). Né de deux résultats
> du jour : R-111 (la variance empilée, tous les axes larges à la fois, fait abandonner la marche ; le curriculum ne s'élargit jamais) et
> R-116 (des difficultés une à la fois, mélangées, donnent la meilleure marche). Prédictions écrites avant ; verdicts après. Tout est simulé.

## 1. La question

**Une marche qui a appris les difficultés une à la fois tient-elle mieux quand elles arrivent toutes ensemble ?** C'est la différence entre
la variance qu'on peut apprendre et la variance empilée, mesurée sur le jeu d'évaluation de R-111.

## 2. Le dispositif

- **Le régime U1** : à chaque épisode, **un seul** des 25 axes de R-111 (tous sauf la vitesse visée) est tiré dans sa plage large ; les
  autres restent au nominal ; la vitesse visée dans l'étroite.
- **Le reste ne change pas** : le départ (la marche pré-entraînée), CMA-ES (pas 0,02, population 16, 8 épisodes, 50 générations), les
  graines 1, 2, 3, la note de R-111, le jeu d'évaluation de 360 conditions, le juge.
- **Comparé à** R0, R1, R2, R3 de R-111 (mêmes graines).

## 3. Les prédictions (avec ma crédence)

- **H177 — il marche encore** : au nominal, au moins 80 % de réussite (3 graines ensemble). Crédence 0,70.
- **H178 — il tient mieux tout ensemble** : dans les plages larges (tous les axes à la fois), au moins 5 points de plus que R0. Crédence 0,35.
- **H179 — surtout quand c'est peu à la fois** : sur les coins (trois axes à un bord, les autres dans les plages), au moins 10 points de
  plus que R0. Crédence 0,40.
- **H180 — il tombe moins** : dans les plages larges, moins de chutes que R0. Crédence 0,55.

## 4. Ce qui ne serait pas une preuve

La même petite marche (19 réglages) ; un petit budget ; le jeu d'évaluation empile les difficultés : s'il reste au plancher, la marche
elle-même est peut-être trop petite pour tout tenir à la fois.

## 5. Résultats (12.11, de 14:43 à 17:44, simulé ; `banc_variance/une_a_la_fois.py`, `banc_variance/resultats-r120/`)

Chaque graine a pris une heure (les épisodes durent jusqu'au bout : la marche tient sous une seule difficulté). Pendant l'entraînement, la
réussite des candidats (une difficulté à la fois) : graine 1 de 57 % à la première génération à 70 % à la dernière (au mieux 100 %) ; graine 2 de 48 % à 88 % (au mieux 99 %) ;
graine 3 de 46 % à 99 % (au mieux 99 %).

| 3 graines ensemble | nominal | dans les plages | hors plages | coins | autre solveur | chutes dans les plages |
|---|---|---|---|---|---|---|
| R0 (sans variance, R-111) | 100 % | 1,0 % | 0 % | 2,3 % | 1,3 % | 95,7 % |
| **U1 (une difficulté à la fois)** | **100 %** | **0,7 %** | 0 % | **3,0 %** | 0 % | **93,7 %** |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H177 | U1 garde la marche au nominal, au moins 80 % (0,70) | 100 % | **confirmée** |
| H178 | dans les plages, au moins 5 points de plus que R0 (0,35) | 0,7 % contre 1,0 % | **réfutée** |
| H179 | sur les coins, au moins 10 points de plus que R0 (0,40) | 3,0 % contre 2,3 % | **réfutée** |
| H180 | moins de chutes que R0 dans les plages (0,55) | 93,7 % contre 95,7 % | **confirmée** (de 2 points) |

## 6. Ce que ça dit

1. **Tenir chaque difficulté séparément ne donne pas la capacité de les tenir ensemble**, pour cette petite marche. U1 apprend bien (ses
   candidats réussissent souvent sous une seule difficulté), garde sa marche au nominal, mais reste au plancher quand toutes arrivent à la fois.
2. **Avec R-116** : le généraliste de R-116 (cinq difficultés, une à la fois) réussissait 78 % de ces difficultés, une à la fois. La variance
   apprenable rend robuste **à ce qu'on a vu** ; elle ne se compose pas toute seule en robustesse à tout ensemble.
3. **Ce qui reste** : R-121 (ajouter les difficultés une par une, jusqu'à les tenir ensemble), et une marche plus grande (19 réglages ne
   suffisent peut-être pas à tout tenir à la fois).
