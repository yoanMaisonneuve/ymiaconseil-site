# R-119 — Le piège de la récompense : payer pour marcher, pas pour rester debout
mots-cles: Navitek, N3, récompense, note, piège, variance large, rester immobile, marche, CMA-ES, MuJoCo

> Ouvert le 12.11.2026 à 11:36 (heure lue), par la session, sans attendre d'accord (consigne de Yoan du 12.11 à 09:42). Suite d'un constat de
> R-111 en cours : sous la variance large (R2), deux graines sur deux ont appris à **ne plus marcher** (0,02 m en 10 s au nominal), parce
> que la note paie le temps passé debout. Prédictions écrites avant ; verdicts après. Tout est simulé.

## 1. La question

La note d'entraînement de R-111 : 1 si le juge dit oui ; plus 0,5 × l'avance (jusqu'à 0,6 m), seulement si le robot n'est pas tombé ; plus
0,3 × le temps debout ; moins des pénalités (dérive, vol). Sous la variance large, marcher fait tomber presque toujours : rester immobile
rapporte 0,3, marcher et tomber à 3 s, environ 0,1. **Si on retire ce qui paie l'immobilité, la variance large apprend-elle à marcher, et la
marche apprise est-elle plus solide ?**

## 2. Le dispositif

- **La note « marcher »** : 1 si le juge dit oui ; plus 0,5 × l'avance (jusqu'à 0,6 m), **même si le robot tombe** ; **moins 0,5 s'il tombe** ;
  les mêmes pénalités ; **rien pour le temps debout**. Rester immobile rapporte 0 ; avancer de 0,3 m et tomber, −0,25 ; réussir, 1,5.
- **Le reste ne change pas** : le régime R2 de R-111 (tous les axes dans leur plage large), le départ (la marche pré-entraînée), CMA-ES (pas
  0,02, population 16, 8 épisodes, 50 générations), les **mêmes graines 1, 2, 3** (donc les mêmes conditions tirées à chaque génération que
  R2-g1 à R2-g3 de R-111) ; le même jeu d'évaluation de 360 conditions.
- **Comparé à** R2 (la note de R-111) et R0 (sans variance), graines 1 à 3, sur le même jeu.

## 3. Les prédictions (avec ma crédence)

- **H174 — il marche encore** : avec la note « marcher », R2 garde la marche au nominal, au moins 80 % de réussite (3 graines ensemble).
  Crédence 0,50.
- **H175 — et mieux que sans variance** : dans les plages larges, il dépasse R0 d'au moins 10 points. Crédence 0,30.
- **H176 — en prenant des risques** : dans les plages larges, il tombe plus souvent que R2 avec la note de R-111. Crédence 0,70.

## 4. Ce qui ne serait pas une preuve

Une seule autre note ; un petit budget ; la même petite marche (19 réglages). Si la variance large n'apprend toujours rien, c'est peut-être la
marche (la forme de la politique) qui est trop petite, pas la note.

## 5. Résultats (12.11, de 13:07 à 14:42, simulé ; `banc_variance/piege_recompense.py`, `banc_variance/resultats-r119/`)

Parti environ 5 min après R-118, au lieu d'aussitôt (E57 : la chaîne d'attente ne voyait pas son signal) ; rien d'autre ne change.

| 3 graines ensemble | nominal | dans les plages | hors plages | coins | autre solveur | chutes dans les plages | avance au nominal |
|---|---|---|---|---|---|---|---|
| R0 (sans variance) | 100 % | 1 % | 0 % | 2,3 % | 1,3 % | 96 % | 1,02 m |
| R2 (la note de R-111) | 0 % | 0 % | 0 % | 0,3 % | 0 % | 41 % | −0,01 m |
| **R2, note « marcher »** | **0 %** | **0 %** | 0,3 % | 1,3 % | 0 % | **60 %** | **0,02 m** |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H174 | avec la note « marcher », R2 garde la marche au nominal, au moins 80 % (0,50) | 0 % ; il avance de 2 cm en 10 s | **réfutée** |
| H175 | dans les plages, au moins 10 points de plus que R0 (0,30) | 0 % contre 1 % | **réfutée** |
| H176 | il tombe plus souvent que R2 avec la note de R-111 (0,70) | 60 % contre 41 % | **confirmée** |

## 6. Ce que ça dit

1. **Le piège ne vient pas de la note.** Sans rien pour le temps debout, R2 ne remarche pas : il reste presque immobile, et il tombe plus
   (il n'a plus de raison de bien se tenir). Sous la variance empilée, tout candidat qui marche tombe ; la pénalité de chute pousse, elle
   aussi, vers l'immobilité.
2. **Ce qui manque, c'est une expérience qu'on peut réussir.** Pendant ses 150 générations (3 graines), 0,2 à 0,6 % des épisodes en moyenne (au plus 5 % dans une génération) ; presque aucun candidat de R2 n'a
   réussi une seule fois : rien à imiter, rien à renforcer. C'est la question de R-120 (une difficulté à la fois) et de R-116 (le généraliste
   qui gagne quand chaque expérience reste à portée).
