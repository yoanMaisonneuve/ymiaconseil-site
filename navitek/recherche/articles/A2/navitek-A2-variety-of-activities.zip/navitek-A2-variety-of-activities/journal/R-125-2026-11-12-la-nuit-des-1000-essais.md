# R-125 — La nuit des 1000 essais : la variété des activités pratiquées et la réussite sur l'inconnu
mots-cles: Navitek, N3, multisport, multidiscipline, modèle norvégien, variété, transfert, généralisation, 1000 essais, yoga, danse, athlétisme, arts martiaux, patin, soccer, gymnastique, échauffements, CMA-ES, MuJoCo

> Ouvert le 12.11.2026 à 21:43 (heure lue), par la session, sur la demande de Yoan du 12.11 à 21:41 : « Continue toute la nuit à demain matin,
> 1000 tests », dans la suite de son idée (I-016, 21:17 : « on développe la multidiscipline qui nous rend meilleurs plus tard quand on se
> spécialise ; on apprend plus en faisant des expériences variées ») et de R-124 (un exercice impossible seul devient possible grâce à un
> autre). Prédictions écrites avant ; verdicts le matin. Tout est simulé.

## 1. La question

**À temps de pratique égal, un N3 qui a pratiqué plus d'activités différentes réussit-il mieux des activités qu'il n'a jamais faites ?**
Et lesquelles, dans le répertoire, apprennent le plus aux autres ?

## 2. Le dispositif

- **Le répertoire : 20 exercices sur une jambe**, dans le cadre de R-073 et R-123 (le même socle d'équilibre de 7 réglages, le même juge) :
  les 13 de R-123, plus 7 ajoutés ce soir, tirés du catalogue (`navitek-sim/multisport/CATALOGUE-EXERCICES.md`) : les **talons-fesses**
  (athlétisme), le **coup de pied de face** (karaté), le **passage de haie** (athlétisme), l'**attitude** (ballet), le **balancier latéral**
  (échauffement), la **poussée du patineur** (patin), la **balance avant** (gymnastique).
- **Les 5 activités de test, jamais pratiquées** : le patineur (patin), les montées de genou (athlétisme), l'arabesque (danse), le coup de pied
  de côté (karaté), le danseur (yoga). Les deux derniers ne s'apprenaient pas seuls en 15 générations (R-123), mais d'autres exercices les
  rendaient possibles (R-124).
- **Le bassin d'entraînement : les 15 autres.** Les familles (pour H199) : *droites* (flamant, arbre, développé, haie, talons), *penchées*
  (avion, guerrier, attitude, balance), *en mouvement* (balancier, cercles, tir, face, latéral, poussée).
- **Un essai** : un répertoire de k activités tiré au hasard dans le bassin (graine fixée par l'essai) ; le socle appris dessus par CMA-ES
  depuis le socle de départ (10 générations × 8 candidats × 6 épisodes : **480 épisodes, le même budget pour tous**, chaque épisode jouant une
  activité du répertoire tirée au hasard) ; puis la moyenne de CMA-ES jouée sur les **5 activités de test** (4 épisodes chacune) et sur ses
  propres activités (2 épisodes chacune).
- **Les 1000 essais** : k = 1 (45 essais : chaque activité, 3 graines), 2, 3, 4, 6, 8 (155 chacun), 11 (120), 15 (60, tout le bassin).
- Calcul détaché, priorité basse, 14 processus ; il part après la fin de R-123. La méditation de 3 h 10 passe avant.

## 3. Les prédictions (avec ma crédence)

- **H198 — la variété paie** : la réussite moyenne sur les activités de test à k = 8 dépasse celle à k = 1 d'au moins 10 points. Crédence 0,55.
- **H199 — la variété des familles compte** : à k égal (de 3 à 8), les répertoires qui couvrent les trois familles réussissent mieux les tests
  que ceux qui en couvrent une ou deux (l'écart moyen, à k égal, est positif). Crédence 0,55.
- **H200 — les rendements baissent** : le gain de k = 1 à k = 3 est plus grand que le gain de k = 8 à k = 15. Crédence 0,60.
- **H201 — le meilleur professeur est difficile** : l'activité qui apporte le plus aux tests (la réussite moyenne des répertoires qui la
  contiennent, moins celle de ceux qui ne la contiennent pas, à k égal) est l'avion ou les cercles. Crédence 0,45.
- **H202 — un bon spécialiste vaut une variété moyenne** : le meilleur des répertoires d'une seule activité dépasse la médiane des répertoires
  de 8 activités. Crédence 0,50.
- **H203 — la variété coûte à chaque activité** : la réussite sur ses propres activités baisse avec k (k = 1 au-dessus de k = 8). Crédence 0,60.

## 4. Ce qui ne serait pas une preuve

Un socle de 7 réglages, pas un cerveau ; des activités toutes sur une jambe ; 480 épisodes par essai (une enfance très courte) ; un robot
simulé. Si la variété paie ici, c'est un indice pour l'idée de Yoan, pas une preuve pour les enfants.

## 5. Résultats (12.11 à 22:18 au 13.11 à 03:58, simulé ; `essai_n3_nuit_1000.py`, `analyse_nuit_1000.py` ; `resultats/n3-nuit-1000*.json*`)

**1000 essais faits**, en 5 h 40 (environ 20 s chacun ; 14 processus en priorité basse). Les deux premiers (k = 1, flamant et arbre) ont tourné
à 21:45 comme essai de fumée, avec le même code et les mêmes graines : ils comptent. Intervalles : bootstrap sur les essais (2000 tirages).

**La courbe** : la réussite moyenne sur les 5 activités jamais pratiquées, et sur ses propres activités, selon le nombre d'activités
pratiquées (le même temps de pratique pour tous) ; puis la réussite par activité de test (%).

| k | essais | jamais vues (IC 95 %) | ses propres | genoux | arabesque | danseur | pied côté | patineur |
|---|---|---|---|---|---|---|---|---|
| 1 | 45 | 25,4 % (19,2 à 31,7) | 38,9 % | 72 | 33 | 7 | 12 | 3 |
| 2 | 155 | 30,8 % (27,6 à 34,0) | 42,3 % | 88 | 38 | 12 | 11 | 6 |
| 3 | 155 | 31,5 % (28,6 à 34,7) | 34,9 % | 90 | 39 | 12 | 12 | 4 |
| 4 | 155 | 33,1 % (30,1 à 36,2) | 38,1 % | 93 | 42 | 16 | 9 | 6 |
| 6 | 155 | 33,5 % (30,2 à 36,9) | 34,4 % | 92 | 42 | 13 | 16 | 5 |
| 8 | 155 | 33,0 % (30,4 à 35,7) | 33,3 % | 94 | 47 | 12 | 11 | 1 |
| 11 | 120 | 37,1 % (33,9 à 40,5) | 37,0 % | 95 | 56 | 19 | 13 | 3 |
| 15 | 60 | 32,8 % (27,9 à 37,4) | 34,4 % | 92 | 45 | 18 | 9 | 0 |

Corrélation de Spearman entre k et la réussite sur l'inconnu, sur les 1000 essais : **ρ = 0,10 (p = 0,001)** ; jusqu'à
k = 11 : ρ = 0,11 (p = 0,0006).

**Ce que chaque activité apporte** (la réussite sur l'inconnu des répertoires qui la contiennent, moins celle de ceux qui ne la contiennent
pas, à k égal, moyenne de k = 2 à 11, en points ; intervalle à 95 %) et sa réussite sur l'inconnu quand on ne pratique qu'elle :

| activité | apport | IC 95 % | pratiquée seule |
|---|---|---|---|
| balance avant (gymnastique) | +7,2 | +4,1 à +10,4 | 50,0 % |
| poussée du patineur | +3,4 | −0,4 à +7,3 | 15,0 % |
| passage de haie | +3,2 | +0,2 à +6,1 | 13,3 % |
| balancier latéral | +2,6 | −0,6 à +5,8 | 26,7 % |
| cercles de hanche | +1,9 | −1,2 à +5,0 | 48,3 % |
| flamant | +1,8 | −1,1 à +4,7 | 25,0 % |
| balancier | −0,2 | −3,4 à +3,0 | 0,0 % |
| développé | −0,4 | −3,2 à +2,4 | 40,0 % |
| avion | −0,7 | −3,9 à +2,4 | 35,0 % |
| arbre | −1,9 | −4,7 à +1,0 | 33,3 % |
| talons-fesses | −2,5 | −5,2 à +0,3 | 11,7 % |
| guerrier | −2,8 | −6,2 à +0,7 | 0,0 % |
| tir (soccer) | −3,2 | −6,1 à −0,4 | 26,7 % |
| attitude (ballet) | −3,6 | −6,4 à −0,8 | 36,7 % |
| coup de pied de face (karaté) | −4,2 | −6,9 à −1,4 | 20,0 % |

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H198 | k = 8 dépasse k = 1 d'au moins 10 points (0,55) | 33,0 % contre 25,4 % : +7,6 points (à k = 11 : +11,7) | **réfutée** |
| H199 | à k égal, couvrir les trois familles aide (0,55) | écart moyen +4,7 points (k = 3 : +7,6 ; 4 : −1,4 ; 6 : −0,7 ; 8 : +13,1) | **confirmée** (inégal selon k) |
| H200 | les rendements baissent : le gain de 1 à 3 dépasse celui de 8 à 15 (0,60) | +6,1 points contre −0,3 | **confirmée** |
| H201 | le meilleur professeur est l'avion ou les cercles (0,45) | la balance avant de gymnastique (+7,2 points, IC 4,1 à 10,4) | **réfutée** |
| H202 | le meilleur répertoire d'une seule activité dépasse la médiane de ceux de 8 (0,50) | 90,0 % (attitude (ballet), une graine) contre 40,0 % | **confirmée** |
| H203 | la variété coûte à chaque activité pratiquée : k = 1 au-dessus de k = 8 (0,60) | 38,9 % contre 33,3 % | **confirmée** |

## 6. Ce que ça dit

1. **La variété paie, faiblement mais nettement** : sur 1000 essais, plus on pratique d'activités différentes (à temps égal), mieux on réussit
   celles qu'on n'a jamais faites (ρ = 0,10, p = 0,001) : de 25 % avec une seule activité à 37 % avec onze.
2. **Les rendements baissent vite** : l'essentiel du gain vient des deux ou trois premières activités ajoutées (25 → 31 %).
3. **Toutes les variétés ne se valent pas.** La **balance avant** (gymnastique : le torse à 45°, la jambe libre tendue derrière) est le meilleur
   professeur (+7,2 points) ; le passage de haie aide aussi. Le **coup de pied de face**, l'**attitude** du ballet et le **tir** coûtent
   (−3 à −4 points) : difficiles, ils prennent du temps de pratique sans rien transmettre. C'est pourquoi pratiquer tout le bassin (15) fait
   moins bien qu'onze.
4. **La variété coûte un peu sur chaque activité pratiquée** (de 39 % à 33 % à temps égal) : on devient moins bon dans chacune, meilleur
   devant l'inconnu. C'est le marché du modèle norvégien.
5. **Ce qui se transfère, et ce qui ne se transfère pas** : les montées de genou (72 → 95 %), l'arabesque (33 → 56 %), le danseur (7 → 19 %)
   profitent de la variété ; le patineur reste presque impossible sans sa propre pratique (0 à 6 %).
6. **Pour l'idée de Yoan** : ici, sur un socle d'équilibre de 7 réglages, la multidiscipline rend meilleur devant l'inconnu, et le choix des
   disciplines compte autant que leur nombre.

*Correction du 13.11 à 04:04 (E58) : l'apport avait été arrondi deux fois (à 4 décimales, puis à 1) ; la balance avant valait +7,3 dans le texte et +7,2 dans le tableau. La valeur exacte est +7,25 (intervalle 4,15 à 10,35) : +7,2, de 4,1 à 10,4. L'analyse garde maintenant 6 décimales ; dans le tableau, quatre chiffres ont bougé d'un dixième (l'intervalle de la balance, 4,1 à 10,4 ; l'arbre, −1,9 ; le tir, de −6,1). Aucun verdict ne change.*
