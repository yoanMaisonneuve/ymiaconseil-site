# R-111 — Le banc de variance : ce que la variété des expériences apporte à l'apprentissage d'un mouvement
mots-cles: Navitek, N3, variance, randomisation du domaine, curriculum, généralisation, marche, juge, ablation, CMA-ES, MuJoCo, boucle fermée

> Ouvert le 12.11.2026 à 06:02 (heure lue), par la session, sur la mission de Yoan du 12.11 à 06:00 (« construis un banc d'expériences très
> variées pour qu'un robot apprenne un mouvement en simulation, et mesure ce que la variance apporte à l'apprentissage » ; sa note « La boucle
> ouverte » ; « la variance des expériences donne l'intelligence de da Vinci ; on teste l'hypothèse pour le robot »). Prédictions avant toute
> exécution ; verdicts après. Tout est simulé.

> **Correction de Yoan, 12.11 à 21:17** : par « variance des expériences », il voulait dire **la variété des activités** (yoga, soccer,
> athlétisme, danse, patin..., le modèle norvégien : la multidiscipline avant la spécialisation), pas la variance des conditions d'un même
> geste. Ce banc teste la randomisation des conditions (une seule marche) ; **ce n'est pas son hypothèse**. H141 (« l'idée de Yoan, forme
> forte ») la nommait mal ; les résultats restent vrais pour ce qu'ils mesurent. Son hypothèse : R-123 et I-016.

## 1. La question

Une politique entraînée dans une seule condition apprend aussi les accidents de cette condition (un frottement précis, une masse précise,
les manies du simulateur). Quand les conditions varient, seul ce qui marche partout survit. **La variance des conditions d'entraînement
rend-elle le mouvement meilleur là où il n'a jamais été entraîné ? Quelle variance aide, et jusqu'où ?** C'est l'« extension : le corps
comme juge » de la note : la physique dit non sans qu'on puisse argumenter.

## 2. Les cases à remplir de la mission

- **Robot** : N3, `navitek-sim/n3.xml` (1,5 m, 26,5 kg, 17 articulations, hanche à 135°).
- **Mouvement** : la marche avant (le mouvement le plus étudié de N3, et le plus fragile : R-086, R-091, R-093, R-107).
- **Simulateur** : MuJoCo 3.8 sur processeur. MJX n'est installé nulle part ; cet ordinateur n'a pas de carte NVIDIA (la tour a une RTX 3060 Ti
  de 8 Go, pas de 5090). La politique de la v1 est petite (19 réglages) : le processeur suffit.
- **Matériel** : le portable, 16 cœurs (14 au travail).
- **Budget** : 6 400 épisodes de 10 s par entraînement (50 générations × 16 candidats × 8 épisodes ; 1,28 × 10⁸ pas de 0,5 ms), le même pour tous ;
  environ 4 min de calcul chacun ; 48 entraînements en tout (régimes, largeurs, ablation), environ 3 h 30 avec les évaluations.

## 3. La politique et l'algorithme

**La politique** : la marche de R-107 (un rythme à 15 réglages, le pied posé là où le corps s'en va, la cadence qui suit la vitesse) : 19
réglages, qui lisent l'attitude du torse, ses vitesses, la vitesse du corps et la vitesse visée. **L'algorithme** : CMA-ES, population 16,
pas initial 0,15, le même point de départ pour tous (la meilleure marche de R-107). *(Corrigé avant les résultats : le départ est la marche
pré-entraînée au nominal (E54, § 6 bis) et le pas initial 0,02 (E56, § 6 ter).)* Un candidat est noté sur 8 épisodes tirés dans les
conditions de son régime.

## 4. Le juge (proposé à Yoan le 12.11 ; **accordé par Yoan le 12.11 à 09:07 (« Go »)**, tel quel)

**Un épisode de 10 s est réussi si :**
1. **pas de chute** : le torse reste incliné de moins de 40° et le centre de masse au-dessus de 60 % de sa hauteur debout, du début à la fin ;
2. **il avance** d'au moins **0,6 m** dans sa direction de départ (sa marche nominale fait environ 1 m) ;
3. **il reste dans son couloir** : dérive de côté d'au plus **0,5 m** ;
4. **pas de vol** : au plus 0,1 s sans aucun appui (la leçon d'E48).

**Mesures secondaires** : les chutes ; l'erreur de suivi (la vitesse réelle contre la vitesse visée) ; l'énergie (somme des |couple × vitesse
articulaire|, et le coût du transport) ; les pics de couple par articulation, en N·m et en kg à 300 mm (couple ÷ (9,81 × 0,3)) ; la douceur
des commandes (la variation moyenne des consignes, en °/s) ; le glissement des pieds.

## 5. Le protocole

- **Quatre régimes** : R0 sans variance ; R1 étroite ; R2 large ; R3 curriculum automatique (chaque axe part de l'étroite ; à chaque génération,
  des épisodes sondent un axe à la limite de sa plage ; réussite de plus de 80 % à la limite : on élargit l'axe de 25 % ; moins de 50 % : on le
  resserre ; jamais au-delà de l'extrême). **Trois graines** par régime.
- **Le jeu d'évaluation**, tiré avant tout entraînement (graine 111) et jamais vu : **nominal** (10 épisodes, seule la vitesse visée varie,
  dans l'étroite) ; **dans les plages** (100 conditions, tous les axes dans les plages larges) ; **hors plages** (100 : deux axes au hasard
  entre la large et l'extrême, les autres dans la large) ; **combinaisons jamais vues ensemble** (100 : trois axes au hasard à un coin de la
  plage large en même temps) ; **un autre solveur** (50 conditions dans les plages, pas de 1 ms, intégrateur Euler, cône elliptique).
- **La courbe de largeur** : tous les axes à 0, 0,25, 0,5, 1, 1,5 et 2 fois la plage large (3 graines par largeur).
- **L'ablation** : le régime large, moins un groupe d'axes à la fois (8 groupes : corps, actionneurs, délai, frottement au sol, pente et
  terrain, poussées et vent, capteurs, conditions initiales), 3 graines.
- **Le rapport** : régimes × jeux d'évaluation, avec intervalles de confiance à 95 % (Wilson sur les réussites, entre graines et épisodes) ;
  la courbe réussite contre largeur ; le classement des axes ; le point où la variance cesse d'aider ; un film du meilleur et du pire cas
  de chaque régime.

## 6. Les prédictions, écrites avant (avec ma crédence)

- **H135 — sur le nominal, la variance ne coûte presque rien** : R0 ne dépasse pas R2 de plus de 10 points. Crédence 0,60.
- **H136 — dans les plages, la variance gagne** : R2 et R3 dépassent R0 d'au moins 20 points. Crédence 0,75.
- **H137 — hors plages, l'ordre** : R3 > R2 > R1 > R0. Crédence 0,45.
- **H138 — le solveur** : c'est R0 qui perd le plus entre le nominal et l'autre solveur. Crédence 0,60.
- **H139 — la courbe en cloche** : dans les plages, la réussite monte puis redescend avec la largeur ; le meilleur est entre 0,5 et 1 fois
  la plage large ; à 2 fois, au moins 10 points de moins que le meilleur. Crédence 0,55.
- **H140 — les axes qui comptent** : les trois premiers de l'ablation sont parmi le frottement au sol, les poussées et le vent, le délai,
  la pente et le terrain. Crédence 0,60.
- **H141 — l'idée de Yoan, dans sa forme forte** : la variance des expériences fait mieux que la même quantité d'expérience répétée (R2 contre
  R0, même budget) sur **tous** les jeux d'évaluation sauf le nominal. Crédence 0,55.

**Ce qui ne serait pas une preuve.** Un seul mouvement ; une petite politique (19 réglages, pas un réseau de neurones) ; un algorithme
d'évolution, pas d'apprentissage par renforcement ; un modèle simplifié (seuls les pieds touchent le sol) ; des plages choisies par moi.

## 6 bis. Le passage pilote et la correction (E54), avant les résultats

Lancé à 09:15, arrêté à 09:18 après le premier entraînement (R0, graine 1) : réussite 10 % au nominal, 0 % partout ailleurs. Le point de
départ (la marche B-g1 de R-107) ne passait pas le juge : à la vitesse visée de 0,3 m/s, elle avance de 1,06 m mais en sautillant (0,55 s sans
appui) ; à 0,12 m/s, 0,24 m. Après 50 générations, elle ne sautille plus mais plafonne à 0,58-0,76 m, au seuil du juge. Tous les régimes
seraient partis d'un plancher. **Le juge ne change pas.** Le départ commun devient une marche **pré-entraînée au nominal** (100 générations,
4 épisodes par candidat, la vitesse visée dans la plage étroite, le reste nominal) ; les quatre régimes, les largeurs et l'ablation partent
tous d'elle, avec le budget prévu. Ce que le banc mesure devient : **ce que la variance ajoute quand on apprend à marcher partout, à partir
d'une marche qui sait marcher au nominal** (la façon habituelle : apprendre le geste, puis l'apprendre partout). Le passage pilote est gardé
dans `banc_variance/archive-pilote-avant-e54-2026-11-12/`. Les prédictions H135 à H141 n'ont pas changé.

## 6 ter. Le deuxième passage, arrêté (E56), et le diagnostic, prédit avant

Lancé à 09:43 depuis la marche pré-entraînée (100 % au nominal, 0,89 m). R0-g1 : 100 % au nominal, 0 à 1 % ailleurs. **R1-g1 : 0 % partout,
même au nominal**, en 15,8 min ; aucun candidat n'a réussi en 50 générations. R2-g1 : 0 % de réussite des candidats à la génération 21.
Arrêté à 10:05, archivé (`banc_variance/archive-passage2-avant-e56-2026-11-12/`). Le juge ne change pas.

**Le diagnostic, prédictions écrites avant de le lancer (10:06)** :
- **D1** : la marche pré-entraînée, telle quelle, réussit au moins 50 % de 50 conditions étroites (R1). Crédence 0,40.
- **D2** : elle réussit au plus 10 % de 50 conditions larges (R2). Crédence 0,80.
- **D3** : au moins un axe, seul dans sa plage étroite, fait tomber la réussite sous 50 % ; les coupables sont parmi la pente, le sol
  irrégulier, le délai de commande, le retard des capteurs et les poussées. Crédence 0,55.
- **D4** : au pas initial 0,15, moins de 20 % des candidats tirés autour de la marche passent le nominal ; au pas 0,05, plus de 50 %.
  Crédence 0,60.

**Le diagnostic, mesuré (10:07, simulé ; `banc_variance/diagnostic.py`, `resultats/diagnostic_e56.json`)** :

| | prédit | mesuré | verdict |
|---|---|---|---|
| D1 | la marche pré-entraînée réussit au moins 50 % des conditions étroites | 7 sur 50 (14 %), 23 chutes | réfutée |
| D2 | au plus 10 % des conditions larges | 0 sur 50, 49 chutes | confirmée |
| D3 | un axe seul, à l'étroite, la fait tomber sous 50 % | aucun : chaque axe seul à l'étroite la laisse entre 7 et 10 sur 10 (la pente 7, le retard des capteurs 9) | réfutée |
| D4 | au pas 0,15 moins de 20 % des candidats passent le nominal ; au pas 0,05 plus de 50 % | 0 sur 32 au pas 0,15 ; 6 sur 32 au pas 0,05 (27 sur 32 au pas 0,02) | partielle |

**Ce que ça dit.** Deux choses. (1) La marche est fragile à la **combinaison** des variances, pas à un axe : chaque axe seul, dans sa plage
étroite, passe ; tous ensemble, 14 %. Dans la plage large, les axes qui la cassent seuls sont la pente (2 sur 10), le retard des capteurs
(2), le délai de commande (3), le sol mou (5) et le vent (6). (2) La marche vit dans un **bassin très étroit** : le pas initial du banc
(0,15) tirait tous les candidats hors d'elle. C'est ce qui a ruiné R1 (E56).

**La correction (10:09), le juge inchangé.** Le pas initial de CMA-ES devient **0,02** pour tous les régimes, par une règle fixée dans
`calibrer_pas.py` avant de le lancer : le plus grand pas, parmi 0,025, 0,03, 0,035 et 0,04, où au moins la moitié de 64 candidats passent
le nominal, sinon 0,02 (27 sur 32 au diagnostic). Mesuré : 31, 31, 19 et 6 sur 64 ; aucun n'atteint 32 : **0,02**. Le départ est la
marche pré-entraînée exacte (plus de rognage à [0,02, 0,98]). Un essai de fumée de 4 générations (10:11, ne compte pour rien) :
R1 trouve des candidats qui réussissent (1 à 11 %) ; R2 reste à 0 %. Le budget ne change pas (6 400 épisodes par entraînement) ;
le banc complet, environ 7 h 30 sur le portable seul (13 processus, priorité basse), une seule machine pour que tout reste rejouable.
Les prédictions H135 à H141 ne changent pas.

**Les règles de verdict** (écrites à 09:40, avant le premier résultat du banc, et commises avant lui) sont calculées par
`banc_variance/verdicts.py` : H135 R0 − R2 ≤ 10 points au nominal ; H136 R2 et R3 à au moins R0 + 20 points dans les plages (un seul :
partielle) ; H137 l'ordre strict R3 > R2 > R1 > R0 hors plages (R2 et R3 au-dessus de R1 > R0 sans leur ordre : partielle) ; H138 la plus
grande perte du nominal à l'autre solveur est celle de R0 ; H139 le meilleur à 0,5 ou 1 fois la plage large, et à 2 fois au moins
10 points sous le meilleur (un des deux : partielle) ; H140 les trois premiers de l'ablation dans l'ensemble prédit (deux : partielle) ;
H141 R2 > R0 sur les quatre jeux hors nominal (trois : partielle). Le verdict porte sur les taux mesurés ; on dit à côté si l'écart
sort des intervalles de confiance.

## 7. Résultats (troisième passage, de 10:14 à 18:31, simulé ; 48 entraînements ; `banc_variance/rapport/`)

Le rapport (`rapport.py`), les verdicts (`verdicts.py`, règles commises à 09:40), les films (`rapport.py --films`). Deux défauts du rapport,
corrigés avant publication : `rapport.py` lisait aussi le pré-entraînement et le diagnostic (filtré) ; ses films, à partir du deuxième, étaient
noirs (le moteur de rendu précédent libéré trop tard) et le « pire cas » était pris à l'envers (la chute la plus tardive) : corrigés, rendus de
nouveau (le premier rendu gardé dans `navitek-sim/archive-films-noirs-2026-11-12/`).

### 7.1 Les quatre régimes, sur les cinq jeux (3 graines ensemble ; intervalle de Wilson à 95 %)

| régime | nominal (30) | dans les plages (300) | hors plages (300) | coins (300) | autre solveur (150) |
|---|---|---|---|---|---|
| R0 sans variance | 100 % (89-100) | 1,0 % (0,3-2,9) | 0 % (0-1,3) | 2,3 % (1,1-4,7) | 1,3 % (0,4-4,7) |
| R1 étroite | 100 % (89-100) | 1,0 % (0,3-2,9) | 0 % (0-1,3) | 6,3 % (4,1-9,7) | 0,7 % (0,1-3,7) |
| R2 large | **0 %** (0-11) | 0 % (0-1,3) | 0 % (0-1,3) | 0,3 % (0,1-1,9) | 0 % (0-2,5) |
| R3 curriculum | 100 % (89-100) | 1,0 % (0,3-2,9) | 2,0 % (0,9-4,3) | 6,0 % (3,8-9,3) | 0,7 % (0,1-3,7) |

**Mesures secondaires** (les 360 conditions de chaque politique, 3 graines) : chutes R0 92,5 %, R1 88 %, **R2 47 %**, R3 88 % ; avance moyenne
0,27, 0,26, **0,04**, 0,31 m ; coût du transport (médiane) 6,6, 5,0, 5,7, **4,5** ; douceur des consignes 52, **39**, 20, **41** °/s ; pic de
couple 252 N·m (86 kg à 300 mm), le même pour R0, R1, R3 (dans les conditions hors plages où le couple est poussé jusqu'à +40 %), 239 N·m pour R2.

### 7.2 La courbe de largeur (tous les axes à la fois, 3 graines par largeur)

| largeur (× la plage large) | 0 (R0) | 0,25 | 0,5 | 1 (R2) | 1,5 | 2 |
|---|---|---|---|---|---|---|
| nominal | 100 % | 100 % | **67 %** (graines 1, 0, 1) | **0 %** | 0 % | 0 % |
| dans les plages | 1,0 % | 1,7 % | 1,3 % | 0 % | 0 % | 0 % |
| coins | 2,3 % | **6,0 %** | **5,3 %** | 0,3 % | 0,7 % | 0 % |

### 7.3 Le curriculum (R3)

Chaque axe partait à 0,25 fois la plage large. La largeur moyenne des 26 axes a **baissé** d'une génération à l'autre, de 0,25 à 0,21-0,22
pour les trois graines : les sondes au bord n'ont jamais atteint 80 % de réussite. Le curriculum ne s'est jamais élargi.

### 7.4 L'ablation (R2 moins un groupe, 3 graines par groupe)

| groupe retiré | nominal | dans les plages | coins |
|---|---|---|---|
| **pente et terrain** | **93 %** (graines 100, 80, 100) | **3,3 %** | **8,7 %** |
| capteurs | 0 % | 1,0 % | 4,0 % |
| frottement au sol | 0 % | 0,7 % | 3,7 % |
| corps, actionneurs, conditions initiales | 0 % | 0,3 % | 0 à 2 % |
| délai de commande, poussées et vent | 0 % | 0 % | 0 à 1 % |

### 7.5 Les films (le meilleur et le pire cas de chaque régime, parmi les conditions jamais vues ; chacun rejoue son épisode à l'identique)

Meilleurs : R0, R1, R3 sur la même condition de coins (n° 235 : 1,58, 1,51, 2,22 m) ; R2 sur la condition n° 222 (0,76 m, sa seule réussite
ou presque). Pires : des chutes en 0,46 à 0,77 s, hors plages (conditions 201 et 208).

### 7.6 Les verdicts (règles fixées à 09:40)

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H135 | au nominal, R0 ne dépasse pas R2 de plus de 10 points (0,60) | 100 % contre 0 % | **réfutée** |
| H136 | dans les plages, R2 et R3 dépassent R0 d'au moins 20 points (0,75) | 0 %, 1 %, contre 1 % | **réfutée** |
| H137 | hors plages, R3 > R2 > R1 > R0 (0,45) | 2 %, 0 %, 0 %, 0 % | **réfutée** |
| H138 | R0 perd le plus du nominal à l'autre solveur (0,60) | R1 et R3 perdent 99 points, R0 99 (98,7), R2 rien (il partait de 0) | **réfutée** |
| H139 | la courbe en cloche, le meilleur entre 0,5 et 1, à 2 fois au moins 10 points sous le meilleur (0,55) | plate au plancher dans les plages (0 à 1,7 %) ; le meilleur à 0,25 | **réfutée** |
| H140 | les trois premiers de l'ablation parmi frottement, poussées et vent, délai, terrain (0,60) | la règle écrite donne « partielle », mais les pertes sont toutes nulles à un point près (R2 est au plancher) : le classement vient de l'ordre des ex æquo, pas d'une mesure | **à revoir** |
| H141 | R2 > R0 sur tous les jeux sauf le nominal (0,55) | 0 contre 1 ; 0 contre 0 ; 0,3 contre 2,3 ; 0 contre 1,3 | **réfutée** |

## 8. Ce que ça dit

1. **Pour cette marche (19 réglages) et ce budget, aucune variance n'apprend à tenir quand toutes les difficultés arrivent ensemble** : de
   0 à 2 % dans les plages larges, comme sans variance. Le jeu « dans les plages » est au plancher pour tous.
2. **La variance large fait abandonner la tâche** : R2 apprend à rester immobile (0 % au nominal, 4 cm d'avance en moyenne, deux fois moins de
   chutes). La courbe de largeur montre où : la marche tient à 0,25 fois la plage large, vacille à 0,5 (une graine sur trois la perd), disparaît
   à partir de 1. R-119 : ce n'est pas la note ; sous la variance empilée, presque aucun candidat ne réussit jamais, il n'y a rien à apprendre.
3. **Le seul gain de la variance, modeste : aux coins** (trois difficultés au bord à la fois, le reste dans les plages), une variance étroite ou
   modérée passe de 2,3 % à 5-6 % (R1, R3, largeurs 0,25 et 0,5), avec des intervalles qui se touchent à peine. Et des commandes plus douces
   (39-41 °/s contre 52), un coût du transport plus bas (4,5-5,0 contre 6,6).
4. **Le curriculum automatique ne s'est jamais élargi** : un quart de toutes les difficultés à la fois, c'est déjà trop pour cette marche.
5. **Le verrou, c'est le terrain** (la pente, le sol irrégulier, le sol mou) : retiré, la variance large redevient apprenable (93 % au
   nominal, 8,7 % aux coins, 3,3 % dans les plages : le meilleur score du banc dans les plages).
6. **Avec les essais du jour** : la variance d'expériences qu'on peut réussir, une difficulté à la fois, donne la meilleure marche (R-116 :
   78 %, mieux que des experts ; R-118) ; mais elle ne se compose pas toute seule en robustesse à tout ensemble (R-120). R-121 (ajouter les
   difficultés une par une) est en cours au moment d'écrire.
7. **Pour l'hypothèse de Yoan** (« la variance des expériences donne l'intelligence de da Vinci ») : ici, la variance aide quand chaque
   expérience reste à portée, et quand on monte en difficulté par étapes ; empilée d'un coup, elle fait renoncer. Da Vinci a appris beaucoup de
   choses, mais chacune à son niveau. **La suite** : une marche plus grande (plus de réglages, ou un petit réseau), le terrain appris à part,
   et le curriculum du nombre (R-121).
