# R-124 — Ce qu'on apprend de chaque exercice : la batterie commune et la matrice de transfert
mots-cles: Navitek, N3, multisport, exercices, disciplines, transfert, batterie, Eurofit, équilibre, poussées, yoga, soccer, danse, athlétisme, patin, MuJoCo

> Ouvert le 12.11.2026 à 21:26 (heure lue), par la session, sur la demande de Yoan du 12.11 à 21:23 : « Commence par faire la liste de tous
> les exercices par discipline et teste comme un chercheur ce qu'on apprend de chaque pour le mouvement, l'équilibre. » La liste :
> `navitek-sim/multisport/CATALOGUE-EXERCICES.md`. Prédictions écrites avant ; verdicts après. Tout est simulé.

## 1. La question

**Qu'est-ce que chaque exercice apprend au corps ?** On le mesure de deux façons, pour chaque exercice faisable du répertoire de R-123 (13
exercices de 7 disciplines : yoga, danse, arts martiaux, athlétisme, échauffements, soccer, patin) :
1. **ce qu'il apporte aux autres** : le socle d'équilibre appris sur cet exercice seul (l'étape 0 de R-123), joué sur chacun des 13
   exercices (10 épisodes chacun). La **ligne** d'un exercice dit ce qu'il apprend au corps ; la **colonne**, d'où vient ce qu'il demande.
2. **une batterie commune** (inspirée des tests d'éducation physique européens, Eurofit) : avec ce même socle, tenir sous une poussée de 0,1 s
   sur le torse, de plus en plus forte (10, 20, 30, 40, 60, 80, 100, 120 N), dans quatre directions (avant, arrière, gauche, droite), **sur une
   jambe** (le flamant, poussée 3 s après le lever) et **sur deux pieds** (debout, poussée à 5 s). La note : la plus forte poussée tenue
   jusqu'au bout de l'épisode, par direction. Sur deux pieds, les deux chevilles reçoivent la même correction et le poids n'est pas transféré.

## 2. Les familles d'exercices (écrites avant)

- **droites sur une jambe** : le flamant, l'arbre, le développé, le coup de pied de côté ;
- **penchées** (le torse incliné, la jambe libre derrière) : l'avion, le danseur, le guerrier, l'arabesque, le patineur ;
- **dynamiques** (la jambe libre bouge tout le temps) : les montées de genou, le balancier, les cercles de hanche, le tir.

## 3. Les prédictions (avec ma crédence)

- **H193 — les droites s'apprennent entre elles** : dans la famille droite, un socle appris sur l'une réussit en moyenne au moins 70 % des
  épisodes des autres de la famille. Crédence 0,55.
- **H194 — les penchées forment une famille** : les socles appris sur les exercices penchés réussissent mieux, en moyenne, les autres
  penchés que les droits. Crédence 0,55.
- **H195 — le mouvement apprend le plus** : la moyenne de la ligne de transfert (sur les 12 autres exercices) est la plus haute pour un
  exercice dynamique. Crédence 0,40.
- **H196 — la batterie ne dit pas tout** : entre les socles, la corrélation entre la note de batterie (la somme des poussées tenues) et la
  moyenne de la ligne de transfert est faible (|r| < 0,5). Crédence 0,45.
- **H197 — le meilleur professeur** : l'exercice dont la ligne de transfert est la plus haute est le flamant, le plus simple. Crédence 0,20.

## 4. Ce qui ne serait pas une preuve

Un socle de 7 réglages appris en 15 générations ; des exercices sur une jambe, debout ; une batterie de poussées seulement ; un robot simulé.

## 5. Résultats (12.11, de 21:28 à 21:31, simulé ; `essai_n3_chaque_exercice.py`, `resultats/n3-chaque-exercice.json`, figure `fig-r124-matrice.png`)

**L'étape 0 de R-123 (chaque exercice appris seul, 15 générations).** Tenus 10 s dans 100 % des épisodes : le flamant, l'arbre, l'avion, le
développé, l'arabesque, les montées de genou, les cercles de hanche, le patineur. Pas appris seuls : le danseur (2,0 s), le guerrier (0,3 s),
le coup de pied de côté (0,7 s), le balancier (0,9 s), le tir (3,9 s). Sans rien appris (le socle de départ) : tout tombe en moins d'une seconde.

**La matrice de transfert** (réussite sur 10 épisodes, en %) : la ligne = le socle appris sur cet exercice ; la colonne = l'exercice joué.

| socle \ joué | flam. | arbre | avion | dans. | guer. | dév. | arab. | côté | gen. | bal. | cerc. | tir | pat. | ligne |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| flamant | 100 | 100 | 100 | · | · | 100 | 100 | · | 100 | · | · | · | · | 42 |
| arbre | 100 | 100 | 100 | · | · | 100 | · | · | 100 | · | · | · | · | 33 |
| **avion** | 100 | 100 | 100 | **100** | · | 100 | 100 | · | 100 | · | **100** | · | · | **58** |
| danseur | 100 | 100 | · | · | · | 100 | · | · | 80 | · | · | · | · | 32 |
| guerrier | · | · | · | · | · | · | · | · | · | · | · | · | · | 0 |
| développé | 100 | · | 100 | · | · | 100 | · | · | 100 | · | · | · | · | 25 |
| arabesque | 100 | 100 | 100 | · | · | 100 | 100 | **100** | 100 | · | · | · | · | 50 |
| pied côté | 100 | 100 | 100 | · | · | 100 | · | · | 100 | · | · | · | · | 42 |
| genoux | 100 | · | · | · | · | 100 | · | · | 100 | · | · | · | · | 17 |
| balancier | 100 | 100 | · | · | · | · | · | · | 100 | · | · | · | · | 25 |
| **cercles** | 100 | 100 | 100 | · | · | 100 | 100 | **100** | 100 | · | 100 | · | · | **58** |
| tir | 100 | 20 | 50 | · | · | 100 | · | · | 100 | · | · | · | · | 31 |
| **patineur** | 100 | 100 | 100 | · | · | 100 | 100 | **100** | 100 | · | · | · | 100 | **58** |
| *colonne* | *92* | *68* | *62* | *8* | *0* | *83* | *33* | *25* | *90* | *0* | *8* | *0* | *0* | |

**La batterie** (la plus forte poussée tenue, en N, de 10 à 120) : **sur une jambe, le côté est la faiblesse de tous** : 30 à 60 N vers la
gauche ou la droite, contre 60 à 120 N vers l'avant ou l'arrière. **Sur deux pieds**, 60 à 120 N pour presque tous ; mais **les socles de
l'avion et des cercles ne tiennent plus debout sur deux pieds** (0 N : ils tombent sans poussée), comme celui du guerrier sur une jambe.

| | prédit (crédence) | mesuré | verdict |
|---|---|---|---|
| H193 | les droites s'apprennent entre elles, au moins 70 % (0,55) | 67 % (le coup de pied de côté, que personne de la famille ne réussit, tire la moyenne) | **réfutée** |
| H194 | les penchés réussissent mieux les penchés que les droits (0,55) | 25 % sur les penchés, 70 % sur les droits : l'inverse | **réfutée** |
| H195 | la meilleure ligne est celle d'un exercice dynamique (0,40) | trois ex æquo à 58 % : l'avion et le patineur (penchés) et les cercles (dynamique) ; la règle, qui prend le premier de la liste, dit l'avion | **partielle** (un dynamique parmi trois ex æquo) |
| H196 | la batterie ne prédit pas le transfert, |r| < 0,5 (0,45) | r = −0,11 | **confirmée** |
| H197 | le meilleur professeur est le flamant (0,20) | 42 % ; les meilleurs : l'avion, les cercles, le patineur (58 %) | **réfutée** |

## 6. Ce qu'on apprend de chaque exercice

1. **Les exercices difficiles apprennent les faciles ; les faciles n'apprennent pas les difficiles.** Le flamant, les montées de genou et
   le développé sont réussis par presque tous les socles (colonnes de 83 à 92 %) ; le patineur seulement par le sien, les cercles par 8 %
   des autres. Un socle appris sur le flamant ne sait rien du patineur ; un socle appris sur le patineur sait le flamant.
2. **Un exercice impossible seul devient possible grâce à un autre.** Le danseur (2 s seul) tient 100 % avec le socle de l'avion ; le coup
   de pied de côté (0,7 s seul) tient 100 % avec ceux de l'arabesque, des cercles et du patineur. C'est l'idée de Yoan (I-016), mesurée sur un
   exemple : ce qu'on n'apprend pas en répétant une seule chose s'apprend ailleurs. Nuance : « seul » veut dire en 15 générations ; avec plus
   d'essais (20 générations de 16), R-073 avait tenu le danseur.
3. **Les meilleurs professeurs viennent de trois disciplines** : l'avion (yoga), les cercles de hanche (échauffement), le patineur (patin).
4. **Être fort sous les poussées n'est pas être polyvalent** (r = −0,11). Et la spécialisation coûte : les socles de l'avion et des cercles,
   excellents ailleurs, ne tiennent plus debout sur deux pieds.
5. **Ce qu'aucun exercice n'apprend** (le guerrier, le balancier, le tir) dépasse ce socle de 7 réglages : il faudra plus (un socle plus
   grand, ou le geste lui-même à apprendre).
6. **La suite** : R-123 (l'enfance multisport contre le spécialiste, puis la spécialisation) tourne.
