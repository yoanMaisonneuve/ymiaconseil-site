"""Essai N3-T2 (simplifié) : accroupi de N1. Couple au genou, à la hanche et à la cheville (en part du couple de blocage) pour un genou de 0 à 90°,
sur deux jambes, puis sur une jambe (l'autre est repliée ; le balancement de la hanche-roulis et de la cheville-roulis de la jambe
d'appui, en opposition, cherche l'équilibre : décalage fixe, pas de 2°, sans retour d'information).
    python -X utf8 essai_n1_t2.py        → resultats/n3-t2-accroupi.json
"""
import json
import os

import mujoco
import numpy as np

import commun as C

m, d = C.charger("n3.xml")
SG = C.signes(os.environ.get("N3_SIGNES", "signes-n3.json"))   # B48 (E26, E29, R-056) : signes étalonnés sur N3 corrigé ; avant : n3-avant-e29.xml et signes-n1-sans-roulis.json
tau = m.actuator_forcerange[0, 1]
idx = {C.court(n): i for i, n in enumerate(C.noms(m))}


def pose_genou(K, s):
    return {"hanche_tangage" + s: -K / 2, "genou" + s: K, "cheville_tangage" + s: -K / 2}


def run(K, une_jambe, roulis=0.0, duree=3.0):
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    pose = pose_genou(K, "_g")
    if une_jambe:
        pose.update({"hanche_tangage_d": 0, "genou_d": 100, "cheville_tangage_d": 0,
                     "hanche_roulis_g": roulis, "cheville_roulis_g": -roulis})
    else:
        pose.update(pose_genou(K, "_d"))
    c = C.consigne(m, pose, SG)
    somme = np.zeros(m.nu)
    pic = np.zeros(m.nu)
    ns, incl = 0, 0.0
    for k in range(int(duree / m.opt.timestep)):
        t = k * m.opt.timestep
        d.ctrl[:] = c * min(1.0, t / 1.0)
        mujoco.mj_step(m, d)
        incl = max(incl, C.inclinaison(d))
        if t > duree - 1.0:
            somme += np.abs(d.actuator_force)
            ns += 1
        if t > 1.0:
            pic = np.maximum(pic, np.abs(d.actuator_force))
    return C.inclinaison(d) < 20 and incl < 35, incl, C.inclinaison(d), somme / ns / tau, pic / tau


def resume(r):
    ok, incl, fin, moy, pic = r
    sel = lambda a: {k: round(float(a[i]), 3) for k, i in idx.items() if k in ("hanche_tangage_g", "genou_g", "cheville_tangage_g", "hanche_roulis_g", "cheville_roulis_g")}
    return {"tient": bool(ok), "inclinaison_max_deg": round(incl, 1), "inclinaison_fin_deg": round(fin, 1),
            "couple_moyen_sur_blocage": sel(moy), "couple_max_sur_blocage": sel(pic)}


res = {"essai": "N3-T2 (simplifié) accroupi", "couple_blocage_Nm": round(float(tau), 4), "deux_jambes": {}, "une_jambe": {}}
for K in (0, 20, 40, 60, 70, 90):
    res["deux_jambes"][str(K)] = resume(run(K, False))
    print("2 jambes, genou", K, res["deux_jambes"][str(K)]["tient"], res["deux_jambes"][str(K)]["couple_max_sur_blocage"]["genou_g"], flush=True)
json.dump(res, open(os.path.join(C.ICI, "resultats", "n3-t2-accroupi.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
