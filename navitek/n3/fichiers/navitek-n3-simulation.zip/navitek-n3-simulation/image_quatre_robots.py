"""Une image des quatre robots de la série Navitek (N0, N1, N2 simplifié, N3 simplifié) côte à côte, à la même échelle (même caméra).
N2 et N3 sont les robots de N1 agrandis (pas des CAO) : l'image le dit en légende sur la page.
    python -X utf8 image_quatre_robots.py        → resultats/quatre-robots.png
"""
import os

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

ICI = os.path.dirname(os.path.abspath(__file__))
cadres = []
for xml, nom, h in (("n0.xml", "N0 · 33 cm", 0.33), ("n1.xml", "N1 · 63,5 cm", 0.635), ("n2.xml", "N2 · 1 m (simplifié)", 1.0), ("n3.xml", "N3 · 1,5 m (simplifié)", 1.5)):
    m = mujoco.MjModel.from_xml_path(os.path.join(ICI, xml))
    d = mujoco.MjData(m)
    mujoco.mj_forward(m, d)
    r = mujoco.Renderer(m, 640, 480)
    cam = mujoco.MjvCamera()
    cam.lookat[:] = [0, 0, 0.7]
    cam.distance, cam.azimuth, cam.elevation = 3.4, 150, 5
    r.update_scene(d, camera=cam)
    im = Image.fromarray(r.render().copy())
    r.close()
    cadres.append(im)
W = Image.new("RGB", (480 * 4, 640))
for i, im in enumerate(cadres):
    W.paste(im, (i * 480, 0))
W = W.resize((1600, 533))
W.save(os.path.join(ICI, "resultats", "quatre-robots.png"))
print("ok")
