"""Essai T1 du Navitek N1 dans MuJoCo : debout, toutes les articulations au neutre, 5 s. Mesure : la hauteur du torse, son
inclinaison, le couple de chaque servo rapporté à son couple de blocage. Écrit resultats/n3-t1-debout.json et une image.
    python -X utf8 essai_debout.py
"""
import json
import os

import mujoco
import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
m = mujoco.MjModel.from_xml_path(os.path.join(ICI, "n3.xml"))
d = mujoco.MjData(m)
mujoco.mj_forward(m, d)
tau = m.actuator_forcerange[0, 1]
z0 = d.qpos[2]
pire = np.zeros(m.nu)
inclinaisons = []
for k in range(int(5.0 / m.opt.timestep)):
    d.ctrl[:] = 0
    mujoco.mj_step(m, d)
    if k * m.opt.timestep > 0.5:                           # après la mise en place
        pire = np.maximum(pire, np.abs(d.actuator_force))
    q = d.qpos[3:7]
    up = np.array([2 * (q[1] * q[3] + q[0] * q[2]), 2 * (q[2] * q[3] - q[0] * q[1]), 1 - 2 * (q[1] ** 2 + q[2] ** 2)])
    inclinaisons.append(np.degrees(np.arccos(np.clip(up[2], -1, 1))))
res = {
    "essai": "N3 simplifié T1 debout, 5 s, tout au neutre",
    "masse_totale_g": round(float(sum(m.body_mass)) * 1000, 1),
    "hauteur_torse_debut_m": round(float(z0), 4), "hauteur_torse_fin_m": round(float(d.qpos[2]), 4),
    "inclinaison_max_deg": round(float(max(inclinaisons)), 2), "tombe": bool(max(inclinaisons) > 30),
    "couple_max_par_servo_sur_blocage": {mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_ACTUATOR, i): round(float(pire[i] / tau), 3) for i in range(m.nu)},
}
json.dump(res, open(os.path.join(ICI, "resultats", "n3-t1-debout.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(json.dumps(res, ensure_ascii=False, indent=1))
try:
    r = mujoco.Renderer(m, 720, 540)
    cam = mujoco.MjvCamera()
    cam.lookat[:] = [0, 0, 0.75]
    cam.distance, cam.azimuth, cam.elevation = 3.4, 150, -10
    r.update_scene(d, camera=cam)
    import imageio.v3 as iio
    iio.imwrite(os.path.join(ICI, "resultats", "n3-t1-debout.png"), r.render())
    print("image : resultats/n3-t1-debout.png")
except Exception as e:
    print("rendu impossible :", e)
