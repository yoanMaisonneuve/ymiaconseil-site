"""B44 / R-050 § 6 : les marches de N2 se heurtent-elles ? Comme essai_n1_contacts_marche.py (R-048 § 5, E17) : chaque marche est rejouée telle quelle sur
son modèle (la boucle de essai_n2_marche.py, contacts entre pièces coupés comme dans le réglage), et toutes les 50 ms la pose est passée à FCL :
on compte les paires de géométries de corps différents qui se touchent, hors celles déjà en contact au neutre (les pièces vissées ensemble).
Les géométries : les maillages, et les cylindres et boîtes du modèle (les actionneurs de N2 sont des cylindres), à leurs dimensions MuJoCo.
Deux comptes (raffinés après un premier passage, R-050 § 6) : une paire ne compte que si elle pénètre de PROFONDEUR mm au moins (les platines d'un même
membre sont posées à fleur et se touchent au moindre fléchissement) ; et l'on sépare les contacts ENTRE MEMBRES (une jambe contre l'autre, une main
contre une jambe : la question d'E17) des contacts à l'intérieur d'un même membre.

    N2_XML=n2cao.xml N2_SIGNES=signes-n2cao.json python -X utf8 essai_n2_contacts_marche.py n2cao        → resultats/n2-contacts-marche-n2cao.json
    N2_XML=n2.xml N2_SIGNES=signes-n1-sans-roulis.json python -X utf8 essai_n2_contacts_marche.py n2-marche          → resultats/n2-contacts-marche-n2-marche.json
L'argument est le début du nom des marches (resultats/<argument>*-g<N>.json).
"""
import glob
import json
import os
import re
import sys

import mujoco
import numpy as np
import trimesh
from trimesh.collision import CollisionManager

import commun as C
import essai_n2_marche as em

PROFONDEUR = 1.0                                          # mm
MEMBRES = ("jambe-gauche", "jambe-droite", "bras-gauche", "bras-droit")


def membre(nom):
    return next((x for x in MEMBRES if nom.startswith(x)), "tronc")


def gestionnaire(m):
    mgr, noms, corps = CollisionManager(), {}, {}
    for g in range(m.ngeom):
        t = m.geom_type[g]
        nom = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, g) or f"geom{g}"
        if t == mujoco.mjtGeom.mjGEOM_MESH:
            mid = m.geom_dataid[g]
            v0, nv, f0, nf = m.mesh_vertadr[mid], m.mesh_vertnum[mid], m.mesh_faceadr[mid], m.mesh_facenum[mid]
            forme = trimesh.Trimesh(vertices=m.mesh_vert[v0:v0 + nv].copy(), faces=m.mesh_face[f0:f0 + nf].copy(), process=False)
        elif t == mujoco.mjtGeom.mjGEOM_CYLINDER:
            r, demi = m.geom_size[g][0], m.geom_size[g][1]
            forme = trimesh.creation.cylinder(radius=r, height=2 * demi, sections=24)
        elif t == mujoco.mjtGeom.mjGEOM_BOX:
            forme = trimesh.creation.box(extents=2 * m.geom_size[g][:3])
        else:
            continue                                      # le sol (plan) et les autres formes
        mgr.add_object(nom, forme)
        noms[nom], corps[nom] = g, m.geom_bodyid[g]
    return mgr, noms, corps


def paires(m, d, mgr, noms, corps):
    for nom, g in noms.items():
        T = np.eye(4)
        T[:3, :3] = d.geom_xmat[g].reshape(3, 3)
        T[:3, 3] = d.geom_xpos[g]
        mgr.set_transform(nom, T)
    _, ps, donnees = mgr.in_collision_internal(return_names=True, return_data=True)
    prof = {}
    for c in donnees:
        a, b = sorted(c.names)
        if corps[a] != corps[b]:
            prof[(a, b)] = max(prof.get((a, b), 0.0), float(c.depth) * 1000)
    return {q for q, p in prof.items() if p >= PROFONDEUR}


def main():
    prefixe = sys.argv[1] if len(sys.argv) > 1 else "n2cao"
    fichiers = sorted(f for f in glob.glob(os.path.join(C.ICI, "resultats", prefixe + "*-g[0-9].json")))
    em.init()
    m, d = em._m, em._d
    mgr, noms, corps = gestionnaire(m)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    neutre = paires(m, d, mgr, noms, corps)
    f0 = m.actuator_forcerange.copy()
    sortie = []
    for chemin in fichiers:
        f = os.path.basename(chemin)
        r = json.load(open(chemin, encoding="utf-8"))
        p = np.array(r["parametres_liste"])
        em.SANS_RETOUR = "aveugle" in f
        cap = re.search(r"(?:plafond|cap)(\d+)-", f)
        m.actuator_forcerange[:] = [-float(cap.group(1)), float(cap.group(1))] if cap else f0
        mujoco.mj_resetData(m, d)
        mujoco.mj_forward(m, d)
        n, pas_pose, cadre = int(em.DUREE / m.opt.timestep), int(0.01 / m.opt.timestep), int(0.05 / m.opt.timestep)
        x0 = float(d.subtree_com[1][0])
        c = np.zeros(m.nu)
        vus, instants, instants_entre = {}, 0, 0
        for k in range(n):
            t = k * m.opt.timestep
            if k % pas_pose == 0:
                c = C.consigne(m, em.pose_marche(p, t, em.attitude(d)), em._sg)
            d.ctrl[:] = c
            mujoco.mj_step(m, d)
            if C.inclinaison(d) > 40:
                break
            if k % cadre == 0:
                nouveau = paires(m, d, mgr, noms, corps) - neutre
                if nouveau:
                    instants += 1
                if any(membre(a) != membre(b) for a, b in nouveau):
                    instants_entre += 1
                for q in nouveau:
                    vus[" ~ ".join(q)] = vus.get(" ~ ".join(q), 0) + 1
        tot = int(n / cadre)
        entre = {k: v for k, v in vus.items() if membre(k.split(" ~ ")[0]) != membre(k.split(" ~ ")[1])}
        sortie.append({"marche": f, "avance_publiee_m": r.get("avance_m"), "avance_rejeu_m": round(float(d.subtree_com[1][0]) - x0, 4),
                       "instants_entre_membres": instants_entre, "instants_en_contact": instants, "sur": tot,
                       "paires_entre_membres": dict(sorted(entre.items(), key=lambda x: -x[1])), "paires": dict(sorted(vus.items(), key=lambda x: -x[1]))})
        print(f"{f:<64} entre membres {instants_entre:3d} / tous {instants:3d} sur {tot} ; {list(sortie[-1]['paires_entre_membres'].items())[:2]}", flush=True)
    json.dump({"essai": "B44 / R-050 § 6 : contacts entre pièces pendant les marches de N2", "modele": os.environ.get("N2_XML", "n2.xml"),
               "profondeur_min_mm": PROFONDEUR, "paires_au_neutre": len(neutre), "marches": sortie},
              open(os.path.join(C.ICI, "resultats", f"n2-contacts-marche-{prefixe}.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
