"""Le modèle SIMPLIFIÉ de Navitek N2 : la géométrie de N1 mise à l'échelle (hauteur 1 m), pour tirer le couple demandé à chaque articulation.
Ce n'est PAS la CAO de N2 (qui n'existe pas encore) : c'est le robot de N1 agrandi, avec des masses de N2 estimées (voir HYPOTHESES).
Le modèle de N1 (navitek-sim/modele_n1.py) est la base ; tout ce qui diffère est ci-dessous.


- La géométrie et les placements : navitek-n0/web/assemblage.json et les STL du même dossier (écrits par cao/n0.py).
- L'arbre des articulations : déduit des noms des pièces. Chaque « palonnier » ouvre un nouveau corps, articulé sur l'axe de
  l'arbre de son servo (l'axe z du repère de son boîtier, passant par son origine).
- Les masses : les grammes du tranchage (navitek-n1/tranchage/tranchage.json) s'il existe, sinon le volume de la pièce × 1,0 g/cm³
  (rapport médian grammes/volume mesuré sur les 12 pièces de N0, de 0,63 à 1,34) ; les servos à 55 g (fiche STS3215) ; et un bloc
  de 330 g au milieu du torse (pile 3S 141 g, protection, Pico, Pi Zero 2 W, centrale, fils, vis : estimation).
- Les servos : un actionneur de position par articulation, borné au couple de blocage annoncé de la version 12 V (30 kg·cm = 2,94 N·m).

Les hypothèses du modèle (inertie du moteur ramenée à la sortie, amortissement, frottement des pieds) sont dans HYPOTHESES
ci-dessous : ce sont elles que le banc à la webcam devra mesurer.

    python -X utf8 modele_n1.py        → n1.xml (à côté)
"""
import io
import json
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
N0 = os.path.join(ICI, "..", "navitek-n1")
ECH = 1.0 / 0.6349                       # N1 mesure 63,5 cm ; N2 vise 1 m

HYPOTHESES = {
    "couple_blocage_Nm": 200.0,              # volontairement énorme : on MESURE la demande, on ne la borne pas
    "kp": 800.0,                             # N·m/rad
    "kv": 25.0,                              # N·m·s/rad
    "armature": 0.05,                        # kg·m², inertie du moteur ramenée à la sortie (estimation)
    "amortissement": 0.5,                    # N·m·s/rad (estimation)
    "frottement_sol": 0.6,
    "masse_electronique_g": 1500,            # pile 6S environ 800 g + variateurs + Pi 5 + centrale + fils : ESTIMATION
}
MASSE_ACTIONNEUR_G = 550.0                   # moteur sans balais + réducteur imprimé + variateur, par articulation : ESTIMATION (R-039 : aucune fiche)
MASSE_PALONNIER = 0.0
G_PAR_CM3 = 1.0
BORNES = {"hanche-roulis": (-30, 30), "hanche-tangage": (-90, 90), "genou": (-10, 120), "cheville-tangage": (-60, 60),
          "cheville-roulis": (-30, 30), "epaule-tangage": (-90, 90), "epaule-roulis": (-90, 90), "coude": (-10, 120), "cou": (-80, 80)}


def quat(R):
    """Quaternion (w, x, y, z) d'une matrice de rotation."""
    w = np.sqrt(max(0.0, 1 + R[0, 0] + R[1, 1] + R[2, 2])) / 2
    x = np.sqrt(max(0.0, 1 + R[0, 0] - R[1, 1] - R[2, 2])) / 2
    y = np.sqrt(max(0.0, 1 - R[0, 0] + R[1, 1] - R[2, 2])) / 2
    z = np.sqrt(max(0.0, 1 - R[0, 0] - R[1, 1] + R[2, 2])) / 2
    x = np.copysign(x, R[2, 1] - R[1, 2])
    y = np.copysign(y, R[0, 2] - R[2, 0])
    z = np.copysign(z, R[1, 0] - R[0, 1])
    q = np.array([w, x, y, z])
    return q / np.linalg.norm(q)


def matrice(inst):
    M = np.array(inst["matrice"], dtype=float).reshape(4, 4)
    M[:3, 3] /= 1000.0                       # mm → m
    return M


def pose(M):
    p, q = M[:3, 3], quat(M[:3, :3])
    p = p * ECH
    return f'pos="{p[0]:.6f} {p[1]:.6f} {p[2]:.6f}" quat="{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}"'


asm = json.load(io.open(os.path.join(N0, "web", "assemblage.json"), encoding="utf-8"))
GRAMMES = {p["piece"]: p["volume_cm3"] * G_PAR_CM3 for p in asm["pieces"]}
_tr = os.path.join(N0, "tranchage", "tranchage.json")
if os.path.exists(_tr):
    GRAMMES.update({p["piece"]: p["grammes"] for p in json.load(io.open(_tr, encoding="utf-8"))["pieces"]})


def masse(inst):
    p, g = inst["piece"], inst["groupe"]
    if p == "servo-sts3215":
        return MASSE_ACTIONNEUR_G
    if p == "palonnier":
        return MASSE_PALONNIER
    return GRAMMES[p] * ECH ** 3


# le bas du torse (m) : le torse est posé à z = -z_sol dans l'assemblage
ZT = next(i for i in asm["instances"] if i["nom"] == "torse")["matrice"][11] / 1000 * ECH + 0.191 * ECH

# --- l'arbre : chaque palonnier ouvre un corps ; les autres pièces vont au corps courant de leur groupe ---------------------
corps = {"torse": {"parent": None, "M": np.eye(4), "geoms": [], "articulation": None}}
courant = {}                                  # groupe → corps courant
for inst in asm["instances"]:
    g = inst["groupe"]
    cour = courant.get(g, "torse")
    if inst["piece"] == "palonnier":
        art = inst["nom"].rsplit("-palonnier", 1)[0]                     # ex. jambe-gauche-genou, cou
        corps[art] = {"parent": cour, "M": matrice(inst), "geoms": [], "articulation": art}
        courant[g] = cour = art
    corps[cour]["geoms"].append(inst)

xml = []
a = xml.append
a('<mujoco model="navitek-n2-simplifie">')
a('  <compiler angle="radian" meshdir="../navitek-n1/web" autolimits="true"/>')
a('  <option timestep="0.0005" integrator="implicitfast"/>')
a(f'  <default><joint armature="{HYPOTHESES["armature"]}" damping="{HYPOTHESES["amortissement"]}"/>'
  f'<geom friction="{HYPOTHESES["frottement_sol"]} 0.01 0.001" condim="3"/></default>')
a('  <visual><global offwidth="1280" offheight="960"/><quality shadowsize="4096"/></visual>')
a('  <asset>')
for p in sorted({i["piece"] for i in asm["instances"]}):
    a(f'    <mesh name="{p}" file="{p}.stl" scale="{0.001 * ECH:.6f} {0.001 * ECH:.6f} {0.001 * ECH:.6f}"/>')
a('    <texture name="damier" type="2d" builtin="checker" rgb1="0.93 0.92 0.89" rgb2="0.86 0.85 0.82" width="512" height="512"/>')
a('    <material name="sol" texture="damier" texrepeat="12 12"/>')
a('  </asset>')
a('  <worldbody>')
a('    <light pos="0.4 -0.4 1.2" dir="-0.3 0.3 -1" diffuse="0.9 0.9 0.9" castshadow="true"/>')
a('    <geom name="sol" type="plane" size="2 2 0.01" material="sol"/>')


def hexrgba(h):
    h = h.lstrip("#")
    return " ".join(f"{int(h[i:i + 2], 16) / 255:.3f}" for i in (0, 2, 4)) + " 1"


def ecrire_corps(nom, indent):
    c = corps[nom]
    Mp = corps[c["parent"]]["M"] if c["parent"] else np.eye(4)
    rel = np.linalg.inv(Mp) @ c["M"]
    sp = " " * indent
    a(f'{sp}<body name="{nom}" {pose(rel)}>')
    if c["parent"] is None:
        a(f'{sp}  <freejoint name="libre"/>')
    else:
        cle = next(k for k in BORNES if nom.endswith(k))
        lo, hi = BORNES[cle]
        a(f'{sp}  <joint name="{nom}" type="hinge" axis="0 0 1" range="{np.radians(lo):.4f} {np.radians(hi):.4f}"/>')
    for inst in c["geoms"]:
        rel_g = np.linalg.inv(c["M"]) @ matrice(inst)
        a(f'{sp}  <geom name="{inst["nom"]}" type="mesh" mesh="{inst["piece"]}" {pose(rel_g)} mass="{masse(inst) / 1000:.5f}" '
          f'rgba="{hexrgba(inst["couleur"])}"/>')
    if c["parent"] is None:   # le bloc des piles, du Pico, des fils et des vis, dans le bas du torse (sans contact)
        a(f'{sp}  <geom name="electronique" type="box" size="{0.025 * ECH:.4f} {0.04 * ECH:.4f} {0.035 * ECH:.4f}" pos="{-0.008 * ECH:.4f} 0 {ZT + 0.060 * ECH:.4f}" '
          f'mass="{HYPOTHESES["masse_electronique_g"] / 1000}" contype="0" conaffinity="0" rgba="0.2 0.2 0.2 0.0"/>')
        a(f'{sp}  <site name="imu" pos="0 0 {ZT + 0.100 * ECH:.4f}"/>')
    for enfant in [k for k, v in corps.items() if v["parent"] == nom]:
        ecrire_corps(enfant, indent + 2)
    a(f'{sp}</body>')


ecrire_corps("torse", 4)
a('  </worldbody>')
a('  <actuator>')
tau = HYPOTHESES["couple_blocage_Nm"]
articulations = [k for k, v in corps.items() if v["articulation"]]
for art in articulations:
    a(f'    <position name="{art}" joint="{art}" kp="{HYPOTHESES["kp"]}" kv="{HYPOTHESES["kv"]}" forcerange="{-tau:.4f} {tau:.4f}"/>')
a('  </actuator>')
a('  <sensor>')
a('    <framequat name="orientation" objtype="site" objname="imu"/>')
a('    <subtreecom name="centre_de_masse" body="torse"/>')
a('  </sensor>')
a('</mujoco>')
io.open(os.path.join(ICI, "n2.xml"), "w", encoding="utf-8").write("\n".join(xml))
masse_totale = sum(masse(i) for i in asm["instances"]) + HYPOTHESES["masse_electronique_g"]
print(f"n2.xml : {len(corps)} corps, {len(articulations)} articulations, masse {masse_totale:.0f} g")
print("articulations :", ", ".join(articulations))
