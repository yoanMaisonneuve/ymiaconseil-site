"""Essai B30 bis (cahier R-044 § 3 bis) : le même balancement latéral imposé aux deux modèles de N2 (n2.xml, le N1 agrandi ; n2cao.xml, la CAO),
sans pas, pour séparer l'effet du robot de celui de la marche choisie par l'optimiseur.

Loi de commande de essai_n2_marche.py : genou droit (N2_GENOU, 0° par défaut ; le 1er passage à 10° tombait sans balancer), amplitudes de hanche, genou et cheville en tangage à 0, gains de retour à 0 ;
seul le balancement, roulis_g = roulis_d = A (A = 0, 2, 4, 6, 8°), période 1,5 s, 12 s, sans plafond. Relève aussi la géométrie debout.

    python -X utf8 essai_n2_balancement.py        → resultats/n2-balancement.json
"""
import json
import multiprocessing as mp
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
MODELES = {"n1_agrandi": ("n2.xml", "signes-n2.json"), "cao": ("n2cao.xml", "signes-n2cao.json")}
HR = "jambe-gauche-hanche-roulis"
AMPLITUDES = (0, 2, 4, 6, 8)


GENOU = float(os.environ.get("N2_GENOU", "0"))   # 1er passage à 10° : les deux robots tombent même sans balancer (genou non compensé) → 0°


def parametres(A):
    # periode, hanche_amp, hanche_decal, genou_base, genou_amp, genou_phase, chev_amp, chev_phase, roulis_g, roulis_d, roulis_phase, 4 gains
    return [1.5, 0, 0, GENOU, 0, 0, 0, 0, A, A, 0, 0, 0, 0, 0]


def charger(modele):
    xml, sg = MODELES[modele]
    os.environ["N2_XML"], os.environ["N2_SIGNES"] = xml, sg
    import essai_n2_marche as em
    em.CAP = 0.0
    em.init()
    return em


def geometrie(modele):
    import mujoco
    em = charger(modele)
    m, d = em._m, em._d
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    j = {c: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, f"jambe-{c}-hanche-roulis") for c in ("gauche", "droite")}
    p = {c: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, f"jambe-{c}-pied") for c in ("gauche", "droite")}
    jambe = sum(float(m.body_subtreemass[m.jnt_bodyid[j[c]]]) for c in j)
    total = float(m.body_subtreemass[1])
    return {"ecart_hanches_roulis_mm": round(abs(d.xanchor[j["gauche"]][1] - d.xanchor[j["droite"]][1]) * 1000, 1),
            "hauteur_hanche_roulis_mm": round(float(d.xanchor[j["gauche"]][2]) * 1000, 1),
            "ecart_pieds_mm": round(abs(d.geom_xpos[p["gauche"]][1] - d.geom_xpos[p["droite"]][1]) * 1000, 1),
            "hauteur_centre_de_masse_mm": round(float(d.subtree_com[1][2]) * 1000, 1),
            "masse_totale_kg": round(total, 2), "masse_au_dessus_des_hanches_kg": round(total - jambe, 2)}


def tache(args):
    modele, A = args
    em = charger(modele)
    res = em.evaluer(np.array(parametres(A), dtype=float), trace=True)
    return {"modele": modele, "A_deg": A, "tombe": res["tombe"], "temps_tenu_s": res["temps_tenu_s"],
            "hr_moyen": res["couple_moyen_abs_Nm"][HR], "hr_pic": res["couple_max_Nm"][HR],
            "cheville_roulis_moyen": res["couple_moyen_abs_Nm"]["jambe-gauche-cheville-roulis"],
            "deviation_laterale_m": res["deviation_laterale_m"]}


def main():
    geo = {mo: geometrie(mo) for mo in MODELES}
    taches = [(mo, A) for mo in MODELES for A in AMPLITUDES]
    with mp.Pool(10) as pool:
        sorties = pool.map(tache, taches, chunksize=1)
    rapports = {}
    for A in AMPLITUDES:
        a, c = [s for s in sorties if s["A_deg"] == A and s["modele"] == "n1_agrandi"][0], [s for s in sorties if s["A_deg"] == A and s["modele"] == "cao"][0]
        if not a["tombe"] and not c["tombe"] and c["hr_moyen"] > 0:
            rapports[A] = round(a["hr_moyen"] / c["hr_moyen"], 2)
    sortie = {"essai": "B30 bis / R-044 § 3 bis : le même balancement sur les deux modèles de N2", "geometrie": geo, "balancements": sorties,
              "rapport_hr_moyen_n1_agrandi_sur_cao": rapports}
    json.dump(sortie, open(os.path.join(ICI, "resultats", "n2-balancement.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for mo, g in geo.items():
        print(mo, g)
    for s in sorties:
        print(f"{s['modele']:>11} A={s['A_deg']}°  {'tombe à ' + str(s['temps_tenu_s']) + ' s' if s['tombe'] else 'debout':<14} HR moyen {s['hr_moyen']:5.1f}  pic {s['hr_pic']:6.1f}  cheville-roulis {s['cheville_roulis_moyen']:5.1f}")
    print("rapport N1 agrandi / CAO :", rapports)


if __name__ == "__main__":
    main()
