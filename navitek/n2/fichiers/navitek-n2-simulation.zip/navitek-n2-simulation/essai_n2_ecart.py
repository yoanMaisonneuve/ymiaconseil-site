"""Essai B30 (cahier R-044) : d'où vient l'écart de la hanche-roulis de N2 entre le robot de N1 agrandi (n2.xml, R-040) et le robot
tiré de la CAO (n2cao.xml, R-043), et pourquoi une marche réglée sur un seul modèle est fragile.

1. Rejeu croisé : chaque marche de R-040 rejouée sur la CAO, chaque marche de R-043 rejouée sur le N1 agrandi (et chacune sur son propre
   modèle, pour vérifier que le rejeu redonne les chiffres publiés). Même loi de commande (essai_n2_marche.py, 15 paramètres), même plafond.
2. Corrélation de rang (Spearman) entre l'amplitude du balancement commandé (|roulis_g| + |roulis_d|) et le couple moyen de hanche-roulis.
3. Sensibilité : 20 modèles de la CAO dont chaque masse et chaque inertie de corps est multipliée par un facteur tiré entre 0,98 et 1,02
   (graines 0 à 19), pour la marche réglée sur le nominal (plafond 18, g1) et pour la marche robuste (plafond 18, g2).

    python -X utf8 essai_n2_ecart.py        → resultats/n2-ecart.json
"""
import json
import multiprocessing as mp
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")
MODELES = {"n1_agrandi": ("n2.xml", "signes-n2.json"), "cao": ("n2cao.xml", "signes-n2cao.json")}
HR = "jambe-gauche-hanche-roulis"


def lire(f):
    return json.load(open(os.path.join(RES, f), encoding="utf-8"))


def tache(args):
    """args = (modèle, plafond, paramètres, graine de perturbation ou None) → le résultat de evaluer()."""
    modele, cap, p, graine = args
    xml, sg = MODELES[modele]
    os.environ["N2_XML"], os.environ["N2_SIGNES"] = xml, sg
    import essai_n2_marche as em
    em.CAP = cap
    em.init()
    if graine is not None:
        r = np.random.default_rng(graine)
        nb = em._m.nbody
        fm, fi = r.uniform(0.98, 1.02, nb), r.uniform(0.98, 1.02, nb)
        fm[0] = fi[0] = 1.0
        em._m.body_mass[:] *= fm
        em._m.body_inertia[:] *= fi[:, None]
    res = em.evaluer(np.array(p), trace=True)
    return {"avance_m": res["avance_m"], "tombe": res["tombe"], "temps_tenu_s": res["temps_tenu_s"],
            "hr_moyen": res["couple_moyen_abs_Nm"][HR], "hr_pic": res["couple_max_Nm"][HR],
            "max_jambe_moyen": max(v for k, v in res["couple_moyen_abs_Nm"].items() if k.startswith("jambe"))}


def rangs(x):
    o = np.argsort(x)
    r = np.empty(len(x))
    r[o] = np.arange(len(x))
    return r


def spearman(a, b):
    ra, rb = rangs(np.array(a)), rangs(np.array(b))
    return float(np.corrcoef(ra, rb)[0, 1])


def main():
    series = {"n1_agrandi": [(f"n2-marche{s}-g{g}.json", c) for s, c in (("", 0.0), ("-plafond55", 55.0), ("-plafond18", 18.0)) for g in (1, 2, 3)],
              "cao": [(f"n2cao-marche{s}-g{g}.json", c) for s, c in (("", 0.0), ("-plafond55", 55.0), ("-plafond18", 18.0)) for g in (1, 2, 3)]}
    taches, etiquettes = [], []
    for origine, lst in series.items():
        for f, cap in lst:
            r = lire(f)
            for cible in MODELES:
                taches.append((cible, cap, r["parametres_liste"], None))
                etiquettes.append(("croise", f, origine, cible, cap, r))
    for f in ("n2cao-marche-plafond18-g1.json", "n2cao-marche-robuste-cap18-g2.json"):
        r = lire(f)
        for g in range(20):
            taches.append(("cao", 18.0, r["parametres_liste"], g))
            etiquettes.append(("sensibilite", f, "cao", "cao", 18.0, None))
    print(len(taches), "simulations de 12 s", flush=True)
    with mp.Pool(14) as pool:
        sorties = pool.map(tache, taches, chunksize=1)

    croise, sens = [], {}
    for (genre, f, origine, cible, cap, r), s in zip(etiquettes, sorties):
        if genre == "croise":
            ligne = {"marche": f, "reglee_sur": origine, "rejouee_sur": cible, "plafond_Nm": cap or None,
                     "roulis_commande_deg": round(abs(r["parametres"]["roulis_g"]) + abs(r["parametres"]["roulis_d"]), 2), **s}
            if origine == cible:
                ligne["publie_avance_m"], ligne["publie_hr_moyen"] = r["avance_m"], r["couple_moyen_abs_Nm"][HR]
            croise.append(ligne)
        else:
            sens.setdefault(f, []).append(s)

    propres = [c for c in croise if c["reglee_sur"] == c["rejouee_sur"]]
    rho = spearman([c["roulis_commande_deg"] for c in propres], [c["hr_moyen"] for c in propres])
    bilan_sens = {}
    for f, l in sens.items():
        av = np.array([s["avance_m"] for s in l])
        bilan_sens[f] = {"avance_moyenne_m": round(float(av.mean()), 4), "ecart_type_m": round(float(av.std()), 4),
                         "cv": round(float(av.std() / abs(av.mean())), 3) if av.mean() else None,
                         "min_m": round(float(av.min()), 4), "max_m": round(float(av.max()), 4), "chutes": int(sum(s["tombe"] for s in l)), "detail": l}
    sortie = {"essai": "B30 / R-044 : rejeu croisé N1 agrandi / CAO, corrélation, sensibilité à ±2 %", "rejeu_croise": croise,
              "spearman_roulis_commande_vs_hr_moyen": round(rho, 3), "sensibilite_masses_inerties_2pc": bilan_sens}
    json.dump(sortie, open(os.path.join(RES, "n2-ecart.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    print(f"\n{'marche':<34}{'réglée':>11}{'rejouée':>11}{'roulis°':>8}{'avance':>8}{'chute':>7}{'HR moy':>8}{'HR pic':>8}{'publié':>14}")
    for c in croise:
        pub = f"{c.get('publie_avance_m', '')}/{c.get('publie_hr_moyen', '')}" if "publie_avance_m" in c else ""
        print(f"{c['marche']:<34}{c['reglee_sur']:>11}{c['rejouee_sur']:>11}{c['roulis_commande_deg']:>8.1f}{c['avance_m']:>8.2f}"
              f"{(str(c['temps_tenu_s']) if c['tombe'] else '-'):>7}{c['hr_moyen']:>8.1f}{c['hr_pic']:>8.1f}{pub:>14}")
    print("Spearman (roulis commandé, HR moyen) sur les 18 marches d'origine :", round(rho, 3))
    for f, b in bilan_sens.items():
        print(f, {k: v for k, v in b.items() if k != "detail"})


if __name__ == "__main__":
    main()
