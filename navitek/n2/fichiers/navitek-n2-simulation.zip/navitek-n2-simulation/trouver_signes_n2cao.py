"""Trouve le signe de charnière de chaque articulation de jambe (hanche, genou, cheville-tangage, par côté) : celui pour lequel
l'accroupi de main.py (35°) garde le torse droit et abaisse le centre de masse. Écrit resultats/signes-n2cao.json.
    python -X utf8 trouver_signes.py
"""
import itertools
import json
import os

import mujoco
import numpy as np

import commun as C

m, d = C.charger("n2cao.xml")
cles = ["hanche_tangage", "genou", "cheville_tangage"]
tous = {}


def accroupi(f=1.0):
    a = 30 * f
    return {"hanche_tangage_g": -a, "genou_g": 2 * a, "cheville_tangage_g": -a, "hanche_tangage_d": -a, "genou_d": 2 * a, "cheville_tangage_d": -a}


def essai(sg, f=1.0, duree=2.0):
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    z0 = float(d.subtree_com[1][2])
    c = C.consigne(m, accroupi(f), sg)
    pire = 0.0
    for k in range(int(duree / m.opt.timestep)):
        d.ctrl[:] = c * min(1.0, k * m.opt.timestep / 1.0)
        mujoco.mj_step(m, d)
        pire = max(pire, C.inclinaison(d))
    return pire, z0 - float(d.subtree_com[1][2])


meilleur = None
for sg_g in itertools.product((1, -1), repeat=3):
    for sg_d in itertools.product((1, -1), repeat=3):
        sg = dict(tous)
        for c, s in zip(cles, sg_g):
            sg[c + "_g"] = s
        for c, s in zip(cles, sg_d):
            sg[c + "_d"] = s
        incl, baisse = essai(sg)
        note = incl - 100 * baisse                       # torse droit et centre de masse plus bas
        if incl < 25 and (meilleur is None or note < meilleur[0]):
            meilleur = (note, incl, baisse, sg)
        print(sg_g, sg_d, f"inclinaison max {incl:5.1f}°, centre de masse abaissé de {baisse * 100:5.1f} cm")
print("MEILLEUR :", meilleur)

# Les roulis (09.11, réveil 6, R-054 ; la leçon d'ERREURS E26, comme trouver_signes_n1.py). La CAO de N2 version 2 retourne l'actionneur de la
# cheville-roulis (axe −x, son moteur devant) : la loi « cheville = −hanche » de la marche coucherait les pieds sur la tranche. On cherche le signe de
# chaque cheville-roulis pour lequel le balancement (hanches à r, chevilles à −r) garde le torse droit et les pieds à plat, pour r = +10° et −10°.
pieds = {c: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, f"jambe-{c}-pied") for c in ("gauche", "droite")}


def balancement(sg, r, duree=1.5):
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    c = C.consigne(m, {"hanche_roulis_g": r, "hanche_roulis_d": r, "cheville_roulis_g": -r, "cheville_roulis_d": -r}, sg)
    for k in range(int(duree / m.opt.timestep)):
        d.ctrl[:] = c * min(1.0, k * m.opt.timestep / 1.0)
        mujoco.mj_step(m, d)
    return C.inclinaison(d), max(float(d.geom_xpos[g][2]) for g in pieds.values()), float(d.subtree_com[1][1])


roulis = None
for sg_cg, sg_cd in itertools.product((1, -1), repeat=2):
    sg = dict(meilleur[3], cheville_roulis_g=sg_cg, cheville_roulis_d=sg_cd)
    mesures = [balancement(sg, r) for r in (10.0, -10.0)]
    note = sum(incl + 1000 * z for incl, z, _ in mesures)          # torse droit, pieds au plus bas (à plat)
    print(f"chevilles-roulis g {sg_cg:+d} d {sg_cd:+d} :", "; ".join(f"inclinaison {i:4.1f}°, pied le plus haut {z * 1000:4.1f} mm" for i, z, _ in mesures))
    if roulis is None or note < roulis[0]:
        roulis = (note, sg)
print("ROULIS :", {k: v for k, v in roulis[1].items() if "roulis" in k})
os.makedirs(os.path.join(C.ICI, "resultats"), exist_ok=True)
json.dump(roulis[1], open(os.path.join(C.ICI, "resultats", "signes-n2cao.json"), "w", encoding="utf-8"), indent=1)
