"""Essai B51 (cahier R-058) : N2 (la CAO version 2, n2cao.xml) encaisse-t-il une poussée ? Une force horizontale constante sur le torse pendant 0,1 s,
de 0 à 400 N par pas de 10 N, vers l'avant, l'arrière, la gauche et la droite. Chute : le torse incliné de plus de 40° avant la fin de l'essai.

1. Debout : la posture de chaque marche robuste (n2cao-marche-robuste*.json) sans ses oscillations (amplitudes et balancement à 0), avec ses gains de
   retour, puis sans ; poussée à 3 s, observée jusqu'à 7 s ; plafond de couple de la marche.
2. En marche : les mêmes marches robustes, poussées à 5 s + 0, ¼, ½, ¾ de période, observées jusqu'à 12 s.

Pour chaque cas : la plus forte poussée encaissée (toutes les plus faibles aussi), en N, en N·s et en vitesse donnée au robot entier (impulsion ÷ masse).

    python -X utf8 essai_n2_poussee.py [--pas 10] [--max 400] [--processus 14]        → resultats/n2cao-poussee.json
"""
import argparse
import glob
import json
import multiprocessing as mp
import os

os.environ.setdefault("N2_XML", "n2cao.xml")
os.environ.setdefault("N2_SIGNES", "signes-n2cao.json")
import mujoco
import numpy as np

import commun as C
import essai_n2_marche as M

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")
DUREE_POUSSEE = 0.1
DIRECTIONS = {"avant": (1.0, 0.0), "arriere": (-1.0, 0.0), "gauche": (0.0, 1.0), "droite": (0.0, -1.0)}
AMPLITUDES = (1, 4, 6, 8, 9)          # hanche_amp, genou_amp, chev_amp, roulis_g, roulis_d : à 0 pour « debout »
_fr0 = None


def init():
    global _fr0
    M.init()
    _fr0 = M._m.actuator_forcerange.copy()


def jouer(args):
    """args = (p, plafond, t_poussee, t_fin, direction, force, retour) → (tombe, inclinaison max après la poussée, temps de la chute)."""
    p, cap, t_p, t_fin, direction, F, retour = args
    m, d = M._m, M._d
    m.actuator_forcerange[:] = [-cap, cap] if cap else _fr0
    M.SANS_RETOUR = not retour
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    pas_pose = int(0.01 / m.opt.timestep)
    ux, uy = DIRECTIONS[direction]
    c = np.zeros(m.nu)
    incl_max, chute = 0.0, None
    for k in range(int(t_fin / m.opt.timestep)):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, M.pose_marche(p, t, M.attitude(d)), M._sg)
        d.ctrl[:] = c
        d.xfrc_applied[1, :3] = [F * ux, F * uy, 0.0] if t_p <= t < t_p + DUREE_POUSSEE else [0.0, 0.0, 0.0]
        mujoco.mj_step(m, d)
        if k % 20 == 0:
            i = C.inclinaison(d)
            if t >= t_p:
                incl_max = max(incl_max, i)
            if i > 40:
                chute = t
                break
    d.xfrc_applied[:] = 0
    return chute is not None, round(incl_max, 1), (round(chute, 2) if chute is not None else None)


def seuil(forces, issues):
    """La plus forte poussée encaissée en partant de 0 (avant la première chute), et la première qui fait tomber."""
    tient = None
    for F, (tombe, _, _) in zip(forces, issues):
        if tombe:
            return tient, F
        tient = F
    return tient, None


def main():
    a = argparse.ArgumentParser()
    a.add_argument("--pas", type=float, default=10.0)
    a.add_argument("--max", type=float, default=400.0)
    a.add_argument("--processus", type=int, default=14)
    o = a.parse_args()
    init()
    masse = float(np.sum(M._m.body_mass))
    forces = [float(f) for f in np.arange(0.0, o.max + 0.5 * o.pas, o.pas)]
    marches = sorted(glob.glob(os.path.join(RES, "n2cao-marche-robuste*-g[0-9].json")))
    cas = []        # (nom, p, plafond, t_poussee, t_fin, direction, retour, phase)
    for f in marches:
        r = json.load(open(f, encoding="utf-8"))
        p = np.array(r["parametres_liste"], dtype=float)
        cap = r.get("plafond_Nm") or 0.0
        debout = p.copy()
        debout[list(AMPLITUDES)] = 0.0
        nom = os.path.basename(f)
        for direction in DIRECTIONS:
            for retour in (True, False):
                cas.append(("debout", nom, debout, cap, 3.0, 7.0, direction, retour, None))
            T = float(p[0])
            for q in (0.0, 0.25, 0.5, 0.75):
                cas.append(("marche", nom, p, cap, 5.0 + q * T, M.DUREE, direction, True, q))
    taches = [(c[2], c[3], c[4], c[5], c[6], F, c[7]) for c in cas for F in forces]
    print(f"{len(cas)} cas × {len(forces)} poussées = {len(taches)} simulations ; masse {masse:.2f} kg ; corps poussé : {mujoco.mj_id2name(M._m, mujoco.mjtObj.mjOBJ_BODY, 1)}", flush=True)
    with mp.Pool(o.processus, initializer=init) as pool:
        issues = pool.map(jouer, taches, chunksize=8)
    sortie = []
    for i, c in enumerate(cas):
        iss = issues[i * len(forces):(i + 1) * len(forces)]
        tient, tombe_a = seuil(forces, iss)
        non_monotone = sum(1 for F, x in zip(forces, iss) if tombe_a is not None and F > tombe_a and not x[0])
        e = {"essai": c[0], "marche": c[1], "plafond_Nm": c[3] or None, "direction": c[6], "retour": c[7], "phase": c[8], "t_poussee_s": round(c[4], 3),
             "tient_jusqu_a_N": tient, "tombe_a_N": tombe_a,
             "impulsion_encaissee_Ns": round(tient * DUREE_POUSSEE, 2) if tient is not None else None,
             "dv_encaisse_m_s": round(tient * DUREE_POUSSEE / masse, 3) if tient is not None else None,
             "poussees_plus_fortes_encaissees_apres_la_chute": non_monotone,
             "sans_poussee_tombe": bool(iss[0][0])}
        sortie.append(e)
        print(f"{c[0]:6s} {c[1][13:]:28s} {c[6]:8s} {'retour' if c[7] else 'aveugle':7s} {'' if c[8] is None else 'phase ' + str(c[8]):10s} "
              f"tient jusqu'à {tient} N ({e['dv_encaisse_m_s']} m/s), tombe à {tombe_a} N{' ; NON MONOTONE ' + str(non_monotone) if non_monotone else ''}"
              f"{' ; TOMBE SANS POUSSÉE' if e['sans_poussee_tombe'] else ''}", flush=True)
    json.dump({"essai": "B51 / R-058 : N2 (CAO version 2) encaisse-t-il une poussée ?", "modele": os.environ["N2_XML"], "masse_kg": round(masse, 2),
               "corps_pousse": mujoco.mj_id2name(M._m, mujoco.mjtObj.mjOBJ_BODY, 1), "duree_poussee_s": DUREE_POUSSEE, "forces_N": forces,
               "chute": "torse incliné de plus de 40°", "cas": sortie},
              open(os.path.join(RES, "n2cao-poussee.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
