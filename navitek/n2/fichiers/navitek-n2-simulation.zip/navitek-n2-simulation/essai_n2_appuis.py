"""Essai B30 ter (cahier R-044 § 3 ter) : les 18 marches de N2 (9 sur le N1 agrandi, 9 sur la CAO) rejouées sur leur propre modèle, en relevant
les appuis : à chaque relevé (toutes les 20 itérations, comme evaluer()), quel pied touche le sol ; la hauteur maximale de chaque pied au-dessus de
sa hauteur de départ ; le glissement (chemin horizontal d'un pied pendant qu'il touche). Seule la phase établie compte (après la montée de 1,5 s).
La boucle est celle de essai_n2_marche.evaluer() (consigne toutes les 0,01 s, même retour d'information).

    python -X utf8 essai_n2_appuis.py        → resultats/n2-appuis.json
"""
import json
import multiprocessing as mp
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")
MODELES = {"n1_agrandi": ("n2.xml", "signes-n1-sans-roulis.json", "n2-marche"), "cao": ("n2cao.xml", "signes-n2cao.json", "n2cao-marche")}
HR = "jambe-gauche-hanche-roulis"


def tache(args):
    modele, f, cap = args
    import mujoco
    xml, sg, _ = MODELES[modele]
    os.environ["N2_XML"], os.environ["N2_SIGNES"] = xml, sg
    import commun as C
    import essai_n2_marche as em
    em.CAP = cap
    em.init()
    m, d = em._m, em._d
    p = np.array(json.load(open(os.path.join(RES, f), encoding="utf-8"))["parametres_liste"])
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    sol = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, "sol")
    pieds = {c: mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_GEOM, f"jambe-{c}-pied") for c in ("gauche", "droite")}
    z0 = {c: float(d.geom_xpos[g][2]) for c, g in pieds.items()}
    zmax = {c: 0.0 for c in pieds}
    gliss = {c: 0.0 for c in pieds}
    prec = {c: None for c in pieds}
    compte = {"double": 0, "simple": 0, "aucun": 0}
    n, pas_pose = int(em.DUREE / m.opt.timestep), int(0.01 / m.opt.timestep)
    c = np.zeros(m.nu)
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, em.pose_marche(p, t, em.attitude(d)), em._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20:
            continue
        if C.inclinaison(d) > 40:
            break
        if t < 1.5:
            continue
        touche = {cc: False for cc in pieds}
        for i in range(d.ncon):
            g1, g2 = d.contact[i].geom1, d.contact[i].geom2
            for cc, g in pieds.items():
                if (g1 == g and g2 == sol) or (g2 == g and g1 == sol):
                    touche[cc] = True
        nb = sum(touche.values())
        compte["double" if nb == 2 else "simple" if nb == 1 else "aucun"] += 1
        for cc, g in pieds.items():
            xy = d.geom_xpos[g][:2].copy()
            zmax[cc] = max(zmax[cc], float(d.geom_xpos[g][2]) - z0[cc])
            if touche[cc] and prec[cc] is not None:
                gliss[cc] += float(np.linalg.norm(xy - prec[cc]))
            prec[cc] = xy if touche[cc] else None
    tot = max(1, sum(compte.values()))
    return {"modele": modele, "marche": f, "plafond_Nm": cap or None,
            "fraction_double": round(compte["double"] / tot, 3), "fraction_simple": round(compte["simple"] / tot, 3), "fraction_aucun": round(compte["aucun"] / tot, 3),
            "pied_hauteur_max_mm": {cc: round(v * 1000, 1) for cc, v in zmax.items()}, "glissement_m": {cc: round(v, 3) for cc, v in gliss.items()}}


def rangs(x):
    o = np.argsort(x)
    r = np.empty(len(x))
    r[o] = np.arange(len(x))
    return r


def main():
    taches = [(mo, f"{pre}{s}-g{g}.json", cap) for mo, (_, _, pre) in MODELES.items() for s, cap in (("", 0.0), ("-plafond55", 55.0), ("-plafond18", 18.0)) for g in (1, 2, 3)]
    robustes = [("cao", f, cap) for f, cap in (("n2cao-marche-robuste-g1.json", 0.0), ("n2cao-marche-robuste-g2.json", 0.0),
                                               ("n2cao-marche-robuste-cap18-g1.json", 18.0), ("n2cao-marche-robuste-cap18-g2.json", 18.0))]
    with mp.Pool(14) as pool:
        tout = pool.map(tache, taches + robustes, chunksize=1)
    sorties, rob = tout[:len(taches)], tout[len(taches):]
    for s in rob:
        r = json.load(open(os.path.join(RES, s["marche"]), encoding="utf-8"))
        s["hr_moyen"], s["avance_m"] = r["couple_moyen_abs_Nm"][HR], r["avance_m"]
        print("robuste :", s)
    for s in sorties:
        r = json.load(open(os.path.join(RES, s["marche"]), encoding="utf-8"))
        s["hr_moyen"], s["avance_m"] = r["couple_moyen_abs_Nm"][HR], r["avance_m"]
    rho = float(np.corrcoef(rangs([s["fraction_simple"] for s in sorties]), rangs([s["hr_moyen"] for s in sorties]))[0, 1])
    med = {mo: float(np.median([s["fraction_simple"] for s in sorties if s["modele"] == mo])) for mo in MODELES}
    json.dump({"essai": "B30 ter / R-044 § 3 ter : les appuis des 18 marches de N2 (et des 4 marches robustes, à part)", "marches": sorties, "robustes": rob, "mediane_fraction_simple": med,
               "spearman_fraction_simple_vs_hr_moyen": round(rho, 3)}, open(os.path.join(RES, "n2-appuis.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"{'marche':<32}{'double':>8}{'simple':>8}{'aucun':>7}{'pied haut g/d mm':>18}{'gliss. g/d m':>15}{'HR moy':>8}{'avance':>8}")
    for s in sorties:
        print(f"{s['marche']:<32}{s['fraction_double']:>8.2f}{s['fraction_simple']:>8.2f}{s['fraction_aucun']:>7.2f}"
              f"{s['pied_hauteur_max_mm']['gauche']:>9.0f}/{s['pied_hauteur_max_mm']['droite']:<8.0f}{s['glissement_m']['gauche']:>7.2f}/{s['glissement_m']['droite']:<7.2f}{s['hr_moyen']:>8.1f}{s['avance_m']:>8.2f}")
    print("médiane de la fraction de simple appui :", med, "; Spearman (simple appui, HR moyen) :", round(rho, 3))


if __name__ == "__main__":
    main()
