"""Essai N2-T5 du Navitek N2 simplifié (N1 agrandi, masses de N2 estimées) : une marche avec retour d'information, réglée par CMA-ES.

Même squelette que la marche de N0 (essai_t5.py) : une oscillation périodique des consignes de hanche (tangage), de genou et de
cheville (tangage) en opposition de phase d'une jambe à l'autre, plus un balancement latéral par la hanche-roulis (la cheville-roulis
fait l'inverse pour garder le pied à plat). N1 y ajoute ce que N0 n'avait pas : la centrale inertielle et la position de chaque servo
sont disponibles, donc quatre gains de retour d'information corrigent la cheville (tangage et roulis) d'après l'inclinaison du torse et
sa vitesse. 15 paramètres. Aptitude : une chute (inclinaison > 40°) arrête l'essai et vaut moins que n'importe quelle marche debout ;
sans chute, l'avance du centre de masse (+x) moins 0,3 fois la dérive de côté. Seuls les pieds touchent le sol.

    python -X utf8 essai_n1_marche.py --graine 1 --generations 60 --population 28 [--video] [--sans-retour]
    python -X utf8 essai_n1_marche.py --rejouer resultats/n2-marche-g1.json --video
--sans-retour : les quatre gains valent 0 (la même marche aveugle, pour mesurer ce que le retour apporte).
"""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C

DUREE = 12.0
NOMS_P = ["periode", "hanche_amp", "hanche_decal", "genou_base", "genou_amp", "genou_phase", "chev_amp", "chev_phase",
          "roulis_g", "roulis_d", "roulis_phase", "gain_tangage", "gain_tangage_vitesse", "gain_roulis", "gain_roulis_vitesse"]
BAS = np.array([1.0, 0, -10, 0, 0, -3.14, 0, -3.14, -15, -15, -3.14, -2, -0.3, -2, -0.3])
HAUT = np.array([2.5, 30, 10, 50, 50, 3.14, 30, 3.14, 15, 15, 3.14, 2, 0.3, 2, 0.3])
SANS_RETOUR = False
CAP = float(os.environ.get("N2_CAP", "0"))      # plafond de couple des actionneurs en N·m ; 0 = aucun (200 N·m)

_m = _d = _sg = None
_idx = {}


def init():
    global _m, _d, _sg
    _m, _d = C.charger(os.environ.get("N2_XML", "n2.xml"))
    _sg = C.signes(os.environ.get("N2_SIGNES", "signes-n1.json"))
    if CAP:
        _m.actuator_forcerange[:] = [-CAP, CAP]
    for g in range(_m.ngeom):
        n = mujoco.mj_id2name(_m, mujoco.mjtObj.mjOBJ_GEOM, g)
        if n != "sol" and "pied" not in n:
            _m.geom_contype[g] = 0
            _m.geom_conaffinity[g] = 0
    for i, n in enumerate(C.noms(_m)):
        _idx[C.court(n)] = i


def initialiser(sans_retour):
    global SANS_RETOUR
    SANS_RETOUR = sans_retour
    init()


def attitude(d):
    """(inclinaison avant en degrés, roulis en degrés, vitesse d'inclinaison avant, vitesse de roulis) du torse."""
    R = d.xmat[1].reshape(3, 3)
    avant = -np.degrees(np.arcsin(np.clip(R[2, 0], -1, 1)))
    roulis = np.degrees(np.arcsin(np.clip(R[2, 1], -1, 1)))
    return avant, roulis, np.degrees(d.qvel[4]), np.degrees(d.qvel[3])


def pose_marche(p, t, fb):
    T, ah, h0, kb, ak, pk, aa, pa, rg, rd, pr, gt, gtv, gr, grv = p
    if SANS_RETOUR:
        gt = gtv = gr = grv = 0.0
    montee = min(1.0, t / 1.5)
    th = 2 * np.pi * t / T
    avant, roulis, va, vr = fb
    corr_t = gt * avant + gtv * va
    corr_r = gr * roulis + grv * vr
    out = {}
    for cote, dec in (("g", 0.0), ("d", np.pi)):
        out["hanche_tangage_" + cote] = montee * (h0 + ah * np.sin(th + dec))
        out["genou_" + cote] = montee * (kb + ak * 0.5 * (1 + np.sin(th + dec + pk)))
        out["cheville_tangage_" + cote] = montee * (aa * np.sin(th + dec + pa)) + corr_t
    s = np.sin(th + pr)
    for cote, r in (("g", rg), ("d", rd)):
        h = montee * r * s
        out["hanche_roulis_" + cote] = h
        out["cheville_roulis_" + cote] = -h + corr_r
    return out


def evaluer(p, trace=False, video=None):
    m, d = _m, _d
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    tau = m.actuator_forcerange[0, 1]
    pire = np.zeros(m.nu)
    somme = np.zeros(m.nu)
    nmes = 0
    x0 = float(d.subtree_com[1][0])
    chute = None
    n = int(DUREE / m.opt.timestep)
    cadre = int(0.05 / m.opt.timestep)
    pas_pose = int(0.01 / m.opt.timestep)
    c = np.zeros(m.nu)
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, pose_marche(p, t, attitude(d)), _sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0:
            pire = np.maximum(pire, np.abs(d.actuator_force))
            somme += np.abs(d.actuator_force)
            nmes += 1
            if C.inclinaison(d) > 40:
                chute = t
                break
        if video is not None and k % cadre == 0:
            video(d)
    x = float(d.subtree_com[1][0]) - x0
    y = float(d.subtree_com[1][1])
    tt = chute if chute is not None else DUREE
    score = (tt / DUREE - 1.0) if chute is not None else (x - 0.3 * abs(y))
    if not trace:
        return -score
    return {"avance_m": round(x, 4), "deviation_laterale_m": round(y, 4), "tombe": chute is not None,
            "temps_tenu_s": round(tt, 2),
            "plafond_Nm": CAP or None,
            "couple_max_Nm": {nm: round(float(pire[i]), 1) for i, nm in enumerate(C.noms(m))},
            "couple_moyen_abs_Nm": {nm: round(float(somme[i] / max(nmes, 1)), 1) for i, nm in enumerate(C.noms(m))},
            "inclinaison_fin_deg": round(C.inclinaison(d), 1)}


def f(u):
    return evaluer(BAS + np.clip(u, 0, 1) * (HAUT - BAS))


def main():
    global SANS_RETOUR
    ap = argparse.ArgumentParser()
    ap.add_argument("--graine", type=int, default=1)
    ap.add_argument("--generations", type=int, default=60)
    ap.add_argument("--population", type=int, default=28)
    ap.add_argument("--processus", type=int, default=14)
    ap.add_argument("--rejouer")
    ap.add_argument("--video", action="store_true")
    ap.add_argument("--sans-retour", action="store_true")
    a = ap.parse_args()
    SANS_RETOUR = a.sans_retour
    suffixe = "-aveugle" if a.sans_retour else ""
    init()
    if a.rejouer:
        p = np.array(json.load(open(a.rejouer, encoding="utf-8"))["parametres_liste"])
        fichier = os.path.splitext(a.rejouer)[0]
        histo = None
    else:
        from cmaes import CMA
        cma = CMA(mean=np.full(len(BAS), 0.5), sigma=0.3, population_size=a.population, seed=a.graine, bounds=np.array([[0, 1]] * len(BAS)))
        meilleur = (1e9, None)
        histo = []

        with mp.Pool(min(a.processus, a.population), initializer=initialiser, initargs=(a.sans_retour,)) as pool:
            for g in range(a.generations):
                xs = [cma.ask() for _ in range(cma.population_size)]
                vals = pool.map(f, xs)
                cma.tell(list(zip(xs, vals)))
                i = int(np.argmin(vals))
                if vals[i] < meilleur[0]:
                    meilleur = (vals[i], xs[i])
                histo.append(round(-meilleur[0], 4))
                print(f"génération {g + 1:3d}  meilleur {-meilleur[0] * 100:7.2f} cm  (cette génération {-vals[i] * 100:7.2f})", flush=True)
        p = BAS + meilleur[1] * (HAUT - BAS)
        fichier = os.path.join(C.ICI, "resultats", f"{os.environ.get('N2_PREFIXE', 'n2-marche')}{suffixe}{'-plafond' + str(int(CAP)) if CAP else ''}-g{a.graine}")
    images = []
    rend = mujoco.Renderer(_m, 360, 480) if a.video else None
    cam = mujoco.MjvCamera()
    cam.distance, cam.azimuth, cam.elevation = 2.8, 140, -8

    def video(d):
        cam.lookat[:] = [d.subtree_com[1][0], d.subtree_com[1][1], 0.5]
        rend.update_scene(d, camera=cam)
        images.append(rend.render().copy())

    res = evaluer(p, trace=True, video=video if a.video else None)
    res.update({"essai": "N2 simplifié : marche avec retour d'information" + (" (retour coupé)" if SANS_RETOUR else ""), "duree_s": DUREE,
                "parametres": dict(zip(NOMS_P, [round(float(v), 4) for v in p])), "parametres_liste": [float(v) for v in p]})
    if histo is not None:
        res.update({"graine": a.graine, "generations": a.generations, "population": a.population,
                    "optimiseur": "CMA-ES (cmaes), sigma 0,3", "meilleur_par_generation_m": histo})
    json.dump(res, open(fichier + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in res.items() if k not in ("parametres_liste", "meilleur_par_generation_m")}, ensure_ascii=False, indent=1))
    if a.video:
        import imageio.v2 as iio
        iio.mimsave(fichier + ".mp4", images, fps=20, macro_block_size=1)
        print("vidéo :", fichier + ".mp4", len(images), "images")


if __name__ == "__main__":
    main()
