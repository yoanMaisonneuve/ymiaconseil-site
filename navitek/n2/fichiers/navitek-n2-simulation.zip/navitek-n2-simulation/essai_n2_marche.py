"""Essai N2-T5 du Navitek N2 simplifié (N1 agrandi, masses de N2 estimées) : une marche avec retour d'information, réglée par CMA-ES.

Même squelette que la marche de N0 (essai_t5.py) : une oscillation périodique des consignes de hanche (tangage), de genou et de
cheville (tangage) en opposition de phase d'une jambe à l'autre, plus un balancement latéral par la hanche-roulis (la cheville-roulis
fait l'inverse pour garder le pied à plat). N1 y ajoute ce que N0 n'avait pas : la centrale inertielle et la position de chaque servo
sont disponibles, donc quatre gains de retour d'information corrigent la cheville (tangage et roulis) d'après l'inclinaison du torse et
sa vitesse. 15 paramètres. Aptitude : une chute (inclinaison > 40°) arrête l'essai et vaut moins que n'importe quelle marche debout ;
sans chute, l'avance du centre de masse (+x) moins 0,3 fois la dérive de côté. Seuls les pieds touchent le sol.

    python -X utf8 essai_n1_marche.py --graine 1 --generations 60 --population 28 [--video] [--sans-retour]
    python -X utf8 essai_n1_marche.py --rejouer resultats/n2-marche-g1.json --video
--sans-retour : les quatre gains valent 0 (la même marche aveugle, pour mesurer ce que le retour apporte).
"""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C

DUREE = 12.0
NOMS_P = ["periode", "hanche_amp", "hanche_decal", "genou_base", "genou_amp", "genou_phase", "chev_amp", "chev_phase",
          "roulis_g", "roulis_d", "roulis_phase", "gain_tangage", "gain_tangage_vitesse", "gain_roulis", "gain_roulis_vitesse"]
BAS = np.array([1.0, 0, -10, 0, 0, -3.14, 0, -3.14, -15, -15, -3.14, -2, -0.3, -2, -0.3])
HAUT = np.array([2.5, 30, 10, 50, 50, 3.14, 30, 3.14, 15, 15, 3.14, 2, 0.3, 2, 0.3])
SANS_RETOUR = False
CAP = float(os.environ.get("N2_CAP", "0"))      # plafond de couple des actionneurs en N·m ; 0 = aucun (200 N·m)
# B42 (R-050 § 5) : les mêmes options que essai_n1_marche.py. --sans-glisser : l'aptitude paie le glissement des pieds, un appui simple sous 30 %
# et un pied levé de moins de 10 mm ; --droit : 0,5 × le lacet maximal (radians) au-delà de --seuil-lacet degrés ; --retour-cap : un 16e réglage,
# gain_lacet, qui allonge le pas d'une jambe selon l'écart au cap (ici RETOUR_CAP : le nom CAP est déjà le plafond de couple).
SANS_GLISSER = False
DROIT = False
SEUIL_LACET = 0.0
RETOUR_CAP = False
BAS_CAP, HAUT_CAP = -3.0, 3.0

_m = _d = _sg = None
_idx = {}
_pieds = {}
_sol = None


def init():
    global _m, _d, _sg, _sol
    _m, _d = C.charger(os.environ.get("N2_XML", "n2.xml"))
    _sg = C.signes(os.environ.get("N2_SIGNES", "signes-n1.json"))
    if CAP:
        _m.actuator_forcerange[:] = [-CAP, CAP]
    for g in range(_m.ngeom):
        n = mujoco.mj_id2name(_m, mujoco.mjtObj.mjOBJ_GEOM, g)
        if n != "sol" and "pied" not in n:
            _m.geom_contype[g] = 0
            _m.geom_conaffinity[g] = 0
    for i, n in enumerate(C.noms(_m)):
        _idx[C.court(n)] = i
    _sol = mujoco.mj_name2id(_m, mujoco.mjtObj.mjOBJ_GEOM, "sol")
    _pieds.update({c: mujoco.mj_name2id(_m, mujoco.mjtObj.mjOBJ_GEOM, f"jambe-{c}-pied") for c in ("gauche", "droite")})


def initialiser(sans_retour, sans_glisser=False, droit=False, retour_cap=False, seuil=0.0):
    global SANS_RETOUR, SANS_GLISSER, DROIT, RETOUR_CAP, SEUIL_LACET
    SANS_RETOUR, SANS_GLISSER, DROIT, RETOUR_CAP, SEUIL_LACET = sans_retour, sans_glisser, droit, retour_cap, seuil
    init()


def bornes():
    if RETOUR_CAP:
        return np.append(BAS, BAS_CAP), np.append(HAUT, HAUT_CAP)
    return BAS, HAUT


def attitude(d):
    """(inclinaison avant en degrés, roulis en degrés, vitesse d'inclinaison avant, vitesse de roulis) du torse."""
    R = d.xmat[1].reshape(3, 3)
    avant = -np.degrees(np.arcsin(np.clip(R[2, 0], -1, 1)))
    roulis = np.degrees(np.arcsin(np.clip(R[2, 1], -1, 1)))
    return avant, roulis, np.degrees(d.qvel[4]), np.degrees(d.qvel[3]), float(np.arctan2(d.xmat[1][3], d.xmat[1][0]))


def pose_marche(p, t, fb):
    T, ah, h0, kb, ak, pk, aa, pa, rg, rd, pr, gt, gtv, gr, grv = p[:15]
    gl = p[15] if len(p) > 15 else 0.0
    if SANS_RETOUR:
        gt = gtv = gr = grv = 0.0
    montee = min(1.0, t / 1.5)
    th = 2 * np.pi * t / T
    avant, roulis, va, vr = fb[:4]
    lac = fb[4] if len(fb) > 4 else 0.0
    corr_t = gt * avant + gtv * va
    corr_r = gr * roulis + grv * vr
    out = {}
    for cote, dec, sg in (("g", 0.0, 1.0), ("d", np.pi, -1.0)):
        ah_c = ah * float(np.clip(1.0 + sg * gl * lac, 0.3, 1.7))
        out["hanche_tangage_" + cote] = montee * (h0 + ah_c * np.sin(th + dec))
        out["genou_" + cote] = montee * (kb + ak * 0.5 * (1 + np.sin(th + dec + pk)))
        out["cheville_tangage_" + cote] = montee * (aa * np.sin(th + dec + pa)) + corr_t
    s = np.sin(th + pr)
    for cote, r in (("g", rg), ("d", rd)):
        h = montee * r * s
        out["hanche_roulis_" + cote] = h
        out["cheville_roulis_" + cote] = -h + corr_r
    return out


def evaluer(p, trace=False, video=None):
    m, d = _m, _d
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    tau = m.actuator_forcerange[0, 1]
    pire = np.zeros(m.nu)
    somme = np.zeros(m.nu)
    nmes = 0
    x0 = float(d.subtree_com[1][0])
    chute = None
    n = int(DUREE / m.opt.timestep)
    cadre = int(0.05 / m.opt.timestep)
    pas_pose = int(0.01 / m.opt.timestep)
    c = np.zeros(m.nu)
    z0 = {cc: float(d.geom_xpos[g][2]) for cc, g in _pieds.items()}
    levee, gliss, prec = {cc: 0.0 for cc in _pieds}, {cc: 0.0 for cc in _pieds}, {cc: None for cc in _pieds}
    appuis = {"simple": 0, "tous": 0}
    lacet = lambda: float(np.arctan2(d.xmat[1][3], d.xmat[1][0]))
    lacet0, lacet_max = lacet(), 0.0
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, pose_marche(p, t, attitude(d)), _sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20 == 0:
            pire = np.maximum(pire, np.abs(d.actuator_force))
            somme += np.abs(d.actuator_force)
            nmes += 1
            if C.inclinaison(d) > 40:
                chute = t
                break
            lacet_max = max(lacet_max, abs((lacet() - lacet0 + np.pi) % (2 * np.pi) - np.pi))
            if (SANS_GLISSER or trace) and t >= 1.5:          # les appuis, comme essai_n2_appuis.py
                touche = {cc: False for cc in _pieds}
                for i in range(d.ncon):
                    g1, g2 = d.contact[i].geom1, d.contact[i].geom2
                    for cc, g in _pieds.items():
                        if (g1 == g and g2 == _sol) or (g2 == g and g1 == _sol):
                            touche[cc] = True
                appuis["tous"] += 1
                appuis["simple"] += sum(touche.values()) == 1
                for cc, g in _pieds.items():
                    xy = d.geom_xpos[g][:2].copy()
                    levee[cc] = max(levee[cc], float(d.geom_xpos[g][2]) - z0[cc])
                    if touche[cc] and prec[cc] is not None:
                        gliss[cc] += float(np.linalg.norm(xy - prec[cc]))
                    prec[cc] = xy if touche[cc] else None
        if video is not None and k % cadre == 0:
            video(d)
    x = float(d.subtree_com[1][0]) - x0
    y = float(d.subtree_com[1][1])
    tt = chute if chute is not None else DUREE
    simple = appuis["simple"] / max(1, appuis["tous"])
    g_tot = sum(gliss.values())
    if chute is not None:
        score = tt / DUREE - 1.0 - (1.0 if SANS_GLISSER else 0.0)
    elif SANS_GLISSER:
        score = x - 0.3 * abs(y) - 1.0 * g_tot - 1.0 * max(0.0, 0.30 - simple) - 5.0 * max(0.0, 0.010 - min(levee.values()))
        if DROIT:
            score -= 0.5 * max(0.0, lacet_max - np.radians(SEUIL_LACET))
    else:
        score = x - 0.3 * abs(y)
    if not trace:
        return -score
    return {"avance_m": round(x, 4), "deviation_laterale_m": round(y, 4), "tombe": chute is not None,
            "temps_tenu_s": round(tt, 2), "aptitude": round(score, 4), "aptitude_sans_glisser": SANS_GLISSER, "aptitude_droit": DROIT,
            "lacet_fin_deg": round(float(np.degrees((lacet() - lacet0 + np.pi) % (2 * np.pi) - np.pi)), 1), "lacet_max_deg": round(float(np.degrees(lacet_max)), 1),
            "glissement_m": {cc: round(v, 3) for cc, v in gliss.items()}, "appui_simple": round(simple, 3),
            "pied_levee_max_mm": {cc: round(v * 1000, 1) for cc, v in levee.items()},
            "plafond_Nm": CAP or None,
            "couple_max_Nm": {nm: round(float(pire[i]), 1) for i, nm in enumerate(C.noms(m))},
            "couple_moyen_abs_Nm": {nm: round(float(somme[i] / max(nmes, 1)), 1) for i, nm in enumerate(C.noms(m))},
            "inclinaison_fin_deg": round(C.inclinaison(d), 1)}


def f(u):
    b, h = bornes()
    return evaluer(b + np.clip(u, 0, 1) * (h - b))


def main():
    global SANS_RETOUR, SANS_GLISSER, DROIT, RETOUR_CAP, SEUIL_LACET
    ap = argparse.ArgumentParser()
    ap.add_argument("--graine", type=int, default=1)
    ap.add_argument("--generations", type=int, default=60)
    ap.add_argument("--population", type=int, default=28)
    ap.add_argument("--processus", type=int, default=14)
    ap.add_argument("--rejouer")
    ap.add_argument("--video", action="store_true")
    ap.add_argument("--sans-retour", action="store_true")
    ap.add_argument("--sans-glisser", action="store_true")
    ap.add_argument("--droit", action="store_true")
    ap.add_argument("--seuil-lacet", type=float, default=0.0)
    ap.add_argument("--retour-cap", action="store_true")
    ap.add_argument("--depart", help="JSON d'une marche de départ (moyenne initiale de CMA-ES, écart 0,12)")
    a = ap.parse_args()
    SANS_RETOUR, SANS_GLISSER, DROIT, RETOUR_CAP, SEUIL_LACET = a.sans_retour, a.sans_glisser, a.droit, a.retour_cap, a.seuil_lacet
    suffixe = (("-aveugle" if a.sans_retour else "") + ("-sans-glisser" if a.sans_glisser else "") + ("-droit" if a.droit else "")
               + (f"-seuil{int(a.seuil_lacet)}" if a.seuil_lacet else "") + ("-cap" if a.retour_cap else ""))
    init()
    if a.rejouer:
        origine = json.load(open(a.rejouer, encoding="utf-8"))
        p = np.array(origine["parametres_liste"])
        fichier = os.path.splitext(a.rejouer)[0]
        histo = None
    else:
        from cmaes import CMA
        b, h = bornes()
        if a.depart:
            p0 = np.array(json.load(open(a.depart, encoding="utf-8"))["parametres_liste"])
            if len(p0) < len(b):
                p0 = np.append(p0, 0.0)
            moyenne, ecart = np.clip((p0 - b) / (h - b), 0.02, 0.98), 0.12
            suffixe += "-depart-" + os.path.splitext(os.path.basename(a.depart))[0]
        else:
            moyenne, ecart = np.full(len(b), 0.5), 0.3
        cma = CMA(mean=moyenne, sigma=ecart, population_size=a.population, seed=a.graine, bounds=np.array([[0, 1]] * len(b)))
        meilleur = (1e9, None)
        histo = []

        with mp.Pool(min(a.processus, a.population), initializer=initialiser, initargs=(a.sans_retour, a.sans_glisser, a.droit, a.retour_cap, a.seuil_lacet)) as pool:
            for g in range(a.generations):
                xs = [cma.ask() for _ in range(cma.population_size)]
                vals = pool.map(f, xs)
                cma.tell(list(zip(xs, vals)))
                i = int(np.argmin(vals))
                if vals[i] < meilleur[0]:
                    meilleur = (vals[i], xs[i])
                histo.append(round(-meilleur[0], 4))
                print(f"génération {g + 1:3d}  meilleur {-meilleur[0] * 100:7.2f} cm  (cette génération {-vals[i] * 100:7.2f})", flush=True)
        p = b + meilleur[1] * (h - b)
        fichier = os.path.join(C.ICI, "resultats", f"{os.environ.get('N2_PREFIXE', 'n2-marche')}{suffixe}{'-plafond' + str(int(CAP)) if CAP else ''}-g{a.graine}")
    images = []
    rend = mujoco.Renderer(_m, 360, 480) if a.video else None
    cam = mujoco.MjvCamera()
    cam.distance, cam.azimuth, cam.elevation = 2.8, 140, -8

    def video(d):
        cam.lookat[:] = [d.subtree_com[1][0], d.subtree_com[1][1], 0.5]
        rend.update_scene(d, camera=cam)
        images.append(rend.render().copy())

    res = evaluer(p, trace=True, video=video if a.video else None)
    res.update({"essai": "N2 simplifié : marche avec retour d'information" + (" (retour coupé)" if SANS_RETOUR else ""), "duree_s": DUREE,
                "parametres": dict(zip(NOMS_P + ["gain_lacet"], [round(float(v), 4) for v in p])), "parametres_liste": [float(v) for v in p]})
    if a.rejouer:                       # un rejeu garde la graine et l'historique du réglage
        res = {**origine, **res}
    if histo is not None:
        res.update({"graine": a.graine, "generations": a.generations, "population": a.population,
                    "optimiseur": "CMA-ES (cmaes), sigma 0,3", "meilleur_par_generation_m": histo})
    json.dump(res, open(fichier + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in res.items() if k not in ("parametres_liste", "meilleur_par_generation_m")}, ensure_ascii=False, indent=1))
    if a.video:
        import imageio.v2 as iio
        iio.mimsave(fichier + ".mp4", images, fps=20, macro_block_size=1)
        print("vidéo :", fichier + ".mp4", len(images), "images")


if __name__ == "__main__":
    main()
