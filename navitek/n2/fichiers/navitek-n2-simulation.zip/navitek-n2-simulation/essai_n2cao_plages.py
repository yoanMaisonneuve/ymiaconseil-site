"""B47 (R-054) : les plages des articulations de jambe de la CAO de N2, sur les géométries exactes (le T4 de N2, qui n'avait jamais été fait).
Chaque articulation de la jambe gauche est tournée seule, les autres au neutre, le robot figé en l'air (cinématique : mj_forward, pas de simulation),
de 0 à ±90° par pas de 1° ; à chaque angle, les paires de géométries de corps différents qui pénètrent de 1 mm au moins (FCL, comme
essai_n2_contacts_marche.py), hors celles déjà là au neutre. La butée d'un côté est le premier angle où une paire apparaît ; la profondeur est relevée.
    N2_XML=n2cao.xml N2_SIGNES=signes-n2cao.json python -X utf8 essai_n2cao_plages.py [<sortie.json>]
    → resultats/n2cao-plages.json (par défaut)
"""
import json
import os
import sys

import mujoco
import numpy as np

import commun as C
import essai_n2_marche as em
from essai_n2_contacts_marche import gestionnaire

PROFONDEUR = 1.0                                          # mm
ARTICULATIONS = ["hanche-roulis", "hanche-tangage", "genou", "cheville-tangage", "cheville-roulis"]


def profondeurs(m, d, mgr, noms, corps):
    for nom, g in noms.items():
        T = np.eye(4)
        T[:3, :3] = d.geom_xmat[g].reshape(3, 3)
        T[:3, 3] = d.geom_xpos[g]
        mgr.set_transform(nom, T)
    _, _, donnees = mgr.in_collision_internal(return_names=True, return_data=True)
    prof = {}
    for c in donnees:
        a, b = sorted(c.names)
        if corps[a] != corps[b]:
            prof[(a, b)] = max(prof.get((a, b), 0.0), float(c.depth) * 1000)
    return prof


def main():
    sortie = sys.argv[1] if len(sys.argv) > 1 else "n2cao-plages.json"
    em.init()
    m, d = em._m, em._d
    mgr, noms, corps = gestionnaire(m)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    neutre = {q for q, p in profondeurs(m, d, mgr, noms, corps).items() if p >= PROFONDEUR}
    q0 = d.qpos.copy()
    res = {"essai": "R-054 : plages de la jambe gauche de la CAO de N2, géométries exactes, pénétration >= 1 mm, cinématique",
           "modele": os.environ.get("N2_XML", "n2.xml"), "paires_au_neutre": len(neutre), "articulations": {}}
    for art in ARTICULATIONS:
        nom_j = f"jambe-gauche-{art}"
        adr = m.jnt_qposadr[mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, nom_j)]
        res["articulations"][nom_j] = {}
        for sens in (1, -1):
            butee, pire = None, {}
            for a in range(1, 91):
                d.qpos[:] = q0
                d.qpos[adr] = sens * np.radians(a)
                mujoco.mj_forward(m, d)
                nouv = {q: p for q, p in profondeurs(m, d, mgr, noms, corps).items() if p >= PROFONDEUR and q not in neutre}
                if nouv and butee is None:
                    butee = sens * (a - 1)
                    pire = {" ~ ".join(q): round(p, 1) for q, p in sorted(nouv.items(), key=lambda x: -x[1])}
                    break
            cle = "max_deg" if sens > 0 else "min_deg"
            res["articulations"][nom_j][cle] = butee if butee is not None else sens * 90
            res["articulations"][nom_j]["butee_" + cle[:3]] = pire
            print(f"{nom_j:32s} {'+' if sens > 0 else '-'} : {'libre jusqu à 90°' if butee is None else f'butée à {butee}°'} {list(pire.items())[:3]}", flush=True)
    d.qpos[:] = q0
    json.dump(res, open(os.path.join(C.ICI, "resultats", sortie), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
