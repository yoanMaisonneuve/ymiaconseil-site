"""Le modèle MuJoCo de Navitek N2 TIRÉ DE LA CAO du robot entier (navitek-n2/robot/web/assemblage.json, écrit par navitek-n2/cao/n2_robot.py).

Remplace le modèle « N1 agrandi » (modele_n2.py) : la géométrie, les corps, les articulations (centre et axe) et les masses viennent de la CAO.
    - Pièces imprimées en maillage ; masse = volume CAO × G_PAR_CM3 (1,0 g/cm³ : le rapport médian mesuré sur les pièces de N0 ; ESTIMATION, rien n'est tranché pour N2).
    - Actionneur : côté moteur (moteur, boîtier, 17 goupilles d'acier) et côté sortie (excentrique d'acier, disques et bride imprimés) = deux cylindres pleins
      de leur masse. Moteur sans balais : 300 g, variateur + roulements + visserie : 60 g par actionneur (ESTIMATIONS, R-039 : aucune fiche).
    - Électronique (pile 6S, Raspberry Pi 5, centrale, fils) : 1,5 kg, boîte dans le torse (ESTIMATION, la même que l'ancien modèle).
Aucun contact sauf les pieds. Les actionneurs de position ne sont volontairement PAS bornés (200 N·m) : on mesure ce que le mouvement DEMANDE.

    python -X utf8 modele_n2_cao.py        → n2cao.xml (à côté)
"""
import io
import json
import os

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
N2 = os.path.join(ICI, "..", "navitek-n2", "robot")

HYPOTHESES = {"couple_blocage_Nm": 200.0, "kp": 800.0, "kv": 25.0, "armature": 0.05, "amortissement": 0.5, "frottement_sol": 0.6,
              "masse_electronique_g": 1500, "masse_moteur_g": 300, "masse_divers_actionneur_g": 60,
              "g_par_cm3_imprime": 1.0, "g_par_cm3_acier": 7.85}
BORNES = {"hanche-roulis": (-30, 30), "hanche-tangage": (-90, 90), "genou": (-10, 120), "cheville-tangage": (-60, 60),
          "cheville-roulis": (-30, 30), "epaule-tangage": (-90, 90), "epaule-roulis": (-90, 90), "coude": (-10, 120), "cou": (-80, 80)}
# le côté sortie d'un actionneur et son côté moteur, en z local (n2.py : boîtier de 0 à 36, moteur de -22 à -1, bride de 28 à 36, axes de sortie de 6 à 28)
BASE_Z, ROTOR_Z, RAYON = (-22.0, 36.0), (6.0, 36.0), 33.0
CENTRE_LOCAL = 18.0
STEEL = {"excentrique", "goupille"}


def quat(R):
    w = np.sqrt(max(0.0, 1 + R[0, 0] + R[1, 1] + R[2, 2])) / 2
    x = np.copysign(np.sqrt(max(0.0, 1 + R[0, 0] - R[1, 1] - R[2, 2])) / 2, R[2, 1] - R[1, 2])
    y = np.copysign(np.sqrt(max(0.0, 1 - R[0, 0] + R[1, 1] - R[2, 2])) / 2, R[0, 2] - R[2, 0])
    z = np.copysign(np.sqrt(max(0.0, 1 - R[0, 0] - R[1, 1] + R[2, 2])) / 2, R[1, 0] - R[0, 1])
    q = np.array([w, x, y, z])
    return q / np.linalg.norm(q)


asm = json.load(io.open(os.path.join(N2, "web", "assemblage.json"), encoding="utf-8"))
VOL = asm["volumes_cm3"]
ART = {a["nom"]: a for a in asm["articulations"]}
centre = lambda corps: np.zeros(3) if corps == "torse" else np.array(ART[corps]["centre"], dtype=float) / 1000.0
H = HYPOTHESES
PIECES_ACT = {"moteur", "boitier", "goupille", "excentrique", "disque-a", "disque-b", "bride-sortie"}


def masse_g(piece):
    if piece == "moteur":
        return H["masse_moteur_g"]
    return VOL[piece] * (H["g_par_cm3_acier"] if piece in STEEL else H["g_par_cm3_imprime"])


def sous_actionneur(nom):
    """Le nom de l'actionneur d'une pièce d'actionneur (jambe-gauche-genou-boitier → jambe-gauche-genou)."""
    if "-goupille-" in nom:
        return nom.split("-goupille-")[0]
    return nom.rsplit("-", 1)[0] if not nom.endswith(("-disque-a", "-disque-b")) else nom.rsplit("-disque", 1)[0]


# masses par (actionneur, côté)
masse_base, masse_rotor = {}, {}
geoms_imprimes = {c: [] for c in asm["corps"]}          # corps → pièces imprimées de structure
for i in asm["instances"]:
    p = i["piece"]
    if p in PIECES_ACT:
        act = sous_actionneur(i["nom"])
        cote = masse_rotor if p in ("excentrique", "disque-a", "disque-b", "bride-sortie") else masse_base
        cote[act] = cote.get(act, 0.0) + masse_g(p)
    else:
        geoms_imprimes[i["groupe"]].append(i)
for act in masse_base:
    masse_base[act] += H["masse_divers_actionneur_g"]
enfants = {c: [] for c in asm["corps"]}
for a in asm["articulations"]:
    enfants[a["parent"]].append(a["nom"])
act_axe = {a["nom"]: np.array(a["axe"], dtype=float) for a in asm["articulations"]}
act_centre = {a["nom"]: np.array(a["centre"], dtype=float) for a in asm["articulations"]}
# l'actionneur d'une articulation : son côté sortie est dans le corps de l'articulation, son côté moteur dans le corps du parent
xml = []
a = xml.append


def hexrgba(h):
    h = h.lstrip("#")
    return " ".join(f"{int(h[k:k + 2], 16) / 255:.3f}" for k in (0, 2, 4)) + " 1"


def cylindre(nom, art, z0, z1, masse, couleur, c0, rayon=RAYON):
    """Un cylindre plein dans le repère du corps (origine en c0, en mètres), le long de l'axe de l'actionneur 'art'."""
    ax, ct = act_axe[art], act_centre[art] / 1000.0
    p0 = ct + ax * (z0 - CENTRE_LOCAL) / 1000.0 - c0
    p1 = ct + ax * (z1 - CENTRE_LOCAL) / 1000.0 - c0
    return (f'<geom name="{nom}" type="cylinder" fromto="{p0[0]:.5f} {p0[1]:.5f} {p0[2]:.5f} {p1[0]:.5f} {p1[1]:.5f} {p1[2]:.5f}" '
            f'size="{rayon / 1000:.4f}" mass="{masse / 1000:.5f}" rgba="{couleur}" contype="0" conaffinity="0"/>')


def ecrire(corps, indent):
    sp = " " * indent
    c0 = centre(corps)
    if corps == "torse":
        a(f'{sp}<body name="torse" pos="0 0 0.002">')
        a(f'{sp}  <freejoint name="libre"/>')
    else:
        art = ART[corps]
        p0 = c0 - centre(art["parent"])
        cle = next(k for k in BORNES if corps.endswith(k))
        lo, hi = BORNES[cle]
        a(f'{sp}<body name="{corps}" pos="{p0[0]:.5f} {p0[1]:.5f} {p0[2]:.5f}">')
        ax = np.abs(act_axe[corps])             # même sens de charnière des deux côtés (les bornes sont asymétriques) ; la CAO du côté droit est en miroir
        a(f'{sp}  <joint name="{corps}" type="hinge" axis="{ax[0]:g} {ax[1]:g} {ax[2]:g}" range="{np.radians(lo):.4f} {np.radians(hi):.4f}"/>')
        a(f'  {sp}' + cylindre(corps + "-sortie", corps, ROTOR_Z[0], ROTOR_Z[1], masse_rotor[corps], "0.78 0.81 0.84 1", c0))
    for i in geoms_imprimes[corps]:
        M = np.array(i["matrice"], dtype=float).reshape(4, 4)
        pos = M[:3, 3] / 1000.0 - c0
        q = quat(M[:3, :3])
        contact = "" if "pied" in i["nom"] else ' contype="0" conaffinity="0"'
        frot = f' friction="{H["frottement_sol"]} 0.01 0.001" condim="3"'
        a(f'{sp}  <geom name="{i["nom"]}" type="mesh" mesh="{i["piece"]}" pos="{pos[0]:.5f} {pos[1]:.5f} {pos[2]:.5f}" '
          f'quat="{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}" mass="{masse_g(i["piece"]) / 1000:.5f}" rgba="{hexrgba(i["couleur"])}"{contact}{frot}/>')
    for e in enfants[corps]:                                        # le côté moteur de l'actionneur de chaque enfant est dans CE corps
        a(f'{sp}  ' + cylindre(e + "-moteur", e, BASE_Z[0], BASE_Z[1], masse_base[e], "0.14 0.15 0.17 1", c0))
    if corps == "torse":
        a(f'{sp}  <geom name="electronique" type="box" size="0.040 0.070 0.080" pos="-0.010 0 0.700" mass="{H["masse_electronique_g"] / 1000}" '
          f'contype="0" conaffinity="0" rgba="0.2 0.2 0.2 0.0"/>')
        a(f'{sp}  <site name="imu" pos="-0.050 0 0.800"/>')
    for e in enfants[corps]:
        ecrire(e, indent + 2)
    a(f'{sp}</body>')


a('<mujoco model="navitek-n2-cao">')
a('  <compiler angle="radian" meshdir="../navitek-n2/robot/web" autolimits="true"/>')
a('  <option timestep="0.0005" integrator="implicitfast"/>')
a(f'  <default><joint armature="{H["armature"]}" damping="{H["amortissement"]}"/></default>')
a('  <visual><global offwidth="1280" offheight="960"/><quality shadowsize="4096"/></visual>')
a('  <asset>')
for p in sorted({i["piece"] for g in geoms_imprimes.values() for i in g}):
    coque = ' inertia="shell"' if p in ("torse", "tete") else ""
    a(f'    <mesh name="{p}" file="{p}.stl" scale="0.001 0.001 0.001"{coque}/>')
a('    <texture name="damier" type="2d" builtin="checker" rgb1="0.93 0.92 0.89" rgb2="0.86 0.85 0.82" width="512" height="512"/>')
a('    <material name="sol" texture="damier" texrepeat="12 12"/>')
a('  </asset>')
a('  <worldbody>')
a('    <light pos="0.4 -0.4 1.8" dir="-0.3 0.3 -1" diffuse="0.9 0.9 0.9" castshadow="true"/>')
a(f'    <geom name="sol" type="plane" size="3 3 0.01" material="sol" friction="{H["frottement_sol"]} 0.01 0.001" condim="3"/>')
ecrire("torse", 4)
a('  </worldbody>')
a('  <actuator>')
tau = H["couple_blocage_Nm"]
noms = [k["nom"] for k in asm["articulations"]]
for art in noms:
    a(f'    <position name="{art}" joint="{art}" kp="{H["kp"]}" kv="{H["kv"]}" forcerange="{-tau:.4f} {tau:.4f}"/>')
a('  </actuator>')
a('  <sensor>')
a('    <framequat name="orientation" objtype="site" objname="imu"/>')
a('    <subtreecom name="centre_de_masse" body="torse"/>')
a('  </sensor>')
a('</mujoco>')
io.open(os.path.join(ICI, "n2cao.xml"), "w", encoding="utf-8").write("\n".join(xml))
tot = sum(masse_base.values()) + sum(masse_rotor.values()) + sum(masse_g(i["piece"]) for g in geoms_imprimes.values() for i in g) + H["masse_electronique_g"]
print(f"n2cao.xml : {len(noms)} articulations, masse totale {tot:.0f} g (imprimé et électronique estimés)")
print("masse base par actionneur (g) :", round(float(np.mean(list(masse_base.values()))), 1), "; masse sortie (g) :", round(float(np.mean(list(masse_rotor.values()))), 1))
