"""Navitek N2, CONCEPT : un actionneur à réducteur cycloïdal imprimé (16:1) et une jambe d'un humanoïde d'environ 1,1 m (08.11.2026).

    freecadcmd n2.py          (FreeCAD 1.1 ; sous Windows : "<dossier de FreeCAD>/bin/freecadcmd.exe" n2.py, lancé depuis cao/)

C'est un concept, pas un robot prêt à imprimer : les moteurs, les roulements, les goupilles et la visserie sont du commerce et ne sont
dessinés qu'en volume (pièces « du commerce ») ; le dimensionnement du réducteur (profil des lobes, nombre de goupilles) est celui
d'une cycloïde classique, mais AUCUN calcul de résistance n'est fait (R-039 : pas de donnée de résistance du PLA relevée ; R-040 donne
le couple demandé par la simulation). Rien ici n'a été imprimé ni essayé.

L'actionneur (axe z, sortie vers +z) : un moteur sans balais à rotor extérieur (volume), un boîtier imprimé qui porte NPINS goupilles
d'acier, un arbre excentrique à deux excentriques à 180°, deux disques cycloïdaux (NPINS - 1 lobes) et une bride de sortie imprimée
portant 6 axes qui traversent les disques. Rapport 16:1. Boîtier de 72 mm de diamètre : tout tient sur le plateau de 200 mm.

La jambe : cinq actionneurs (hanche-roulis, hanche-tangage, genou, cheville-tangage, cheville-roulis) reliés par des platines, un pied.
Sorties : stl-impression/, step/, web/ (pièces dans le repère de l'assemblage + assemblage.json).
"""
import json
import math
import os

import FreeCAD as App
import MeshPart
import Part

V = App.Vector
OUT = os.environ.get("NAVITEK_OUT", os.path.abspath(os.path.join(os.getcwd(), "..")))
ORANGE, GRIS, NOIR, ACIER, BLEU = "#f26b1d", "#7d838c", "#23262b", "#c9ced6", "#1d2a6b"

# --- le réducteur cycloïdal -----------------------------------------------------------------------------------------------
NPINS = 17          # goupilles du boîtier ; le disque a NPINS - 1 = 16 lobes : rapport 16:1
RP = 28.0           # rayon du cercle des goupilles
RPIN = 3.0          # rayon d'une goupille (6 mm : tige d'acier du commerce)
E = 1.2             # excentricité
TD = 8.0            # épaisseur d'un disque
HOUSE_R = 36.0      # rayon extérieur du boîtier
FLANGE_R = 33.0     # rayon de la bride de sortie
PHASE_B = float(os.environ.get('N2_PHASE_B', 11.25))   # le 2e disque : profil tourné d'un demi-pas de lobe (180 / 16)
NOUT = 6            # axes de sortie
ROUT, RPOUT = 14.0, 2.5     # cercle et rayon des axes de sortie
BORE = 9.5          # trou central d'un disque (siège du roulement de l'excentrique)
ECC_R = 7.5         # rayon de l'excentrique (le roulement du commerce est à choisir)
MOTOR_R, MOTOR_L = 31.0, 22.0   # le moteur sans balais : un volume (du commerce)
Z0, Z1 = 0.0, 36.0  # le boîtier, de z = 0 à z = 36 ; le moteur est en dessous


def cyl(r, z0, z1, x=0.0, y=0.0):
    return Part.makeCylinder(r, z1 - z0, V(x, y, z0))


def unir(formes):
    s = formes[0]
    for f in formes[1:]:
        s = s.fuse(f)
    return s.removeSplitter()


def contour_cycloidal(decal=0.0, n_pts=720):
    """Le profil du disque (cycloïde raccourcie), centré sur l'axe de l'excentrique."""
    pts = []
    for k in range(n_pts):
        th = 2 * math.pi * k / n_pts
        psi = math.atan2(math.sin((1 - NPINS) * th), RP / (E * NPINS) - math.cos((1 - NPINS) * th))
        x = RP * math.cos(th) - RPIN * math.cos(th + psi) - E * math.cos(NPINS * th)
        y = -RP * math.sin(th) + RPIN * math.sin(th + psi) + E * math.sin(NPINS * th)
        pts.append(V(x, y, 0))
    pts.append(pts[0])
    return pts


def disque(z0, z1, phase_deg):
    """Un disque cycloïdal, son trou central et ses 6 trous d'axes de sortie ; le PROFIL est tourné de phase_deg (les trous non)."""
    pts = contour_cycloidal()
    c, sn = math.cos(math.radians(phase_deg)), math.sin(math.radians(phase_deg))
    pts = [V(p.x * c - p.y * sn, p.x * sn + p.y * c, 0) for p in pts]
    face = Part.Face(Part.makePolygon(pts))
    s = face.extrude(V(0, 0, z1 - z0))
    s = s.cut(cyl(BORE, -1, z1 - z0 + 1))
    for k in range(NOUT):
        a = 2 * math.pi * k / NOUT
        s = s.cut(cyl(RPOUT + E + 0.2, -1, z1 - z0 + 1, ROUT * math.cos(a), ROUT * math.sin(a)))
    s.translate(V(0, 0, z0))
    return s.removeSplitter()


def boitier():
    s = cyl(HOUSE_R, Z0, Z1)
    s = s.cut(cyl(RP + 0.6, Z0 + 3.0, Z1 + 1))                         # la cavité, fond de 3 mm
    s = s.cut(cyl(11.0, Z0 - 1, Z0 + 4))                                # passage de l'arbre du moteur
    for k in range(NPINS):                                             # les gorges des goupilles
        a = 2 * math.pi * k / NPINS
        s = s.cut(cyl(RPIN + 0.1, Z0 + 2.0, Z1 + 1, RP * math.cos(a), RP * math.sin(a)))
    for k in range(6):                                                 # 6 trous M3 pour fixer le moteur et la platine
        a = math.pi / 6 + 2 * math.pi * k / 6
        s = s.cut(cyl(1.6, Z0 - 1, Z0 + 8, 31.0 * math.cos(a), 31.0 * math.sin(a)))
    return s.removeSplitter()


def arbre_excentrique():
    corps = cyl(5.0, Z0 + 3.0, Z1 - 4.0)
    ex_a = cyl(ECC_R, Z0 + 6.0, Z0 + 14.0, E, 0)
    ex_b = cyl(ECC_R, Z0 + 16.0, Z0 + 24.0, -E, 0)
    return unir([corps, ex_a, ex_b])


def bride_sortie():
    s = cyl(FLANGE_R, Z1 - 8.0, Z1)
    s = s.cut(cyl(11.0, Z1 - 9, Z1 + 1))                               # le passage du roulement de sortie
    for k in range(NOUT):
        a = 2 * math.pi * k / NOUT
        s = s.fuse(cyl(RPOUT, Z0 + 6.0, Z1 - 8.0, ROUT * math.cos(a), ROUT * math.sin(a)))
    for k in range(4):                                                 # 4 trous M3 pour fixer la platine de la jambe
        a = math.pi / 4 + k * math.pi / 2
        s = s.cut(cyl(1.6, Z1 - 9, Z1 + 1, 25.0 * math.cos(a), 25.0 * math.sin(a)))
    return s.removeSplitter()


def goupille():
    return cyl(RPIN, Z0 + 3.0, Z1 - 8.0)


def moteur():
    return unir([cyl(MOTOR_R, Z0 - MOTOR_L, Z0 - 1.0), cyl(4.0, Z0 - 1.0, Z0 + 5.0)])


# --- la jambe (repère : x vers l'avant, y vers la gauche, z vers le haut ; le sol à z = 0) --------------------------------
PAS = 80.0           # entre deux axes consécutifs d'une paire (rotule à deux axes)
LONG = 160.0         # cuisse et tibia, d'axe à axe
Z_CHEV_R = 46.0      # l'axe de la cheville-roulis, au-dessus du sol
LARGEUR_PLATINE = 44.0
ACT_L = Z1 + MOTOR_L   # longueur de l'actionneur (moteur compris) = 58 mm


def platine(p0, p1):
    """Une platine de liaison (boîte) entre deux points, dans le plan x = 0, de section LARGEUR_PLATINE × 8 mm."""
    z0, z1 = min(p0.z, p1.z), max(p0.z, p1.z)
    return Part.makeBox(8.0, LARGEUR_PLATINE, z1 - z0, V(-4.0, -LARGEUR_PLATINE / 2, z0))


def pied():
    s = Part.makeBox(190.0, 90.0, 8.0, V(-60.0, -45.0, 0.0))
    s = s.makeFillet(14.0, [e for e in s.Edges if abs(e.BoundBox.ZMax - e.BoundBox.ZMin) > 6])
    s = s.fuse(Part.makeBox(30.0, 50.0, Z_CHEV_R - 8.0 - HOUSE_R, V(-15.0, -25.0, 8.0)))
    return s.removeSplitter()


PIECES = {
    "boitier": boitier(), "excentrique": arbre_excentrique(), "disque-a": disque(Z0 + 6.0, Z0 + 14.0, 0.0),
    "disque-b": disque(Z0 + 16.0, Z0 + 24.0, PHASE_B), "bride-sortie": bride_sortie(), "goupille": goupille(), "moteur": moteur(),
    "platine-cuisse": platine(V(0, 0, 0), V(0, 0, LONG)), "platine-tibia": platine(V(0, 0, 0), V(0, 0, LONG)),
    "platine-pas": platine(V(0, 0, 0), V(0, 0, PAS)), "pied": pied(),
}
# un seul disque modélisé, le deuxième tourné de 180° autour de l'axe à la pose (les excentriques sont à 180°)
PIECES["disque-b"] = PIECES["disque-b"]
IMPRIMEES = ["boitier", "bride-sortie", "disque-a", "disque-b", "platine-cuisse", "platine-tibia", "platine-pas", "pied"]
COULEUR = {"boitier": ORANGE, "excentrique": ACIER, "disque-a": GRIS, "disque-b": GRIS, "bride-sortie": ORANGE, "goupille": ACIER,
           "moteur": NOIR, "platine-cuisse": GRIS, "platine-tibia": GRIS, "platine-pas": GRIS, "pied": ORANGE}

instances = []


def poser(nom, piece, pl, groupe):
    instances.append((nom, piece, App.Placement(pl.toMatrix()), groupe))


def placer_actionneur(nom, pl, groupe):
    poser(nom + "-moteur", "moteur", pl, groupe)
    poser(nom + "-boitier", "boitier", pl, groupe)
    poser(nom + "-excentrique", "excentrique", pl, groupe)
    poser(nom + "-disque-a", "disque-a", pl.multiply(App.Placement(V(E, 0, 0), App.Rotation())), groupe)
    # le deuxième disque est décalé de -E (excentrique opposé)
    poser(nom + "-disque-b", "disque-b", pl.multiply(App.Placement(V(-E, 0, 0), App.Rotation())), groupe)
    poser(nom + "-bride", "bride-sortie", pl, groupe)
    for k in range(NPINS):
        a = 2 * math.pi * k / NPINS
        poser(f"{nom}-goupille-{k}", "goupille", pl.multiply(App.Placement(V(RP * math.cos(a), RP * math.sin(a), 0), App.Rotation())), groupe)


def axe_vers(axe):
    """Placement dont l'axe z local est 'axe' (un des axes du monde)."""
    z = V(*axe)
    if abs(z.x) == 1:
        return App.Placement(V(0, 0, 0), App.Rotation(V(0, 1, 0), 90 * z.x))
    if abs(z.y) == 1:
        return App.Placement(V(0, 0, 0), App.Rotation(V(1, 0, 0), -90 * z.y))
    return App.Placement()


def actionneur_en(centre, axe):
    # le centre de l'actionneur est au milieu du boîtier (z = 18 local) : on place l'origine locale pour que ce milieu tombe sur 'centre'
    pl = axe_vers(axe)
    dec = pl.Rotation.multVec(V(0, 0, (Z0 + Z1) / 2))
    return App.Placement(V(centre.x - dec.x, centre.y - dec.y, centre.z - dec.z), pl.Rotation)


def jambe():
    g = "jambe"
    z_c = Z_CHEV_R
    zs = {"cheville-roulis": z_c, "cheville-tangage": z_c + PAS}
    zs["genou"] = zs["cheville-tangage"] + LONG
    zs["hanche-tangage"] = zs["genou"] + LONG
    zs["hanche-roulis"] = zs["hanche-tangage"] + PAS
    axes = {"cheville-roulis": (1, 0, 0), "cheville-tangage": (0, 1, 0), "genou": (0, 1, 0), "hanche-tangage": (0, 1, 0), "hanche-roulis": (1, 0, 0)}
    for nom, z in zs.items():
        placer_actionneur(nom, actionneur_en(V(0, 0, z), axes[nom]), g)
    poser("pied", "pied", App.Placement(), g)
    # les platines : de l'axe d'un actionneur à l'axe du suivant (le long de z), côté +x de l'actionneur pour ne pas le traverser
    def plat(nom, piece, za, zb, dx):
        poser(nom, piece, App.Placement(V(dx, 0, za), App.Rotation()), g)
    plat("platine-cheville", "platine-pas", zs["cheville-roulis"], zs["cheville-tangage"], HOUSE_R + 6.0)
    plat("platine-tibia", "platine-tibia", zs["cheville-tangage"], zs["genou"], HOUSE_R + 6.0)
    plat("platine-cuisse", "platine-cuisse", zs["genou"], zs["hanche-tangage"], HOUSE_R + 6.0)
    plat("platine-hanche", "platine-pas", zs["hanche-tangage"], zs["hanche-roulis"], HOUSE_R + 6.0)
    return zs


zs = jambe()


def maillage(forme, chemin):
    m = MeshPart.meshFromShape(Shape=forme, LinearDeflection=0.04, AngularDeflection=0.3, Relative=False)
    m.write(chemin)
    return m.CountFacets


for d in ("stl-impression", "step", "web"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)
resume = []
for nom, forme in PIECES.items():
    assert forme.isValid(), nom
    forme.exportStep(os.path.join(OUT, "step", nom + ".step"))
    maillage(forme, os.path.join(OUT, "web", nom + ".stl"))
    if nom in IMPRIMEES:
        f = forme.copy()
        if nom == "bride-sortie":                      # imprimée la bride à plat sur le plateau, les axes vers le haut (sinon 66 mm de pont sans appui)
            f.Placement = App.Placement(V(0, 0, 0), App.Rotation(V(1, 0, 0), 180)).multiply(f.Placement)
            f = f.copy()
        bb = f.BoundBox
        f.translate(V(-(bb.XMin + bb.XMax) / 2, -(bb.YMin + bb.YMax) / 2, -bb.ZMin))
        bb = f.BoundBox
        maillage(f, os.path.join(OUT, "stl-impression", nom + ".stl"))
        resume.append({"piece": nom, "quantite": sum(1 for i in instances if i[1] == nom), "x": round(bb.XLength, 1), "y": round(bb.YLength, 1),
                       "z": round(bb.ZLength, 1), "volume_cm3": round(forme.Volume / 1000, 2)})
tout = []
for n, p, pl, g in instances:
    f = PIECES[p].copy()
    f.Placement = pl.multiply(f.Placement)
    tout.append(f)
Part.makeCompound(tout).exportStep(os.path.join(OUT, "step", "n2-jambe.step"))
bb = Part.makeCompound(tout).BoundBox
json.dump({
    "robot": "Navitek N2 (concept : une jambe)", "date": "2026-11-08", "unites": "mm",
    "encombrement": [round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1)],
    "instances": [{"nom": n, "piece": p, "couleur": COULEUR[p], "groupe": g, "imprimee": p in IMPRIMEES,
                   "matrice": [round(v, 5) for v in pl.toMatrix().A]} for n, p, pl, g in instances],
    "pieces": resume,
}, open(os.path.join(OUT, "web", "assemblage.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ENCOMBREMENT", round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1), "mm ;", len(instances), "instances ; axes z", {k: round(v, 1) for k, v in zs.items()})
for r in resume:
    print("PIECE", r)

# --- contrôle des collisions entre pièces imprimées et du commerce de VOISINS non prévus ---------------------------------
if os.environ.get("N2_COLLISIONS"):
    vus = 0
    for i in range(len(instances)):
        for j in range(i + 1, len(instances)):
            (na, pa, _, ga), (nb, pb, _, gb) = instances[i], instances[j]
            fa, fb = tout[i], tout[j]
            # dans un même actionneur, les pièces s'emboîtent par conception : on ne les compare pas
            grp = lambda n: next((k for k in zs if n.startswith(k + "-")), n)
            if grp(na) == grp(nb):
                continue
            if not fa.BoundBox.intersect(fb.BoundBox):
                continue
            vus += 1
            v = fa.common(fb).Volume
            if v > 1.0:
                print("COLLISION", na, "x", nb, round(v, 1), "mm3")
    print("COLLISIONS : paires examinées", vus)

# --- contrôle des disques contre les goupilles, dans UN actionneur (N2_INTRA=1) : une cycloïde bien engrenée touche, sans mordre ---------------
if os.environ.get("N2_INTRA"):
    nom = "genou"
    pires = {}
    for (n, p, pl, g), f in zip(instances, tout):
        if n.startswith(nom + "-disque"):
            for (n2, p2, pl2, g2), f2 in zip(instances, tout):
                if n2.startswith(nom + "-goupille"):
                    v = f.common(f2).Volume
                    pires[n] = max(pires.get(n, 0.0), v)
    print("INTRA disque x goupille, volume de morsure maximal (mm3) :", {k: round(v, 3) for k, v in pires.items()}, "phase B", PHASE_B)
