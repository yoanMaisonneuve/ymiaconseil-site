"""Navitek N2, le ROBOT ENTIER en CAO (B25, 09.11.2026) : bassin, torse, deux jambes, deux bras, cou et tête, tous les actionneurs du même module cycloïdal 16:1.

    freecadcmd n2_robot.py          (lancé depuis cao/ ; sorties dans ../robot/ : web/, step/, stl-impression/)

Réutilise tout ce que n2.py définit (l'actionneur, la platine, le pied) en exécutant sa première partie, sans toucher aux sorties de la jambe
seule. CONCEPT, comme n2.py : rien n'est imprimé, aucun calcul de résistance. Les bras et le cou reprennent le MÊME actionneur que les jambes,
par simplicité (R-040 : les bras demandent au plus 2,7 N·m et le cou 0,1 N·m : un actionneur plus petit conviendrait).

Chaque pièce porte un CORPS (le segment rigide auquel elle appartient) : le côté moteur d'un actionneur (moteur, boîtier, goupilles) appartient au
corps de son parent ; le côté sortie (excentrique, disques, bride), la platine qui suit et le côté moteur de l'actionneur suivant appartiennent au
corps de l'articulation. assemblage.json liste ces corps et les articulations (centre, axe), pour que le modèle MuJoCo (modele_n2_cao.py) soit tiré de la CAO.
Repère : x vers l'avant, y vers la gauche, z vers le haut ; le sol à z = 0.
"""
import json
import math
import os

_src = open("n2.py", encoding="utf-8").read()
_coupe = _src.index("zs = jambe()")
os.environ.setdefault("NAVITEK_OUT", os.path.abspath(os.path.join(os.getcwd(), "..", "robot")))
exec(compile(_src[:_coupe], "n2.py", "exec"))      # définit V, Part, App, MeshPart, PIECES, poser, actionneur_en, constantes...

HIP_Y = 90.0            # axe de chaque jambe, de part et d'autre du plan médian
Z_HANCHE = Z_CHEV_R + 2 * PAS + 2 * LONG          # hanche-roulis (526 mm)
PLAT_X = HOUSE_R + 6.0
EP_Y = 152.0            # axe des épaules
Z_EPAULE = 800.0
PAS_BRAS, LONG_BRAS = 80.0, 110.0
Z_COU = 920.0

# --- les pièces nouvelles -------------------------------------------------------------------------------------------------------


def coque(x0, x1, y0, y1, z0, z1, e=2.4):
    """Une boîte creuse (coque fermée de e mm) : une pièce imprimée à parois minces."""
    s = Part.makeBox(x1 - x0, y1 - y0, z1 - z0, V(x0, y0, z0))
    return s.cut(Part.makeBox(x1 - x0 - 2 * e, y1 - y0 - 2 * e, z1 - z0 - 2 * e, V(x0 + e, y0 + e, z0 + e)))


def plat(x0, x1, y0, y1, z0, z1):
    return Part.makeBox(x1 - x0, y1 - y0, z1 - z0, V(x0, y0, z0))


NOUV = {
    "bassin": plat(-72.0, -40.0, -135.0, 135.0, Z_HANCHE - 36.0, Z_HANCHE + 36.0),
    "torse": coque(-72.0, 30.0, -112.0, 112.0, Z_HANCHE + 36.0, 880.0),
    "tete": coque(-60.0, 50.0, -55.0, 55.0, Z_COU + 18.0, Z_COU + 18.0 + 122.0),
    "main": plat(26.0, 66.0, -22.0, 22.0, 0.0, 90.0),
}
for k, f in NOUV.items():
    assert f.isValid(), k
PIECES.update(NOUV)
IMPRIMEES += ["bassin", "torse", "tete", "main"]
COULEUR.update({"bassin": GRIS, "torse": ORANGE, "tete": ORANGE, "main": NOIR})
PIECES["platine-bras"] = platine(V(0, 0, 0), V(0, 0, PAS_BRAS))
PIECES["platine-long-bras"] = platine(V(0, 0, 0), V(0, 0, LONG_BRAS))
IMPRIMEES += ["platine-bras", "platine-long-bras"]
COULEUR.update({"platine-bras": GRIS, "platine-long-bras": GRIS})

# --- l'assemblage : des corps et des articulations --------------------------------------------------------------------------------
instances.clear()
articulations = []          # {nom, corps, parent, centre, axe}
corps_liste = ["torse"]


def poser_actionneur(nom, centre, axe, parent, corps):
    """Côté moteur → corps 'parent' ; côté sortie → corps 'corps' (l'articulation porte le nom du corps)."""
    pl = actionneur_en(V(*centre), axe)
    for suffixe, piece in (("moteur", "moteur"), ("boitier", "boitier")):
        poser(f"{nom}-{suffixe}", piece, pl, parent)
    for k in range(NPINS):
        a = 2 * math.pi * k / NPINS
        poser(f"{nom}-goupille-{k}", "goupille", pl.multiply(App.Placement(V(RP * math.cos(a), RP * math.sin(a), 0), App.Rotation())), parent)
    poser(nom + "-excentrique", "excentrique", pl, corps)
    poser(nom + "-disque-a", "disque-a", pl.multiply(App.Placement(V(E, 0, 0), App.Rotation())), corps)
    poser(nom + "-disque-b", "disque-b", pl.multiply(App.Placement(V(-E, 0, 0), App.Rotation())), corps)
    poser(nom + "-bride", "bride-sortie", pl, corps)
    articulations.append({"nom": corps, "corps": corps, "parent": parent, "centre": list(centre), "axe": list(axe)})
    corps_liste.append(corps)


def poser_platine(nom, piece, z_haut, x, y, corps, z_bas=None):
    """Une platine descendante : son origine est à son z bas."""
    poser(nom, piece, App.Placement(V(x, y, z_bas), App.Rotation()), corps)


def jambe(cote):
    sy = 1 if cote == "gauche" else -1
    y = sy * HIP_Y
    pre = f"jambe-{cote}-"
    z = {"cheville-roulis": Z_CHEV_R, "cheville-tangage": Z_CHEV_R + PAS}
    z["genou"] = z["cheville-tangage"] + LONG
    z["hanche-tangage"] = z["genou"] + LONG
    z["hanche-roulis"] = z["hanche-tangage"] + PAS
    axes = {"hanche-roulis": (1, 0, 0), "hanche-tangage": (0, sy, 0), "genou": (0, sy, 0), "cheville-tangage": (0, sy, 0), "cheville-roulis": (-1, 0, 0)}
    # 09.11 (R-054) : la cheville de côté retournée (axe −x) : son moteur passe devant, la platine de cheville derrière ne le traverse plus
    ordre = ["hanche-roulis", "hanche-tangage", "genou", "cheville-tangage", "cheville-roulis"]
    parent = "torse"
    for art in ordre:
        corps = pre + art
        poser_actionneur(corps, (0, y, z[art]), axes[art], parent, corps)
        parent = corps
    # platines : sous l'actionneur d'en haut, dans son corps ; (pièce, de l'actionneur d'en haut à celui du dessous, face : +1 devant, -1 derrière)
    # 09.11 (R-054) : ALTERNÉES. Toutes devant, bout à bout, la platine du dessous entrait dans celle du dessus dès 1° à chaque axe de tangage.
    for haut, bas, piece, face in (("hanche-roulis", "hanche-tangage", "platine-pas", 1), ("hanche-tangage", "genou", "platine-cuisse", -1),
                                   ("genou", "cheville-tangage", "platine-tibia", 1), ("cheville-tangage", "cheville-roulis", "platine-pas", -1)):
        poser(f"{pre}platine-{haut}", piece, App.Placement(V(face * PLAT_X, y, z[bas]), App.Rotation()), pre + haut)
    poser(pre + "pied", "pied", App.Placement(V(0, y, 0), App.Rotation()), pre + "cheville-roulis")


def bras(cote):
    sy = 1 if cote == "gauche" else -1
    y = sy * EP_Y
    pre = f"bras-{cote}-"
    z_r, z_c = Z_EPAULE - PAS_BRAS, Z_EPAULE - PAS_BRAS - LONG_BRAS
    for art, z, axe, parent in (("epaule-tangage", Z_EPAULE, (0, sy, 0), "torse"), ("epaule-roulis", z_r, (1, 0, 0), pre + "epaule-tangage"),
                                ("coude", z_c, (0, sy, 0), pre + "epaule-roulis")):
        poser_actionneur(pre + art, (0, y, z), axe, parent, pre + art)
    poser(pre + "platine-epaule", "platine-bras", App.Placement(V(PLAT_X, y, z_r), App.Rotation()), pre + "epaule-tangage")
    poser(pre + "platine-bras", "platine-long-bras", App.Placement(V(PLAT_X, y, z_c), App.Rotation()), pre + "epaule-roulis")
    poser(pre + "platine-avant-bras", "platine-long-bras", App.Placement(V(PLAT_X, y, z_c - LONG_BRAS), App.Rotation()), pre + "coude")
    poser(pre + "main", "main", App.Placement(V(0, y, z_c - LONG_BRAS - 90.0), App.Rotation()), pre + "coude")


def tete():
    poser_actionneur("cou", (0, 0, Z_COU), (0, 0, 1), "torse", "cou")
    poser("tete", "tete", App.Placement(), "cou")


for cote in ("gauche", "droite"):
    jambe(cote)
    bras(cote)
tete()
poser("bassin", "bassin", App.Placement(), "torse")
poser("torse", "torse", App.Placement(), "torse")

# --- les sorties -------------------------------------------------------------------------------------------------------------------
for d in ("stl-impression", "step", "web"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)


def maillage(forme, chemin):
    m = MeshPart.meshFromShape(Shape=forme, LinearDeflection=0.04, AngularDeflection=0.3, Relative=False)
    m.write(chemin)
    return m.CountFacets


volumes, resume = {}, []
for nom, forme in PIECES.items():
    assert forme.isValid(), nom
    volumes[nom] = round(forme.Volume / 1000, 3)
    maillage(forme, os.path.join(OUT, "web", nom + ".stl"))
    if nom in IMPRIMEES:
        f = forme.copy()
        if nom == "bride-sortie":
            f.Placement = App.Placement(V(0, 0, 0), App.Rotation(V(1, 0, 0), 180)).multiply(f.Placement)
            f = f.copy()
        bb = f.BoundBox
        f.translate(V(-(bb.XMin + bb.XMax) / 2, -(bb.YMin + bb.YMax) / 2, -bb.ZMin))
        bb = f.BoundBox
        maillage(f, os.path.join(OUT, "stl-impression", nom + ".stl"))
        resume.append({"piece": nom, "quantite": sum(1 for i in instances if i[1] == nom), "x": round(bb.XLength, 1), "y": round(bb.YLength, 1),
                       "z": round(bb.ZLength, 1), "volume_cm3": volumes[nom]})
tout = []
for n, p, pl, g in instances:
    f = PIECES[p].copy()
    f.Placement = pl.multiply(f.Placement)
    tout.append(f)
comp = Part.makeCompound(tout)
comp.exportStep(os.path.join(OUT, "step", "n2-robot.step"))
bb = comp.BoundBox
json.dump({
    "robot": "Navitek N2 (concept : le robot entier)", "date": "2026-11-09", "unites": "mm",
    "encombrement": [round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1)], "z_min": round(bb.ZMin, 1), "z_max": round(bb.ZMax, 1),
    "corps": corps_liste, "articulations": articulations, "volumes_cm3": volumes,
    "instances": [{"nom": n, "piece": p, "couleur": COULEUR[p], "groupe": g, "imprimee": p in IMPRIMEES,
                   "matrice": [round(v, 5) for v in pl.toMatrix().A]} for n, p, pl, g in instances],
    "pieces": resume,
}, open(os.path.join(OUT, "web", "assemblage.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ROBOT", len(instances), "instances,", len(articulations), "articulations ; encombrement", [round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1)],
      "z de", round(bb.ZMin, 1), "à", round(bb.ZMax, 1))
for r in resume:
    print("PIECE", r)

if os.environ.get("N2_COLLISIONS"):
    vus, coll = 0, 0
    act = lambda n: n.rsplit("-", 1)[0] if "-goupille-" not in n else n.split("-goupille-")[0]
    parties = ("-moteur", "-boitier", "-excentrique", "-disque-a", "-disque-b", "-bride")
    grp = lambda n: next((n[: -len(s)] for s in parties if n.endswith(s)), n.split("-goupille-")[0] if "-goupille-" in n else n)
    for i in range(len(instances)):
        for j in range(i + 1, len(instances)):
            na, nb = instances[i][0], instances[j][0]
            if grp(na) == grp(nb):
                continue
            if not tout[i].BoundBox.intersect(tout[j].BoundBox):
                continue
            vus += 1
            v = tout[i].common(tout[j]).Volume
            if v > 1.0:
                coll += 1
                print("COLLISION", na, "x", nb, round(v, 1), "mm3")
    print("COLLISIONS : paires examinées", vus, "; en collision", coll)
