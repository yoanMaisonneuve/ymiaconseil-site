"""R-139 — apprendre sur la carte graphique de la tour : 4 096 N3 à la fois (MuJoCo Warp), un PPO écrit à la main (PyTorch, CUDA).

L'environnement reprend celui de R-137 (essai_n3_rl.N3Marche) : la marche de la sprinteuse en référence, la correction (±15° aux
jambes, ±30° aux bras, ±10° au cou), les 67 observations dans le même ordre, les poussées, l'épisode de 10 s. Le modèle : n3-gpu.xml
(les pieds en boîtes). La configuration (la référence, les noms, les signes) vient du portable : config-n3.json (gpu/preparer.py).

Sur la tour :  E:\\navitek-gpu\\venv\\Scripts\\python rl_gpu.py valider
               E:\\navitek-gpu\\venv\\Scripts\\python rl_gpu.py apprendre <nom> <millions> [A|B] [nworld]
Récompense A : celle de R-137. B : A, plus le pied libre qui se lève (jusqu'à 5 cm) et un coût pour le pied d'appui qui glisse.
Tout est simulé."""
import json
import math
import os
import sys
import time

import mujoco
import numpy as np
import torch
import torch.nn as nn
import warp as wp
import mujoco_warp as mjw

ICI = os.path.dirname(os.path.abspath(__file__))
DEV = "cuda:0"
CFG = json.load(open(os.path.join(ICI, "config-n3.json"), encoding="utf-8"))
DT_C, DUREE, CIBLE, V_CIBLE = CFG["DT_C"], CFG["DUREE"], CFG["CIBLE"], CFG["V_CIBLE"]
DEMI_EPAISSEUR = 0.0077                                       # la demi-épaisseur de la semelle en boîte (pieds_boites.py)


def modele(mains=False):
    defaut = "n3-gpu-sprint.xml" if mains else "n3-gpu.xml"            # R-146 : les mains en boîtes, elles touchent le sol au départ
    m = mujoco.MjModel.from_xml_path(os.path.join(ICI, os.environ.get("N3_GPU_XML", defaut)))   # R-142 : n3-gpu-barres.xml
    for g in range(m.ngeom):
        n = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, g) or ""
        if n != "sol" and "pied" not in n and not n.startswith("barre") and not (mains and n.endswith("-main")):
            m.geom_contype[g] = 0
            m.geom_conaffinity[g] = 0
    return m


def fb2_avant(W):
    """L'inclinaison avant du torse (degrés, + = vers l'avant), lue après le pas."""
    R = W.xmat[:, 1]
    return -torch.rad2deg(torch.asin(torch.clamp(R[:, 2, 0], -1, 1)))


class Monde:
    """nworld N3 sur la carte ; tout l'état est vu par PyTorch sans copie."""

    def __init__(self, nworld, recompense="A", pousses=True, graine=0):
        wp.init()
        self.N, self.rec, self.pousses = nworld, recompense, pousses
        self.gen = torch.Generator(device=DEV)
        self.gen.manual_seed(graine)
        self.sprint = recompense in ("S", "S2", "S3", "S4", "S5", "S6", "S7")  # R-146 : les départs du sprint (2, 3 ou 4 appuis), 2,5 m en ligne droite
        self.honnete = recompense in ("S2", "S3", "S4", "S5", "S6", "S7")
        self.eliminatoire = recompense in ("S3", "S4", "S5", "S6", "S7")  # R-146 S3 (E72) : la faute (même pied, deux pieds, vol long) finit l'essai
        self.saut = recompense in ("L", "L3", "L4")              # R-147 : le saut en longueur (sans élan, et avec 1,5 m d'élan)
        self.saut_ref = recompense == "L4"                       # R-147 L4 : le saut scripté comme référence (saut-reference.json)
        if self.saut_ref:
            self.P_saut = json.load(open(os.path.join(ICI, "saut-reference.json"), encoding="utf-8"))["reglages"]
        mjm = modele(mains=self.sprint)
        self.mjm = mjm
        assert [mujoco.mj_id2name(mjm, mujoco.mjtObj.mjOBJ_ACTUATOR, i) for i in range(mjm.nu)] is not None
        mjd = mujoco.MjData(mjm)
        mujoco.mj_forward(mjm, mjd)
        self.m = mjw.put_model(mjm)
        self.d = mjw.put_data(mjm, mjd, nworld=nworld, nconmax=20 if self.sprint else 12, njmax=96 if self.sprint else 64, nccdmax=1)
        T = lambda a: wp.to_torch(a)
        self.qpos, self.qvel, self.ctrl = T(self.d.qpos), T(self.d.qvel), T(self.d.ctrl)
        self.xmat, self.subtree_com, self.xfrc = T(self.d.xmat), T(self.d.subtree_com), T(self.d.xfrc_applied)
        self.geom_xpos = T(self.d.geom_xpos)
        self.geom_xmat = T(self.d.geom_xmat)
        self.qacc_ws = T(self.d.qacc_warmstart)
        art = mjm.actuator_trnid[:, 0]
        self.jq = torch.tensor([mjm.jnt_qposadr[j] for j in art], device=DEV)
        self.jv = torch.tensor([mjm.jnt_dofadr[j] for j in art], device=DEV)
        self.qpos0 = torch.tensor(mjm.qpos0, dtype=torch.float32, device=DEV)
        self.nu = mjm.nu
        self.noms = CFG["noms"]
        self.sg = torch.tensor(CFG["signes"], device=DEV)
        self.ech = torch.tensor(CFG["ech"], device=DEV)
        self.imit_w = 0.0 if recompense in ("K", "M", "S", "S2", "S3", "S4", "S5", "S6", "S7", "L", "L3", "L4") else 0.5   # E69 : ressembler à la sprinteuse coûte plus que le genou ne rapporte ; pas d'imitation pour K et M
        if recompense in ("K", "M"):                             # E68 : ±15° ne laisse pas plier la hanche au-delà d'environ 35° ; ±70° pour le high knee et la marche
            for n in ("hanche_tangage_g", "hanche_tangage_d", "genou_g", "genou_d"):
                self.ech[CFG["noms"].index(n)] = 70.0
        if recompense == "M":                                    # E70 : le bras suit 1,2 fois la cuisse opposée (jusqu'à 80°) ; ±30° ne l'atteint pas
            for n in ("epaule_tangage_g", "epaule_tangage_d"):
                self.ech[CFG["noms"].index(n)] = 80.0
        if (self.sprint and recompense not in ("S6", "S7")) or (self.saut and recompense != "L4"):   # R-146 : se relever d'un départ accroupi demande de grands gestes (E68) ; R-147 : sauter aussi ; S6 (E76) : non
            for n in ("hanche_tangage_g", "hanche_tangage_d", "genou_g", "genou_d", "cheville_tangage_g", "cheville_tangage_d", "coude_g", "coude_d"):
                self.ech[CFG["noms"].index(n)] = 45.0
            for n in ("epaule_tangage_g", "epaule_tangage_d"):
                self.ech[CFG["noms"].index(n)] = 60.0
        if self.saut and recompense != "L4":                     # R-147 : s'accroupir pour sauter (le genou à 60° au moins, E68)
            for n in ("hanche_tangage_g", "hanche_tangage_d", "genou_g", "genou_d", "cheville_tangage_g", "cheville_tangage_d"):
                self.ech[CFG["noms"].index(n)] = 60.0
        self.jambes = torch.tensor(CFG["jambes"], device=DEV)
        self.p = [float(x) for x in CFG["p"]]
        self.h0 = CFG["h0"]
        self.idx = {n: i for i, n in enumerate(self.noms)}
        self.pieds = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "jambe-%s-pied" % c) for c in ("gauche", "droite")]
        self.demi_pied = torch.tensor(mjm.geom_size[self.pieds], dtype=torch.float32, device=DEV)   # (2, 3) : les demi-tailles des boîtes
        self.n_sub = int(round(DT_C / mjm.opt.timestep))
        mjw.step(self.m, self.d)                                # compile
        wp.synchronize()
        with wp.ScopedCapture() as cap:
            for _ in range(self.n_sub):
                mjw.step(self.m, self.d)
        self.graphe_pas = cap.graph
        with wp.ScopedCapture() as cap2:
            mjw.forward(self.m, self.d)
        self.graphe_avant = cap2.graph
        z = lambda *s: torch.zeros(*s, device=DEV)
        self.t, self.th = z(nworld), z(nworld)
        self.a_prev = z(nworld, self.nu)
        self.t_pousse, self.fin_pousse = z(nworld), z(nworld) - 1.0
        self.cm_prec = z(nworld, 2)
        self.pied_prec = z(nworld, 2, 2)
        self.c_ref = z(nworld, self.nu)
        self.ret, self.long = z(nworld), z(nworld)
        self.commande = recompense in ("C", "D", "E", "F", "G", "O", "K", "M", "P")  # R-140 : cap et vitesse ; R-142 E, O : barres ; R-141 F, G : courir ; R-143 K : high knee ; R-144 M : marche militaire
        self.oeil = recompense == "O"                            # R-142 O : la distance et la hauteur de la prochaine barre, dans ce que voit le réseau
        if self.oeil:
            bx, bh = [], []
            for g in range(mjm.ngeom):
                if (mujoco.mj_id2name(mjm, mujoco.mjtObj.mjOBJ_GEOM, g) or "").startswith("barre"):
                    bx.append(float(mjm.geom_pos[g][0]))
                    bh.append(2.0 * float(mjm.geom_size[g][2]))
            self.barres_x = torch.tensor(bx, device=DEV)
            self.barres_h = torch.tensor(bh, device=DEV)
        self.lever_max = 0.25 if recompense == "O" else (0.15 if recompense == "E" else (0.10 if recompense in ("C", "D", "F", "G") else 0.05))
        self.freq = recompense in ("D", "F", "G", "K", "P", "S", "S2", "S3", "S4", "S5", "S6", "S7", "L", "L3", "L4")  # R-140 D : la course ; le réseau règle aussi la cadence (une action de plus)
        if recompense in ("K", "M"):                             # R-143, R-144 : la hanche et le genou de chaque jambe (leurs axes), pour le genou haut
            self.xanchor = T(self.d.xanchor)
            JJ = lambda n: mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_JOINT, n)
            self.j_hanche = [JJ("jambe-%s-hanche-tangage" % c) for c in ("gauche", "droite")]
            self.j_genou = [JJ("jambe-%s-genou" % c) for c in ("gauche", "droite")]
        self.v_max = 1.5 if recompense in ("D", "F", "G", "P") else (0.6 if recompense == "M" else 0.8)
        self.t_air = z(nworld)
        self.ema = z(nworld, 2) + 0.5
        self.t_air = z(nworld)                                   # R-141 F : le temps passé les deux pieds en l'air, d'affilée
        self.ema = z(nworld, 2) + 0.5                            # R-141 F : la part de temps de chaque pied au sol (moyenne glissante)
        self.na = self.nu + (1 if self.freq else 0) + (1 if self.sprint else 0)   # S : l'action nu règle la vitesse de relevée (beta)
        self.a_prev = z(nworld, self.na)
        self.duree = 4.0 if (self.sprint or self.saut) else DUREE
        self.sans_reinit = False                                 # le banc : pas de remise à zéro automatique
        self.juge_libre = False                                  # R-146 : le banc « style libre » (pas de règle d'allure)
        if self.sprint:
            Dp = json.load(open(os.path.join(ICI, "departs-n3.json"), encoding="utf-8"))
            cles = ["2 appuis", "3 appuis", "4 appuis"]
            self.q_appui = torch.tensor([Dp[k]["gpu"]["qpos"] for k in cles], dtype=torch.float32, device=DEV)      # (3, nq), la ligne à x = 0
            self.c_appui = torch.tensor([Dp[k]["gpu"]["ctrl"] for k in cles], dtype=torch.float32, device=DEV)      # (3, nu), radians
            self.pose_appui = torch.rad2deg(self.c_appui) * self.sg[None]                                           # degrés de main
            self.appui = torch.arange(nworld, device=DEV) % 3                                                       # 0 : 2 appuis ; 1 : 3 ; 2 : 4
            self.beta = z(nworld)
            self.t15, self.t8, self.nb_pas = z(nworld) - 1.0, z(nworld) - 1.0, z(nworld)
            self.touche_prec = torch.ones(nworld, 2, dtype=torch.bool, device=DEV)
            self.air_pied, self.x_decol = z(nworld, 2), z(nworld, 2)       # le temps en l'air de chaque pied ; son x au décollage
            self.pas_valide = torch.zeros(nworld, 2, dtype=torch.bool, device=DEV)
            self.dernier_pied, self.t_dernier, self.t_arr = z(nworld) - 1.0, z(nworld) - 1.0, z(nworld) - 1.0
            self.autre_touche = torch.zeros(nworld, dtype=torch.bool, device=DEV)   # E80 v3 : l'autre pied a touché depuis le dernier pas
            self.ev_deux = torch.zeros(nworld, dtype=torch.bool, device=DEV)      # deux pieds posés ensemble (un bond)
            self.ev_meme = torch.zeros(nworld, dtype=torch.bool, device=DEV)      # le même pied deux fois de suite (un saut à cloche-pied)
            self.dernier_tombe = torch.zeros(nworld, dtype=torch.bool, device=DEV)
        if self.saut:
            mujoco.mj_forward(mjm, mjd)
            pointe = max(float(mjd.geom_xpos[g][0] + np.abs(mjd.geom_xmat[g].reshape(3, 3)[0]) @ mjm.geom_size[g]) for g in self.pieds)
            self.x0_saut = torch.tensor([-pointe - 0.05, -pointe - 0.05 - 1.5], device=DEV)   # la racine : la pointe 5 cm derrière la ligne ; avec 1,5 m d'élan
            self.epreuve = torch.arange(nworld, device=DEV) % 2                                 # 0 : sans élan ; 1 : avec élan
            if recompense in ("L3", "L4"):                                                      # L3 (E77) : sans élan seulement
                self.epreuve = torch.zeros(nworld, dtype=torch.long, device=DEV)
            self.saute = torch.zeros(nworld, dtype=torch.bool, device=DEV)
            self.t_pose, self.marque, self.vx_appel, self.vol_saut = z(nworld) - 1.0, z(nworld) - 9.0, z(nworld), z(nworld)
            self.mordu = torch.zeros(nworld, dtype=torch.bool, device=DEV)
            self.dernier_tombe = torch.zeros(nworld, dtype=torch.bool, device=DEV)
        if self.sprint:                                          # E80 : les mains (en boîtes) comptent comme appui pour le vol
            self.mains = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "bras-%s-main" % c) for c in ("gauche", "droit")]
            self.demi_main = torch.tensor(mjm.geom_size[self.mains], dtype=torch.float32, device=DEV)
        self.cap_cmd, self.v_cmd, self.t_cmd = z(nworld), z(nworld) + V_CIBLE, z(nworld)
        self.reinit(torch.ones(nworld, dtype=torch.bool, device=DEV))

    # --- la marche de la sprinteuse (essai_n3_base.pose_phase), pour tous les mondes à la fois ; renvoie les consignes en radians
    def attitude(self):
        R = self.xmat[:, 1]
        avant = -torch.rad2deg(torch.asin(torch.clamp(R[:, 2, 0], -1, 1)))
        roulis = torch.rad2deg(torch.asin(torch.clamp(R[:, 2, 1], -1, 1)))
        return avant, roulis, torch.rad2deg(self.qvel[:, 4]), torch.rad2deg(self.qvel[:, 3])

    def reference(self, fb):
        T_, ah, h0, kb, ak, pk, aa, pa, rg, rd, pr, gt, gtv, gr, grv = self.p
        a, r, va, vr = fb
        av = a - CIBLE
        montee = torch.clamp(self.t / 1.5, max=1.0)
        if self.saut:                                           # R-147 : sans élan, la référence reste debout ; avec élan, la foulée en 0,5 s
            montee = torch.clamp(self.t / 0.5, max=1.0) * self.epreuve.float()
        if self.sprint:                                         # R-146 : la foulée arrive avec la relevée ; la correction d'équilibre aussi
            b = self.beta
            av, r, va, vr = torch.clamp(av, -8.0, 8.0) * b, r * b, va * b, vr * b
            montee = b
        th = self.th
        pose = torch.zeros(self.N, self.nu, device=DEV)
        for cote, dec in (("g", 0.0), ("d", math.pi)):
            pose[:, self.idx["hanche_tangage_" + cote]] = montee * (h0 + ah * torch.sin(th + dec))
            pose[:, self.idx["genou_" + cote]] = montee * (kb + ak * 0.5 * (1 + torch.sin(th + dec + pk)))
            pose[:, self.idx["cheville_tangage_" + cote]] = montee * (aa * torch.sin(th + dec + pa)) + gt * av + gtv * va
        s = torch.sin(th + pr)
        for cote, rr in (("g", rg), ("d", rd)):
            pose[:, self.idx["hanche_roulis_" + cote]] = montee * rr * s
            pose[:, self.idx["cheville_roulis_" + cote]] = -montee * rr * s + gr * r + grv * vr
        if self.sprint:                                         # de la position de départ à la foulée
            pose = (1 - self.beta[:, None]) * self.pose_appui[self.appui] + self.beta[:, None] * pose
        if self.saut_ref:                                       # R-147 L4 : le saut scripté, en quatre temps
            P = self.P_saut
            t = self.t
            f = torch.clamp(t / P["TA"], 0.0, 1.0)
            p1 = ((t < P["TA"]) & ~self.saute).float()
            p2 = ((t >= P["TA"]) & (t < P["TA"] + P["TB"]) & ~self.saute).float()
            p4 = (self.t_pose >= 0).float()
            p3 = (1.0 - p1 - p2 - p4).clamp(min=0.0)
            val = {"hanche_tangage": -P["h1"] * f * p1 + P["h2"] * p2 - P["h3"] * p3 - P["h4"] * p4,
                   "genou": P["k1"] * f * p1 + P["k3"] * p3 + P["k4"] * p4,
                   "cheville_tangage": -P["a1"] * f * p1 + P["a2"] * p2 - P["a4"] * p4,
                   "epaule_tangage": P["s1"] * f * p1 - P["s2"] * (p2 + p3) - 0.5 * P["s2"] * p4}
            pose = pose.clone()
            for cle, v in val.items():
                for cote in ("g", "d"):
                    pose[:, self.idx[cle + "_" + cote]] = v
        return pose                                             # en degrés de main ; consigne = radians(pose) x signe

    def lacet(self):
        R = self.xmat[:, 1]
        return torch.atan2(R[:, 1, 0], R[:, 0, 0])

    def obs(self, fb):
        psi = self.lacet()
        c, s = torch.cos(psi), torch.sin(psi)
        v = self.qvel[:, 0:3]
        vl = torch.stack([c * v[:, 0] + s * v[:, 1], -s * v[:, 0] + c * v[:, 1], v[:, 2]], 1)
        q = self.qpos[:, self.jq] - self.c_ref
        cm = self.subtree_com[:, 1]
        return torch.cat([torch.stack([torch.sin(self.th), torch.cos(self.th)], 1),
                          torch.stack([fb[0] / 45.0, fb[1] / 45.0, fb[2] / 100.0, fb[3] / 100.0], 1),
                          0.2 * self.qvel[:, 3:6], vl, (5.0 * (cm[:, 2] / self.h0 - 1.0))[:, None],
                          2.0 * q, 0.05 * self.qvel[:, self.jv], self.a_prev,
                          torch.stack([torch.sin(psi), torch.cos(psi), cm[:, 1]], 1)]
                         + ([torch.stack([torch.sin(self.cap_cmd - psi), torch.cos(self.cap_cmd - psi), self.v_cmd], 1)] if self.commande else [])
                         + ([self.prochaine_barre(cm[:, 0])] if self.oeil else [])
                         + ([nn.functional.one_hot(self.appui, 3).float(),
                             torch.stack([torch.clamp(self.t / 3.0, max=1.0), cm[:, 0] / 2.5, self.beta], 1)] if self.sprint else [])
                         + ([nn.functional.one_hot(self.epreuve, 2).float(),
                             torch.stack([torch.clamp(cm[:, 0], -2.0, 3.0) / 2.0, self.saute.float(), (self.t_pose >= 0).float(),
                                          torch.clamp(self.t / 4.0, max=1.0)], 1)] if self.saut else []), 1)

    def prochaine_barre(self, x):
        """(distance à la prochaine barre devant le centre de masse, plafonnée à 3 m ; sa hauteur x 10) ; rien devant : (3, 0)."""
        dist = self.barres_x[None, :] - x[:, None]
        devant = dist > -0.1
        dm = torch.where(devant, dist, torch.full_like(dist, 99.0))
        k = dm.argmin(1)
        d0 = dm.gather(1, k[:, None])[:, 0]
        h0 = self.barres_h[k]
        rien = d0 > 50
        return torch.stack([torch.where(rien, torch.full_like(d0, 3.0), torch.clamp(d0, max=3.0)), torch.where(rien, torch.zeros_like(h0), 10.0 * h0)], 1)

    def inclinaison(self):
        qq = self.qpos[:, 3:7]
        z = 1 - 2 * (qq[:, 1] ** 2 + qq[:, 2] ** 2)
        return torch.rad2deg(torch.acos(torch.clamp(z, -1, 1)))

    def tirer_commandes(self, masque):
        k = int(masque.sum())
        if k == 0 or not self.commande:
            return
        largeur = 0.3 if self.rec in ("E", "O") else math.pi          # E, O : vers les barres (x croissant), à ±17° près
        self.cap_cmd[masque] = (torch.rand(k, device=DEV, generator=self.gen) * 2 - 1) * largeur
        vmin = 0.3 if self.rec in ("E", "O") else 0.2
        self.v_cmd[masque] = vmin + (self.v_max - vmin) * torch.rand(k, device=DEV, generator=self.gen)
        self.t_cmd[masque] = self.t[masque] + 3.0 + 3.0 * torch.rand(k, device=DEV, generator=self.gen)

    def reinit(self, masque, perturbations=None):
        """Remet les mondes du masque debout : ±1° à chaque articulation (ou les perturbations données, en degrés)."""
        k = int(masque.sum())
        if k == 0:
            return
        q = self.q_appui[self.appui[masque]].clone() if self.sprint else self.qpos0.repeat(k, 1)
        if perturbations is None:
            pert = (torch.rand(k, self.nu, device=DEV, generator=self.gen) * 2 - 1)
        else:
            pert = torch.as_tensor(perturbations, dtype=torch.float32, device=DEV)
        q[:, self.jq] += torch.deg2rad(pert)
        if self.saut:
            q[:, 0] = self.x0_saut[self.epreuve[masque]]
        if self.rec in ("E", "O") and perturbations is None:         # E, O : un départ décalé de −1,0 à +0,3 m (les barres à des distances variées)
            q[:, 0] += -1.0 + 1.3 * torch.rand(k, device=DEV, generator=self.gen)
        self.qpos[masque] = q
        self.qvel[masque] = 0.0
        self.qacc_ws[masque] = 0.0
        self.xfrc[masque] = 0.0
        self.ctrl[masque] = self.c_appui[self.appui[masque]] if self.sprint else 0.0
        self.t[masque], self.th[masque] = 0.0, 0.0
        if self.saut:
            self.saute[masque] = False
            self.mordu[masque] = False
            self.t_pose[masque], self.marque[masque], self.vx_appel[masque], self.vol_saut[masque] = -1.0, -9.0, 0.0, 0.0
        if self.sprint:
            self.beta[masque] = 0.0
            self.t15[masque], self.t8[masque], self.nb_pas[masque] = -1.0, -1.0, 0.0
            self.touche_prec[masque] = True
            self.air_pied[masque] = 0.0
            self.pas_valide[masque] = False
            self.dernier_pied[masque], self.t_dernier[masque], self.t_arr[masque] = -1.0, -1.0, -1.0
            self.autre_touche[masque] = False
        self.a_prev[masque] = 0.0
        self.t_pousse[masque] = 2.0 + 2.0 * torch.rand(k, device=DEV, generator=self.gen)
        self.fin_pousse[masque] = -1.0
        self.ret[masque], self.long[masque] = 0.0, 0.0
        self.tirer_commandes(masque)
        if hasattr(self, "t_air"):
            self.t_air[masque] = 0.0
            self.ema[masque] = 0.5
        torch.cuda.synchronize()
        wp.capture_launch(self.graphe_avant)                     # recalcule les positions de tous les mondes (les autres ne bougent pas)
        wp.synchronize()
        self.cm_prec[masque] = self.subtree_com[masque, 1, :2]
        self.pied_prec[masque] = self.geom_xpos[masque][:, self.pieds, :2]
        if self.sprint:                                          # E80 : le point de décollage de départ = où est le pied
            self.x_decol[masque] = self.geom_xpos[masque][:, self.pieds, 0]
        fb = self.attitude()
        self.c_ref[masque] = (torch.deg2rad(self.reference(fb)) * self.sg)[masque]

    def premiere_obs(self):
        return self.obs(self.attitude())

    def pas(self, action, residuel=True):
        a = torch.clamp(action, -1.0, 1.0)
        if self.commande:
            self.tirer_commandes(self.t >= self.t_cmd)
        if self.sprint:                                          # R-146 : la relevée, de 0 à 1 en 0,25 s au plus vite ; elle ne redescend pas
            self.beta = torch.clamp(self.beta + DT_C * (1.5 if self.rec == "S7" else 4.0) * (a[:, self.nu] + 1.0) / 2.0, max=1.0)
        fb = self.attitude()
        pose = self.reference(fb)
        self.c_ref = torch.deg2rad(pose) * self.sg
        if residuel:
            pose = pose + self.ech * a[:, :self.nu]
        self.ctrl[:] = torch.deg2rad(pose) * self.sg
        if self.pousses:                                         # une poussée (jusqu'à 30 N pendant 0,1 s, toutes les 2 à 4 s)
            go = self.t >= self.t_pousse
            if bool(go.any()):
                k = int(go.sum())
                ang = torch.rand(k, device=DEV, generator=self.gen) * 2 * math.pi
                f = torch.rand(k, device=DEV, generator=self.gen) * 30.0
                F = torch.zeros(k, 6, device=DEV)
                F[:, 0], F[:, 1] = f * torch.cos(ang), f * torch.sin(ang)
                x = self.xfrc[go]
                x[:, 1] = F
                self.xfrc[go] = x
                self.fin_pousse[go] = self.t[go] + 0.1
                self.t_pousse[go] = self.t[go] + 2.0 + 2.0 * torch.rand(k, device=DEV, generator=self.gen)
        torch.cuda.synchronize()
        wp.capture_launch(self.graphe_pas)
        wp.synchronize()
        fin_p = self.t >= self.fin_pousse
        if bool(fin_p.any()):
            x = self.xfrc[fin_p]
            x[:, 1] = 0.0
            self.xfrc[fin_p] = x
        self.t += DT_C
        self.th += 2 * math.pi / self.p[0] * DT_C * ((1.0 + 0.45 * a[:, -1]) if self.freq else 1.0)   # D : la cadence, de 0,55 à 1,45 fois
        cm = self.subtree_com[:, 1, :2]
        vx = (cm[:, 0] - self.cm_prec[:, 0]) / DT_C
        vy = (cm[:, 1] - self.cm_prec[:, 1]) / DT_C
        self.cm_prec = cm.clone()
        tilt = self.inclinaison()
        if self.sprint:                                          # R-146 : accroupi au départ ; relevé (le centre de masse à 55 cm, le torse à moins de 60°) après 1 s
            czs = self.subtree_com[:, 1, 2]
            tombe = (czs < 0.28) | (tilt > 100.0) | ((self.t > 1.0) & ((czs < 0.55) | (tilt > 60.0))) | ~torch.isfinite(self.qpos).all(1)
        else:
            tombe = (tilt > 40.0) | (self.subtree_com[:, 1, 2] < 0.6 * self.h0) | ~torch.isfinite(self.qpos).all(1)
        debout = (tilt < 25.0).float()
        q = self.qpos[:, self.jq]
        imit = ((q[:, self.jambes] - self.c_ref[:, self.jambes]) ** 2).mean(1)
        psi = self.lacet()
        if self.commande:                                         # R-140 : avancer dans la direction commandée, à la vitesse commandée
            v_dir = vx * torch.cos(self.cap_cmd) + vy * torch.sin(self.cap_cmd)
            dpsi = torch.atan2(torch.sin(self.cap_cmd - psi), torch.cos(self.cap_cmd - psi))
            r = 1.0 + debout * (torch.exp(-((v_dir - self.v_cmd) / 0.2) ** 2) + self.imit_w * torch.exp(-imit / (2 * 0.15 ** 2)) + 0.5 * torch.exp(-(dpsi / 0.5) ** 2))
        else:
            r = 1.0 + debout * (torch.exp(-((vx - V_CIBLE) / 0.2) ** 2) + self.imit_w * torch.exp(-imit / (2 * 0.15 ** 2)) + 0.3 * torch.exp(-(psi / 0.3) ** 2))
        r = r - 0.1 * ((a - self.a_prev) ** 2).mean(1)
        pied = self.geom_xpos[:, self.pieds]                     # (N, 2, 3) : le centre des deux semelles
        Rp = self.geom_xmat[:, self.pieds]                       # (N, 2, 3, 3)
        haut = pied[:, :, 2] - (Rp[:, :, 2, :].abs() * self.demi_pied[None]).sum(2)   # le coin le plus bas de la boîte (E63)
        touche = haut < 0.003
        haut = torch.clamp(haut, min=0.0)
        vpied = torch.linalg.norm(pied[:, :, :2] - self.pied_prec, dim=2) / DT_C
        self.pied_prec = pied[:, :, :2].clone()
        arrive = torch.zeros_like(tombe)
        if self.sprint:                                          # R-146 : aller vite tout droit ; une foulée honnête (F) ; 20 points à 2,5 m
            autre = touche.flip(1)
            lever = ((~touche) & autre).float() * torch.clamp(haut / 0.10, 0, 1)
            Rm = self.geom_xmat[:, self.mains]                    # E80 : un vol = ni pied ni main au sol
            hm = self.geom_xpos[:, self.mains, 2] - (Rm[:, :, 2, :].abs() * self.demi_main[None]).sum(2)
            air = (~touche).all(1) & (hm > 0.003).all(1)
            self.t_air = (self.t_air + DT_C) * air.float()
            self.ema = 0.98 * self.ema + 0.02 * touche.float()
            cx = self.subtree_com[:, 1, 0]
            # S2 (E71) : les appuis honnêtes, lus avant la paie
            atterrit = touche & ~self.touche_prec & (self.air_pied >= 0.06 - 1e-6) & (pied[:, :, 0] - self.x_decol >= 0.05)   # E80 : un vrai pas
            un = atterrit.any(1)
            pied_pose = atterrit[:, 1].float()                    # 0 : gauche ; 1 : droit (si les deux, droit)
            self.ev_deux = atterrit.all(1) | (un & (self.t - self.t_dernier <= 0.04 + 1e-6) & (pied_pose != self.dernier_pied) & (self.t_dernier >= 0))
            self.ev_meme = un & ~atterrit.all(1) & (pied_pose == self.dernier_pied) & ~self.ev_deux & ~self.autre_touche   # E80 v3
            self.dernier_pied = torch.where(un, pied_pose, self.dernier_pied)
            self.autre_touche = torch.where(un, torch.zeros_like(self.autre_touche), self.autre_touche)
            autre_i = (1 - self.dernier_pied).clamp(0, 1).long()
            self.autre_touche = self.autre_touche | ((self.dernier_pied >= 0) & touche.gather(1, autre_i[:, None])[:, 0])
            self.t_dernier = torch.where(un, self.t + 0.0, self.t_dernier)
            self.t_arr = torch.where((self.t_arr < 0) & (cx >= 2.5), self.t + 0.0, self.t_arr)
            if self.honnete or self.sans_reinit:                  # le banc juge avec les règles de S2
                if not self.juge_libre:
                    tombe = tombe | (self.t_air > 0.2 + 1e-6)                                   # un vol de plus de 0,2 s : une chute
                    if self.eliminatoire:
                        tombe = tombe | self.ev_deux | self.ev_meme
                arrive = (self.t_arr >= 0) & (self.t >= self.t_arr + 0.5 - 1e-6) & ~tombe
            else:
                arrive = (cx >= 2.5) & ~tombe
            if self.rec in ("S4", "S5", "S7"):                    # la vitesse payée au pas honnête
                pas_ok = atterrit & ~(self.ev_deux | self.ev_meme)[:, None]
                gain = (pas_ok.float() * torch.clamp(pied[:, :, 0] - self.x_decol, 0.0, 0.8)).sum(1)
                r = (10.0 * gain + 0.1 * torch.clamp(vx, -1.0, 3.0) - 0.5 * vy.abs() - 0.5 * psi ** 2 - 0.1 * ((a - self.a_prev) ** 2).mean(1)
                     + 0.3 * lever.sum(1) - 0.5 * (touche.float() * vpied).sum(1) - 0.3 * (self.ema[:, 0] - self.ema[:, 1]).abs()
                     + 20.0 * arrive.float())
            elif self.honnete:
                r = (1.0 * torch.clamp(vx, -1.0, 3.0) - 0.5 * vy.abs() - 0.5 * psi ** 2 - 0.1 * ((a - self.a_prev) ** 2).mean(1)
                     + 0.3 * lever.sum(1) - 0.5 * (touche.float() * vpied).sum(1) - 3.0 * self.ev_deux.float() - 3.0 * self.ev_meme.float()
                     - 0.3 * (self.ema[:, 0] - self.ema[:, 1]).abs() + 20.0 * arrive.float())
            else:
                r = (1.0 * torch.clamp(vx, -1.0, 3.0) - 0.5 * vy.abs() - 0.5 * psi ** 2 - 0.1 * ((a - self.a_prev) ** 2).mean(1)
                     + 0.3 * lever.sum(1) - 0.5 * (touche.float() * vpied).sum(1) - 0.5 * (self.t_air > 0.15).float()
                     - 0.3 * (self.ema[:, 0] - self.ema[:, 1]).abs() + 20.0 * arrive.float())
            self.dernier_tombe = tombe.clone()
            xp = pied[:, :, 0]
            decolle = self.touche_prec & ~touche
            self.x_decol = torch.where(decolle, xp, self.x_decol)
            pose_ = touche & ~self.touche_prec                    # un pied qui se pose après 0,06 s en l'air, 5 cm plus loin : un pas
            self.pas_valide = pose_ & (self.air_pied >= 0.06 - 1e-6) & (xp - self.x_decol >= 0.05)
            self.air_pied = torch.where(touche, torch.zeros_like(self.air_pied), self.air_pied + DT_C)
            self.nb_pas += self.pas_valide.float().sum(1)
            self.touche_prec = touche.clone()
            self.t15 = torch.where((self.t15 < 0) & (cx >= 1.5), self.t + 0.0, self.t15)
            self.t8 = torch.where((self.t8 < 0) & (self.nb_pas >= 8), self.t + 0.0, self.t8)
        elif self.saut:                                          # R-147 : le saut en longueur
            cx = self.subtree_com[:, 1, 0]
            air = (~touche).all(1)
            self.t_air = (self.t_air + DT_C) * air.float()
            demi_x = (Rp[:, :, 0, :].abs() * self.demi_pied[None]).sum(2)          # la demi-longueur de chaque semelle sur l'axe x du monde
            avant, arriere = pied[:, :, 0] + demi_x, pied[:, :, 0] - demi_x
            self.mordu = (~self.saute) & (touche & (avant > 0.0)).any(1)          # un pied posé au-delà de la ligne avant le saut
            debut = (~self.saute) & (self.t_air >= 0.12 - 1e-6)
            self.vx_appel = torch.where(debut, vx, self.vx_appel)
            self.saute = self.saute | debut
            self.vol_saut = torch.where(self.saute & (self.t_pose < 0) & air, self.t_air, self.vol_saut)
            recoit = self.saute & (self.t_pose < 0) & touche.any(1)
            mq = torch.where(touche, arriere, torch.full_like(arriere, 99.0)).min(1).values
            self.marque = torch.where(recoit, mq, self.marque)
            self.t_pose = torch.where(recoit, self.t + 0.0, self.t_pose)
            tombe = (tilt > 60.0) | (self.subtree_com[:, 1, 2] < 0.40) | ~torch.isfinite(self.qpos).all(1) | self.mordu
            arrive = (self.t_pose >= 0) & (self.t >= self.t_pose + 1.0 - 1e-6) & ~tombe
            if self.saut_ref:                                    # E79 : la réception immobile, au-dessus des pieds
                cxs = self.subtree_com[:, 1, 0]
                talon = torch.where(touche, arriere, torch.full_like(arriere, 99.0)).min(1).values
                pointe_ = torch.where(touche, avant, torch.full_like(avant, -99.0)).max(1).values
                stable = touche.any(1) & (cxs >= talon) & (cxs <= pointe_) & (vx.abs() < 0.3)
                rate = arrive & ~stable
                tombe = tombe | rate
                arrive = arrive & stable
            avant_saut = (~self.saute).float()
            debout_tot = avant_saut * (self.t < 1.0).float()                       # L2 (E75) : debout la première seconde
            tient = (self.t_pose >= 0).float()                                       # L2 : la réception qui tient
            if self.rec in ("L3", "L4"):                                             # L3 (E77) : en proportion du saut
                tient = tient * torch.clamp((self.marque + 0.35) / 0.3, 0.0, 1.0)
            r = (0.1 * torch.clamp(vx, -1.0, 3.0) * avant_saut * self.epreuve.float() - 0.1 * vy.abs() - 0.1 * psi ** 2
                 - 0.05 * ((a - self.a_prev) ** 2).mean(1) + 0.05 * debout_tot + 0.05 * tient
                 + arrive.float() * 20.0 * torch.clamp(self.marque + 0.35, min=0.0))
            self.dernier_tombe = tombe.clone()
        elif self.rec in ("F", "G", "K", "M", "P"):                # R-141 F (E65) : une course honnête ; G, P : et le penché ; R-143 K : le genou haut ; R-144 M
            autre = touche.flip(1)                                # le pied levé n'est payé que si l'autre porte (pas de saut payé)
            lever = ((~touche) & autre).float() * torch.clamp(haut / self.lever_max, 0, 1)
            if self.rec == "K":                                   # le genou de la jambe qui balance, payé jusqu'à 1,2 fois la cuisse au-dessus de debout
                zg = self.xanchor[:, self.j_genou, 2]
                zh = self.xanchor[:, self.j_hanche, 2]
                rel = torch.clamp((zg - zh + 0.204) / 0.204, 0, 1.2)   # 0 : debout ; 1 : le genou à la hauteur de la hanche
                lever = ((~touche) & autre).float() * 2.0 * rel       # 0,3 x 2 = jusqu'à 0,72 point par pas pour un genou à la hauteur de la hanche
            if self.rec == "M":                                   # R-144 la marche militaire : le genou à 60 % de la cuisse, sans plus
                zg = self.xanchor[:, self.j_genou, 2]
                zh = self.xanchor[:, self.j_hanche, 2]
                rel = (zg - zh + 0.204) / 0.204
                lever = ((~touche) & autre).float() * 1.5 * torch.clamp(1.0 - (rel - 0.6).abs() / 0.6, min=0.0)   # E70 (M4) : en pente de 0 à 0,6 (E67)
            air = (~touche).all(1)
            self.t_air = (self.t_air + DT_C) * air.float()
            self.ema = 0.98 * self.ema + 0.02 * touche.float()
            r = r + debout * (0.3 * lever.sum(1) - 0.5 * (touche.float() * vpied).sum(1) - 0.5 * (self.t_air > 0.15).float()
                              - 1.0 * (self.ema[:, 0] - self.ema[:, 1]).abs())
            if self.rec == "M":                                  # R-144 : le torse droit ; les bras tendus suivent la cuisse opposée, 1,2 fois plus grand
                qq = self.qpos[:, self.jq]
                i_ = {n: self.idx[n] for n in ("hanche_tangage_g", "hanche_tangage_d", "epaule_tangage_g", "epaule_tangage_d", "coude_g", "coude_d")}
                err = ((qq[:, i_["epaule_tangage_g"]] - 1.2 * qq[:, i_["hanche_tangage_d"]]) ** 2
                       + (qq[:, i_["epaule_tangage_d"]] - 1.2 * qq[:, i_["hanche_tangage_g"]]) ** 2) / 2
                r = r + debout * (0.3 * torch.exp(-err / (2 * 0.25 ** 2)) + 0.3 * torch.exp(-(fb2_avant(self) / 4.0) ** 2)
                                  - 0.1 * (qq[:, i_["coude_g"]] ** 2 + qq[:, i_["coude_d"]] ** 2))
            if self.rec == "P":                                  # R-141 G2 (E67) : la même cible, une paie en pente partout (0,4 à la cible, −0,02 par degré d'écart)
                cible_penche = 2.0 + 8.0 * self.v_cmd
                r = r + debout * (0.4 - 0.02 * (fb2_avant(self) - cible_penche).abs())
            if self.rec == "G":                                  # l'idée de Yoan : plus on va vite, plus on se penche vers l'avant
                cible_penche = 2.0 + 8.0 * self.v_cmd             # degrés : 5,2° à 0,4 m/s, 11,6° à 1,2 m/s, 14° à 1,5 m/s
                r = r + debout * 0.3 * torch.exp(-((fb2_avant(self) - cible_penche) / 4.0) ** 2)
        elif self.rec in ("B", "C", "D", "E", "O"):                                      # le pied libre se lève (jusqu'à 5 cm) ; le pied d'appui ne glisse pas ; pas en l'air des deux pieds
            lever = (~touche).float() * torch.clamp(haut / self.lever_max, 0, 1)
            vol = 0.0 if self.freq else 0.3 * (~touche).all(1).float()     # D : courir, c'est avoir les deux pieds en l'air un instant
            r = r + debout * (0.3 * lever.mean(1) - 0.5 * (touche.float() * vpied).sum(1) - vol)
        self.a_prev = a
        self.ret += r
        self.long += 1
        termine = tombe | arrive                                 # R-146 : la ligne des 2,5 m termine l'épisode (sans valeur après)
        tronque = (self.t >= self.duree - 1e-6) & ~termine
        fini = termine | tronque
        fb2 = self.attitude()
        self.c_ref = torch.deg2rad(self.reference(fb2)) * self.sg
        o_fin = self.obs(fb2)
        info = {"ret": self.ret[fini].clone(), "long": self.long[fini].clone(), "tombe": tombe[fini].clone(), "vx": vx,
                "lever": (~touche).float().mean(), "glisse": (touche.float() * vpied).sum(1).mean()}
        if self.sprint:
            info["arrive"] = arrive[fini].clone()
            info["t15"] = self.t15[fini].clone()
            info["t8"] = self.t8[fini].clone()
        if self.saut:
            info["arrive"] = arrive[fini].clone()
            info["marque"] = torch.where(arrive, self.marque, torch.full_like(self.marque, -9.0))[fini].clone()
            info["mordu"] = self.mordu[fini].clone()
        if self.sans_reinit:
            return o_fin, r, termine, tronque, o_fin, info
        if bool(fini.any()):
            self.reinit(fini)
        o = self.obs(self.attitude()) if bool(fini.any()) else o_fin
        return o, r, termine, tronque, o_fin, info


# --- la validation H323 : la marche de la sprinteuse seule, mêmes départs que le processeur
def valider():
    cpu = json.load(open(os.path.join(ICI, "valider-cpu.json"), encoding="utf-8"))
    graines = sorted(CFG["perturbations"])
    W = Monde(len(graines), pousses=False)
    W.reinit(torch.ones(len(graines), dtype=torch.bool, device=DEV), [CFG["perturbations"][g] for g in graines])
    traj = {g: [] for g in graines}
    vivant = torch.ones(len(graines), dtype=torch.bool, device=DEV)
    for k in range(150):
        # pas de remise à zéro pendant la validation : on joue les 3 s, et on note la chute
        a = torch.zeros(len(graines), W.nu, device=DEV)
        fb = W.attitude()
        pose = W.reference(fb)
        W.ctrl[:] = torch.deg2rad(pose) * W.sg
        torch.cuda.synchronize()
        wp.capture_launch(W.graphe_pas)
        wp.synchronize()
        W.t += DT_C
        W.th += 2 * math.pi / W.p[0] * DT_C
        tilt = W.inclinaison()
        cm = W.subtree_com[:, 1].cpu().numpy()
        tombe = ((tilt > 40.0) | (W.subtree_com[:, 1, 2] < 0.6 * W.h0)).cpu().numpy()
        for i, g in enumerate(graines):
            if vivant[i]:
                traj[g].append([round(float(W.t[i]), 2), float(cm[i, 0]), float(cm[i, 1]), float(cm[i, 2]), bool(tombe[i])])
                if tombe[i]:
                    vivant[i] = False
    ecarts = []
    for g in graines:
        a, b = cpu[g], traj[g]
        e1 = float(np.linalg.norm(np.array(a[49][1:4]) - np.array(b[49][1:4]))) if len(a) > 49 and len(b) > 49 else None
        ecarts.append(e1)
        print("%s : processeur %s, carte %s ; écart du centre de masse à 1 s : %s cm" % (
            g, ("chute à %.2f s" % a[-1][0]) if a[-1][4] else "debout à 3 s", ("chute à %.2f s" % b[-1][0]) if b[-1][4] else "debout à 3 s",
            round(100 * e1, 2) if e1 is not None else None), flush=True)
    json.dump({"carte": traj, "ecarts_1s_m": ecarts}, open(os.path.join(ICI, "valider-gpu.json"), "w", encoding="utf-8"))
    print("=> écart maximal à 1 s : %.2f cm" % (100 * max(e for e in ecarts if e is not None)), flush=True)


# --- le PPO
class Normaliseur:
    def __init__(self, n):
        self.m, self.v, self.c = torch.zeros(n, device=DEV), torch.ones(n, device=DEV), 1e-4

    def maj(self, x):
        bm, bv, bc = x.mean(0), x.var(0, unbiased=False), x.shape[0]
        d = bm - self.m
        tot = self.c + bc
        self.m = self.m + d * bc / tot
        self.v = (self.v * self.c + bv * bc + d ** 2 * self.c * bc / tot) / tot
        self.c = tot

    def __call__(self, x):
        return torch.clamp((x - self.m) / torch.sqrt(self.v + 1e-8), -10, 10)


def mlp(i, o):
    return nn.Sequential(nn.Linear(i, 256), nn.ELU(), nn.Linear(256, 256), nn.ELU(), nn.Linear(256, o))


class Agent(nn.Module):
    def __init__(self, no, na):
        super().__init__()
        self.pi, self.v = mlp(no, na), mlp(no, 1)
        self.log_std = nn.Parameter(torch.full((na,), -1.0))

    def loi(self, o):
        return torch.distributions.Normal(self.pi(o), torch.exp(self.log_std))


def apprendre(nom, millions, recompense="A", nworld=4096, T=24, graine=139000, init=None):
    dossier = os.path.join(ICI, "runs", nom)
    os.makedirs(dossier, exist_ok=True)
    torch.manual_seed(graine)
    W = Monde(nworld, recompense=recompense, pousses=recompense not in ("S", "S2", "S3", "S4", "S5", "S6", "S7", "L", "L3", "L4"), graine=graine)
    o = W.premiere_obs()
    no, na = o.shape[1], W.na
    norm = Normaliseur(no)
    ag = Agent(no, na).to(DEV)
    if recompense in ("L", "L3", "L4", "S5"):                     # R-147 L2 (E75), R-146 S5 : un grand espace d'action ; un bruit de départ plus petit
        with torch.no_grad():
            ag.log_std.fill_(-1.6)
    if init:                                                      # R-146 S5 : à chaud, depuis un réseau qui sait déjà se relever et courir
        s0 = torch.load(init, map_location=DEV)
        assert s0["no"] == no and s0["na"] == na, (s0["no"], s0["na"], no, na)
        ag.pi.load_state_dict(s0["pi"])
        norm.m, norm.v, norm.c = s0["norm_m"].to(DEV), s0["norm_v"].to(DEV), 1e6
        print("=> à chaud depuis", init, flush=True)
    opt = torch.optim.Adam(ag.parameters(), lr=3e-4)
    lr, gamma, lam, clip = 3e-4, 0.99, 0.95, 0.2
    total = int(millions * 1e6)
    fait, it, t0 = 0, 0, time.time()
    prog = open(os.path.join(dossier, "progression.jsonl"), "a", encoding="utf-8")
    finis_ret, finis_long, finis_tombe = [], [], []
    finis_arr, finis_t15, finis_t8 = [], [], []
    finis_mq, finis_mordu = [], []
    prochain = 10_000_000
    while fait < total:
        O, A, LP, V, R, D, TR, VF, MU = [], [], [], [], [], [], [], [], []
        sig_old = torch.exp(ag.log_std.detach()).clone()
        with torch.no_grad():
            for _ in range(T):
                norm.maj(o)
                on = norm(o)
                loi = ag.loi(on)
                a = loi.sample()
                o2, r, tombe, tronque, o_fin, info = W.pas(a)
                O.append(on); A.append(a); LP.append(loi.log_prob(a).sum(1)); V.append(ag.v(on).squeeze(1)); MU.append(loi.mean)
                R.append(r); D.append(tombe.float()); TR.append(tronque.float()); VF.append(ag.v(norm(o_fin)).squeeze(1))
                finis_ret += info["ret"].tolist(); finis_long += info["long"].tolist(); finis_tombe += info["tombe"].float().tolist()
                if "t15" in info:
                    finis_arr += info["arrive"].float().tolist(); finis_t15 += info["t15"].tolist(); finis_t8 += info["t8"].tolist()
                if "marque" in info:
                    finis_arr += info["arrive"].float().tolist(); finis_mq += info["marque"].tolist(); finis_mordu += info["mordu"].float().tolist()
                o = o2
            v_der = ag.v(norm(o)).squeeze(1)
            adv = torch.zeros(T, nworld, device=DEV)
            g = torch.zeros(nworld, device=DEV)
            for k in reversed(range(T)):
                fin = torch.clamp(D[k] + TR[k], max=1.0)
                v_suiv = v_der if k == T - 1 else V[k + 1]
                v_suiv = torch.where(fin > 0, VF[k] * (1 - D[k]), v_suiv)    # tronqué : on amorce sur l'état final ; tombé : 0
                delta = R[k] + gamma * v_suiv - V[k]
                g = delta + gamma * lam * (1 - fin) * g
                adv[k] = g
            ret = adv + torch.stack(V)
        O_, A_, LP_, ADV_, RET_, MU_ = torch.cat(O), torch.cat(A), torch.cat(LP), adv.reshape(-1), ret.reshape(-1), torch.cat(MU)
        ADV_ = (ADV_ - ADV_.mean()) / (ADV_.std() + 1e-8)
        n = O_.shape[0]
        kl_moy = 0.0
        for ep in range(5):
            perm = torch.randperm(n, device=DEV)
            for mb in perm.chunk(4):
                loi = ag.loi(O_[mb])
                lp = loi.log_prob(A_[mb]).sum(1)
                ratio = torch.exp(lp - LP_[mb])
                pg = -torch.min(ratio * ADV_[mb], torch.clamp(ratio, 1 - clip, 1 + clip) * ADV_[mb]).mean()
                vl = ((ag.v(O_[mb]).squeeze(1) - RET_[mb]) ** 2).mean()
                perte = pg + 0.5 * vl
                opt.zero_grad()
                perte.backward()
                nn.utils.clip_grad_norm_(ag.parameters(), 1.0)
                opt.step()
                with torch.no_grad():
                    sn = torch.exp(ag.log_std)
                    kl = (torch.log(sn / sig_old) + (sig_old ** 2 + (MU_[mb] - loi.mean) ** 2) / (2 * sn ** 2) - 0.5).sum(1).mean().item()
                kl_moy = kl
                if kl > 0.02:
                    lr = max(1e-5, lr / 1.5)
                elif kl < 0.005:
                    lr = min(1e-3, lr * 1.5)
                for pgp in opt.param_groups:
                    pgp["lr"] = lr
        fait += n
        it += 1
        if it % 5 == 0:
            ligne = {"pas": fait, "minutes": round((time.time() - t0) / 60, 2), "decisions_par_s": round(fait / (time.time() - t0)),
                     "retour_moy": round(float(np.mean(finis_ret)), 1) if finis_ret else None,
                     "duree_moy_s": round(float(np.mean(finis_long)) * DT_C, 2) if finis_long else None,
                     "chutes": round(float(np.mean(finis_tombe)), 3) if finis_tombe else None, "kl": round(kl_moy, 4), "lr": lr,
                     "std": round(float(torch.exp(ag.log_std).mean()), 3), "vx": round(float(info["vx"].mean()), 3),
                     "en_l_air": round(float(info["lever"]), 3), "glisse_m_s": round(float(info["glisse"]), 3)}
            if finis_mq:
                mq = [x for x in finis_mq if x > -5]
                ligne.update({"tenus": round(float(np.mean(finis_arr)), 3), "mordus": round(float(np.mean(finis_mordu)), 3),
                              "marque_med": round(float(np.median(mq)), 3) if mq else None, "marque_max": round(float(np.max(mq)), 3) if mq else None})
                finis_arr, finis_mq, finis_mordu = [], [], []
            if finis_arr:
                t15 = [x for x in finis_t15 if x > 0]
                t8 = [x for x in finis_t8 if x > 0]
                ligne.update({"arrivees": round(float(np.mean(finis_arr)), 3), "t15_med": round(float(np.median(t15)), 2) if t15 else None,
                              "t8_med": round(float(np.median(t8)), 2) if t8 else None})
                finis_arr, finis_t15, finis_t8 = [], [], []
            prog.write(json.dumps(ligne) + "\n")
            prog.flush()
            print(ligne, flush=True)
            finis_ret, finis_long, finis_tombe = [], [], []
        if fait >= prochain or fait >= total:
            tag = "%dM" % (fait // 1_000_000) if fait < total else "final"
            torch.save({"pi": ag.pi.state_dict(), "log_std": ag.log_std.detach().cpu(), "norm_m": norm.m.cpu(), "norm_v": norm.v.cpu(),
                        "no": no, "na": na, "recompense": recompense, "pas": fait, "ech": W.ech.cpu().tolist()},
                       os.path.join(dossier, "politique-%s.pt" % tag))
            prochain += 10_000_000
    print("=> FIN apprentissage", nom, fait, "pas en %.1f min" % ((time.time() - t0) / 60), flush=True)


def banc_sprint(f, sortie, n_graines=30, libre=False):
    """R-146 : 30 départs perturbés (±1°, graines 137900 et suivantes) par position, la politique sans hasard ; le temps aux 1,5 m,
    le temps du 8e pas, les pas (le pied, le temps, l'endroit), la chute ; les qpos de chaque course (pour les films du portable)."""
    s = torch.load(f, map_location=DEV)
    N = 3 * n_graines
    W = Monde(N, recompense="S3", pousses=False, graine=146900)
    W.ech = torch.tensor(s["ech"], dtype=torch.float32, device=DEV)     # l'échelle des corrections du réseau jugé (S6 : ±15°)
    W.juge_libre = libre
    W.appui = torch.arange(N, device=DEV) // n_graines
    W.sans_reinit = True
    pert = np.stack([np.random.default_rng(137900 + i % n_graines).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    pi = mlp(s["no"], s["na"]).to(DEV)
    pi.load_state_dict(s["pi"])
    nm, nv = s["norm_m"].to(DEV), s["norm_v"].to(DEV)
    o = W.premiere_obs()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    t_chute = torch.full((N,), -1.0, device=DEV)
    t_arr = torch.full((N,), -1.0, device=DEV)
    QP, PAS = [], [[] for _ in range(N)]
    vmax = torch.zeros(N, device=DEV)
    n_deux, n_meme, vol_max = torch.zeros(N, device=DEV), torch.zeros(N, device=DEV), torch.zeros(N, device=DEV)
    cause = ["" for _ in range(N)]
    with torch.no_grad():
        for k in range(int(W.duree / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            o, r, term, tronq, _, info = W.pas(a)
            QP.append(W.qpos.clone().cpu().numpy())
            for i, c in zip(*[x.tolist() for x in torch.nonzero(W.pas_valide & vivant[:, None], as_tuple=True)]):
                PAS[i].append([c, round(float(W.t[i]), 2), round(float(W.geom_xpos[i, W.pieds[c], 0]), 3)])
            vmax = torch.where(vivant, torch.maximum(vmax, info["vx"]), vmax)
            n_deux += (W.ev_deux & vivant).float()
            n_meme += (W.ev_meme & vivant).float()
            vol_max = torch.where(vivant, torch.maximum(vol_max, W.t_air), vol_max)
            tombe_ = W.dernier_tombe & term
            for i in torch.nonzero(vivant & tombe_).flatten().tolist():
                cause[i] = ("deux pieds" if bool(W.ev_deux[i]) else "même pied" if bool(W.ev_meme[i]) else
                            "vol long" if float(W.t_air[i]) > 0.2 else "chute")
            t_chute = torch.where(vivant & tombe_, W.t, t_chute)
            t_arr = torch.where(vivant & term & ~tombe_, W.t_arr, t_arr)
            vivant = vivant & ~term
    noms = ["2 appuis", "3 appuis", "4 appuis"]
    courses = []
    for i in range(N):
        courses.append({"appuis": noms[i // n_graines], "graine": 137900 + i % n_graines, "t15_s": round(float(W.t15[i]), 2),
                        "t8_s": round(float(W.t8[i]), 2), "arrivee_25_s": round(float(t_arr[i]), 2), "chute_s": round(float(t_chute[i]), 2),
                        "vmax_m_s": round(float(vmax[i]), 2), "bonds_deux_pieds": int(n_deux[i]), "meme_pied": int(n_meme[i]),
                        "vol_max_s": round(float(vol_max[i]), 2), "cause": cause[i], "pas": PAS[i]})
    bilan = {}
    for j, n in enumerate(noms):
        cc = courses[j * n_graines:(j + 1) * n_graines]
        t15 = [c["t15_s"] for c in cc if c["t15_s"] > 0 and c["chute_s"] < 0]
        t8 = [c["t8_s"] for c in cc if c["t8_s"] > 0 and c["chute_s"] < 0]
        bilan[n] = {"debout_a_2_5m": sum(1 for c in cc if c["arrivee_25_s"] > 0), "chutes": sum(1 for c in cc if c["chute_s"] > 0),
                    "t15_med_s": round(float(np.median(t15)), 2) if t15 else None, "t15_min_s": round(float(np.min(t15)), 2) if t15 else None,
                    "t8_med_s": round(float(np.median(t8)), 2) if t8 else None,
                    "vmax_med_m_s": round(float(np.median([c["vmax_m_s"] for c in cc])), 2),
                    "bonds_deux_pieds_par_course": round(float(np.mean([c["bonds_deux_pieds"] for c in cc])), 2),
                    "meme_pied_par_course": round(float(np.mean([c["meme_pied"] for c in cc])), 2),
                    "vol_max_med_s": round(float(np.median([c["vol_max_s"] for c in cc])), 2),
                    "causes": {k: sum(c["cause"] == k for c in cc) for k in ("chute", "vol long", "même pied", "deux pieds") if any(c["cause"] == k for c in cc)}}
        print(n, bilan[n], flush=True)
    json.dump({"politique": f, "bilan": bilan, "courses": courses}, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32))
    print("=> écrit", sortie, flush=True)


def banc_saut(f, sortie, n_graines=30):
    """R-147 : 30 essais perturbés (±1°, graines 137900 et suivantes) par épreuve (sans élan, avec 1,5 m d'élan), la politique sans
    hasard : la marque (de la ligne au point le plus en arrière des pieds à la réception), tenue 1 s ou non ; mordu ; chute ; la vitesse
    à l'appel, le temps de vol ; les qpos (pour les films du portable)."""
    s = torch.load(f, map_location=DEV)
    N = 2 * n_graines
    W = Monde(N, recompense=s.get("recompense", "L") if s.get("recompense") in ("L", "L3", "L4") else "L", pousses=False, graine=147900)
    W.ech = torch.tensor(s["ech"], dtype=torch.float32, device=DEV)
    W.epreuve = torch.arange(N, device=DEV) // n_graines
    W.sans_reinit = True
    pert = np.stack([np.random.default_rng(137900 + i % n_graines).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    pi = mlp(s["no"], s["na"]).to(DEV)
    pi.load_state_dict(s["pi"])
    nm, nv = s["norm_m"].to(DEV), s["norm_v"].to(DEV)
    o = W.premiere_obs()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    t_fin = torch.full((N,), -1.0, device=DEV)
    issue = ["" for _ in range(N)]
    QP = []
    with torch.no_grad():
        for k in range(int(W.duree / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            o, r, term, tronq, _, info = W.pas(a)
            QP.append(W.qpos.clone().cpu().numpy())
            for i in torch.nonzero(vivant & term).flatten().tolist():
                issue[i] = "mordu" if bool(W.mordu[i]) else ("chute" if bool(W.dernier_tombe[i]) else "tenu")
                t_fin[i] = W.t[i]
            vivant = vivant & ~term
    noms = ["sans élan", "élan 1,5 m"]
    essais = []
    for i in range(N):
        essais.append({"epreuve": noms[i // n_graines], "graine": 137900 + i % n_graines, "issue": issue[i] or "rien (4 s)",
                       "marque_m": round(float(W.marque[i]), 3) if float(W.marque[i]) > -5 else None, "t_reception_s": round(float(W.t_pose[i]), 2),
                       "vx_appel_m_s": round(float(W.vx_appel[i]), 2), "vol_s": round(float(W.vol_saut[i]), 2), "t_fin_s": round(float(t_fin[i]), 2)})
    bilan = {}
    for j, n in enumerate(noms):
        ee = essais[j * n_graines:(j + 1) * n_graines]
        tenus = [e["marque_m"] for e in ee if e["issue"] == "tenu" and e["marque_m"] is not None]
        bilan[n] = {"tenus": len(tenus), "mordus": sum(e["issue"] == "mordu" for e in ee), "chutes": sum(e["issue"] == "chute" for e in ee),
                    "marque_med_m": round(float(np.median(tenus)), 3) if tenus else None, "marque_max_m": round(float(np.max(tenus)), 3) if tenus else None,
                    "vx_appel_med_m_s": round(float(np.median([e["vx_appel_m_s"] for e in ee if e["vol_s"] > 0])), 2) if any(e["vol_s"] > 0 for e in ee) else None,
                    "vol_med_s": round(float(np.median([e["vol_s"] for e in ee if e["vol_s"] > 0])), 2) if any(e["vol_s"] > 0 for e in ee) else None}
        print(n, bilan[n], flush=True)
    json.dump({"politique": f, "bilan": bilan, "essais": essais}, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32))
    print("=> écrit", sortie, flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "valider":
        valider()
    elif sys.argv[1] == "banc_saut":
        banc_saut(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "banc_sprint":
        banc_sprint(sys.argv[2], sys.argv[3], libre=len(sys.argv) > 4 and sys.argv[4] == "libre")
    elif sys.argv[1] == "apprendre":
        apprendre(sys.argv[2], float(sys.argv[3]), sys.argv[4] if len(sys.argv) > 4 else "A", int(sys.argv[5]) if len(sys.argv) > 5 else 4096,
                  init=sys.argv[6] if len(sys.argv) > 6 else None)
