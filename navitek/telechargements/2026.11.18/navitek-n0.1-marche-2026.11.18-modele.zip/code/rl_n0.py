"""R-150 — N0 (33 cm, 0,59 kg, 13 SG90 : leur vrai couple, 0,18 N·m, et leur vitesse) apprend à marcher sur la carte de la tour
(MuJoCo Warp, 4 096 robots, le PPO de rl_gpu.py). Pas de marche de référence : le réseau commande les 13 angles autour de la position
debout (±30° aux jambes et aux bras, ±10° au cou) et sa cadence (une horloge de 0,5 s, de 0,55 à 1,45 fois). La paie de F (R-141),
à l'échelle de N0 : suivre un cap et une vitesse commandés (1 à 10 cm/s), le pied levé payé seulement si l'autre porte (jusqu'à 1,5 cm),
le pied d'appui qui glisse coûte, le vol long coûte (plus de 0,08 s), les deux pieds doivent travailler autant. Pas de poussées.

Sur la tour :  venv\\Scripts\\python rl_n0.py apprendre <nom> <millions> [nworld]
               venv\\Scripts\\python rl_n0.py banc <politique.pt> <sortie.json>
Tout est simulé."""
import json
import math
import os
import sys
import time

import mujoco
import numpy as np
import torch
import torch.nn as nn
import warp as wp
import mujoco_warp as mjw

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, ICI)
from rl_gpu import Normaliseur, mlp, Agent, DEV  # noqa: E402

DT_C, DUREE, T0 = 0.02, float(os.environ.get("N0_DUREE", "10")), float(os.environ.get("N0_T0", "0.5"))   # R-167 : T0, la période de base de l'oscillateur
HORLOGE = float(os.environ.get("N0_HORLOGE", "0"))           # R-167 (15.11, après le contrôle à 20 M) : l'oscillateur relié aux pieds : chaque pied payé
                                                              # d'être en l'air (plus de 5 mm) pendant sa moitié du cycle (sin th > 0,3 pour le
                                                              # gauche, < -0,3 pour le droit), pénalisé sinon ; 0 = rien
N0_XML = os.environ.get("N0_XML", "n0-gpu.xml")              # R-160 : une autre cheville ; R-159 : l'escalier
N0_POSE0 = os.environ.get("N0_POSE0", "")
ESCALIER = os.environ.get("N0_ESCALIER", "") != ""             # R-159 : monter un escalier (le modèle n0-gpu-escalier.xml)
ESC_X0, ESC_PROF, ESC_NB = 0.20, float(os.environ.get("N0_ESC_PROF", "0.10")), 5   # la première marche à 20 cm du départ, 10 cm de giron, 5 marches
                                                              # R-186 : le giron réglable (N0_ESC_PROF ; 0,08 : le décollage du pied de derrière
                                                              # devient possible sur des SG90, escalier_statique_n01.py)
ESC_COULOIRS = [(-0.9, 0.01), (-0.3, 0.02), (0.3, 0.03), (0.9, 0.03)]   # (y du couloir, hauteur de marche) : 1, 2, 3, 3 cm
if os.environ.get("N0_ESC_HAUTEURS"):                         # R-165 : les hauteurs des couloirs (les mêmes que escalier_n0.py)
    ESC_COULOIRS = [(y, float(h)) for (y, _), h in zip(ESC_COULOIRS, os.environ["N0_ESC_HAUTEURS"].split(","))]
ESC_PIED = float(os.environ.get("N0_ESC_PIED", "0"))           # R-186 (esc-imite : tous tombés au départ du banc, debout au pied de l'escalier,
                                                              # un départ qu'il n'avait presque jamais vécu) : la part des départs de l'apprentissage
                                                              # au pied de l'escalier, immobiles, les pieds ensemble, comme au banc
ESC_BONUS = float(os.environ.get("N0_ESC_BONUS", "2.0"))      # R-165 : la prime par nouvelle marche montée (R-159 : 2 points)
PENTES = os.environ.get("N0_PENTES", "")                       # R-167 : des rampes au lieu des marches (les degrés des quatre couloirs), avec
PENTE_TAN = [math.tan(math.radians(float(a))) for a in PENTES.split(",")] if PENTES else []   # N0_ESCALIER=1 (les couloirs, le regard)
RAMPE_L = 1.15                                                # la longueur au sol de la rampe (m), après ESC_X0
GRAND_PAS = float(os.environ.get("N0_GRAND_PAS", "0"))       # R-167 (Yoan, 15.11 08:00 : « récompense les grands pas aujourd'hui ») : les points
GP_LONG = float(os.environ.get("N0_GP_LONG", "0.10"))         # par pied posé, au plein quand il a parcouru GP_LONG en l'air le long du cap
GP_FORME = os.environ.get("N0_GP_FORME", "carre")             # R-167 (15.11, corrigé avant le départ) : « carre » = la paie au carré de la
                                                              # longueur (la paie linéaire payait la distance : à vitesse égale, 20 pas de
                                                              # 1 cm valaient un pas de 20 cm) ; « lineaire » = la première version
GP_HAUT = float(os.environ.get("N0_GP_HAUT", "0.005"))         # un pas ne compte que si le pied s'est levé d'au moins 5 mm (N0.1 glisse : ses
                                                              # pieds ne montent qu'à 1,5 à 3,7 mm dans les marches de R-163)
ESC_SCAN = (0.0, 0.03, 0.06, 0.09, 0.12)                        # le regard vers le bas : la hauteur des marches devant le bassin                     # R-160 : la posture debout (un fichier JSON de qpos), si elle change
V_MIN, V_MAX = 0.01, 0.10
LEVER_MAX, VOL_MAX = float(os.environ.get("N0_LEVER_MAX", "0.015")), 0.08   # R-157 N0e : le pied levé payé jusqu'à 3 cm (le genou haut)
POUSSEE = float(os.environ.get("N0_POUSSEES", "0"))       # R-157 N0h : des poussées au hasard (un coup de vitesse du bassin, m/s)
POUSSEE_P = float(os.environ.get("N0_POUSSEES_P", "0.01"))  # sa chance à chaque pas de 20 ms (0,01 : environ une toutes les 2 s)
PAIE = os.environ.get("N0_PAIE", "cloche")                    # R-150 : "pente" pour N0b
CAP = os.environ.get("N0_CAP", "")                            # R-163 : "cos" : le cap payé sur tout le cercle (0,5 cos Δψ en plus) ; la cloche
                                                                # seule (σ 0,5 rad) ne donne aucune pente quand il faut se retourner (N0d : 0/90 au T-test)
ENERGIE = float(os.environ.get("N0_ENERGIE", "0"))           # R-161 (Yoan, 15.11 : « la marche économe ») : points retirés par watt estimé
KT, R_SERVO = 0.277, 7.4                                       # R-161 : un SG90 vu de sa sortie : 0,18 N·m pour 0,65 A au blocage, 4,8 V / 0,65 A
INIT = os.environ.get("N0_INIT", "")                          # R-169 (15.11) : partir d'une politique apprise (le réseau d'action et la normalisation) ;
INIT_GEL = int(os.environ.get("N0_INIT_GEL", "10"))           # le critique repart de zéro : le réseau d'action gelé pendant INIT_GEL itérations
INIT_LR = float(os.environ.get("N0_INIT_LR", "1e-4"))         # E90 (15.11 16:40) : le pas d'apprentissage au dégel. Avant, pendant le gel, le pas montait
                                                              # à 1e-3 (l'écart des politiques était nul) et Adam repartait à vide : au dégel, chaque poids
                                                              # sautait d'environ 3e-3 et la marche se défaisait en un million de pas
POINTE = float(os.environ.get("N0_POINTE", "0"))             # R-171 (Yoan, 15.11 13:29) : marcher sur la pointe des pieds : le pied qui porte payé
                                                              # de garder son talon levé (au plein à 1 cm), puni s'il le pose
assert not os.environ.get("N0_ESCALIER") or any(m_ in os.environ.get("N0_XML", "") for m_ in ("escalier", "pente")), \
    "E101 : N0_ESCALIER demande un modèle d'escalier ou de rampe (N0_XML=n0-gpu-1-escalier-... ou -pente) : sur le modèle plat, les marches ne sont que calculées"
TALON_POINTE = float(os.environ.get("N0_TALON_POINTE", "0"))  # R-172 (Yoan, 15.11 13:47 : « dépose sur le talon, la jambe droite ; talon levé ») :
                                                              # à chaque vrai pas (le pied monté de 5 mm), payés à la pose le bout relevé au-dessus
                                                              # du talon (plein à 12 mm) et, au décollage d'avant, le talon levé au-dessus du bout
PIVOT = float(os.environ.get("N0_PIVOT", "0"))                # R-197 (Yoan, 17.11 21:47 : « valoriser la conversion du moment linéaire en rotation ;
                                                              # une récompense corrélée à la vitesse angulaire autour de la cheville lors du contact,
                                                              # combinée à la vitesse vers l'avant ») : pour chaque pied au sol, la jambe (de la
                                                              # hanche au pied) qui bascule vers l'avant autour du pied, rapportée à v / 0,20 m
                                                              # (bornée à 1,5), fois la part de la vitesse demandée tenue (0 à 1)
RIGIDE = float(os.environ.get("N0_RIGIDE", "0"))              # R-197 (« pénalise les postures trop rigides ») : coûte d'être planté sur les deux
                                                              # pieds sans avancer (la vitesse lissée sous 0,3 fois la commande)
POSE_PHOTO = float(os.environ.get("N0_POSE_PHOTO", "0"))     # R-198 (Yoan, 18.11 06:19 : « vise quand même 33 entre les jambes et le genou sous 10, les
POSE_ECART = float(os.environ.get("N0_POSE_ECART", "33"))    # deux ensemble ») : à chaque pose du talon, payés ensemble : la jambe qui se pose tendue
                                                              # (8° d'échelle) et l'écart entre les jambes (hanche → cheville, dans le sens du cap) à
                                                              # POSE_ECART ou plus (6° d'échelle en dessous) ; le reste du pas reste libre de changer
GENOU_TENDU = float(os.environ.get("N0_GENOU_TENDU", "0"))    # R-190 (Yoan, 16.11 15:22 : « déplie le genou au complet, la jambe en extension ; avec
                                                              # l'inertie, le centre de masse va faire un pivot sur le pied ») : à chaque vrai pas
                                                              # (la pose du talon-pointe de R-172), payé le genou de la jambe qui se pose tendu :
                                                              # POIDS x exp(-(genou / 6°)²)
TP_MARCHE = os.environ.get("N0_TP_MARCHE") == "1"           # R-172 (16:35, N0.1-talon-pointe a appris à plonger : 36 % du temps en l'air, une chute
                                                              # en 0,9 s) : le talon-pointe payé seulement si l'autre pied est au sol (une marche, pas un saut)
Y_RELATIF = os.environ.get("N0_Y_RELATIF") == "1"            # R-167 (15.11) : sur les couloirs, le réseau ne voit que sa position par rapport au
                                                              # milieu de son couloir (sinon y désigne le couloir, donc le terrain : une fuite)
FLOW_TAU = float(os.environ.get("N0_FLOW_TAU", "0"))         # R-170 (Yoan, 15.11 12:27, le flow) : un « muscle » : chaque consigne passe par un
                                                              # filtre du premier ordre de FLOW_TAU s (0 = aucun) ; le réseau voit les consignes filtrées
FLOW = float(os.environ.get("N0_FLOW", "0"))                 # R-170 : le coût des à-coups de la commande (le carré de sa dérivée seconde)
BRAS_FIXES = os.environ.get("N0_BRAS_FIXES") == "1"          # R-169 (Yoan, 15.11 11:40, la marche du mannequin) : les bras et le cou tenus à la
                                                              # posture debout, le réseau ne les commande plus
MANNEQUIN = float(os.environ.get("N0_MANNEQUIN", "0"))        # R-169 : la rotation du tronc autour de la verticale coûte (points par rad/s)
CONTRAINTES = [(c.split(":")[0], float(c.split(":")[1])) for c in os.environ.get("N0_CONTRAINTES", "").split(",") if c]   # R-180 (Yoan,
LAM_PAS, LAM_MAX = 0.02, float(os.environ.get("N0_LAM_MAX", "2.0"))   # 19:04, les prix duaux) : « roulis:5,tangage:5 » : chaque contrainte (la moyenne quadratique
                                                              # d'un angle du tronc, en degrés) coûte lambda x (angle / limite)^2 ; lambda monte tant que la
                                                              # moyenne dépasse la limite, redescend sinon (une montée de dual après chaque itération)
CONTRAINTES_OSC = os.environ.get("N0_CONTRAINTES_OSC") == "1"   # R-180, essai 2 (15.11, après L2c qui se dégradait) : la contrainte porte sur l'oscillation
                                                              # (l'écart de l'angle à sa moyenne glissante d'une seconde, robot par robot), pas sur l'angle
                                                              # absolu (qui comptait l'inclinaison naturelle du corps)
APPUI = float(os.environ.get("N0_APPUI", "0"))                # R-178 (Yoan, 15.11 18:40 : « chaque pas sur le point de contact de la projection du centre de
                                                              # gravité, à l'instant où le robot sera par-dessus le point d'appui ») : payé, par pied au sol,
                                                              # quand le centre de gravité passe au-dessus de lui le long du cap (à 1 cm près) et que l'écart
                                                              # de côté est petit (une cloche de 1 cm). Mesuré avant : les marches apprises, 16 à 20 mm
IMITE = float(os.environ.get("N0_IMITE", "0"))                # R-181 (Yoan, 15.11 19:04 : « l'imitation d'une marche de référence remplace une bonne
IMITE_REF = os.environ.get("N0_IMITE_REF", "ref-marche-talon.json")   # partie des règles par une seule ») : payé de ressembler à la marche de référence
IMITE_PROGRES = os.environ.get("N0_IMITE_PROGRES") == "1"     # R-186 (esc-imite, esc-imite2 : debout, immobiles devant l'escalier : la phase lue sur
                                                              # la progression ne bouge pas, rester planté imitait parfaitement) : la ressemblance de
                                                              # l'escalier payée en proportion de la progression (sa vitesse lissée sur 0,5 s, rapportée
                                                              # à la vitesse demandée, de 0 à 1)
IMITE_CADENCE = float(os.environ.get("N0_IMITE_CADENCE", "0"))   # R-189 (L13 : le poids de la vitesse ne fait pas obéir) : la période de la référence
                                                              # raccourcit avec la vitesse commandée, comme la cadence humaine :
                                                              # P(v) = période x (5 cm/s / v)^CADENCE, bornée de 0,5 à 2 fois ; 0 : fixe
IMITE_SIGMA = float(os.environ.get("N0_IMITE_SIGMA", "0.2"))  # (reference_marche_n01.py : le talon, le pied à plat, la pointe ; les bras opposés) :
IMITE_APPUI = float(os.environ.get("N0_IMITE_APPUI", "0.3"))
ELAN = [float(x) for x in os.environ.get("N0_ELAN", "").split(",") if x.strip()]   # R-201 (Yoan, 18.11 07:59 : « commencer la simulation avec le
ELAN_P = float(os.environ.get("N0_ELAN_P", "1"))              # centre de masse qui a déjà une vitesse, la jambe déjà ouverte vers l'avant [...] on lui
ELAN_POSE = float(os.environ.get("N0_ELAN_POSE", "0.04"))     # donne déjà de la vitesse, puis on lui dit apprends ») : une part ELAN_P des départs de la
                                                              # référence (RSI) juste avant la pose d'un talon (ELAN_POSE de phase avant), lancés à une
                                                              # vitesse tirée entre ELAN[0] et ELAN[-1] (m/s) : le corps à cette vitesse, les articulations à
                                                              # celles de la référence au même instant ; la commande, cette vitesse, vers l'avant
CADENCE_MIN = float(os.environ.get("N0_CADENCE_MIN", "0.5"))  # R-201 : la période de la référence bornée à CADENCE_MIN fois la sienne (0,5 : au-delà de
                                                              # 10 cm/s la référence ne suivait plus ; 0,25 la porte à 20 cm/s)
IMITE_RSI = os.environ.get("N0_IMITE_RSI") == "1"             # R-181, essai 3 (comme DeepMimic, « reference state initialization ») : chaque départ dans la
                                                              # posture de la référence à sa phase de départ (au milieu d'un pas), pas debout immobile  # exp(-moyenne des écarts² / SIGMA²) sur les articulations suivies (rad), plus APPUI x la part
                                                              # des pieds dont l'appui est celui de la référence ; la table de sa vitesse commandée
                                                              # (S = v x période), à la phase d'une horloge à elle (1 s par cycle), vue par le réseau
ARMATURE = [float(x) for x in os.environ.get("N0_ARMATURE", "").split(",") if x]   # R-188 : l'inertie des rotors ramenée à la sortie, tirée
                                                              # par monde à chaque départ (log-uniforme entre les deux bornes ; le modèle : 0,002,
                                                              # jamais mesurée ; la fiche du SG90 va avec 0,0003 à 0,0005) ; « 0.0005,0.0005 » : fixe
ADHERENCE = [float(x) for x in os.environ.get("N0_ADHERENCE", "").split(",") if x]   # R-182 (Yoan, 15.11 18:40 : « un jour on devra s'entraîner sur
                                                              # un sol imparfait, les robots vont peut-être marcher dans le gazon ») : L6a, l'adhérence de
                                                              # chaque monde tirée entre les deux bornes (« 0.35,0.9 » ; le modèle : 0,6) à chaque départ
MOU = [float(x) for x in os.environ.get("N0_MOU", "").split(",") if x]   # R-182 : L6a, le sol mou (le gazon) : la constante de temps du contact (s ; le
                                                              # modèle : 0,02) tirée par monde entre les deux bornes à chaque départ (« 0.02,0.05 »)
BOSSES = float(os.environ.get("N0_BOSSES", "0"))              # R-182 (L6b) : le sol à bosses : la hauteur des plus hautes (m, 0,01 au plus) ; le modèle doit avoir
BOSSES_LISSAGE = int(os.environ.get("N0_BOSSES_LISSAGE", "4"))
BOSSES_SANS_PIED = os.environ.get("N0_BOSSES_SANS_PIED") == "1"
BOSSES_DEBUT = float(os.environ.get("N0_BOSSES_DEBUT", os.environ.get("N0_BOSSES", "0")))   # R-182 : l'apprentissage progressif : les bosses grandissent de
                                                              # BOSSES_DEBUT à BOSSES sur les premiers 70 % des pas (comme un enfant, du plancher au gazon)   # R-182 : les pieds (maillages) ne touchent plus le sol, seulement la semelle  # le champ de hauteur « sol » (n0-gpu-1-bosses.xml) ; un bruit lissé, tiré une fois (graine 182) ;
                                                              # chaque départ à un endroit au hasard (±1,5 m) ; la hauteur du sol lue sous chaque pied
PAS_VITESSE = float(os.environ.get("N0_PAS_VITESSE", "0"))   # R-177 (15.11, après L2c et L3i qui couraient : 10 à 14 cm/s quelle que soit la commande) :
                                                              # les paies par pas (le talon-pointe, les grands pas) ne paient plus quand le robot dépasse la
                                                              # vitesse commandée : pleines jusqu'à PAS_VITESSE fois la commande (1,3), nulles à +0,3 de plus ;
                                                              # la vitesse lissée sur 0,4 s ; 0 = rien
VITESSE_POIDS = float(os.environ.get("N0_VITESSE_POIDS", "1"))   # R-181 (15.11, l'imitation marchait sur place ou gardait son pas) : le poids de la paie de
                                                              # la vitesse commandée (1 = comme avant)
PENTE_MONDE = float(os.environ.get("N0_PENTE_MONDE", "0"))   # R-182 (L6c, le 16.11) : le sol ordinaire (le plan, des contacts exacts) incliné robot par robot,
                                                              # d'un angle au hasard de 0 à PENTE_MONDE degrés, dans une direction au hasard, à chaque départ
VERRE_DEBORDE = float(os.environ.get("N0_VERRE_DEBORDE", "15"))   # R-184 (Yoan, 16.11 02:12 : « un verre d'eau dans chaque main, l'eau ne doit pas sortir
                                                              # du verre ; ça va isoler le bas du corps ») : l'eau suit la gravité apparente (la gravité moins
                                                              # l'accélération de la main) ; elle déborde si le verre penche de plus de VERRE_DEBORDE degrés par
                                                              # rapport à elle. Mesuré toujours (le journal, le banc) ; payé par une contrainte « verre:<deg> »
                                                              # (N0_CONTRAINTES, les prix duaux, sur l'angle du verre le plus penché des deux)
COUDES_FIXES = os.environ.get("N0_COUDES_FIXES") == "1"       # R-184 (Yoan, 02:12 : « barrer les poignets le plus possible ; dans la marche à imiter, ils sont
                                                              # fixes ») : les coudes, les épaules de côté et le cou tenus à la posture debout ; l'épaule
                                                              # d'avant en arrière reste libre
SEMELLE_MU = float(os.environ.get("N0_SEMELLE_MU", "0"))      # R-184 (Yoan, 02:12 : « une semelle en caoutchouc, le Vibram des souliers de construction,
                                                              # pas le PLA sur céramique ») : le frottement des pièces du pied (0 = le modèle, 0,6)
SYM_PAS = float(os.environ.get("N0_SYM_PAS", "0"))           # R-185 suite (L8 : la politique symétrique, la démarche pas encore) : à chaque pied
                                                              # posé, l'égalité avec le dernier pas de l'autre pied : la hauteur du vol, et la
                                                              # durée du demi-cycle (depuis la pose de l'autre pied) contre le demi-cycle d'avant ;
                                                              # SYM_PAS x (exp(-(écart_h/0,2)²) + exp(-(écart_c/0,1)²) - 1), de -1 à +1 par pas
SYMETRIE = float(os.environ.get("N0_SYMETRIE", "0"))         # R-185 (Yoan, 16.11 02:12 : « le robot boite ; chaque pas son propre cycle, deux cycles qui
                                                              # s'enchaînent de façon symétrique ») : la perte miroir (Yu, Turk et Liu, 2018) : le réseau doit faire,
                                                              # pour le robot reflété (gauche ↔ droite, la phase décalée d'un demi-cycle), le reflet exact de ce
                                                              # qu'il fait : SYMETRIE x la moyenne de (mu(s) - miroir(mu(miroir(s))))² ; la carte miroir des
                                                              # articulations calculée par miroir_n01.py (gpu/miroir-n01.json)
TRONC_CIBLE = float(os.environ.get("N0_TRONC_CIBLE", "0"))     # R-190 (Yoan, 16.11 09:16 : « on est trop vers l'arrière » : L14 au banc, le tronc à -18°) :
TRONC_CIBLE_POIDS = float(os.environ.get("N0_TRONC_CIBLE_POIDS", "0"))   # payé d'avoir le tronc penché de TRONC_CIBLE degrés vers l'avant (la photo : +6°) :
                                                              # POIDS x max(0, 1 - |tangage - cible| / 30°) (un triangle : la pente se sent encore à 24°
                                                              # de la cible, où une cloche de 5° ne donne plus rien)
TRONC = float(os.environ.get("N0_TRONC", "0"))                # R-177 (Yoan, 15.11 18:33 : « le haut du corps ne peut pas être mou comme ça pendant la
                                                              # marche ») : le tronc ferme : coûtent sa vitesse de tangage et de roulis (rad/s) et son
                                                              # écart à la verticale (au carré, 1 à 20°)
LIGNE = float(os.environ.get("N0_LIGNE", "0"))                # R-176 (Yoan, 15.11 18:29 : la ligne, les pieds un peu décalés, « le réseau peut trouver
LIGNE_DEMI = float(os.environ.get("N0_LIGNE_DEMI", "0.015"))  # l'optimum ») : à chaque vrai pas, le pied posé payé selon son écart à la ligne (la droite du
                                                              # départ le long du cap, refaite quand le cap change) : plein jusqu'à DEMI, nul à 2 DEMI, -1 à 3
OPPOSITION_SOL = os.environ.get("N0_OPPOSITION_SOL") == "1"   # R-175, essai 2 (E91) : l'opposition des cuisses prise par rapport au sol (l'angle du
                                                              # segment hanche-genou dans le monde, le long du cap), pas sur les articulations (le bassin
                                                              # qui bascule les faisait bouger ensemble) ; et le tangage du bassin coûte un peu
OPPOSITION = float(os.environ.get("N0_OPPOSITION", "0"))      # R-175 (Yoan, 15.11 16:41 : « les bras opposés qui contrebalancent ») ; mesuré à 16:55 :
                                                              # toutes les marches apprises de N0.1 ont les hanches en phase (+0,8 à +1). Payé, par pas
                                                              # de 20 ms : les hanches opposées, les bras opposés, chaque bras avec la hanche opposée
PAS_CMD = os.environ.get("N0_PAS_CMD") == "1"                 # R-169 : une grandeur de pas demandée (2 à 8 cm), vue par le réseau ; chaque pas
PAS_MIN, PAS_MAX, PAS_SIGMA = 0.02, 0.08, 0.02                # posé payé en cloche (±2 cm) autour d'elle
GENOU = float(os.environ.get("N0_GENOU", "0"))                 # R-168 : le genou haut : le genou de la jambe en l'air payé sa montée
GENOU_MAX = float(os.environ.get("N0_GENOU_MAX", "0.03"))      # au-dessus de sa hauteur debout, l'autre pied qui porte (au plein à 3 cm)
RETARD_MAX = int(os.environ.get("N0_RETARD_MAX", "0"))         # R-150 N0c : un retard de commande tiré au hasard, 0 à RETARD_MAX pas de 20 ms
                                                                # par départ (le Wi-Fi) ; 0 = aucun


def modele():
    m = mujoco.MjModel.from_xml_path(os.path.join(ICI, N0_XML))
    if BOSSES:                                                  # R-182 : le champ de hauteur rempli ici, de 0 à BOSSES
        assert m.nhfield == 1 and 0 < BOSSES <= m.hfield_size[0][2] + 1e-9 and not ESCALIER, "N0_BOSSES : n0-gpu-1-bosses.xml, 1 cm au plus"
        nr, nc = int(m.hfield_nrow[0]), int(m.hfield_ncol[0])
        h = np.random.default_rng(182).standard_normal((nr, nc))
        for _ in range(BOSSES_LISSAGE):
            h = (h + np.roll(h, 1, 0) + np.roll(h, -1, 0) + np.roll(h, 1, 1) + np.roll(h, -1, 1)) / 5.0
        h = (np.clip(h / h.std(), -2.0, 2.0) + 2.0) / 4.0                    # borné à ±2 écarts types : des bosses réelles, pas quelques pics
        m.hfield_data[:] = h.ravel().astype(np.float32)
        m.hfield_size[0][2] = BOSSES
    for g in range(m.ngeom):
        n = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, g) or ""
        if SEMELLE_MU and ("pied" in n or n.startswith("semelle")):   # R-184 : la semelle en caoutchouc
            m.geom_friction[g, 0] = SEMELLE_MU
        if (n != "sol" and "pied" not in n and not n.startswith("marche") and not n.startswith("semelle")) or (BOSSES_SANS_PIED and n.endswith("-pied")):   # R-160 : la semelle
                                                                # arrondie touche ; R-182 : sur les bosses, BOSSES_SANS_PIED laisse aux rouleaux et à la plaque le contact (moins cher)
            m.geom_contype[g] = 0
            m.geom_conaffinity[g] = 0
    return m


class MondeN0:
    def __init__(self, nworld, graine=0):
        wp.init()
        self.N = nworld
        self.gen = torch.Generator(device=DEV)
        self.gen.manual_seed(graine)
        mjm = modele()
        self.mjm = mjm
        mjd = mujoco.MjData(mjm)
        if N0_POSE0:                                            # R-160 : la posture debout de cette cheville
            mjd.qpos[:] = json.load(open(os.path.join(ICI, N0_POSE0), encoding="utf-8"))
        mujoco.mj_forward(mjm, mjd)
        self.h0 = float(mjd.subtree_com[1][2])
        if BOSSES:                                              # R-182 : la carte des hauteurs, pour lire le sol sous un point (x, y)
            nr, nc = int(mjm.hfield_nrow[0]), int(mjm.hfield_ncol[0])
            self.sol_hn = torch.tensor(mjm.hfield_data.reshape(nr, nc), dtype=torch.float32, device=DEV)   # de 0 à 1
            self.sol_h = self.sol_hn * float(mjm.hfield_size[0][2])
            self.sol_hmaxn = torch.nn.functional.max_pool2d(self.sol_hn[None, None], 3, stride=1, padding=1)[0, 0]   # sous un pied : la plus
            self.sol_hmax = self.sol_hmaxn * float(mjm.hfield_size[0][2])   # haute bosse de son empreinte (3 x 3 cases, ±2 cm), là où il repose
            self.sol_n, self.sol_r = (nr, nc), (float(mjm.hfield_size[0][0]), float(mjm.hfield_size[0][1]))
        self.genoux = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_BODY, "jambe-%s-genou" % c) for c in ("gauche", "droite")]
        self.hk0 = torch.tensor(mjd.xpos[self.genoux, 2], dtype=torch.float32, device=DEV)   # R-168 : la hauteur des genoux debout
        if BOSSES:                                              # R-182 : la posture de départ (faite pour le sol plat) soulevée au-dessus des bosses
            mjd.qpos[2] += BOSSES
            mujoco.mj_forward(mjm, mjd)
        self.m = mjw.put_model(mjm)
        if BOSSES:                                              # R-182 : la hauteur des bosses, lue par la carte à chaque contact (une vue modifiable)
            self.hf_size = wp.to_torch(self.m.hfield_size)
        if ARMATURE:                                            # R-188 : dof_armature par monde (vérifié : essai_armature.py, le genou 3,15 fois
            self.m.dof_armature = wp.array(np.tile(mjm.dof_armature[None], (nworld, 1)).astype(np.float32), dtype=float)   # plus vif à 0,0003)
            self.armat = wp.to_torch(self.m.dof_armature)          # (mondes, ddl), une vue sur la mémoire de la carte
        if ADHERENCE:                                           # R-182 : MuJoCo Warp lit geom_friction[monde % lignes] : une ligne par monde
            self.m.geom_friction = wp.array(np.tile(mjm.geom_friction[None], (nworld, 1, 1)).astype(np.float32), dtype=wp.vec3)
            self.frott = wp.to_torch(self.m.geom_friction)      # (mondes, géométries, 3), une vue sur la mémoire de la carte
        if PENTE_MONDE:                                         # R-182 L6c : geom_quat par monde (MuJoCo Warp lit geom_quat[monde % lignes])
            self.sol_id = mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "sol")
            assert mjm.geom_type[self.sol_id] == mujoco.mjtGeom.mjGEOM_PLANE and not ESCALIER and not BOSSES
            self.m.geom_quat = wp.array(np.tile(mjm.geom_quat[None], (nworld, 1, 1)).astype(np.float32), dtype=wp.quat)
            self.gquat = wp.to_torch(self.m.geom_quat)              # (mondes, géométries, 4), dans l'ordre de MuJoCo (w, x, y, z)
            self.sol_n = torch.zeros(nworld, 3, device=DEV)
            self.sol_n[:, 2] = 1.0
        if MOU:                                                 # R-182 : geom_solref par monde (le contact mêle les deux pièces : toutes changent)
            self.m.geom_solref = wp.array(np.tile(mjm.geom_solref[None], (nworld, 1, 1)).astype(np.float32), dtype=wp.vec2)
            self.solref = wp.to_torch(self.m.geom_solref)
        semelle = any((mujoco.mj_id2name(mjm, mujoco.mjtObj.mjOBJ_GEOM, g) or "").startswith("semelle") for g in range(mjm.ngeom))
        # R-163 (15.11, la vraie physique) : la semelle arrondie fait jusqu'à 16 contacts debout et 96 contraintes par monde ; avec 12 et
        # 64 réservés, Warp en jetait (72 millions d'avertissements « nefc overflow » dans le premier apprentissage de N0.1)
        ncon, njm = (128, 512) if mjm.nhfield else (48, 256) if (ESCALIER and semelle) else (32, 128) if ESCALIER else (32, 192) if semelle else (12, 64)   # R-165 : N0.1 sur l'escalier
        self.d = mjw.put_data(mjm, mjd, nworld=nworld, nconmax=ncon, njmax=njm, nccdmax=ncon if (mjm.nhfield or ESCALIER) else 1)   # R-182 : sur les bosses, chaque contact passe par le calcul convexe (1 seul faisait traverser le sol)
        # R-186 : sur l'escalier aussi (la semelle et les rouleaux contre une boîte : le calcul convexe) : avec 1 par monde, « CCD overflow », des contacts jetés
        couloir = torch.arange(nworld, device=DEV) % len(ESC_COULOIRS)
        self.esc_y = torch.tensor([c[0] for c in ESC_COULOIRS], device=DEV)[couloir]
        self.esc_h = torch.tensor([c[1] for c in ESC_COULOIRS], device=DEV)[couloir]
        self.marche_max = torch.zeros(nworld, device=DEV)
        self.esc_tan = torch.tensor(PENTE_TAN, device=DEV)[couloir] if PENTES else torch.zeros(nworld, device=DEV)
        self.x_decol = torch.zeros(nworld, 2, device=DEV)         # R-167 : où chaque pied a quitté le sol (le long du cap)
        self.touche_prev = torch.ones(nworld, 2, dtype=torch.bool, device=DEV)
        self.h_vol = torch.zeros(nworld, 2, device=DEV)          # R-167 : la plus grande hauteur du pied pendant son vol
        self.tp_sol = torch.ones(nworld, 2, dtype=torch.bool, device=DEV)   # R-172 : le pied au sol (son rouleau le plus bas à moins de 1,5 mm)
        self.tp_vol = torch.zeros(nworld, 2, device=DEV)                     # R-172 : le plus haut du pied pendant son vol
        self.sp_hv, self.sp_dh = torch.zeros(nworld, 2, device=DEV), torch.zeros(nworld, 2, device=DEV)   # R-185 suite : ce vol, le dernier pas
        self.sp_tp = torch.zeros(nworld, 2, device=DEV)                      # l'heure de la dernière pose de chaque pied
        self.sp_dc = torch.zeros(nworld, 2, device=DEV)                      # le dernier demi-cycle fini par chaque pied
        self.sp_ok = torch.zeros(nworld, 2, dtype=torch.bool, device=DEV)    # chaque pied a déjà fait un vrai pas
        self.sp_eh, self.sp_ec, self.sp_n = (torch.zeros((), device=DEV) for _ in range(3))   # le journal
        self.tp_decol = torch.zeros(nworld, 2, device=DEV)                   # R-172 : la paie du talon levé au décollage, versée à la pose
        self.tp_n, self.tp_t, self.tp_k = torch.zeros((), device=DEV), torch.zeros((), device=DEV), 0   # R-172 : pas, talons d'abord (journal)
        self.gp_n, self.gp_l, self.gp_k = torch.zeros((), device=DEV), torch.zeros((), device=DEV), 0   # les pas payés, leur longueur, les pas de temps
        self.gn_s, self.gn_k = torch.zeros((), device=DEV), 0   # R-168 : la paie du genou haut versée (pour le journal)
        self.hl_ok, self.hl_n = torch.zeros((), device=DEV), torch.zeros((), device=DEV)   # R-167 : les pieds en l'air à l'heure (journal)
        self.op_s, self.op_k = torch.zeros((), device=DEV), 0     # R-175 : l'opposition moyenne (journal)
        self.lam = torch.zeros(len(CONTRAINTES), device=DEV)         # R-180 : les prix duaux
        self.c_s = torch.zeros(len(CONTRAINTES), device=DEV)         # R-180 : la somme des angles² sur l'itération (debout)
        self.c_n = torch.zeros((), device=DEV)
        self.c_moy = [0.0] * len(CONTRAINTES)
        self.c_ema = torch.zeros(nworld, max(1, len(CONTRAINTES)), device=DEV)   # R-180 essai 2 : la moyenne glissante des angles, par robot
        self.ligne_o = torch.zeros(nworld, 2, device=DEV)            # R-176 : l'origine de la ligne et son cap
        self.ligne_cap = torch.zeros(nworld, device=DEV)
        self.li_s, self.li_n = torch.zeros((), device=DEV), torch.zeros((), device=DEV)   # R-176 : l'écart des pieds posés (journal)
        self.acu_prec = torch.zeros(nworld, 2, device=DEV)           # R-175 essai 2 : l'angle des cuisses au pas d'avant
        T = lambda a: wp.to_torch(a)
        self.qpos, self.qvel, self.ctrl = T(self.d.qpos), T(self.d.qvel), T(self.d.ctrl)
        self.force = T(self.d.actuator_force)                    # R-161 : le couple de chaque servo
        self.masse = float(mjm.body_mass.sum())
        self.xmat, self.subtree_com = T(self.d.xmat), T(self.d.subtree_com)
        self.xpos = T(self.d.xpos)                                # R-168 : la position des corps (les genoux)
        self.geom_xpos, self.geom_xmat, self.qacc_ws = T(self.d.geom_xpos), T(self.d.geom_xmat), T(self.d.qacc_warmstart)
        art = mjm.actuator_trnid[:, 0]
        self.jq = torch.tensor([mjm.jnt_qposadr[j] for j in art], device=DEV)
        self.jv = torch.tensor([mjm.jnt_dofadr[j] for j in art], device=DEV)
        self.qpos0 = torch.tensor(mjd.qpos if N0_POSE0 else mjm.qpos0, dtype=torch.float32, device=DEV)
        self.nu = mjm.nu
        noms = [mujoco.mj_id2name(mjm, mujoco.mjtObj.mjOBJ_ACTUATOR, i) for i in range(mjm.nu)]
        self.ech = torch.tensor([10.0 if n == "cou" else 30.0 for n in noms], device=DEV)
        self.fixes = torch.tensor([i for i, n in enumerate(noms) if n.startswith("bras-") or n == "cou"], device=DEV)   # R-169
        self.fixes_coudes = torch.tensor([i for i, n in enumerate(noms) if n.endswith("-coude") or n.endswith("-epaule-roulis") or n == "cou"], device=DEV)   # R-184
        self.main_g = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "bras-%s-main" % c) for c in ("gauche", "droit")]   # R-184 : les verres
        self.coude_b = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_BODY, "bras-%s-coude" % c) for c in ("gauche", "droit")]   # (l'axe x de l'avant-bras = le haut du verre)
        self.corps_hanche = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_BODY, "jambe-%s-hanche" % c) for c in ("gauche", "droite")]   # R-175 essai 2
        self.genou_q = torch.tensor([int(mjm.jnt_qposadr[mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_JOINT, "jambe-%s-genou" % c)])
                                     for c in ("gauche", "droite")], device=DEV)   # R-190 : la jambe tendue à la pose
        self.corps_genou = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_BODY, "jambe-%s-genou" % c) for c in ("gauche", "droite")]
        self.corps_cheville = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_BODY, "jambe-%s-cheville-tangage" % c) for c in ("gauche", "droite")]   # R-198
        self.dof_opp = [int(mjm.jnt_dofadr[mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_JOINT, n)]) for n in
                        ("jambe-gauche-hanche", "jambe-droite-hanche", "bras-gauche-epaule", "bras-droit-epaule")]   # R-175
        self.im_esc, self.im_bdz, self.im_bdzS, self.im_btg = False, None, None, 0.0
        if IMITE:                                               # R-181 : les tables de la marche de référence (longueurs x phases x actionneurs)
            J = json.load(open(os.path.join(ICI, IMITE_REF), encoding="utf-8"))
            assert J["noms"] == [mujoco.mj_id2name(mjm, mujoco.mjtObj.mjOBJ_JOINT, j) for j in art], "l'ordre des actionneurs"
            self.im_q = torch.tensor(J["q"], dtype=torch.float32, device=DEV)
            self.im_esc = J.get("type") == "escalier"           # R-186 : la montée marche à marche : une table par hauteur de marche, la phase
            if self.im_esc:                                     # lue sur la progression du corps (pas une horloge), le bassin pour les départs
                assert ESCALIER and not PENTES and not SYMETRIE and abs(float(J["prof"]) - ESC_PROF) < 1e-6, "l'escalier de la référence"
                self.im_S = torch.tensor(J["hauteurs"], dtype=torch.float32, device=DEV)   # l'axe des tables : la hauteur de la marche (m)
                self.im_rac = torch.tensor(J["racine"], dtype=torch.float32, device=DEV)   # (hauteurs, phases, 3) : la racine dx, dz (m), tangage (rad)
                self.im_P, self.im_n, self.im_p0 = 1.0, int(J["n"]), float(J["p0"])
            else:
                self.im_S = torch.tensor(J["pas_m"], dtype=torch.float32, device=DEV)
                self.im_P, self.im_n = float(J["periode_s"]), int(J["n"])
            self.im_bdz = torch.tensor(J["bassin_dz"], dtype=torch.float32, device=DEV) if "bassin_dz" in J else None   # R-187 v2 : la hauteur du bassin
            self.im_bdzS = torch.tensor(J["bassin_dz_S"], dtype=torch.float32, device=DEV)[:, :, None] if "bassin_dz_S" in J else None   # R-190 :
            self.im_btg = math.radians(float(J.get("bassin_tangage_deg", 0.0)))   # par longueur de pas ; le tronc penché de la référence
            self.im_suiv = torch.tensor([J["noms"].index(n) for n in J["suivies"]], device=DEV)
            self.im_appuis = torch.tensor(J["appuis"], dtype=torch.bool, device=DEV)
            self.im_noms = J["suivies"]
            self.im_ea_w = torch.zeros(nworld, len(J["suivies"]), device=DEV)   # R-181 : l'écart² par articulation suivie, par monde (le banc)
        self.im_s, self.im_e, self.im_c, self.im_k = (torch.zeros((), device=DEV) for _ in range(4))   # R-181 : le journal
        self.pieds = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "jambe-%s-pied" % c) for c in ("gauche", "droite")]
        self.talons = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "semelle-%s-talon" % c) for c in ("gauche", "droite")]   # R-171
        self.bouts = [mujoco.mj_name2id(mjm, mujoco.mjtObj.mjOBJ_GEOM, "semelle-%s-pointe" % c) for c in ("gauche", "droite")]   # R-172
        self.r_talon = float(mjm.geom_size[self.talons[0]][0]) if self.talons[0] >= 0 else 0.0
        self.hl_talon = float(mjm.geom_size[self.talons[0]][1]) if self.talons[0] >= 0 else 0.0
        self.demi_pied = torch.tensor(mjm.geom_size[self.pieds], dtype=torch.float32, device=DEV)
        self.n_sub = int(round(DT_C / mjm.opt.timestep))
        mjw.step(self.m, self.d)
        wp.synchronize()
        with wp.ScopedCapture() as cap:
            for _ in range(self.n_sub):
                mjw.step(self.m, self.d)
        self.graphe_pas = cap.graph
        with wp.ScopedCapture() as cap2:
            mjw.forward(self.m, self.d)
        self.graphe_avant = cap2.graph
        z = lambda *s: torch.zeros(*s, device=DEV)
        self.na = self.nu + 1
        self.t, self.th = z(nworld), z(nworld)
        self.phi = z(nworld)                                       # R-181 : la phase de la marche de référence (0 à 1)
        self.im_kc, self.im_hc = z(nworld), z(nworld)              # R-186 : le cycle de la montée (de la marche k à k+1) et la hauteur qu'il monte
        self.im_p, self.im_pp, self.im_pv = z(nworld), z(nworld), z(nworld)   # R-186 : la progression, celle d'avant, sa vitesse lissée
        self.main_prec, self.main_v, self.main_a = z(nworld, 2, 3), z(nworld, 2, 3), z(nworld, 2, 3)   # R-184 : les mains (les verres)
        self.verre_th = z(nworld)                                  # R-184 : l'angle du verre le plus penché par rapport à l'eau (degrés)
        self.vr_n_w, self.vr_d_w, self.vr_s_w = z(nworld), z(nworld), z(nworld)   # R-184 : par monde (le banc) : pas debout, pas qui débordent, somme des angles
        self.im_e_w, self.im_c_w, self.im_n_w = z(nworld), z(nworld), z(nworld)   # R-181 : par monde (le banc)
        self.a_prev = z(nworld, self.na)
        self.a_prev2 = z(nworld, self.na)                          # R-170 : l'avant-dernière action (les à-coups de la commande)
        self.cible = self.qpos0[self.jq].repeat(nworld, 1)         # R-170 : les consignes filtrées (le « muscle »)
        self.cm_prec, self.pied_prec = z(nworld, 2), z(nworld, 2, 2)
        self.ret, self.long = z(nworld), z(nworld)
        self.v_lisse = z(nworld)                                   # R-177 : la vitesse le long du cap, lissée (le frein des paies par pas)
        self.el_n = 0.0                                            # R-201 : le nombre de départs lancés
        self.piv_th = z(nworld, 2)                                 # R-197 : l'angle de chaque jambe autour de son pied, au pas d'avant
        self.piv_ok = torch.zeros(nworld, dtype=torch.bool, device=DEV)
        self.cap_cmd, self.v_cmd, self.t_cmd = z(nworld), z(nworld), z(nworld)
        self.l_cmd = z(nworld) + 0.05                              # R-169 : la grandeur de pas demandée (m)
        self.t_air, self.ema = z(nworld), z(nworld, 2) + 0.5
        self.hist = z(RETARD_MAX + 1, nworld, self.na)          # les dernières commandes du réseau (la plus récente en 0)
        self.retard = torch.zeros(nworld, dtype=torch.long, device=DEV)
        self.sans_reinit = False
        self.depart_pied = False                                   # R-186 : True (le banc) : tous au pied de l'escalier, les pieds ensemble
        self.reinit(torch.ones(nworld, dtype=torch.bool, device=DEV))

    def periode(self, v):
        """R-189 : la période de la référence à la vitesse commandée v (fixe sans IMITE_CADENCE, et toujours pour l'escalier, dont l'axe des
        tables est la hauteur de marche)."""
        if IMITE_CADENCE <= 0 or self.im_esc:
            return self.im_P
        return self.im_P * torch.clamp((0.05 / torch.clamp(v, min=1e-3)) ** IMITE_CADENCE, CADENCE_MIN, 2.0)

    def racine_reference(self, h, phi):
        """R-186 : la racine de la référence de l'escalier (dx, dz, tangage), interpolée en hauteur et en phase (sans boucler la phase)."""
        K_ = self.im_S.shape[0]
        pos_ = torch.clamp(h, 0.0, float(self.im_S[-1])) / float(self.im_S[1] - self.im_S[0])
        k0_ = torch.clamp(pos_.floor().long(), 0, K_ - 2)
        w_ = (pos_ - k0_.float()).clamp(0.0, 1.0)[:, None]
        f_ = torch.clamp(phi, 0.0, 1.0 - 1e-6) * (self.im_n - 1)
        i0_ = f_.floor().long()
        g_ = (f_ - f_.floor())[:, None]
        R_ = self.im_rac
        return (1 - w_) * ((1 - g_) * R_[k0_, i0_] + g_ * R_[k0_, i0_ + 1]) + w_ * ((1 - g_) * R_[k0_ + 1, i0_] + g_ * R_[k0_ + 1, i0_ + 1])

    def phase_escalier(self):
        """R-186 : la phase de la montée, lue sur la progression du corps : p = la moyenne des x du centre de masse et des deux pieds ; le
        cycle k (de la marche k à k+1 ; 0 = du sol à la 1re marche), la phase u dans [0, 1), la hauteur que ce cycle monte (0 avant
        l'escalier et sur le palier)."""
        p = (self.subtree_com[:, 1, 0] + self.geom_xpos[:, self.pieds[0], 0] + self.geom_xpos[:, self.pieds[1], 0]) / 3.0
        s = (p - (ESC_X0 - 0.5 * ESC_PROF) - self.im_p0) / ESC_PROF
        k = torch.floor(s)
        h = torch.where((k >= 0) & (k <= ESC_NB - 1), self.esc_h, torch.zeros_like(self.esc_h))
        self.im_p = p
        return s - k, k, h

    def q_reference(self, v, phi, Q_=None):
        """R-181 : la référence (les angles des actionneurs) pour une vitesse commandée et une phase, interpolée en longueur de pas et en
        phase ; rend aussi l'indice de phase (pour les appuis de la référence)."""
        K_ = self.im_S.shape[0]
        pos_ = torch.clamp(v * self.periode(v), 0.0, float(self.im_S[-1])) / float(self.im_S[1] - self.im_S[0])   # R-189 : S = v x P(v)
        k0_ = torch.clamp(pos_.floor().long(), 0, K_ - 2)
        w_ = (pos_ - k0_.float()).clamp(0.0, 1.0)[:, None]
        f_ = phi * self.im_n
        i0_ = f_.floor().long() % self.im_n
        i1_ = (i0_ + 1) % self.im_n
        g_ = (f_ - f_.floor())[:, None]
        Q_ = self.im_q if Q_ is None else Q_
        return (1 - w_) * ((1 - g_) * Q_[k0_, i0_] + g_ * Q_[k0_, i1_]) + w_ * ((1 - g_) * Q_[k0_ + 1, i0_] + g_ * Q_[k0_ + 1, i1_]), i0_

    def miroirs(self, no):
        """R-185 : les cartes miroir (gauche ↔ droite) des mesures et des actions : miroir(x)[k] = S[k] * x[P[k]]. Suit obs() bloc par bloc ;
        les phases (l'oscillateur, la référence) avancent d'un demi-cycle : leurs sinus et cosinus changent de signe."""
        J = json.load(open(os.path.join(ICI, "miroir-n01.json"), encoding="utf-8"))
        noms = [mujoco.mj_id2name(self.mjm, mujoco.mjtObj.mjOBJ_JOINT, j) for j in self.mjm.actuator_trnid[:, 0]]
        assert J["noms"] == noms, "l'ordre des actionneurs"
        pj, sj = J["perm"], J["signe"]
        P, S = [], []

        def bloc(idx, sg):
            o_ = len(P)
            P.extend([o_ + i for i in idx])
            S.extend(sg)

        bloc([0, 1], [-1, -1])                                     # sin, cos de l'oscillateur : un demi-cycle plus loin
        bloc([0, 1, 2, 3], [1, -1, 1, -1])                         # tangage, roulis, leurs vitesses
        bloc([0, 1, 2], [-1, 1, -1])                               # la vitesse angulaire du bassin (repère local)
        bloc([0, 1, 2], [1, -1, 1])                                # la vitesse dans le repère du cap
        bloc([0], [1])                                             # la hauteur
        bloc(pj, sj)                                               # les angles
        bloc(pj, sj)                                               # leurs vitesses
        bloc(pj + [self.nu], sj + [1])                             # l'action d'avant (et la cadence)
        bloc([0, 1, 2], [-1, 1, -1])                               # sin, cos du lacet, y du centre de masse
        bloc([0, 1, 2], [-1, 1, 1])                                # le cap commandé relatif, la vitesse commandée
        if ESCALIER:
            bloc(list(range(len(ESC_SCAN))), [1] * len(ESC_SCAN))
        if PAS_CMD:
            bloc([0], [1])
        if FLOW_TAU > 0:
            bloc(pj, sj)                                           # les consignes filtrées
        if IMITE:
            bloc([0, 1], [-1, -1])                                 # sin, cos de la référence : un demi-cycle plus loin
        assert len(P) == no, (len(P), no)
        Pa, Sa = list(pj) + [self.nu], list(sj) + [1]
        T_ = lambda x, dt: torch.tensor(x, device=DEV, dtype=dt)
        return T_(P, torch.long), T_(S, torch.float32), T_(Pa, torch.long), T_(Sa, torch.float32)

    def bosses(self, A):
        """R-182 : la hauteur des plus hautes bosses (m), changée en place : la carte et la lecture du sol (terrain) ensemble."""
        self.hf_size[0, 2] = A
        self.sol_h = self.sol_hn * A
        self.sol_hmax = self.sol_hmaxn * A

    def attitude(self):
        R = self.xmat[:, 1]
        return (-torch.rad2deg(torch.asin(torch.clamp(R[:, 2, 0], -1, 1))), torch.rad2deg(torch.asin(torch.clamp(R[:, 2, 1], -1, 1))),
                torch.rad2deg(self.qvel[:, 4]), torch.rad2deg(self.qvel[:, 3]))

    def lacet(self):
        R = self.xmat[:, 1]
        return torch.atan2(R[:, 1, 0], R[:, 0, 0])

    def terrain(self, x, y=None, pied=False):
        """R-159 : la hauteur du terrain sous x (un tenseur (N,) ou (N, k)) dans le couloir de chaque monde ; 0 sans escalier.
        R-182 : sur le sol à bosses, sous (x, y) : le champ de hauteur interpolé entre ses quatre points voisins."""
        if PENTE_MONDE:                                         # R-182 L6c : le plan incliné de chaque monde, passant par l'origine
            assert y is not None, "la pente demande y"
            n_ = self.sol_n if x.dim() == 1 else self.sol_n[:, None, :]
            return -(n_[..., 0] * x + n_[..., 1] * y) / n_[..., 2]
        if BOSSES:
            assert y is not None, "le sol à bosses demande y"
            (nr, nc), (rx, ry) = self.sol_n, self.sol_r
            u = torch.clamp((x + rx) / (2 * rx) * (nc - 1), 0.0, nc - 1.0001)
            v = torch.clamp((y + ry) / (2 * ry) * (nr - 1), 0.0, nr - 1.0001)
            j, i = u.floor().long(), v.floor().long()
            fu, fv = u - j, v - i
            Hs = self.sol_hmax if pied else self.sol_h               # pied=True : la plus haute bosse sous l'empreinte d'un pied
            return (1 - fv) * ((1 - fu) * Hs[i, j] + fu * Hs[i, j + 1]) + fv * ((1 - fu) * Hs[i + 1, j] + fu * Hs[i + 1, j + 1])
        if not ESCALIER:
            return torch.zeros_like(x)
        if PENTES:                                              # R-167 : la rampe monte de tan(angle) par mètre après ESC_X0
            t = self.esc_tan if x.dim() == 1 else self.esc_tan[:, None]
            return t * torch.clamp(x - ESC_X0, 0.0, RAMPE_L)
        h = self.esc_h if x.dim() == 1 else self.esc_h[:, None]
        n = torch.clamp(torch.floor((x - ESC_X0) / ESC_PROF) + 1, 0, ESC_NB)
        return n * h

    def inclinaison(self):
        qq = self.qpos[:, 3:7]
        return torch.rad2deg(torch.acos(torch.clamp(1 - 2 * (qq[:, 1] ** 2 + qq[:, 2] ** 2), -1, 1)))

    def puissance(self):
        """R-161 : les watts estimés des servos : le travail mécanique (|couple x vitesse|) et la chaleur du courant qui tient le couple
        (R I², I = couple / KT) ; la somme est l'électricité qu'il faudrait aux 13 servos (le rendement du réducteur est ignoré)."""
        tau, w = self.force, self.qvel[:, self.jv]
        return (tau * w).abs().sum(1), (R_SERVO * (tau / KT) ** 2).sum(1)

    def obs(self):
        fb = self.attitude()
        psi = self.lacet()
        c, s = torch.cos(psi), torch.sin(psi)
        v = self.qvel[:, 0:3]
        vl = torch.stack([c * v[:, 0] + s * v[:, 1], -s * v[:, 0] + c * v[:, 1], v[:, 2]], 1)
        cm = self.subtree_com[:, 1]
        return torch.cat([torch.stack([torch.sin(self.th), torch.cos(self.th)], 1),
                          torch.stack([fb[0] / 45.0, fb[1] / 45.0, fb[2] / 100.0, fb[3] / 100.0], 1),
                          0.2 * self.qvel[:, 3:6], 10.0 * vl, (5.0 * ((cm[:, 2] - self.terrain(cm[:, 0], cm[:, 1])) / self.h0 - 1.0))[:, None],
                          2.0 * (self.qpos[:, self.jq] - self.qpos0[self.jq]), 0.05 * self.qvel[:, self.jv], self.a_prev,
                          torch.stack([torch.sin(psi), torch.cos(psi), 10.0 * (cm[:, 1] - (self.esc_y if (ESCALIER and Y_RELATIF) else 0.0))], 1),
                          torch.stack([torch.sin(self.cap_cmd - psi), torch.cos(self.cap_cmd - psi), 10.0 * self.v_cmd], 1)]
                         + ([20.0 * (self.terrain(cm[:, 0:1] + torch.tensor(ESC_SCAN, device=DEV)[None]) - self.terrain(cm[:, 0])[:, None])]
                            if ESCALIER else [])
                         + ([10.0 * self.l_cmd[:, None]] if PAS_CMD else [])     # R-169 : la grandeur de pas demandée
                         + ([2.0 * (self.cible - self.qpos0[self.jq])] if FLOW_TAU > 0 else [])    # R-170 : les consignes filtrées
                         + ([torch.stack([torch.sin(2 * math.pi * self.phi), torch.cos(2 * math.pi * self.phi)], 1)] if IMITE else []), 1)   # R-181

    def tirer_commandes(self, masque, cap_fixe=None, v_fixe=None):
        k = int(masque.sum())
        if k == 0:
            return
        self.cap_cmd[masque] = (torch.rand(k, device=DEV, generator=self.gen) * 2 - 1) * math.pi if cap_fixe is None else cap_fixe
        self.v_cmd[masque] = (V_MIN + (V_MAX - V_MIN) * torch.rand(k, device=DEV, generator=self.gen)) if v_fixe is None else v_fixe
        if ESCALIER and cap_fixe is None:                       # R-159 : face à l'escalier, de 3 à 8 cm/s
            self.cap_cmd[masque] = 0.0
            self.v_cmd[masque] = 0.03 + 0.05 * torch.rand(k, device=DEV, generator=self.gen)
        if PAS_CMD:                                             # R-169 : une grandeur de pas demandée, tirée avec la vitesse
            self.l_cmd[masque] = PAS_MIN + (PAS_MAX - PAS_MIN) * torch.rand(k, device=DEV, generator=self.gen)
        self.t_cmd[masque] = self.t[masque] + 3.0 + 3.0 * torch.rand(k, device=DEV, generator=self.gen)

    def reinit(self, masque, perturbations=None):
        k = int(masque.sum())
        if k == 0:
            return
        q = self.qpos0.repeat(k, 1)
        pert = (torch.rand(k, self.nu, device=DEV, generator=self.gen) * 2 - 1) if perturbations is None else torch.as_tensor(perturbations, dtype=torch.float32, device=DEV)
        q[:, self.jq] += torch.deg2rad(pert)
        if PENTE_MONDE:                                         # R-182 L6c : un angle et une direction au hasard ; le départ soulevé de ce que la pente
            th_ = torch.deg2rad(PENTE_MONDE * torch.rand(k, device=DEV, generator=self.gen))   # creuse sous un pied (±4 cm)
            ph_ = 2 * math.pi * torch.rand(k, device=DEV, generator=self.gen)
            n_ = torch.stack([torch.sin(th_) * torch.cos(ph_), torch.sin(th_) * torch.sin(ph_), torch.cos(th_)], 1)
            self.sol_n[masque] = n_
            qs_ = torch.stack([torch.cos(th_ / 2), -torch.sin(ph_) * torch.sin(th_ / 2), torch.cos(ph_) * torch.sin(th_ / 2), torch.zeros_like(th_)], 1)
            self.gquat[masque, self.sol_id] = qs_                   # la rotation qui porte z sur la normale n (l'axe z x n, l'angle th)
            q[:, 2] += torch.tan(th_) * 0.04
        if BOSSES:                                              # R-182 : un endroit au hasard du champ, posé au-dessus des plus hautes bosses
            q[:, 0:2] += (torch.rand(k, 2, device=DEV, generator=self.gen) * 2 - 1) * 1.5
            q[:, 2] += BOSSES
        if ESCALIER:                                            # R-159 : au pied de l'escalier de son couloir
            q[:, 0] = (torch.rand(k, device=DEV, generator=self.gen) * 2 - 1) * 0.05
            q[:, 1] += self.esc_y[masque]
            self.marche_max[masque] = 0.0
        self.qpos[masque] = q
        self.qvel[masque] = 0.0
        self.qacc_ws[masque] = 0.0
        self.ctrl[masque] = 0.0
        self.t[masque], self.th[masque] = 0.0, 0.0
        self.a_prev[masque] = 0.0
        self.a_prev2[masque] = 0.0
        self.cible[masque] = q[:, self.jq]                         # R-170 : le muscle part de la posture de départ
        self.ret[masque], self.long[masque] = 0.0, 0.0
        self.v_lisse[masque] = 0.0
        self.piv_ok[masque] = False
        self.t_air[masque], self.ema[masque] = 0.0, 0.5
        self.touche_prev[masque], self.x_decol[masque], self.h_vol[masque] = True, 0.0, 0.0
        self.tp_sol[masque], self.tp_vol[masque], self.tp_decol[masque] = True, 0.0, 0.0   # R-172
        self.sp_hv[masque], self.sp_dh[masque], self.sp_tp[masque], self.sp_dc[masque], self.sp_ok[masque] = 0.0, 0.0, 0.0, 0.0, False   # R-185 suite
        self.hist[:, masque] = 0.0
        if RETARD_MAX:
            self.retard[masque] = torch.randint(0, RETARD_MAX + 1, (k,), device=DEV, generator=self.gen)
        self.tirer_commandes(masque)
        if IMITE and self.im_esc:                               # R-186 : un départ dans la montée : un cycle et une phase au hasard (RSI), ou au
            if IMITE_RSI and not self.depart_pied:              # pied de l'escalier, les pieds ensemble sur le sol (le banc, et sans RSI)
                kc_ = torch.randint(-1, ESC_NB + 1, (k,), device=DEV, generator=self.gen).float()
                u_ = torch.rand(k, device=DEV, generator=self.gen) * 0.98
                if ESC_PIED > 0:                                # R-186 : une part au pied de l'escalier, comme au banc
                    pied_ = torch.rand(k, device=DEV, generator=self.gen) < ESC_PIED
                    kc_ = torch.where(pied_, torch.zeros_like(kc_), kc_)
                    u_ = torch.where(pied_, torch.zeros_like(u_), u_)
            else:
                kc_, u_ = torch.zeros(k, device=DEV), torch.zeros(k, device=DEV)
            eh_ = self.esc_h[masque]
            hc_ = torch.where((kc_ >= 0) & (kc_ <= ESC_NB - 1), eh_, torch.zeros_like(eh_))
            qr_, _ = self.q_reference(hc_, u_)
            qr_ = qr_ + torch.deg2rad(pert)
            rac_ = self.racine_reference(hc_, u_)
            qm_ = self.qpos[masque]
            qm_[:, self.jq] = qr_
            qm_[:, 0] = ESC_X0 - 0.5 * ESC_PROF + kc_ * ESC_PROF + rac_[:, 0]
            qm_[:, 2] = self.qpos0[2] + eh_ * torch.clamp(kc_, 0, ESC_NB) + rac_[:, 1]
            qm_[:, 3:7] = torch.stack([torch.cos(rac_[:, 2] / 2), torch.zeros_like(u_), torch.sin(rac_[:, 2] / 2), torch.zeros_like(u_)], 1)
            self.qpos[masque] = qm_
            self.cible[masque] = qr_
            self.phi[masque], self.im_kc[masque], self.im_hc[masque] = u_, kc_, hc_
        elif IMITE:                                             # R-181 : la marche de référence part à une phase au hasard
            self.phi[masque] = torch.rand(k, device=DEV, generator=self.gen)
            if ELAN and IMITE_RSI:                              # R-201 : les départs lancés, juste avant une pose du talon (phase 0 ou 0,5)
                el_ = torch.rand(k, device=DEV, generator=self.gen) < ELAN_P
                v0_ = ELAN[0] + (ELAN[-1] - ELAN[0]) * torch.rand(k, device=DEV, generator=self.gen)
                cote_ = torch.randint(0, 2, (k,), device=DEV, generator=self.gen).float() * 0.5
                self.phi[masque] = torch.where(el_, (cote_ - ELAN_POSE * torch.rand(k, device=DEV, generator=self.gen)) % 1.0, self.phi[masque])
                self.v_cmd[masque] = torch.where(el_, v0_, self.v_cmd[masque])
                self.cap_cmd[masque] = torch.where(el_, torch.zeros_like(v0_), self.cap_cmd[masque])
            if IMITE_RSI:                                       # R-181 essai 3 : le départ dans la posture de la référence (+ le même petit bruit)
                qr_, _ = self.q_reference(self.v_cmd[masque], self.phi[masque])
                qr_ = qr_ + torch.deg2rad(pert)
                qm_ = self.qpos[masque]
                qm_[:, self.jq] = qr_
                if self.im_bdz is not None:                     # R-187 v2 : le bassin à la hauteur de la référence (plus haut sur la jambe d'appui)
                    qm_[:, 2] = qm_[:, 2] + self.im_bdz[(self.phi[masque] * self.im_n).long() % self.im_n]
                if self.im_bdzS is not None:                    # R-190 : la hauteur du bassin de la table de sa longueur de pas, et son tangage
                    dz_, _ = self.q_reference(self.v_cmd[masque], self.phi[masque], self.im_bdzS)
                    qm_[:, 2] = qm_[:, 2] + dz_[:, 0]
                    if self.im_btg:                             # (qt x q, comme Statique.pose : le tangage autour de y du monde)
                        c_, s_ = math.cos(self.im_btg / 2), math.sin(self.im_btg / 2)
                        w_, x_, y_, z_ = qm_[:, 3].clone(), qm_[:, 4].clone(), qm_[:, 5].clone(), qm_[:, 6].clone()
                        qm_[:, 3:7] = torch.stack([c_ * w_ - s_ * y_, c_ * x_ + s_ * z_, c_ * y_ + s_ * w_, c_ * z_ - s_ * x_], 1)
                self.qpos[masque] = qm_
                self.cible[masque] = qr_
                if ELAN:                                        # R-201 : les vitesses de la référence au même instant (dq/dphi x dphi/dt, dphi/dt = v / S)
                    vv_ = self.v_cmd[masque]
                    e_ = 0.005
                    qa_, _ = self.q_reference(vv_, (self.phi[masque] + e_) % 1.0)
                    qb_, _ = self.q_reference(vv_, (self.phi[masque] - e_) % 1.0)
                    S_ = torch.clamp(vv_ * self.periode(vv_), min=1e-3, max=float(self.im_S[-1]))
                    dphi_ = vv_ / S_
                    qv_ = self.qvel[masque]
                    jv_ = qv_[:, self.jv]
                    qv_[:, self.jv] = torch.where(el_[:, None], (qa_ - qb_) / (2 * e_) * dphi_[:, None], jv_)
                    qv_[:, 0] = torch.where(el_, vv_, qv_[:, 0])            # le corps lancé vers l'avant (le départ face à +x)
                    if self.im_bdzS is not None:
                        za_, _ = self.q_reference(vv_, (self.phi[masque] + e_) % 1.0, self.im_bdzS)
                        zb_, _ = self.q_reference(vv_, (self.phi[masque] - e_) % 1.0, self.im_bdzS)
                        qv_[:, 2] = torch.where(el_, (za_[:, 0] - zb_[:, 0]) / (2 * e_) * dphi_, qv_[:, 2])
                    self.qvel[masque] = qv_
                    self.el_n += float(el_.sum())
        if ARMATURE:                                            # R-188 : une inertie nouvelle à chaque départ, la même pour tous les servos d'un robot
            la_ = math.log(ARMATURE[0]) + (math.log(ARMATURE[-1]) - math.log(ARMATURE[0])) * torch.rand(k, device=DEV, generator=self.gen)
            a_ = self.armat[masque]
            a_[:, self.jv] = torch.exp(la_)[:, None]
            self.armat[masque] = a_
        if ADHERENCE:                                           # R-182 : une adhérence nouvelle à chaque départ (toutes les pièces : le contact
            mu = ADHERENCE[0] + (ADHERENCE[-1] - ADHERENCE[0]) * torch.rand(k, device=DEV, generator=self.gen)   # prend la plus grande des deux)
            self.frott[masque, :, 0] = mu[:, None]
        if MOU:
            tc = MOU[0] + (MOU[-1] - MOU[0]) * torch.rand(k, device=DEV, generator=self.gen)
            self.solref[masque, :, 0] = tc[:, None]
        torch.cuda.synchronize()
        wp.capture_launch(self.graphe_avant)
        wp.synchronize()
        if ESCALIER and not PENTES:                             # R-186 : un départ au milieu de l'escalier : les marches sous lui ne paient pas
            self.marche_max[masque] = torch.clamp(torch.floor((self.subtree_com[masque, 1, 2] - self.h0 + 0.5 * self.esc_h[masque]) / self.esc_h[masque]), 0, ESC_NB)
            if IMITE and self.im_esc:                           # R-186 : la progression part de la posture de départ, immobile
                self.phase_escalier()
                self.im_pp[masque] = self.im_p[masque]
                self.im_pv[masque] = 0.0
        self.cm_prec[masque] = self.subtree_com[masque, 1, :2]
        self.main_prec[masque] = self.geom_xpos[masque][:, self.main_g]   # R-184 : les verres partent immobiles
        self.main_v[masque], self.main_a[masque] = 0.0, 0.0
        self.ligne_o[masque] = self.subtree_com[masque, 1, :2]       # R-176 : la ligne part du centre de masse au départ, le long du cap
        if CONTRAINTES and CONTRAINTES_OSC:                     # R-180 essai 2 : la moyenne glissante part de la posture de départ
            fb0_ = self.attitude()
            ang0_ = {"tangage": fb0_[0], "roulis": fb0_[1]}
            for k_, (nom_, _) in enumerate(CONTRAINTES):
                self.c_ema[masque, k_] = ang0_[nom_][masque]
        self.ligne_cap[masque] = self.cap_cmd[masque]
        self.pied_prec[masque] = self.geom_xpos[masque][:, self.pieds, :2]

    def pas(self, action):
        a = torch.clamp(action, -1.0, 1.0)
        if RETARD_MAX:                                          # le robot exécute la commande d'il y a self.retard pas
            self.hist = torch.cat([a[None], self.hist[:-1]], 0)
            a = self.hist[self.retard, torch.arange(self.N, device=DEV)]
        if not self.sans_reinit:
            self.tirer_commandes(self.t >= self.t_cmd)
        if POUSSEE:                                             # R-157 N0h : un coup au bassin, en avant, en arrière ou de côté
            coup = torch.rand(self.N, device=DEV, generator=self.gen) < POUSSEE_P
            if coup.any():
                self.qvel[coup, 0:2] += (torch.rand(int(coup.sum()), 2, device=DEV, generator=self.gen) * 2 - 1) * POUSSEE
        brute = torch.deg2rad(self.ech * a[:, :self.nu]) + self.qpos0[self.jq]
        if FLOW_TAU > 0:                                        # R-170 : le muscle : la consigne glisse vers celle du réseau (1er ordre)
            self.cible = self.cible + min(1.0, DT_C / FLOW_TAU) * (brute - self.cible)
            self.ctrl[:] = self.cible
        else:
            self.ctrl[:] = brute
        if BRAS_FIXES:                                          # R-169 : les bras et le cou tenus à la posture debout
            self.ctrl[:, self.fixes] = self.qpos0[self.jq][self.fixes]
        if COUDES_FIXES:                                        # R-184 : les coudes, les épaules de côté et le cou barrés
            self.ctrl[:, self.fixes_coudes] = self.qpos0[self.jq][self.fixes_coudes]
        torch.cuda.synchronize()
        wp.capture_launch(self.graphe_pas)
        wp.synchronize()
        self.t += DT_C
        mp_ = self.geom_xpos[:, self.main_g]                       # R-184 : le verre d'eau : la gravité apparente dans chaque main
        mv_ = (mp_ - self.main_prec) / DT_C
        self.main_a = self.main_a + 0.2 * ((mv_ - self.main_v) / DT_C - self.main_a)   # l'accélération de la main, lissée sur 0,1 s (le ballottement de
                                                                   # l'eau dans un verre, 3 à 5 Hz ; vérifié sur la référence rejouée : 4,8° et 0 % à 5 cm/s)
        self.main_prec, self.main_v = mp_.clone(), mv_
        hv_ = self.xmat[:, self.coude_b][:, :, :, 0]                # le haut du verre (l'axe x de l'avant-bras, vertical debout)
        ga_ = self.main_a.clone()
        ga_[:, :, 2] += 9.81                                       # le haut apparent de l'eau : l'accélération de la main plus la gravité
        cv_ = (hv_ * ga_).sum(2) / torch.clamp(ga_.norm(dim=2), min=1e-6)
        self.verre_th = torch.rad2deg(torch.acos(torch.clamp(cv_, -1.0, 1.0))).max(1).values
        self.th += 2 * math.pi / T0 * DT_C * (1.0 + 0.45 * a[:, -1])
        if IMITE and self.im_esc:                               # R-186 : la phase lue sur la progression du corps
            self.phi, self.im_kc, self.im_hc = self.phase_escalier()
            self.im_pv = self.im_pv + (DT_C / 0.5) * ((self.im_p - self.im_pp) / DT_C - self.im_pv)   # R-186 : la vitesse de la progression
            self.im_pp = self.im_p.clone()
        elif IMITE:                                             # R-181 : l'horloge de la référence avance d'elle-même
            self.phi = (self.phi + DT_C / self.periode(self.v_cmd)) % 1.0   # R-189 : à la cadence de la vitesse commandée
        cm = self.subtree_com[:, 1, :2]
        vx = (cm[:, 0] - self.cm_prec[:, 0]) / DT_C
        vy = (cm[:, 1] - self.cm_prec[:, 1]) / DT_C
        self.cm_prec = cm.clone()
        tilt = self.inclinaison()
        tombe = (tilt > 40.0) | (self.subtree_com[:, 1, 2] - self.terrain(self.subtree_com[:, 1, 0], self.subtree_com[:, 1, 1]) < 0.6 * self.h0) | ~torch.isfinite(self.qpos).all(1) | ~torch.isfinite(self.qvel).all(1)
        debout = (tilt < 25.0).float()
        self.vr_n_w += debout                                       # R-184 : la mesure du verre (le journal, le banc)
        self.vr_d_w += debout * (self.verre_th > VERRE_DEBORDE).float()
        self.vr_s_w += debout * self.verre_th
        psi = self.lacet()
        v_dir = vx * torch.cos(self.cap_cmd) + vy * torch.sin(self.cap_cmd)
        self.v_lisse = 0.95 * self.v_lisse + 0.05 * v_dir
        frein = torch.clamp((PAS_VITESSE + 0.3 - self.v_lisse / self.v_cmd) / 0.3, 0.0, 1.0) if PAS_VITESSE else 1.0   # R-177 : 1 tant qu'il obéit
        dpsi = torch.atan2(torch.sin(self.cap_cmd - psi), torch.cos(self.cap_cmd - psi))
        if PAIE == "pente":                                    # R-150 N0b (E67) : la vitesse payée en pente, 0 à l'arrêt, 1 à la vitesse commandée
            r_v = torch.clamp(v_dir / self.v_cmd, -1.0, 1.0)
        elif PAIE == "triangle":                               # R-150 N0d : la pente des deux côtés (0 à l'arrêt, 1 à la commande, 0 au double)
            r_v = torch.clamp(1.0 - torch.abs(v_dir - self.v_cmd) / self.v_cmd, -1.0, 1.0)
        else:
            r_v = torch.exp(-((v_dir - self.v_cmd) / 0.03) ** 2)
        r = 1.0 + debout * (VITESSE_POIDS * r_v + 0.5 * torch.exp(-(dpsi / 0.5) ** 2))
        if CAP == "cos":
            r = r + debout * 0.5 * torch.cos(dpsi)
        r = r - 0.1 * ((a - self.a_prev) ** 2).mean(1)
        if FLOW:                                                # R-170 : les à-coups de la commande coûtent
            r = r - FLOW * ((a - 2 * self.a_prev + self.a_prev2) ** 2).mean(1)
        p_meca, p_joule = self.puissance()
        if ENERGIE:                                             # R-161 : payer l'économie (les watts estimés des 13 servos)
            r = r - ENERGIE * debout * (p_meca + p_joule)
        if OPPOSITION:                                          # R-175 : +1 en opposition, -1 ensemble, presque 0 sous 0,5 rad/s (pas de prime au tremblement)
            w_ = self.qvel[:, self.dof_opp]                       # (le sens : un angle positif ramène le bras et la jambe vers l'arrière, des deux côtés)
            op = lambda a_, b_: -2.0 * a_ * b_ / (a_ * a_ + b_ * b_ + 0.25)
            if OPPOSITION_SOL:                                  # essai 2 : les cuisses dans le monde (vers l'avant +), les bras opposés entre eux et chacun
                vcu = self.xpos[:, self.corps_genou] - self.xpos[:, self.corps_hanche]   # avec la cuisse opposée (un bras vers l'avant = vitesse négative)
                avant = vcu[:, :, 0] * torch.cos(psi)[:, None] + vcu[:, :, 1] * torch.sin(psi)[:, None]
                acu = torch.atan2(avant, -vcu[:, :, 2])
                wc = (acu - self.acu_prec) / DT_C
                self.acu_prec = acu.clone()
                terme = (op(wc[:, 0], wc[:, 1]) + op(w_[:, 2], w_[:, 3]) + op(w_[:, 2], wc[:, 1]) + op(w_[:, 3], wc[:, 0])) / 4.0
                r = r - debout * 0.1 * OPPOSITION * self.qvel[:, 4].abs()   # le bassin qui bascule d'avant en arrière coûte un peu
            else:
                terme = (op(w_[:, 0], w_[:, 1]) + op(w_[:, 2], w_[:, 3]) - op(w_[:, 2], w_[:, 1]) - op(w_[:, 3], w_[:, 0])) / 4.0
            r = r + debout * OPPOSITION * terme
            self.op_s += (terme * debout).sum()
            self.op_k += 1
        if CONTRAINTES:                                         # R-180 : les contraintes à prix duaux
            fb_ = self.attitude()
            angles_ = {"tangage": fb_[0], "roulis": fb_[1], "verre": self.verre_th}   # R-184 : « verre:<deg> »
            pen_ = torch.zeros_like(r)
            for k_, (nom_, lim_) in enumerate(CONTRAINTES):
                ang_ = angles_[nom_]
                if CONTRAINTES_OSC:                             # R-180 essai 2 : l'écart à la moyenne d'une seconde
                    self.c_ema[:, k_] += DT_C * (ang_ - self.c_ema[:, k_])
                    ang_ = ang_ - self.c_ema[:, k_]
                pen_ = pen_ + self.lam[k_] * (ang_ / lim_) ** 2
                self.c_s[k_] += (debout * ang_ ** 2).sum()
            r = r - debout * 0.8 * torch.tanh(pen_ / 0.8)           # bornée en douceur sous la paie de vivre (1) : tomber ne doit jamais
            self.c_n += debout.sum()                                # devenir le moyen d'arrêter la pénalité (l'essai à 0,08 M : le retour à -182)
        if APPUI:                                               # R-178 : le pied sous la projection du centre de gravité, quand le corps passe dessus
            pdp = self.geom_xpos[:, self.pieds, :2] - self.subtree_com[:, 1, None, :2]
            dc, sc_ = torch.cos(self.cap_cmd)[:, None], torch.sin(self.cap_cmd)[:, None]
            long_ = pdp[:, :, 0] * dc + pdp[:, :, 1] * sc_
            cote_ = -pdp[:, :, 0] * sc_ + pdp[:, :, 1] * dc
            hp = self.geom_xpos[:, self.pieds, 2] - (self.geom_xmat[:, self.pieds, 2, :].abs() * self.demi_pied[None]).sum(2) - self.terrain(self.geom_xpos[:, self.pieds, 0], self.geom_xpos[:, self.pieds, 1], pied=True)
            au_sol = (hp < 0.0015).float()
            r = r + debout * APPUI * (au_sol * torch.exp(-(long_ / 0.01) ** 2) * torch.exp(-(cote_ / 0.01) ** 2)).sum(1)
        if PIVOT or RIGIDE:                                     # R-197 : la bascule sur le pied d'appui, transformée en propulsion
            fx_, fy_ = torch.cos(psi)[:, None], torch.sin(psi)[:, None]
            h_ = self.xpos[:, self.corps_hanche]
            p_ = self.geom_xpos[:, self.pieds]
            th_ = torch.atan2((h_[..., 0] - p_[..., 0]) * fx_ + (h_[..., 1] - p_[..., 1]) * fy_, h_[..., 2] - p_[..., 2])
            om_ = (th_ - self.piv_th) / DT_C
            hp_ = p_[..., 2] - (self.geom_xmat[:, self.pieds, 2, :].abs() * self.demi_pied[None]).sum(2) - self.terrain(p_[..., 0], p_[..., 1], pied=True)
            sol_ = hp_ < 0.0015
            if PIVOT:                                           # en appui simple seulement : la somme des deux pieds payait le piétinement (le cas
                om_ref_ = torch.clamp(self.v_cmd, min=0.01)[:, None] / 0.20   # connu, pivot_n01.py : tendue-zero, sur deux pieds 92 % du temps,
                un_ = (sol_.sum(1) == 1)[:, None]                              # payé 1,03 contre 1,26 à la référence ; en appui simple : 0,06 contre 0,72)
                bascule_ = ((self.piv_ok[:, None] & sol_ & un_).float() * torch.clamp(om_ / om_ref_, 0.0, 1.5)).sum(1)
                r = r + debout * PIVOT * bascule_ * torch.clamp(self.v_lisse / torch.clamp(self.v_cmd, min=0.01), 0.0, 1.0)
            if RIGIDE:
                r = r - debout * RIGIDE * (sol_.all(1) & (self.v_lisse < 0.3 * self.v_cmd)).float()
            self.piv_th = th_
            self.piv_ok = torch.ones_like(self.piv_ok)
        if TRONC_CIBLE_POIDS:                                   # R-190 : le tronc penché vers l'avant comme la photo
            r = r + debout * TRONC_CIBLE_POIDS * torch.clamp(1.0 - (self.attitude()[0] - TRONC_CIBLE).abs() / 30.0, min=0.0)
        if TRONC:                                               # R-177 : le tronc ferme
            r = r - debout * TRONC * (self.qvel[:, 3].abs() + self.qvel[:, 4].abs() + (tilt / 20.0) ** 2)
        if MANNEQUIN:                                           # R-169 : le tronc ne tourne pas à chaque pas (la vitesse de lacet coûte)
            r = r - debout * MANNEQUIN * self.qvel[:, 5].abs()
        pied = self.geom_xpos[:, self.pieds]
        Rp = self.geom_xmat[:, self.pieds]
        haut = pied[:, :, 2] - (Rp[:, :, 2, :].abs() * self.demi_pied[None]).sum(2) - self.terrain(pied[:, :, 0], pied[:, :, 1], pied=True)
        touche = haut < 0.0015
        if POINTE and self.talons[0] >= 0:                      # R-171 : le talon du pied qui porte, levé (le rouleau du talon, son point le plus bas)
            ct = self.geom_xpos[:, self.talons]
            az = self.geom_xmat[:, self.talons][:, :, 2, 2]
            h_talon = ct[:, :, 2] - az.abs() * self.hl_talon - self.r_talon * torch.sqrt(torch.clamp(1 - az ** 2, min=0.0)) - self.terrain(ct[:, :, 0], ct[:, :, 1], pied=True)
            r = r + debout * POINTE * (touche.float() * (torch.clamp(h_talon / 0.01, 0.0, 1.0) - 0.5)).sum(1)
        if (TALON_POINTE or GENOU_TENDU or POSE_PHOTO) and self.talons[0] >= 0 and self.bouts[0] >= 0:   # R-172 : le talon d'abord, la pointe en dernier
            def bas_r(ids):
                c_ = self.geom_xpos[:, ids]
                az_ = self.geom_xmat[:, ids][:, :, 2, 2]
                return c_[:, :, 2] - az_.abs() * self.hl_talon - self.r_talon * torch.sqrt(torch.clamp(1 - az_ ** 2, min=0.0)) - self.terrain(c_[:, :, 0], c_[:, :, 1], pied=True)
            ht, hb = bas_r(self.talons), bas_r(self.bouts)
            hmin = torch.minimum(ht, hb)
            sol = hmin < 0.0015
            decol = self.tp_sol & ~sol
            self.tp_decol = torch.where(decol, torch.clamp((ht - hb) / 0.012, -1.0, 1.0), self.tp_decol)
            self.tp_vol = torch.where(sol, self.tp_vol, torch.maximum(self.tp_vol, hmin))
            pose_tp = ~self.tp_sol & sol & (self.tp_vol >= 0.005)         # un vrai pas, comme les grands pas (5 mm de vol)
            if TP_MARCHE:
                pose_tp = pose_tp & sol.flip(1)
            paie = torch.clamp((hb - ht) / 0.012, -1.0, 1.0) + self.tp_decol
            r = r + debout * frein * TALON_POINTE * (pose_tp.float() * paie).sum(1)
            if GENOU_TENDU:                                     # R-190 : la jambe qui se pose, tendue
                kg_ = torch.rad2deg(self.qpos[:, self.genou_q])
                r = r + debout * frein * GENOU_TENDU * (pose_tp.float() * torch.exp(-(kg_ / 6.0) ** 2)).sum(1)
            if POSE_PHOTO:                                      # R-198 : la pose de la photo, les deux ensemble
                kp_ = torch.rad2deg(self.qpos[:, self.genou_q]).abs()
                fx_, fy_ = torch.cos(psi)[:, None], torch.sin(psi)[:, None]
                hz_, ch_ = self.xpos[:, self.corps_hanche], self.xpos[:, self.corps_cheville]
                th_ = torch.atan2((ch_[..., 0] - hz_[..., 0]) * fx_ + (ch_[..., 1] - hz_[..., 1]) * fy_, hz_[..., 2] - ch_[..., 2])
                ecart_ = torch.rad2deg((th_[:, 0] - th_[:, 1]).abs())[:, None]
                r = r + debout * frein * POSE_PHOTO * (pose_tp.float() * torch.exp(-(kp_ / 8.0) ** 2)
                                                        * torch.exp(-(torch.clamp(POSE_ECART - ecart_, min=0.0) / 6.0) ** 2)).sum(1)
            pd = pose_tp & debout[:, None].bool()
            self.tp_n += pd.sum()
            self.tp_t += (pd & (hb - ht >= 0.008)).sum()
            self.tp_k += 1
            self.tp_vol = torch.where(sol, torch.zeros_like(self.tp_vol), self.tp_vol)
            self.tp_sol = sol
        if GRAND_PAS:                                           # R-167 : à chaque pied posé, la longueur qu'il a parcourue en l'air, le long du cap
            dirx = torch.stack([torch.cos(self.cap_cmd), torch.sin(self.cap_cmd)], 1)
            proj = (pied[:, :, :2] * dirx[:, None, :]).sum(2)
            self.x_decol = torch.where(self.touche_prev & ~touche, proj, self.x_decol)
            self.h_vol = torch.where(touche, self.h_vol, torch.maximum(self.h_vol, haut))
            pose = ~self.touche_prev & touche & (self.h_vol >= GP_HAUT)
            L = (proj - self.x_decol) / GP_LONG
            Lp = torch.clamp(L, max=1.5)
            if PAS_CMD:                                         # R-169 : la cloche autour de la grandeur demandée (un pas en arrière ne paie pas)
                gain = torch.where(L > 0, torch.exp(-((L * GP_LONG - self.l_cmd[:, None]) / PAS_SIGMA) ** 2), torch.zeros_like(L))
            elif GP_FORME == "carre":
                gain = torch.where(L > 0, Lp ** 2, torch.clamp(L, min=-0.5))
            elif GP_FORME == "mixte":                          # R-167 : linéaire près de zéro (un signal dès les petits pas), puis de plus en plus
                gain = torch.where(L > 0, Lp * (1 + Lp) / 2, torch.clamp(L, min=-0.5))   # par cm : 10 cm = 1, 2 cm = 0,12, 15 cm = 1,875
            else:
                gain = torch.clamp(L, -0.5, 1.5)
            r = r + debout * frein * GRAND_PAS * (pose.float() * gain).sum(1)
            if LIGNE:                                           # R-176 : l'écart du pied posé à la ligne
                chg = self.cap_cmd != self.ligne_cap                # le cap a changé : une nouvelle ligne, depuis ici
                self.ligne_o = torch.where(chg[:, None], cm, self.ligne_o)
                self.ligne_cap = torch.where(chg, self.cap_cmd, self.ligne_cap)
                sc, cc_ = torch.sin(self.ligne_cap)[:, None], torch.cos(self.ligne_cap)[:, None]
                ecart = (-(pied[:, :, 0] - self.ligne_o[:, 0:1]) * sc + (pied[:, :, 1] - self.ligne_o[:, 1:2]) * cc_).abs()
                r = r + debout * LIGNE * (pose.float() * torch.clamp((2 * LIGNE_DEMI - ecart) / LIGNE_DEMI, -1.0, 1.0)).sum(1)
                pd_ = pose & debout[:, None].bool()
                self.li_s += (pd_.float() * ecart).sum()
                self.li_n += pd_.sum()
            self.gp_n += (pose & debout[:, None].bool()).sum()
            self.gp_l += ((pose & debout[:, None].bool()).float() * L).sum()
            self.gp_k += 1
            self.h_vol = torch.where(touche, torch.zeros_like(self.h_vol), self.h_vol)
        if IMITE:                                               # R-181 : ressembler à la marche de référence (interpolée en longueur et en phase)
            q_ref, i0_ = self.q_reference(self.im_hc if self.im_esc else self.v_cmd, self.phi)   # R-186 : la hauteur du cycle
            ea_ = (self.qpos[:, self.jq] - q_ref)[:, self.im_suiv] ** 2
            e2_ = ea_.mean(1)
            self.im_ea_w += debout[:, None] * ea_
            r_im = torch.exp(-e2_ / IMITE_SIGMA ** 2)
            if self.im_esc:                                     # R-186 : les appuis de la hauteur la plus proche (un tableau par hauteur)
                kh_ = torch.clamp(torch.round(self.im_hc / float(self.im_S[1] - self.im_S[0])).long(), 0, self.im_S.shape[0] - 1)
                ap_ = self.im_appuis[kh_, i0_]
            else:
                ap_ = self.im_appuis[i0_]
            accord = (touche == ap_).float().mean(1)
            if self.im_esc and IMITE_PROGRES:                   # R-186 : immobile, la ressemblance ne paie plus
                r_im = r_im * torch.clamp(self.im_pv / torch.clamp(self.v_cmd, min=1e-3), 0.0, 1.0)
                accord = accord * torch.clamp(self.im_pv / torch.clamp(self.v_cmd, min=1e-3), 0.0, 1.0)
            r = r + debout * IMITE * (r_im + IMITE_APPUI * accord)
            self.im_s += (debout * r_im).sum()
            self.im_e += (debout * e2_).sum()
            self.im_c += (debout * accord).sum()
            self.im_k += debout.sum()
            self.im_e_w += debout * e2_
            self.im_c_w += debout * accord
            self.im_n_w += debout
        if HORLOGE:                                             # R-167 : l'oscillateur relié aux pieds (une marche qui alterne les appuis)
            fen = torch.stack([torch.sin(self.th) > 0.3, torch.sin(self.th) < -0.3], 1)
            en_vol = haut > 0.005
            r = r + debout * HORLOGE * (fen.float() * (en_vol.float() - 0.5)).sum(1)
            fd = fen & debout[:, None].bool()
            self.hl_ok += (fd & en_vol).sum()
            self.hl_n += fd.sum()
        if SYM_PAS:                                             # R-185 suite : chaque pas l'égal du précédent de l'autre pied
            self.sp_hv = torch.where(touche, self.sp_hv, torch.maximum(self.sp_hv, haut))   # le plus haut de ce vol
            pose_ = ~self.touche_prev & touche & (self.sp_hv >= 0.003)                    # un vrai pas posé (3 mm de vol au moins)
            dc_ = self.t[:, None] - self.sp_tp.flip(1)                                    # ce demi-cycle : depuis la pose de l'autre pied
            ok_ = pose_ & self.sp_ok & self.sp_ok.flip(1)
            ah_ = self.sp_dh.flip(1)
            eh_ = (self.sp_hv - ah_).abs() / torch.clamp(0.5 * (self.sp_hv + ah_), min=1e-3)
            pc_ = self.sp_dc.flip(1)                                                       # le demi-cycle d'avant, fini par l'autre pied
            ec_ = (dc_ - pc_).abs() / torch.clamp(0.5 * (dc_ + pc_), min=1e-3)
            paie_ = torch.exp(-(eh_ / 0.2) ** 2) + torch.exp(-(ec_ / 0.1) ** 2) - 1.0
            r = r + debout * SYM_PAS * (ok_.float() * paie_).sum(1)
            okd_ = ok_ & debout[:, None].bool()
            self.sp_eh += (okd_.float() * eh_).sum()
            self.sp_ec += (okd_.float() * ec_).sum()
            self.sp_n += okd_.sum()
            self.sp_dh = torch.where(pose_, self.sp_hv, self.sp_dh)
            self.sp_dc = torch.where(pose_, dc_, self.sp_dc)
            self.sp_tp = torch.where(pose_, self.t[:, None].expand_as(self.sp_tp), self.sp_tp)
            self.sp_ok = self.sp_ok | pose_
            self.sp_hv = torch.where(touche, torch.zeros_like(self.sp_hv), self.sp_hv)
        self.touche_prev = touche.clone()
        haut = torch.clamp(haut, min=0.0)
        vpied = torch.linalg.norm(pied[:, :, :2] - self.pied_prec, dim=2) / DT_C
        self.pied_prec = pied[:, :, :2].clone()
        autre = touche.flip(1)
        lever = ((~touche) & autre).float() * torch.clamp(haut / LEVER_MAX, 0, 1)
        if GENOU:                                               # R-168 : le genou haut (la jambe en l'air, l'autre pied qui porte)
            gz = self.xpos[:, self.genoux, 2] - self.terrain(self.xpos[:, self.genoux, 0], self.xpos[:, self.genoux, 1]) - self.hk0[None]
            pg = debout * GENOU * (((~touche) & autre).float() * torch.clamp(gz / GENOU_MAX, 0, 1)).sum(1)
            r = r + pg
            self.gn_s += pg.sum()
            self.gn_k += 1
        air = (~touche).all(1)
        self.t_air = (self.t_air + DT_C) * air.float()
        self.ema = 0.98 * self.ema + 0.02 * touche.float()
        r = r + debout * (0.3 * lever.sum(1) - 2.5 * (touche.float() * vpied).sum(1) - 0.5 * (self.t_air > VOL_MAX).float()
                          - 1.0 * (self.ema[:, 0] - self.ema[:, 1]).abs())
        if ESCALIER and not PENTES:                             # R-159 : une paie pour chaque nouvelle marche montée (le bassin au-dessus)
            marche = torch.clamp(torch.floor((self.subtree_com[:, 1, 2] - self.h0 + 0.5 * self.esc_h) / self.esc_h), 0, ESC_NB)
            r = r + debout * ESC_BONUS * torch.clamp(marche - self.marche_max, min=0.0)
            self.marche_max = torch.maximum(self.marche_max, marche)
        self.a_prev2 = self.a_prev
        self.a_prev = a
        r = torch.nan_to_num(r, nan=0.0, posinf=0.0, neginf=0.0)  # R-166 (15.11) : un monde qui explose (un contact de l'escalier) ne doit
        self.ret += r                                             # pas empoisonner les autres : N0.1-esc-a et -b sont morts de NaN
        self.long += 1
        tronque = (self.t >= DUREE - 1e-6) & ~tombe
        fini = tombe | tronque
        o_fin = torch.nan_to_num(self.obs(), nan=0.0, posinf=0.0, neginf=0.0)
        info = {"p_meca": p_meca, "p_joule": p_joule, "ret": self.ret[fini].clone(), "long": self.long[fini].clone(), "tombe": tombe[fini].clone(), "vx": vx,
                "lever": (~touche).float().mean(), "glisse": (touche.float() * vpied).sum(1).mean(), "touche": touche, "vpied": vpied}
        if self.sans_reinit:
            return o_fin, r, tombe, tronque, o_fin, info
        if bool(fini.any()):
            self.reinit(fini)
        o = torch.nan_to_num(self.obs(), nan=0.0, posinf=0.0, neginf=0.0) if bool(fini.any()) else o_fin
        return o, r, tombe, tronque, o_fin, info


def apprendre(nom, millions, nworld=4096, T=24, graine=150000):
    dossier = os.path.join(ICI, "runs", nom)
    os.makedirs(dossier, exist_ok=True)
    torch.manual_seed(graine)
    W = MondeN0(nworld, graine=graine)
    o = W.obs()
    no, na = o.shape[1], W.na
    norm = Normaliseur(no)
    ag = Agent(no, na).to(DEV)
    with torch.no_grad():                                       # E75 : un petit bruit de départ (des SG90 fragiles)
        ag.log_std.fill_(-1.6)
    if INIT:                                                    # R-169 : le réseau d'action et la normalisation d'une politique apprise
        s0 = torch.load(os.path.join(ICI, INIT), map_location=DEV)
        assert s0["na"] == na and s0["no"] <= no, (s0["no"], no, s0["na"], na)
        pi0 = s0["pi"]
        if s0["no"] < no:                                       # R-170 (15.11 16:30, N0.1-flow-b mort au départ : 71 mesures contre 88) : les mesures
            ext = no - s0["no"]                                  # en plus sont ajoutées en fin (le muscle, la grandeur de pas) :
            if ESCALIER and ext == len(ESC_SCAN):                # leurs poids d'entrée à zéro, la politique part exactement comme elle était ;
                i_ = 19 + 2 * W.nu + W.na                        # R-186 : le regard sur l'escalier (5 mesures) s'insère après le cap (71e), pas à la fin
            else:
                assert not ESCALIER, "les mesures de l'escalier sont au milieu"
                i_ = s0["no"]
            pi0 = dict(pi0)
            w = pi0["0.weight"]
            z_ = lambda *s: torch.zeros(*s, device=w.device, dtype=w.dtype)
            pi0["0.weight"] = torch.cat([w[:, :i_], z_(w.shape[0], ext), w[:, i_:]], 1)
            s0 = dict(s0)
            m_, v_ = s0["norm_m"].to(DEV), s0["norm_v"].to(DEV)
            s0["norm_m"] = torch.cat([m_[:i_], torch.zeros(ext, device=DEV), m_[i_:]])
            s0["norm_v"] = torch.cat([v_[:i_], torch.ones(ext, device=DEV), v_[i_:]])
            print("départ élargi : %d mesures en plus (à partir de la %de), leurs poids d'entrée à zéro" % (ext, i_ + 1), flush=True)
        ag.pi.load_state_dict(pi0)
        with torch.no_grad():
            ag.log_std.copy_(torch.clamp(s0["log_std"].to(DEV), max=-1.6))
        norm.m, norm.v, norm.c = s0["norm_m"].to(DEV), s0["norm_v"].to(DEV), 1e6
        print("départ depuis", INIT, flush=True)
    if BOSSES and BOSSES_DEBUT != BOSSES:                       # R-182 : les bosses partent petites
        W.bosses(BOSSES_DEBUT)
    opt = torch.optim.Adam(ag.parameters(), lr=3e-4)
    lr, gamma, lam, clip = 3e-4, 0.99, 0.95, 0.2
    if SYMETRIE:                                                # R-185 : les cartes miroir
        mP, mS, aP, aS = W.miroirs(no)
    ls_sym = 0.0
    total = int(millions * 1e6)
    fait, it, t0 = 0, 0, time.time()
    prog = open(os.path.join(dossier, "progression.jsonl"), "a", encoding="utf-8")
    fr, fl, ft = [], [], []
    prochain = 10_000_000
    while fait < total:
        O, A, LP, V, R, D, TR, VF, MU = [], [], [], [], [], [], [], [], []
        sig_old = torch.exp(ag.log_std.detach()).clone()
        with torch.no_grad():
            for _ in range(T):
                norm.maj(o)
                on = norm(o)
                loi = ag.loi(on)
                a = loi.sample()
                o2, r, tombe, tronque, o_fin, info = W.pas(a)
                O.append(on); A.append(a); LP.append(loi.log_prob(a).sum(1)); V.append(ag.v(on).squeeze(1)); MU.append(loi.mean)
                R.append(r); D.append(tombe.float()); TR.append(tronque.float()); VF.append(ag.v(norm(o_fin)).squeeze(1))
                fr += info["ret"].tolist(); fl += info["long"].tolist(); ft += info["tombe"].float().tolist()
                o = o2
            v_der = ag.v(norm(o)).squeeze(1)
            adv = torch.zeros(T, nworld, device=DEV)
            g = torch.zeros(nworld, device=DEV)
            for k in reversed(range(T)):
                fin = torch.clamp(D[k] + TR[k], max=1.0)
                v_suiv = v_der if k == T - 1 else V[k + 1]
                v_suiv = torch.where(fin > 0, VF[k] * (1 - D[k]), v_suiv)
                delta = R[k] + gamma * v_suiv - V[k]
                g = delta + gamma * lam * (1 - fin) * g
                adv[k] = g
            ret = adv + torch.stack(V)
        O_, A_, LP_, ADV_, RET_, MU_ = torch.cat(O), torch.cat(A), torch.cat(LP), adv.reshape(-1), ret.reshape(-1), torch.cat(MU)
        ADV_ = (ADV_ - ADV_.mean()) / (ADV_.std() + 1e-8)
        n = O_.shape[0]
        kl = 0.0
        if INIT and it == INIT_GEL:                              # E90 : au dégel, un petit pas
            lr = INIT_LR
            for pgp in opt.param_groups:
                pgp["lr"] = lr
        for ep in range(5):
            for mb in torch.randperm(n, device=DEV).chunk(4):
                loi = ag.loi(O_[mb])
                ratio = torch.exp(loi.log_prob(A_[mb]).sum(1) - LP_[mb])
                pg = -torch.min(ratio * ADV_[mb], torch.clamp(ratio, 1 - clip, 1 + clip) * ADV_[mb]).mean()
                vl = ((ag.v(O_[mb]).squeeze(1) - RET_[mb]) ** 2).mean()
                opt.zero_grad()
                perte = (0.5 * vl) if (INIT and it < INIT_GEL) else (pg + 0.5 * vl)
                if SYMETRIE and not (INIT and it < INIT_GEL):       # R-185 : la perte miroir (les mesures dénormalisées, reflétées, renormalisées)
                    brut_ = O_[mb] * torch.sqrt(norm.v + 1e-8) + norm.m
                    om_ = norm(mS * brut_[:, mP])
                    mu_m = ag.pi(om_)
                    l_sym = ((loi.mean - aS * mu_m[:, aP]) ** 2).mean()
                    perte = perte + SYMETRIE * l_sym
                    ls_sym = float(l_sym)
                perte.backward()                                    # R-169 : le critique d'abord ; E90 : le réseau d'action
                                                                                           # sans gradient du tout (Adam ne le touche pas)
                nn.utils.clip_grad_norm_(ag.parameters(), 1.0)
                opt.step()
                with torch.no_grad():
                    sn = torch.exp(ag.log_std)
                    kl = (torch.log(sn / sig_old) + (sig_old ** 2 + (MU_[mb] - loi.mean) ** 2) / (2 * sn ** 2) - 0.5).sum(1).mean().item()
                if not (INIT and it < INIT_GEL):                 # E90 : pendant le gel, le pas ne s'adapte pas (l'écart y est nul)
                    lr = max(1e-5, lr / 1.5) if kl > 0.02 else (min(1e-3, lr * 1.5) if kl < 0.005 else lr)
                for pgp in opt.param_groups:
                    pgp["lr"] = lr
        fait += n
        it += 1
        if BOSSES and BOSSES_DEBUT != BOSSES:                   # R-182 : elles grandissent jusqu'à 70 % des pas
            W.bosses(BOSSES_DEBUT + (BOSSES - BOSSES_DEBUT) * min(1.0, fait / (0.7 * total)))
        if CONTRAINTES and float(W.c_n) > 0:                    # R-180 : la montée du dual, une fois par itération
            for k_, (nom_, lim_) in enumerate(CONTRAINTES):
                Ck = float(W.c_s[k_]) / float(W.c_n)
                W.c_moy[k_] = Ck
                W.lam[k_] = min(LAM_MAX, max(0.0, float(W.lam[k_]) + LAM_PAS * (Ck / lim_ ** 2 - 1.0)))
            W.c_s.zero_()
            W.c_n.zero_()
        if it % 5 == 0:
            ligne = {"pas": fait, "minutes": round((time.time() - t0) / 60, 2), "decisions_par_s": round(fait / (time.time() - t0)),
                     "retour_moy": round(float(np.mean(fr)), 1) if fr else None, "duree_moy_s": round(float(np.mean(fl)) * DT_C, 2) if fl else None,
                     "chutes": round(float(np.mean(ft)), 3) if ft else None, "kl": round(kl, 4), "lr": lr, "std": round(float(torch.exp(ag.log_std).mean()), 3),
                     "en_l_air": round(float(info["lever"]), 3), "glisse_m_s": round(float(info["glisse"]), 4)}
            if SYMETRIE:
                ligne["perte_miroir"] = round(ls_sym, 5)
            if SYM_PAS and float(W.sp_n):                              # R-185 suite : l'écart des pas (hauteur, demi-cycle), en part
                ligne["pas_ecart_h"] = round(float(W.sp_eh / W.sp_n), 3)
                ligne["pas_ecart_cycle"] = round(float(W.sp_ec / W.sp_n), 3)
                W.sp_eh.zero_(), W.sp_ec.zero_(), W.sp_n.zero_()
            if HORLOGE and float(W.hl_n) > 0:                        # R-167 : la part des fenêtres de vol où le pied est vraiment en l'air
                ligne["vol_a_l_heure"] = round(float(W.hl_ok) / float(W.hl_n), 3)
                W.hl_ok.zero_(), W.hl_n.zero_()
            if GENOU and W.gn_k:                                    # R-168 : la paie du genou haut, par monde et par pas de 20 ms
                ligne["genou_paie"] = round(float(W.gn_s) / (W.qpos.shape[0] * W.gn_k), 4)
                W.gn_s.zero_()
                W.gn_k = 0
            for k_, (nom_, lim_) in enumerate(CONTRAINTES):         # R-180 : les prix duaux et la moyenne quadratique des angles (degrés)
                ligne["lambda_" + nom_] = round(float(W.lam[k_]), 3)
                ligne["rms_" + nom_] = round(W.c_moy[k_] ** 0.5, 2)
            nvr_ = float(W.vr_n_w.sum())                           # R-184 : l'eau qui déborde (la part des pas debout) et l'angle moyen du verre
            if nvr_ > 0:
                ligne["verre_deborde"] = round(float(W.vr_d_w.sum()) / nvr_, 3)
                ligne["verre_angle"] = round(float(W.vr_s_w.sum()) / nvr_, 2)
                for t_ in (W.vr_n_w, W.vr_d_w, W.vr_s_w):
                    t_.zero_()
            if BOSSES:                                             # R-182 : la hauteur des bosses du moment (mm)
                ligne["bosses_mm"] = round(1000 * float(W.hf_size[0, 2]), 2)
            if IMITE and float(W.im_k):                            # R-181 : la ressemblance (0 à 1), l'écart quadratique moyen (degrés), l'accord des appuis
                ligne["imite"] = round(float(W.im_s) / float(W.im_k), 3)
                ligne["imite_ecart_deg"] = round(math.degrees((float(W.im_e) / float(W.im_k)) ** 0.5), 2)
                ligne["imite_appuis"] = round(float(W.im_c) / float(W.im_k), 3)
                for t_ in (W.im_s, W.im_e, W.im_c, W.im_k):
                    t_.zero_()
            if LIGNE and float(W.li_n):                            # R-176 : l'écart moyen des pieds posés à la ligne (mm)
                ligne["ligne_mm"] = round(1000 * float(W.li_s) / float(W.li_n), 1)
                W.li_s.zero_(), W.li_n.zero_()
            if OPPOSITION and W.op_k:                              # R-175 : l'opposition moyenne, de -1 (tout ensemble) à +1 (tout opposé)
                ligne["opposition"] = round(float(W.op_s) / (W.qpos.shape[0] * W.op_k), 3)
                W.op_s.zero_()
                W.op_k = 0
            if TALON_POINTE and W.tp_k:                            # R-172 : la part des vrais pas posés le talon d'abord (le bout 8 mm plus haut)
                ligne["talon_dabord"] = round(float(W.tp_t) / float(W.tp_n), 3) if float(W.tp_n) else None
                ligne["pas_tp_s"] = round(float(W.tp_n) / (W.qpos.shape[0] * W.tp_k * DT_C), 3)
                W.tp_n.zero_(), W.tp_t.zero_()
                W.tp_k = 0
            if GRAND_PAS and W.gp_k:                               # R-167 : les grands pas pendant l'apprentissage (pas posés par monde et par
                n_, l_ = float(W.gp_n), float(W.gp_l)               # seconde, leur longueur moyenne le long du cap)
                ligne["pas_payes_s"] = round(n_ / (W.qpos.shape[0] * W.gp_k * DT_C), 3)
                ligne["long_pas_cm"] = round(100 * GP_LONG * l_ / n_, 2) if n_ else None
                W.gp_n.zero_(), W.gp_l.zero_()
                W.gp_k = 0
            prog.write(json.dumps(ligne) + "\n")
            prog.flush()
            print(ligne, flush=True)
            fr, fl, ft = [], [], []
        if fait >= prochain or fait >= total:
            tag = "%dM" % (fait // 1_000_000) if fait < total else "final"
            torch.save({"pi": ag.pi.state_dict(), "log_std": ag.log_std.detach().cpu(), "norm_m": norm.m.cpu(), "norm_v": norm.v.cpu(),
                        "no": no, "na": na, "robot": "N0", "pas": fait, "ech": W.ech.cpu().tolist()}, os.path.join(dossier, "politique-%s.pt" % tag))
            prochain += 10_000_000
    print("=> FIN apprentissage", nom, fait, "pas en %.1f min" % ((time.time() - t0) / 60), flush=True)


def banc(f, sortie, n_graines=30, retard=0):
    """30 départs perturbés (±1°) par vitesse commandée (2, 5 et 10 cm/s), tout droit, 10 s : debout, distance, vrai pied levé,
    glissement ; les qpos de chaque essai (pour les films du portable)."""
    s = torch.load(f, map_location=DEV)
    vitesses = [0.02, 0.05, 0.10]
    N = len(vitesses) * n_graines
    W = MondeN0(N, graine=150900)
    W.sans_reinit = True
    pert = np.stack([np.random.default_rng(137900 + i % n_graines).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    W.cap_cmd[:] = 0.0
    W.v_cmd[:] = torch.tensor([vitesses[i // n_graines] for i in range(N)], device=DEV)
    W.t_cmd[:] = 99.0
    pi = mlp(s["no"], s["na"]).to(DEV)
    pi.load_state_dict(s["pi"])
    nm, nv = s["norm_m"].to(DEV), s["norm_v"].to(DEV)
    o = W.obs()
    x0 = W.subtree_com[:, 1, 0].clone()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    t_chute = torch.full((N,), -1.0, device=DEV)
    lev, gl, npas = torch.zeros(N, device=DEV), torch.zeros(N, device=DEV), 0
    e_meca, e_joule = torch.zeros(N, device=DEV), torch.zeros(N, device=DEV)   # R-161 : l'énergie, en joules, tant qu'il est debout
    QP = []
    file_a = [torch.zeros(N, W.na, device=DEV) for _ in range(retard)]     # R-150 : la latence (Wi-Fi), en pas de 20 ms
    with torch.no_grad():
        for k in range(int(DUREE / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            file_a.append(a)
            a = file_a.pop(0)
            o, r, tombe, tronq, _, info = W.pas(a)
            QP.append(W.qpos.clone().cpu().numpy())
            t_chute = torch.where(vivant & tombe, W.t, t_chute)
            vivant = vivant & ~tombe
            gl += (info["touche"].float() * info["vpied"]).sum(1) * DT_C * vivant.float()
            e_meca += info["p_meca"] * DT_C * vivant.float()
            e_joule += info["p_joule"] * DT_C * vivant.float()
    x1 = W.subtree_com[:, 1, 0]
    out = {"politique": f, "bilan": {}, "essais": []}
    for j, v in enumerate(vitesses):
        sl = slice(j * n_graines, (j + 1) * n_graines)
        dist = (x1[sl] - x0[sl]).cpu().numpy()
        deb = (t_chute[sl] < 0).cpu().numpy()
        b = {"debout_10s": int(deb.sum()), "distance_med_cm": round(100 * float(np.median(dist[deb])), 1) if deb.any() else None,
             "vitesse_med_cm_s": round(10 * float(np.median(dist[deb])), 2) if deb.any() else None,
             "glissement_pieds_cm": round(100 * float(np.median(gl[sl].cpu().numpy()[deb])), 1) if deb.any() else None}
        if deb.any():                                            # R-161 : les watts et le coût du transport (énergie / (m g d))
            em, ej = e_meca[sl].cpu().numpy()[deb], e_joule[sl].cpu().numpy()[deb]
            b["watts_meca"], b["watts_joule"] = round(float(np.median(em)) / DUREE, 3), round(float(np.median(ej)) / DUREE, 3)
            d_ok = np.maximum(dist[deb], 1e-3)
            b["cout_transport"] = round(float(np.median((em + ej) / (W.masse * 9.81 * d_ok))), 1)
            Q = np.stack(QP)[:, sl][:, deb]                       # les bras : l'amplitude et le sens par rapport aux jambes
            ja = {n: int(W.mjm.jnt_qposadr[mujoco.mj_name2id(W.mjm, mujoco.mjtObj.mjOBJ_JOINT, n)]) for n in
                  ("bras-gauche-epaule", "bras-droit-epaule", "jambe-gauche-hanche", "jambe-droite-hanche")}
            eg, ed = Q[:, :, ja["bras-gauche-epaule"]], Q[:, :, ja["bras-droit-epaule"]]
            hg, hd = Q[:, :, ja["jambe-gauche-hanche"]], Q[:, :, ja["jambe-droite-hanche"]]
            b["bras_amplitude_deg"] = round(float(np.degrees(np.median(eg.max(0) - eg.min(0)))), 1)
            c = lambda x, y: float(np.median([np.corrcoef(x[:, i], y[:, i])[0, 1] for i in range(x.shape[1]) if x[:, i].std() > 1e-4 and y[:, i].std() > 1e-4] or [0.0]))
            b["bras_avec_hanche_opposee"] = round(c(eg, hd), 2)     # +1 : le bras gauche suit la hanche droite (comme l'humain, au signe près)
            b["bras_avec_hanche_meme_cote"] = round(c(eg, hg), 2)
            cv = lambda x, y: c(np.diff(x, axis=0), np.diff(y, axis=0))   # R-175 : sur les vitesses (une dérive lente ne compte pas)
            b["hanches_entre_elles_v"] = round(cv(hg, hd), 2)      # -1 : les jambes alternent (l'humain) ; +1 : elles vont ensemble
            b["bras_entre_eux_v"] = round(cv(eg, ed), 2)           # -1 : les bras opposés
            b["bras_g_hanche_d_v"] = round(cv(eg, hd), 2)          # +1 : le bras gauche avec la jambe droite (l'humain)
            dk = mujoco.MjData(W.mjm)                              # R-175 essai 2 : la part du mouvement des cuisses (par rapport au sol) en opposition :
            Bh = [mujoco.mj_name2id(W.mjm, mujoco.mjtObj.mjOBJ_BODY, "jambe-%s-hanche" % c) for c in ("gauche", "droite")]   # var(g-d) / (var(g-d)
            Bk = [mujoco.mj_name2id(W.mjm, mujoco.mjtObj.mjOBJ_BODY, "jambe-%s-genou" % c) for c in ("gauche", "droite")]    # + var(g+d)) ; 1 opposé, 0 ensemble ;
            parts = []                                             # vérifiée sur la marche écrite de R-172 (0,52) ; les marches apprises : 0,11 à 0,38
            for w_i in range(Q.shape[1]):
                ang = np.zeros((Q.shape[0], 2))
                for t_i in range(Q.shape[0]):
                    dk.qpos[:] = Q[t_i, w_i]
                    mujoco.mj_kinematics(W.mjm, dk)
                    for s_i in range(2):
                        v_ = dk.xpos[Bk[s_i]] - dk.xpos[Bh[s_i]]
                        ang[t_i, s_i] = math.atan2(v_[0], -v_[2])
                ang = ang - ang.mean(0)
                vd, vs = np.var(ang[:, 0] - ang[:, 1]), np.var(ang[:, 0] + ang[:, 1])
                parts.append(vd / (vd + vs + 1e-12))
            b["cuisses_part_opposee"] = round(float(np.median(parts)), 2)
            qq = Q[:, :, 3:7]                                      # R-177 : le tronc (le corps racine) : l'écart type de son tangage et de son roulis, en degrés
            tang = np.degrees(np.arcsin(np.clip(2 * (qq[..., 0] * qq[..., 2] - qq[..., 3] * qq[..., 1]), -1, 1)))
            roul = np.degrees(np.arctan2(2 * (qq[..., 0] * qq[..., 1] + qq[..., 2] * qq[..., 3]), 1 - 2 * (qq[..., 1] ** 2 + qq[..., 2] ** 2)))
            b["tronc_tangage_deg"] = round(float(np.median(tang.std(0))), 2)
            b["tronc_roulis_deg"] = round(float(np.median(roul.std(0))), 2)
            nv_ = float(W.vr_n_w[sl].sum())                        # R-184 : le verre d'eau, debout
            if nv_ > 0:
                b["verre_deborde_pc"] = round(100.0 * float(W.vr_d_w[sl].sum()) / nv_, 1)
                b["verre_angle_moy_deg"] = round(float(W.vr_s_w[sl].sum()) / nv_, 2)
            if IMITE and float(W.im_n_w[sl].sum()) > 0:            # R-181 : l'écart à la référence (degrés) et l'accord des appuis, debout
                nn_ = float(W.im_n_w[sl].sum())
                b["imite_ecart_deg"] = round(math.degrees((float(W.im_e_w[sl].sum()) / nn_) ** 0.5), 2)
                b["imite_appuis"] = round(float(W.im_c_w[sl].sum()) / nn_, 3)
                b["imite_ecart_par_art_deg"] = {n_: round(math.degrees((float(W.im_ea_w[sl, k_].sum()) / nn_) ** 0.5), 1) for k_, n_ in enumerate(W.im_noms)}
        out["bilan"]["%.0f cm/s" % (100 * v)] = b
        print("%.0f cm/s commandés" % (100 * v), b, flush=True)
    json.dump(out, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32))
    print("=> écrit", sortie, flush=True)


def banc_mannequin(f, sortie, n_graines=15):
    """R-169 : la marche du mannequin au banc : 3 vitesses (3, 5, 8 cm/s) × 3 grandeurs de pas demandées (3, 5, 7 cm), 15 départs chacun,
    10 s, tout droit ; debout, la vitesse, les watts ; les qpos (pour la lecture des pas, du tronc et des épaules sur le portable). L'ordre
    met (5 cm/s, 5 cm) aux départs 45 à 59 (le film de n0_banc.py prend le départ 45)."""
    s = torch.load(f, map_location=DEV)
    combos = [(0.03, 0.03), (0.03, 0.05), (0.03, 0.07), (0.05, 0.05), (0.05, 0.03), (0.05, 0.07), (0.08, 0.03), (0.08, 0.05), (0.08, 0.07)]
    N = len(combos) * n_graines
    W = MondeN0(N, graine=169900)
    W.sans_reinit = True
    pert = np.stack([np.random.default_rng(169000 + i % n_graines).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    W.cap_cmd[:] = 0.0
    W.v_cmd[:] = torch.tensor([combos[i // n_graines][0] for i in range(N)], device=DEV)
    W.l_cmd[:] = torch.tensor([combos[i // n_graines][1] for i in range(N)], device=DEV)
    W.t_cmd[:] = 99.0
    pi = mlp(s["no"], s["na"]).to(DEV)
    pi.load_state_dict(s["pi"])
    nm, nv = s["norm_m"].to(DEV), s["norm_v"].to(DEV)
    o = W.obs()
    x0 = W.subtree_com[:, 1, 0].clone()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    t_chute = torch.full((N,), -1.0, device=DEV)
    e_meca, e_joule = torch.zeros(N, device=DEV), torch.zeros(N, device=DEV)
    QP = []
    with torch.no_grad():
        for k in range(int(DUREE / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            o, r, tombe, tronq, _, info = W.pas(a)
            QP.append(W.qpos.clone().cpu().numpy())
            t_chute = torch.where(vivant & tombe, W.t, t_chute)
            vivant = vivant & ~tombe
            e_meca += info["p_meca"] * DT_C * vivant.float()
            e_joule += info["p_joule"] * DT_C * vivant.float()
    x1 = W.subtree_com[:, 1, 0]
    out = {"politique": f, "combos": combos, "n_graines": n_graines, "bilan": {}}
    for j, (v, l) in enumerate(combos):
        sl = slice(j * n_graines, (j + 1) * n_graines)
        dist = (x1[sl] - x0[sl]).cpu().numpy()
        deb = (t_chute[sl] < 0).cpu().numpy()
        b = {"debout_10s": int(deb.sum()), "vitesse_med_cm_s": round(10 * float(np.median(dist[deb])), 2) if deb.any() else None}
        if deb.any():
            em, ej = e_meca[sl].cpu().numpy()[deb], e_joule[sl].cpu().numpy()[deb]
            b["watts_meca"], b["watts_joule"] = round(float(np.median(em)) / DUREE, 3), round(float(np.median(ej)) / DUREE, 3)
            b["cout_transport"] = round(float(np.median((em + ej) / (W.masse * 9.81 * np.maximum(dist[deb], 1e-3)))), 1)
        out["bilan"]["%.0f cm/s, pas de %.0f cm" % (100 * v, 100 * l)] = b
        print("%.0f cm/s, pas de %.0f cm demandés :" % (100 * v, 100 * l), b, flush=True)
    json.dump(out, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32))
    print("=> écrit", sortie, flush=True)


def banc_escalier(f, sortie, n_graines=30, duree=20.0):
    """R-159 : 30 départs par couloir (1, 2, 3, 3 cm), à 5 cm/s commandés, face à l'escalier, 20 s : debout, les marches montées (le
    bassin au-dessus de chaque marche), arrivé en haut (5 marches) ; les qpos (pour le film du portable)."""
    s_ = torch.load(f, map_location=DEV)
    N = len(ESC_COULOIRS) * n_graines
    W = MondeN0(N, graine=159900)
    W.sans_reinit = True
    W.depart_pied = True                                        # R-186 : pas de départ au milieu des marches au banc
    pert = np.stack([np.random.default_rng(159000 + i // len(ESC_COULOIRS)).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    W.cap_cmd[:] = 0.0
    W.v_cmd[:] = 0.05
    W.t_cmd[:] = 999.0
    pi = mlp(s_["no"], s_["na"]).to(DEV)
    pi.load_state_dict(s_["pi"])
    nm, nv = s_["norm_m"].to(DEV), s_["norm_v"].to(DEV)
    o = W.obs()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    t_chute = torch.full((N,), -1.0, device=DEV)
    t_haut = torch.full((N,), -1.0, device=DEV)
    pieds_max = torch.zeros(N, device=DEV)                       # R-186 : le juge des pieds : la plus haute marche où les deux pieds se sont
    QP = []                                                      # posés ensemble (le juge du centre de masse compte une marche de 0,5 cm dès
    with torch.no_grad():                                        # qu'il monte de 2,5 mm, moins que les variations de la posture)
        for k in range(int(duree / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            o, r, tombe, tronq, _, info = W.pas(a)
            QP.append(W.qpos.clone().cpu().numpy())
            t_chute = torch.where(vivant & tombe, W.t, t_chute)
            vivant = vivant & ~tombe
            t_haut = torch.where(vivant & (W.marche_max >= ESC_NB) & (t_haut < 0), W.t, t_haut)
            nx_ = torch.clamp(torch.floor((W.geom_xpos[:, W.pieds, 0] - ESC_X0) / ESC_PROF) + 1, 0, ESC_NB)   # la marche sous chaque pied
            deux_ = torch.where(W.touche_prev.all(1), nx_.min(1).values, torch.zeros_like(pieds_max))
            pieds_max = torch.where(vivant, torch.maximum(pieds_max, deux_), pieds_max)
    out = {"politique": f, "bilan": {}}
    mm = W.marche_max.cpu().numpy()
    for i, (y, h) in enumerate(ESC_COULOIRS):
        sel = np.arange(i, N, len(ESC_COULOIRS))
        deb = (t_chute.cpu().numpy()[sel] < 0)
        haut = (t_haut.cpu().numpy()[sel] >= 0)
        pm_ = pieds_max.cpu().numpy()[sel]
        b = {"debout_20s": int(deb.sum()), "marches_mediane": float(np.median(mm[sel])), "en_haut": int(haut.sum()),
             "marches_pieds_mediane": float(np.median(pm_)), "en_haut_pieds": int((pm_ >= ESC_NB).sum()),
             "temps_median_en_haut_s": round(float(np.median(t_haut.cpu().numpy()[sel][haut])), 2) if haut.any() else None}
        out["bilan"]["couloir %d (%g cm)" % (i, 100 * h)] = b
        print("couloir %d, marches de %g cm :" % (i, 100 * h), b, flush=True)
    json.dump(out, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32))
    print("=> écrit", sortie, flush=True)


def banc_pente(f, sortie, n_graines=30, duree=20.0):
    """R-167 : 30 départs par couloir (les pentes de N0_PENTES), à 5 cm/s commandés, face à la rampe, 20 s : debout, la distance médiane
    parcourue (x), la hauteur gagnée sur la rampe ; les qpos (pour le film du portable)."""
    s_ = torch.load(f, map_location=DEV)
    N = len(ESC_COULOIRS) * n_graines
    W = MondeN0(N, graine=167900)
    W.sans_reinit = True
    pert = np.stack([np.random.default_rng(167000 + i // len(ESC_COULOIRS)).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    W.cap_cmd[:] = 0.0
    W.v_cmd[:] = 0.05
    W.t_cmd[:] = 999.0
    pi = mlp(s_["no"], s_["na"]).to(DEV)
    pi.load_state_dict(s_["pi"])
    nm, nv = s_["norm_m"].to(DEV), s_["norm_v"].to(DEV)
    o = W.obs()
    x0 = W.subtree_com[:, 1, 0].clone()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    t_chute = torch.full((N,), -1.0, device=DEV)
    QP = []
    with torch.no_grad():
        for k in range(int(duree / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            o, r, tombe, tronq, _, info = W.pas(a)
            QP.append(W.qpos.clone().cpu().numpy())
            t_chute = torch.where(vivant & tombe, W.t, t_chute)
            vivant = vivant & ~tombe
    x1 = W.subtree_com[:, 1, 0]
    haut = W.terrain(x1)
    out = {"politique": f, "bilan": {}}
    for i, (y, _) in enumerate(ESC_COULOIRS):
        sel = np.arange(i, N, len(ESC_COULOIRS))
        deb = (t_chute.cpu().numpy()[sel] < 0)
        d = (x1 - x0).cpu().numpy()[sel]
        h = haut.cpu().numpy()[sel]
        b = {"debout_20s": int(deb.sum()), "distance_med_cm": round(100 * float(np.median(d[deb])), 1) if deb.any() else None,
             "hauteur_gagnee_med_cm": round(100 * float(np.median(h[deb])), 1) if deb.any() else None}
        out["bilan"]["pente %s°" % PENTES.split(",")[i]] = b
        print("pente de %s° :" % PENTES.split(",")[i], b, flush=True)
    json.dump(out, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32))
    print("=> écrit", sortie, flush=True)


TT_L = float(os.environ.get("N0_TTEST_L", "0.5"))              # R-163 : le T-test de R-136/R-140 à l'échelle de N0.1 (N3 : ±2 m pour 1,5 m ;
                                                                # N0.1 : 37 cm, soit ±0,5 m)


def banc_ttest(f, sortie, n_graines=30, vitesses=(0.05, 0.08, 0.10), duree=120.0):
    """R-163 : le T-test de R-136 et R-140, à l'échelle : la ligne à +L (un pied la passe), demi-tour, la ligne à -L, demi-tour, le centre
    (le centre de masse à x > 0). Le pilote commande le cap 0 vers la ligne 1, pi vers la ligne 2, 0 vers le centre, à la vitesse donnée ;
    30 départs perturbés (±1°) par vitesse. Le temps de chaque course, les chutes, et les qpos (pour le film du portable)."""
    s_ = torch.load(f, map_location=DEV)
    N = len(vitesses) * n_graines
    W = MondeN0(N, graine=163900)
    W.sans_reinit = True
    pert = np.stack([np.random.default_rng(163000 + i % n_graines).uniform(-1.0, 1.0, W.nu) for i in range(N)])
    W.reinit(torch.ones(N, dtype=torch.bool, device=DEV), pert)
    W.cap_cmd[:] = 0.0
    W.v_cmd[:] = torch.tensor([vitesses[i // n_graines] for i in range(N)], device=DEV)
    W.t_cmd[:] = 1e9
    pi = mlp(s_["no"], s_["na"]).to(DEV)
    pi.load_state_dict(s_["pi"])
    nm, nv = s_["norm_m"].to(DEV), s_["norm_v"].to(DEV)
    o = W.obs()
    vivant = torch.ones(N, dtype=torch.bool, device=DEV)
    seg = torch.zeros(N, dtype=torch.long, device=DEV)         # 0 : vers la ligne 1 ; 1 : vers la ligne 2 ; 2 : vers le centre ; 3 : fini
    t1, t2, tf, t_chute = (torch.full((N,), -1.0, device=DEV) for _ in range(4))
    QP = []
    with torch.no_grad():
        for k in range(int(duree / DT_C)):
            a = pi(torch.clamp((o - nm) / torch.sqrt(nv + 1e-8), -10, 10))
            o, r, tombe, tronq, _, info = W.pas(a)
            if k % 2 == 0:
                QP.append(W.qpos.clone().cpu().numpy())
            t_chute = torch.where(vivant & tombe & (seg < 3), W.t, t_chute)
            vivant = vivant & ~(tombe & (seg < 3))
            xp = W.geom_xpos[:, W.pieds, 0]
            p1 = vivant & (seg == 0) & (xp.max(1).values > TT_L)
            t1 = torch.where(p1, W.t, t1)
            p2 = vivant & (seg == 1) & (xp.min(1).values < -TT_L)
            t2 = torch.where(p2, W.t, t2)
            p3 = vivant & (seg == 2) & (W.subtree_com[:, 1, 0] > 0.0)
            tf = torch.where(p3, W.t, tf)
            seg = seg + p1.long() + p2.long() + p3.long()
            W.cap_cmd[p1] = math.pi
            W.cap_cmd[p2] = 0.0
            if bool(((seg == 3) | ~vivant).all()):
                break
    out = {"politique": f, "L_m": TT_L, "bilan": {}}
    for j, v in enumerate(vitesses):
        sl = slice(j * n_graines, (j + 1) * n_graines)
        fin = tf[sl].cpu().numpy()
        ok = fin >= 0
        b = {"finis": int(ok.sum()), "tombes": int((t_chute[sl] >= 0).sum()), "temps_median_s": round(float(np.median(fin[ok])), 2) if ok.any() else None,
             "plus_rapide_s": round(float(fin[ok].min()), 2) if ok.any() else None,
             "ligne_1_med_s": round(float(np.median(t1[sl].cpu().numpy()[t1[sl].cpu().numpy() >= 0])), 2) if bool((t1[sl] >= 0).any()) else None,
             "ligne_2_med_s": round(float(np.median(t2[sl].cpu().numpy()[t2[sl].cpu().numpy() >= 0])), 2) if bool((t2[sl] >= 0).any()) else None,
             "segment_median_atteint": float(np.median(seg[sl].cpu().numpy()))}
        out["bilan"]["%.0f cm/s" % (100 * v)] = b
        print("T-test à %.0f cm/s :" % (100 * v), b, flush=True)
    json.dump(out, open(sortie, "w", encoding="utf-8"), indent=1)
    np.savez_compressed(sortie.replace(".json", "-qpos.npz"), qpos=np.stack(QP).astype(np.float32), tf=tf.cpu().numpy(), dt=2 * DT_C)
    print("=> écrit", sortie, flush=True)


if __name__ == "__main__":
    if sys.argv[1] == "apprendre":
        apprendre(sys.argv[2], float(sys.argv[3]), int(sys.argv[4]) if len(sys.argv) > 4 else 4096)
    elif sys.argv[1] == "banc" and PAS_CMD:                     # R-169 : le banc de la marche du mannequin (vitesses × grandeurs de pas)
        banc_mannequin(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "banc" and PENTES:                      # R-167 : le banc de la pente
        banc_pente(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "banc" and ESCALIER:                    # R-159 : le banc de l'escalier quand le travail est un escalier
        banc_escalier(sys.argv[2], sys.argv[3])
    elif sys.argv[1] == "banc":
        banc(sys.argv[2], sys.argv[3], retard=int(sys.argv[4]) if len(sys.argv) > 4 else 0)
    elif sys.argv[1] == "ttest":                                # R-163 : le T-test à l'échelle de N0.1
        banc_ttest(sys.argv[2], sys.argv[3])
