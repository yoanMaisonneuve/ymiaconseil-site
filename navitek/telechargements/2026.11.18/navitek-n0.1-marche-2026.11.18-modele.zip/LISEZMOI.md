# Navitek N0.1 : le modèle de marche 2026.11.18

**La plus proche de la cible** (`N0.1-L18-suite-400`). 31,5° entre les jambes et le genou à 11° quand le talon touche (10 cm/s), sur un seul pied 85 % du temps ; 0,67 fois la vitesse demandée. **Simulé** (MuJoCo, aux couples réels des servos SG90) : rien n'est encore imprimé.

- Score de la marche (0 à 1 ; https://ymiaconseil.com/navitek/these/#ch4) : 0.803 ; les grands pas 0.869, la vitesse 0.744, la
  fluidité 0.703, la sûreté 0.857.
- Appris en 540 millions de pas (la lignée : L18-suite-400 ← L18-jambe-tendue ← photo-zero-genou) par PPO, sur une carte RTX 3060 Ti.

## Ce qu'il y a dedans

- `politique.pt` : les poids (PyTorch) : `pi` (le réseau qui décide : 90 entrées, deux couches de 256 avec ELU, 18 sorties),
  `norm_m`, `norm_v` (la normalisation des entrées), `log_std`, `ech` (les degrés par unité d'action).
- `politique.onnx` : le même réseau, la normalisation et la borne des actions comprises (entrée `observation`, sortie `action`).
- `spec.json` : ce que le réseau reçoit et rend, l'ordre des servos, la cadence (50 fois par seconde).
- `robot/` : N0.1 pour MuJoCo (`n0-gpu-1.xml`, ses maillages `n0-maillages/`, la posture debout `pose0-1.json`) et la marche de
  référence imitée.
- `code/` : `rl_n0.py` et `rl_gpu.py`, l'entraîneur et le banc (MuJoCo Warp, une carte NVIDIA) ; `config.env` : les réglages de cet
  apprentissage.

## S'en servir

1. **Rejouer le banc** (une carte NVIDIA, `pip install mujoco mujoco-warp torch`) : poser les variables de `config.env`, copier
   `robot/` à côté de `code/rl_n0.py`, puis `python code/rl_n0.py banc politique.pt sortie/` (30 départs à 2, 5 et 10 cm/s).
2. **Le réseau seul** (`onnxruntime`) : l'observation se construit comme `Monde.obs()` de `code/rl_n0.py` avec les réglages de
   `config.env` ; l'action `a` (bornée à ±1) donne la consigne de chaque servo : la posture debout + `ech` × `a` degrés, filtrée sur
   80 ms (`N0_FLOW_TAU`) ; la dernière sortie règle la vitesse de l'oscillateur interne.
3. **Les données de ce banc** : le paquet « données » de la même version.

## La fiche du modèle

D'après les fiches de modèle de Mitchell et al. (2019, https://arxiv.org/abs/1810.03993).

- **Ce que c'est.** Une politique de marche pour N0.1 simulé : un réseau de neurones (deux couches de 256, ELU) qui rend une loi
  gaussienne ; on en prend la moyenne pour marcher. Appris par PPO. Version 2026.11.18, `N0.1-L18-suite-400`, 540 millions de pas depuis
  zéro. Par Navitek Robolabs (Yoan Maisonneuve et Claude). Licence CC BY 4.0, le code MIT.
- **Pour quoi faire.** La recherche et l'enseignement, en simulation : rejouer le banc, comparer une autre méthode sur la même tâche,
  repartir de ces poids, étudier une marche apprise.
- **Pas pour.** Piloter un vrai robot tel quel : rien n'est imprimé, aucun vrai SG90 n'a été mesuré, le passage du simulé au réel n'est
  pas fait. Ni aucun usage où une chute blesserait quelqu'un.
- **Comment il est évalué.** Le banc : 90 départs de 10 s (30 à 2, 5 et 10 cm/s, tout droit), debout et immobiles au départ, les servos
  perturbés de ±1° ; l'action moyenne du réseau, sans bruit ; les mêmes graines pour toutes les versions. Le juge : l'écart entre les
  jambes et le genou de devant quand le talon touche (les vrais pas : 5 mm de vol), l'appui simple, la vitesse. Le score : les grands pas
  (λ 0,40), la vitesse (0,25), la fluidité (0,20), la sûreté (0,15).
- **Ses résultats à 10 cm/s.** 24 départs sur 30 debout ; 0,67 fois la vitesse demandée ; 31,5° entre les jambes (le 95e centile) et le genou de devant à 11,2° quand le talon touche ; 85 % du temps sur un seul pied.
- **Ses limites connues.**
  - Simulé seulement : le vrai SG90 a du jeu, des à-coups et une vitesse sous charge que la simulation ne connaît qu'à moitié, et l'inertie de ses rotors n'est pas mesurée.
  - Un seul apprentissage (une seule graine) : pas d'intervalle de confiance d'un apprentissage à l'autre ; le banc, lui, fait 30 départs par vitesse.
  - La cible des grands pas (33° entre les jambes et le genou sous 10° quand le talon touche, à 5 et 10 cm/s) n'est pas atteinte (N1 = 0,869).
  - La vitesse n'est pas celle demandée (N2 = 0,744, 0,67 fois à 10 cm/s).
  - La marche n'est pas encore fluide (N3 = 0,703) : des à-coups aux articulations ou au bassin.
  - Il ne reste pas toujours debout (N4 = 0,857, 24 départs sur 30 à 10 cm/s).
- **Le calcul.** Une carte RTX 3060 Ti (8 Go), MuJoCo Warp, 4 096 robots simulés à la fois : environ 6 h de carte pour toute la
  lignée (la carte tire environ 140 W : près de 1 kWh). Les versions des logiciels : `code/requirements.txt`.
- **L'usage de l'IA.** Le code, les essais, les mesures et ce texte sont de Claude (Anthropic), une IA ; Yoan Maisonneuve dirige et
  décide. Le détail : https://ymiaconseil.com/navitek/these/#declaration

## Citer

Maisonneuve, Y. et Claude (2026). Navitek N0.1, le modèle de marche 2026.11.18 (N0.1-L18-suite-400). Navitek Robolabs.
https://ymiaconseil.com/navitek/telechargements/2026.11.18/ (et `CITATION.cff`)

## In English

Navitek N0.1 walking policy 2026.11.18 (`N0.1-L18-suite-400`), **simulated only** (MuJoCo, real SG90 servo torques; not yet printed). PPO, MLP
2 x 256 ELU, 90 inputs, 18 outputs (17 servo targets plus an oscillator rate), 50 Hz. `politique.onnx` includes the input
normalization and the action bound. `spec.json` documents inputs and outputs; `code/` and `config.env` reproduce the training and the
benchmark (`python code/rl_n0.py banc politique.pt out/`, NVIDIA GPU, MuJoCo Warp). License: CC BY 4.0 (model, data, docs), MIT (code).

Model card (after Mitchell et al., 2019). Intended use: research and teaching in simulation (replay the benchmark, compare methods on the
same task, fine-tune from these weights). Out of scope: driving a real robot as is (nothing printed, no real SG90 measured, no sim-to-real
transfer done). Evaluation: 90 ten-second rollouts (30 each at 2, 5 and 10 cm/s), mean action, fixed seeds. Results at 10 cm/s:
24 of 30 rollouts standing; 0.67 times the commanded speed; 31.5 deg between the legs (95th percentile) and the front knee at 11.2 deg at heel strike; 85 % of the time on one foot. Known limits: simulation only; a single training seed (no confidence interval across trainings). Compute: one RTX 3060 Ti,
about 6 GPU hours for the whole lineage. AI use: code, experiments, measurements and this text by Claude (Anthropic), directed by Yoan
Maisonneuve. Pinned versions: `code/requirements.txt`. Citation: `CITATION.cff`.
