# Navitek N0.1 : le modèle de marche 2026.11.16

**La première marche droite** (`N0.1-photo-zero-genou`). Apprise de zéro en imitant la photo d'un pas humain : le tronc droit, la vitesse obéie à 2, 5 et 10 cm/s. **Simulé** (MuJoCo, aux couples réels des servos SG90) : rien n'est encore imprimé.

- Score de la marche (0 à 1 ; https://ymiaconseil.com/navitek/these/#ch4) : 0.637 ; les grands pas 0.442, la vitesse 0.97, la
  fluidité 0.336, la sûreté 1.0.
- Appris en 60 millions de pas (la lignée : photo-zero-genou) par PPO, sur une carte RTX 3060 Ti.

## Ce qu'il y a dedans

- `politique.pt` : les poids (PyTorch) : `pi` (le réseau qui décide : 90 entrées, deux couches de 256 avec ELU, 18 sorties),
  `norm_m`, `norm_v` (la normalisation des entrées), `log_std`, `ech` (les degrés par unité d'action).
- `politique.onnx` : le même réseau, la normalisation et la borne des actions comprises (entrée `observation`, sortie `action`).
- `spec.json` : ce que le réseau reçoit et rend, l'ordre des servos, la cadence (50 fois par seconde).
- `robot/` : N0.1 pour MuJoCo (`n0-gpu-1.xml`, ses maillages `n0-maillages/`, la posture debout `pose0-1.json`) et la marche de
  référence imitée.
- `code/` : `rl_n0.py` et `rl_gpu.py`, l'entraîneur et le banc (MuJoCo Warp, une carte NVIDIA) ; `config.env` : les réglages de cet
  apprentissage.

## S'en servir

1. **Rejouer le banc** (une carte NVIDIA, `pip install mujoco mujoco-warp torch`) : poser les variables de `config.env`, copier
   `robot/` à côté de `code/rl_n0.py`, puis `python code/rl_n0.py banc politique.pt sortie/` (30 départs à 2, 5 et 10 cm/s).
2. **Le réseau seul** (`onnxruntime`) : l'observation se construit comme `Monde.obs()` de `code/rl_n0.py` avec les réglages de
   `config.env` ; l'action `a` (bornée à ±1) donne la consigne de chaque servo : la posture debout + `ech` × `a` degrés, filtrée sur
   80 ms (`N0_FLOW_TAU`) ; la dernière sortie règle la vitesse de l'oscillateur interne.
3. **Les données de ce banc** : le paquet « données » de la même version.

## Citer

Maisonneuve, Y. et Claude (2026). Navitek N0.1, le modèle de marche 2026.11.16 (N0.1-photo-zero-genou). Navitek Robolabs.
https://ymiaconseil.com/navitek/telechargements/2026.11.16/

## In English

Navitek N0.1 walking policy 2026.11.16 (`N0.1-photo-zero-genou`), **simulated only** (MuJoCo, real SG90 servo torques; not yet printed). PPO, MLP
2 x 256 ELU, 90 inputs, 18 outputs (17 servo targets plus an oscillator rate), 50 Hz. `politique.onnx` includes the input
normalization and the action bound. `spec.json` documents inputs and outputs; `code/` and `config.env` reproduce the training and the
benchmark (`python code/rl_n0.py banc politique.pt out/`, NVIDIA GPU, MuJoCo Warp). License: CC BY 4.0 (model, data, docs), MIT (code).
