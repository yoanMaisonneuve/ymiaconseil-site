# Navitek N0.1 : les données de la marche 2026.11.16

Le banc de `N0.1-photo-zero-genou` (**simulé**, MuJoCo) : 90 départs de 10 s, 30 à 2 cm/s, 30 à 5 cm/s, 30 à 10 cm/s, debout et immobiles au départ.

- `banc-final.json` : le bilan du banc (debout à 10 s, la vitesse, l'énergie, le tronc, le glissement...) et chaque départ.
- `banc-final-qpos.npz` : `qpos` (500 images à 50 par seconde x 90 départs x 24 positions : la base libre, puis les 17 articulations dans
  l'ordre de `spec.json`).
- `progression.jsonl` : la courbe d'apprentissage (une ligne tous les 0,5 million de pas environ).
- `juge.json` : le juge de Navitek (l'écart entre les jambes, le genou quand le talon touche, la pointe, le talon arrière, l'appui
  simple...) et `score.json` (le score de la marche, ses quatre niveaux, le coût en millions de pas).

## La fiche des données

D'après les fiches de données de Gebru et al. (2021, https://arxiv.org/abs/1803.09010).

- **Pourquoi.** Mesurer chaque version de la marche sur le même banc, pour la comparer aux autres versions et à d'autres méthodes.
- **Ce qu'il y a.** 90 départs simulés ; pour chacun, les positions de la base et des 17 articulations à 50 images par seconde, et son
  bilan. Aucune donnée de personne : la marche de référence est construite par notre code, et aucune image n'est dans le paquet.
- **Comment c'est produit.** `python code/rl_n0.py banc politique.pt sortie/` (le paquet « modèle » de la même version), sur la tour
  (RTX 3060 Ti) : le monde simulé à la graine 150900, les départs perturbés de ±1° (graines 137900 à 137929, les mêmes à chaque vitesse),
  l'action moyenne du réseau, sans bruit. Le juge et le score viennent de nos scripts d'analyse, pas encore dans ce paquet ; leurs
  définitions : la thèse (§4.4) et les cahiers R-190, R-198 et R-200.
- **Pour quoi faire.** Comparer, analyser une marche apprise (les angles pas à pas), refaire nos figures, vérifier nos verdicts.
- **Les limites.** Simulé seulement ; un seul apprentissage derrière chaque version.
- **Diffusion et suivi.** CC BY 4.0 ; chaque version est datée, ses empreintes sha256 sont dans
  https://ymiaconseil.com/navitek/telechargements/versions.json ; une erreur repérée : yoan@ymiaconseil.com.

Licence CC BY 4.0. Citer : Maisonneuve, Y. et Claude (2026). Navitek N0.1, les données de la marche 2026.11.16. https://ymiaconseil.com/navitek/telechargements/2026.11.16/
(et `CITATION.cff`)

In English: benchmark data of the simulated N0.1 walking policy 2026.11.16: 90 ten-second rollouts (2, 5, 10 cm/s), joint trajectories
(`qpos`, 50 Hz), the training curve, our gait judge and the walking score. CC BY 4.0. Datasheet (after Gebru et al., 2021): simulated
only, no human data, no images; produced by `code/rl_n0.py banc` (world seed 150900, start perturbation seeds 137900-137929, mean action);
the judge and score scripts are not yet in this package (definitions: the thesis, section 4.4). Citation: `CITATION.cff`.
