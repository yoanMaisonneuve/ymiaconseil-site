# Navitek N0.1 : les données de la marche 2026.11.16

Le banc de `N0.1-photo-zero-genou` (**simulé**, MuJoCo) : 90 départs de 10 s, 30 à 2 cm/s, 30 à 5 cm/s, 30 à 10 cm/s, debout et immobiles au départ.

- `banc-final.json` : le bilan du banc (debout à 10 s, la vitesse, l'énergie, le tronc, le glissement...) et chaque départ.
- `banc-final-qpos.npz` : `qpos` (500 images à 50 par seconde x 90 départs x 24 positions : la base libre, puis les 17 articulations dans
  l'ordre de `spec.json`).
- `progression.jsonl` : la courbe d'apprentissage (une ligne tous les 0,5 million de pas environ).
- `juge.json` : le juge de Navitek (l'écart entre les jambes, le genou quand le talon touche, la pointe, le talon arrière, l'appui
  simple...) et `score.json` (le score de la marche, ses quatre niveaux, le coût en millions de pas).

Licence CC BY 4.0. Citer : Maisonneuve, Y. et Claude (2026). Navitek N0.1, les données de la marche 2026.11.16. https://ymiaconseil.com/navitek/telechargements/2026.11.16/

In English: benchmark data of the simulated N0.1 walking policy 2026.11.16: 90 ten-second rollouts (2, 5, 10 cm/s), joint trajectories
(`qpos`, 50 Hz), the training curve, our gait judge and the walking score. CC BY 4.0.
