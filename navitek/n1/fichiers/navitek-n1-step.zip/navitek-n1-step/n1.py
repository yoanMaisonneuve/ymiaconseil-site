"""Navitek N1 : l'humanoïde d'environ 65 cm à servos à bus Feetech STS3215 (08.11.2026, boucle Navitek). Toute la CAO, FreeCAD 1.1 :

    freecadcmd n1.py          (FreeCAD 1.1 ; sous Windows : "<dossier de FreeCAD>/bin/freecadcmd.exe" n0.py, lancé depuis cao/)

Variable NAVITEK_OUT : le dossier de sortie (par défaut, le dossier parent de ce fichier).
Sorties : stl-impression/<pièce>.stl (orientée pour l'impression, posée sur le plateau), step/<pièce>.step, step/n1-assemblage.step,
web/<pièce>.stl (dans le repère de l'assemblage) et web/assemblage.json (une instance par pièce posée : matrice, couleur, groupe).

Le système (version 2, 09.11.2026, R-047) : un BOÎTIER reçoit chaque STS3215 par le dessus, une BRIDE de 2 mm le tient (4 vis M2) ;
un ÉTRIER en U tourne avec l'arbre, vissé sur les DEUX disques du servo (bras A sur le palonnier rond, bras B sous les fiches des
câbles, par une bague jusqu'au disque du bas) ; la base de l'étrier se visse (4 vis M3, carré de 16 mm) sur la paroi du bout du
boîtier suivant. Repère d'un servo : l'arbre sur l'axe z, le dessus du corps du servo à z = 0, le corps vers +x.
Les cotes du servo, en tête, viennent du modèle STEP du projet SO-ARM100 (R-047) : les vérifier au pied à coulisse sur le premier
servo reçu (le gabarit d'essai), puis relancer. La version 1 (08.11) supposait des oreilles de fixation, que le STS3215 n'a pas.
Version 2.3 (09.11, R-051) : hanches à 50 mm du milieu, épaules à 123, torse élargi avec les hanches, bord intérieur du pied à 16 mm de la
cheville : la hanche de côté s'ouvre de 10° vers l'intérieur et 12° vers l'extérieur (4 et 5 sur la 2.2, gelée dans navitek-sim/n1-v2.2-gele/).
Version 2.4 (10.11, R-060) : un étrier de genou long remplace la rallonge du tibia (même longueur de jambe) ; le genou s'ouvre à 139° (112 sur la
2.3, gelée dans navitek-sim/n1-v2.3-gele/), pour s'accroupir assez bas et se relever.
"""
import json
import math
import os

import FreeCAD as App
import MeshPart
import Part

V = App.Vector
OUT = os.environ.get("NAVITEK_OUT", os.path.abspath(os.path.join(os.getcwd(), "..")))   # le dossier navitek-n0 (lancé depuis cao/)
POLICE = os.environ.get("NAVITEK_POLICE", "C:/Windows/Fonts/arialbd.ttf")   # une police grasse TrueType (Linux : DejaVuSans-Bold.ttf)

# --- Le servo Feetech STS3215 : cotes prises sur le modèle STEP publié par le projet SO-ARM100 (R-047, 09.11.2026) --------------
# Version 2 (09.11) : la version 1 supposait des oreilles de fixation (54 mm, trous à 49 mm) : le STS3215 n'en a pas (R-047, ERREURS E16).
# Repère : l'arbre sur z, z = 0 au dessus du corps (couvercle compris), le corps vers +x. À VÉRIFIER au pied à coulisse sur le premier servo.
SL, SW = 45.4, 24.8                # longueur, largeur du corps [V : modèle SO-ARM100 ; fiches : 45,2 x 24,7]
SH = 31.8                          # hauteur du corps, couvercles compris, sans les disques de sortie [V, R-047]
E = 10.2                           # de l'axe de l'arbre au bout du corps, côté arbre [V, R-047]
DISQUE_R = 10.0                    # les deux disques de sortie (le palonnier rond fourni et la seconde sortie), Ø 20 [V]
DA0, DA1 = 0.3, 2.8                # disque du haut, en z [V]
DB0, DB1 = -SH - 1.8, -SH          # disque du bas, en z (2,1 mm dont 0,3 dans le corps) [V]
DISQUE_TROU = 4.95                 # 4 trous taraudés M3 (Ø 2,5) aux coins d'un carré de 9,9 mm centré sur l'arbre [V : Ø ; M3 : déduit du Ø et des vis fournies]
BOSSE_R = 4.5                      # la bosse cannelée sous le disque du haut, Ø 9 [V]
FICHE_X, FICHE_Y = 14.05, 9.5      # les deux connecteurs 3 broches sous le corps (au pas de 2,4 mm, à x = 14,05) [V] ; demi-largeur des fiches : estimation
FICHE_BAS = -SH - 8.0              # le bas des fiches branchées, câble plié compris : ESTIMATION (8 mm sous le corps)
JEU = 0.4                          # jeu d'impression autour du servo

# --- Le système -----------------------------------------------------------------------------------------------------------
PAROI, PAROI_Y, FOND, BOUT = 3.0, 4.0, 3.5, 5.0     # parois (bouts, côtés), fond, paroi du bout qui reçoit le motif
XC = SL / 2 - E                    # centre du servo en x
BX0, BX1 = -E - JEU - PAROI, SL - E + JEU + BOUT    # le boîtier, en x
BY = SW / 2 + JEU + PAROI_Y        # demi-largeur du boîtier
BZ0 = -SH - JEU - FOND             # dessous du boîtier
TROU_FOND_R = DISQUE_R + 1.5       # le trou du fond, autour du disque du bas et de la bague de l'étrier
BRIDE_T = 2.0                      # la bride qui tient le servo par le dessus (z de 0 à 2)
BRIDE_VIS = ((-6.0, 1), (-6.0, -1), (SL - E - 5.0, 1), (SL - E - 5.0, -1))   # 4 vis M2 x 8 dans les côtés du boîtier (x, côté)
VIS_Y = SW / 2 + JEU + PAROI_Y / 2
M2_PILOTE, M2_PASSAGE = 1.6, 2.4
MOTIF = 8.0                        # demi-côté du carré de 4 trous M3
MOTIF_Z = -19.0                    # centre du motif (même hauteur sur le boîtier et sur l'étrier : la chaîne reste droite)
PILOTE, PASSAGE = 2.5, 3.5         # trou pour vis M3 autotaraudeuse ; trou de passage
UA0, UA_T = DA1, 3.5               # bras A de l'étrier, posé sur le disque du haut (4 vis M3 x 6, celles du servo)
UB1 = FICHE_BAS - 1.2              # dessus du bras B : sous les fiches des câbles, à tout angle
UB_T = 3.5
UB0 = UB1 - UB_T
BAGUE_R0, BAGUE_R1 = 3.5, DISQUE_R + 0.5      # la bague du bras B, du bras jusqu'au disque du bas (4 vis M3 x 10, têtes en lamage)
LAMAGE_D, LAMAGE_P = 6.5, 3.0
UX1, UX0 = -23.0, -27.0            # la base de l'étrier, en x (le coin du boîtier passe à 21,6 mm de l'arbre)
UY = 11.5                          # demi-largeur des bras
LS = 18.0                          # rallonge de cuisse et de tibia : 2,5 (étrier) + 10 + 3,5 de prise = une vis M2 x 16 (08.11 : à 12, elle ne mordait que 1,5 mm)
GENOU_LONG = os.environ.get("N1_GENOU_LONG", "1") != "0"   # version 2.4 (R-060) : l'étrier de genou long (bras + LS) remplace la rallonge du tibia ; le genou bute à 139° au lieu de 112 (N1_GENOU_LONG=0 : la 2.3)

ORANGE, GRIS, BLEU, NOIR = "#f26b1d", "#7d838c", "#1d2a6b", "#23262b"


def boite(x0, x1, y0, y1, z0, z1):
    return Part.makeBox(x1 - x0, y1 - y0, z1 - z0, V(x0, y0, z0))


def cyl(r, z0, z1, x=0.0, y=0.0):
    return Part.makeCylinder(r, z1 - z0, V(x, y, z0))


def cyl_x(r, x0, x1, y, z):
    return Part.makeCylinder(r, x1 - x0, V(x0, y, z), V(1, 0, 0))


def cyl_y(r, y0, y1, x, z):
    return Part.makeCylinder(r, y1 - y0, V(x, y0, z), V(0, 1, 0))


def unir(formes):
    s = formes[0]
    for f in formes[1:]:
        s = s.fuse(f)
    return s.removeSplitter()


def axes(xa, ya, za, o=V(0, 0, 0)):
    """Placement dont les colonnes sont les axes donnés (le repère local vu du parent)."""
    return App.Placement(App.Matrix(xa.x, ya.x, za.x, o.x, xa.y, ya.y, za.y, o.y, xa.z, ya.z, za.z, o.z, 0, 0, 0, 1))


def rot(axe, deg):
    return App.Placement(V(0, 0, 0), App.Rotation(axe, deg))


def trans(x, y, z):
    return App.Placement(V(x, y, z), App.Rotation())


# =========================================================================================================================
# Les pièces, chacune dans son repère
# =========================================================================================================================
def trous_disque(z0, z1, r):
    return [cyl(r, z0, z1, dx, dy) for dx in (-DISQUE_TROU, DISQUE_TROU) for dy in (-DISQUE_TROU, DISQUE_TROU)]


def servo_modele():
    """Le servo lui-même (pas imprimé), pour l'assemblage : le corps, la bosse cannelée, le disque du bas, les deux connecteurs."""
    corps = boite(-E, SL - E, -SW / 2, SW / 2, -SH, 0)
    bosse = cyl(BOSSE_R, -0.5, DA0)
    disque_b = cyl(DISQUE_R, DB0, DB1)
    for t in trous_disque(DB0 - 1, DB1 + 0.01, 1.25):
        disque_b = disque_b.cut(t)
    connecteurs = boite(FICHE_X - 2.0, FICHE_X + 2.0, -8.6, 8.6, -SH - 3.5, -SH + 0.01)
    return unir([corps, bosse, disque_b, connecteurs])


def palonnier_modele():
    """Le palonnier rond fourni (le disque du haut, Ø 20, 4 trous M3 sur un carré de 9,9 mm, la vis centrale)."""
    s = cyl(DISQUE_R, DA0, DA1)
    for t in trous_disque(DA0 - 1, DA1 + 1, 1.25):
        s = s.cut(t)
    return s


def fiches_modele():
    """Les deux fiches des câbles branchées sous le servo (ESTIMATION : 8 mm sous le corps, câble plié compris) : pas imprimées,
    mais le contrôle des collisions les voit (le bras B de l'étrier doit passer dessous à tout angle)."""
    return boite(FICHE_X - 3.0, FICHE_X + 3.0, -FICHE_Y, FICHE_Y, FICHE_BAS, -SH - 0.01)


def boitier():
    """Le boîtier d'un servo (version 2) : une poche ouverte en haut, le servo posé sur le fond ; le fond est ouvert autour de l'arbre (le
    disque du bas et la bague de l'étrier y tournent) et sous les connecteurs ; 4 trous pilotes M2 dans les côtés pour la bride ;
    le motif de 4 trous M3 dans la paroi du bout opposé à l'arbre."""
    s = boite(BX0, BX1, -BY, BY, BZ0, 0)
    s = s.cut(boite(-E - JEU, SL - E + JEU, -SW / 2 - JEU, SW / 2 + JEU, -SH - JEU, 1))
    s = s.cut(cyl(TROU_FOND_R, BZ0 - 1, -SH))
    s = s.cut(boite(FICHE_X - 4.0, FICHE_X + 4.0, -FICHE_Y - 0.5, FICHE_Y + 0.5, BZ0 - 1, -SH))
    for x, c in BRIDE_VIS:
        s = s.cut(cyl(M2_PILOTE / 2, -8.0, 1, x, c * VIS_Y))
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PILOTE / 2, BX1 - BOUT + 0.5, BX1 + 1, dy, MOTIF_Z + dz))
    return s.removeSplitter()


def bride():
    """La bride (imprimée, une par servo) : une plaque de 2 mm sur le boîtier, qui tient le servo par le dessus ; un grand trou
    autour de l'arbre (le palonnier y tourne) ; 4 vis M2 x 8."""
    s = boite(BX0, BX1, -BY, BY, 0, BRIDE_T)
    s = s.cut(cyl(TROU_FOND_R, -1, BRIDE_T + 1))
    for x, c in BRIDE_VIS:
        s = s.cut(cyl(M2_PASSAGE / 2, -1, BRIDE_T + 1, x, c * VIS_Y))
    return s.removeSplitter()


def bras_etrier(z0, z1, ux0=UX0):
    return unir([boite(ux0, 0, -UY, UY, z0, z1), cyl(UY, z0, z1)])


def etrier(long=0.0):
    """L'étrier en U (version 2), vissé sur les DEUX disques du servo (le STS3215 a une seconde sortie) : le bras A sur le palonnier
    (4 vis M3 x 6), le bras B, sous les fiches des câbles, par une bague jusqu'au disque du bas (4 vis M3 x 10 en lamage) ; un trou
    au centre de chaque bras pour la vis centrale ; la base porte le motif de 4 trous de passage.
    long (R-060) : les bras allongés de « long » mm et la base reculée d'autant (l'étrier de genou long, qui remplace la rallonge du tibia)."""
    UX0, UX1 = globals()["UX0"] - long, globals()["UX1"] - long
    a = bras_etrier(UA0, UA0 + UA_T, UX0)
    a = a.cut(cyl(3.5, UA0 - 1, UA0 + UA_T + 1))
    for t in trous_disque(UA0 - 1, UA0 + UA_T + 1, PASSAGE / 2):
        a = a.cut(t)
    b = unir([bras_etrier(UB0, UB1, UX0), cyl(BAGUE_R1, UB1 - 0.01, DB0)])
    b = b.cut(cyl(BAGUE_R0, UB0 - 1, DB0 + 1))
    for t in trous_disque(UB0 - 1, DB0 + 1, PASSAGE / 2):
        b = b.cut(t)
    for t in trous_disque(UB0 - 1, UB0 + LAMAGE_P, LAMAGE_D / 2):
        b = b.cut(t)
    base = boite(UX0, UX1, -UY, UY, UB0, UA0 + UA_T)
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            base = base.cut(cyl_x(PASSAGE / 2, UX0 - 1, UX1 + 1, dy, MOTIF_Z + dz))
    return unir([a, b, base])


def rallonge():
    """Rallonge de cuisse et de tibia : x de -LS à 0, le motif traversant (vis M2 x 16)."""
    s = boite(-LS, 0, -BY, BY, MOTIF_Z - 9, MOTIF_Z + 9)
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PASSAGE / 2, -LS - 1, 1, dy, MOTIF_Z + dz))
    return s


def main_piece():
    """La main : une mitaine sous la base de l'étrier du coude. Repère : la face de montage dans le plan x = 0, la main vers -x."""
    paume = boite(-70, 0, -11, 11, MOTIF_Z - 18, MOTIF_Z + 18)
    pouce = boite(-48, -18, -11, 11, MOTIF_Z + 18, MOTIF_Z + 28)
    s = unir([paume, pouce, cyl_y(18, -11, 11, -70, MOTIF_Z)])
    s = s.cut(boite(-90, -55, -12, 12, MOTIF_Z - 2.2, MOTIF_Z + 2.2))              # la fente entre les doigts
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PILOTE / 2, -12, 1, dy, MOTIF_Z + dz))
    return s.removeSplitter()


# --- Le torse (repère du monde : z vers le haut, x vers l'avant, y vers la gauche) ---------------------------------------
YH = float(os.environ.get("N1_YH", "50.0"))   # (R-051 : N1_YH pour un essai, avec NAVITEK_OUT hors du dépôt) centre des motifs des hanches (v2.2 : 26 → 36 ; à 26, les modules de tangage des deux jambes se touchaient, R-048 ; v2.3 : 36 → 50, la hanche de côté s'ouvre, R-051)
YS = float(os.environ.get("N1_YS", "123.0"))  # (R-051 : N1_YS pour un essai) centre des motifs des épaules (v2.2 : 88 → 98, pour que les mains restent hors des hanches ; v2.3 : 98 → 123, la main hors de la bride du genou)
TX, TY = 40.0, float(os.environ.get("N1_TY", YH + 16.0))   # demi-profondeur et demi-largeur du torse (v2.3 : TY suit YH, 52 sur la 2.2 ; à TY 52 et YH 50, le boîtier de chaque hanche dépassait de 15 mm et deux vis sur quatre tombaient hors du torse : ERREURS E22)
TZ0, TZ1 = 191.0, 321.0            # bas et haut du torse
TP = 2.4                           # parois
XN = 5.0                           # l'arbre du cou (légèrement vers l'avant)


SC_X0, SC_X1 = XN - BX1 - 4.0, XN - BX1        # le support du cou : la plaque du motif, en x (repère du monde)
SC_AILE = 9.0                                  # les deux ailes sous le toit, de part et d'autre du boîtier, en y
SUPPORT_COU_VIS = [(SC_X0 + 6.0, s * (BY + 0.5 + SC_AILE / 2)) for s in (1, -1)] + [(SC_X0 + 16.0, s * (BY + 0.5 + SC_AILE / 2)) for s in (1, -1)]


def support_cou():
    """Le support du cou (version 2.1, repère du monde) : une plaque verticale qui reçoit le motif du boîtier du cou (4 trous de passage M3),
    et deux ailes sous le toit, vissées par le dessus (4 vis M3 x 8 dans des trous pilotes). S'imprime couché sur la plaque."""
    plaque = boite(SC_X0, SC_X1, -BY, BY, TZ1 + BZ0, TZ1 - 3)
    ailes = [boite(SC_X0, SC_X0 + 22.0, s0, s1, TZ1 - 3 - 6.0, TZ1 - 3) for s0, s1 in ((BY + 0.5, BY + 0.5 + SC_AILE), (-BY - 0.5 - SC_AILE, -BY - 0.5))]
    pont = [boite(SC_X0, SC_X1, s0, s1, TZ1 - 3 - 6.0, TZ1 - 3) for s0, s1 in ((BY - 0.01, BY + 0.51), (-BY - 0.51, -BY + 0.01))]
    s = unir([plaque] + ailes + pont)
    for dy in (-MOTIF, MOTIF):
        for dz in (-MOTIF, MOTIF):
            s = s.cut(cyl_x(PASSAGE / 2, SC_X0 - 1, SC_X1 + 1, -dy, TZ1 + MOTIF_Z + dz))
    for x, y in SUPPORT_COU_VIS:
        s = s.cut(cyl(PILOTE / 2, TZ1 - 3 - 7.0, TZ1, x, y))
    return s.removeSplitter()


def texte(chaine, taille, centre, xa, ya, profondeur):
    """Un texte en creux : les lettres extrudées de « profondeur », posées dans le plan (xa, ya) autour de « centre »."""
    lettres = Part.makeWireString(chaine, POLICE, taille, 0.0)
    faces = [Part.Face(fils, "Part::FaceMakerBullseye") for fils in lettres if fils]
    c = Part.makeCompound(faces)
    bb = c.BoundBox
    c.translate(V(-(bb.XMin + bb.XMax) / 2, -(bb.YMin + bb.YMax) / 2, 0))
    s = c.extrude(V(0, 0, profondeur))
    za = xa.cross(ya)
    s.Placement = axes(xa, ya, za, centre).multiply(trans(0, 0, -profondeur / 2))
    return s


def torse():
    s = boite(-TX, TX, -TY, TY, TZ0, TZ1)
    s = s.cut(boite(-TX - 1, TX - TP, -TY + TP, TY - TP, TZ0 + 3, TZ1 - 3))      # creux, ouvert à l'arrière
    for sy in (1, -1):
        # v2.3 : le rebord d'épaule n'est plus dans le torse (d'une pièce, le torse ne tenait plus sur le plateau : R-051 § 6, ERREURS E23) ;
        # chaque flanc reçoit les 4 vis de son épaulette, posées de l'intérieur
        for x, z in EP_VIS:
            s = s.cut(cyl_y(PASSAGE / 2, TY - TP - 1 if sy > 0 else -TY - 1, TY + 1 if sy > 0 else -TY + TP + 1, x, z))
        for dx in (-MOTIF, MOTIF):
            for dy in (-MOTIF, MOTIF):
                s = s.cut(cyl(PASSAGE / 2, TZ0 - 1, TZ0 + 5, dx, sy * YH + dy))  # hanches : vis par l'intérieur
        s = s.cut(boite(-12, 12, sy * (YH - 18) - 5, sy * (YH - 18) + 5, TZ0 - 1, TZ0 + 5))  # câbles des jambes (v2.2 : entre le milieu et le motif)
        s = s.cut(boite(-8, 8, sy * TY - 3 if sy > 0 else -TY - 1, sy * TY + 1 if sy > 0 else -TY + 3, TZ1 - 22, TZ1 - 9))   # câbles des bras
    # le servo du cou (version 2) : son boîtier passe par une ouverture du toit, le dessus au ras du toit ; il est vissé par son motif
    # sur le SUPPORT DU COU (pièce à part, en L), lui-même vissé sous le toit par 4 vis M3 (version 2.1 : la cloison imprimée avec le
    # torse faisait une étagère de 33 mm en porte-à-faux)
    s = s.cut(boite(XN - BX1 - 0.4, XN - BX0 + 0.4, -BY - 0.4, BY + 0.4, TZ1 - 4, TZ1 + 1))
    for x, y in SUPPORT_COU_VIS:
        s = s.cut(cyl(PASSAGE / 2, TZ1 - 4, TZ1 + 1, x, y))
    # coins pour les vis du dos
    for sy in (1, -1):
        for z in (TZ0 + 8, TZ1 - 8):
            s = s.fuse(boite(-TX, -TX + 6, sy * (TY - TP - 5) if sy > 0 else -(TY - TP), sy * (TY - TP) if sy > 0 else -(TY - TP - 5), z - 3, z + 3))
            yw = sy * (TY - TP)                                                  # la paroi de côté
            biseau = Part.Face(Part.makePolygon([V(-TX + 6, yw, z - 3), V(-TX + 6, yw - sy * 5, z - 3), V(-TX + 11, yw, z - 3), V(-TX + 6, yw, z - 3)]))
            s = s.fuse(biseau.extrude(V(0, 0, 6)))
            s = s.cut(cyl_x(PILOTE / 2, -TX - 1, -TX + 6, sy * (TY - TP - 2.5), z))
    # le Pico 2 W : 4 entretoises sur la paroi avant, trous M2 (47 x 11,4 mm)
    for dy in (-23.5, 23.5):
        for dz in (-5.7, 5.7):
            s = s.fuse(cyl_x(2.2, TX - TP - 4, TX - TP, dy, TZ0 + 80 + dz))
            s = s.cut(cyl_x(PILOTE / 2, TX - TP - 5, TX - TP, dy, TZ0 + 80 + dz))
    # NAVITEK en creux sur la poitrine
    s = s.cut(texte(u"NAVITEK", 14.0, V(TX, 0, TZ0 + 100), V(0, 1, 0), V(0, 0, 1), 2.0))
    return s.removeSplitter()


def dos():
    s = boite(-TX - 2.4, -TX, -TY, TY, TZ0, TZ1)
    for sy in (1, -1):
        for z in (TZ0 + 8, TZ1 - 8):
            s = s.cut(cyl_x(PASSAGE / 2, -TX - 3, -TX + 1, sy * (TY - TP - 2.5), z))
    for k in range(5):                                                           # aération
        s = s.cut(boite(-TX - 3, -TX + 1, -34, 34, TZ0 + 22 + 11 * k, TZ0 + 27 + 11 * k))
    s = s.cut(texte(u"N1", 16.0, V(-TX - 2.4, 0, TZ0 + 100), V(0, -1, 0), V(0, 0, 1), 1.5))
    return s.removeSplitter()


# --- La tête (repère du servo du cou : l'arbre en z, z = 0 au dessus du servo) -------------------------------------------
def tete():
    z0 = UA0                                                                     # le dessous de la tête repose sur le palonnier rond (0,8 mm au-dessus de la bride)
    h = 80.0
    s = boite(-46, 40, -40, 40, z0, z0 + h)
    s = s.makeFillet(8.0, [e for e in s.Edges if e.BoundBox.ZMin > z0 + 1])      # arêtes du haut et verticales arrondies
    # le creux : un plafond en pignon à 45° (porte-à-faux du 08.11 : le plafond plat faisait un pont de 37,6 mm) ; le faîte court en y
    x0, x1, zt = -42.5, 36.5, z0 + h - 3.0
    zr = zt - (x1 - x0) / 2
    s = s.cut(boite(x0, x1, -36.5, 36.5, z0 + 4.0, zr + 0.01))
    pignon = Part.Face(Part.makePolygon([V(x0, -36.5, zr), V(x1, -36.5, zr), V((x0 + x1) / 2, -36.5, zt), V(x0, -36.5, zr)]))
    s = s.cut(pignon.extrude(V(0, 73.0, 0)))
    # version 2 : le fond (4 mm) posé sur le palonnier rond ; 4 vis M3 x 6 par l'intérieur, trou de la vis centrale (version 2.1 : sans entretoise,
    # qui laissait tout le dessous de la tête en porte-à-faux à 2 mm du plateau)
    s = s.cut(cyl(3.5, z0 - 1, z0 + 5.0))
    for t in trous_disque(z0 - 1, z0 + 5.0, PASSAGE / 2):
        s = s.cut(t)
    s = s.cut(cyl(4.5, z0 + h - 12, z0 + h + 1))                                  # accès au tournevis, fermé par l'antenne
    # la fente de la visière, sur la face -x du repère du cou (le cou tourne de 180° : -x ici est le devant du robot)
    s = s.cut(boite(-47, -43, -30, 30, z0 + 34, z0 + 52))
    return s.removeSplitter()


def visiere():
    """L'insert gris de la visière (repère de la tête)."""
    z0 = UA0
    s = boite(-46.6, -43.4, -29.6, 29.6, z0 + 34.6, z0 + 51.4)
    return s.cut(boite(-47, -45.6, -24, 24, z0 + 42.0, z0 + 44.0))               # une ligne d'« yeux »


EP_T, EP_H = 6.0, 40.0                         # l'épaulette : épaisseur de l'aile verticale, et sa hauteur depuis le dessus du toit
EP_VIS = [(x, z) for x in (-26.0, 26.0) for z in (TZ1 - 16.0, TZ1 - 32.0)]     # ses 4 vis M3 x 8 dans le flanc du torse (x, z)


def epaulette():
    """L'épaulette (version 2.3, R-051 § 6 ; repère du monde, côté gauche : la droite est la même pièce tournée d'un demi-tour autour de z).
    Une équerre : l'aile horizontale (8 mm, au niveau du toit, là où était le rebord d'épaule du torse) reçoit le motif de l'épaule (4 trous de
    passage M3, vis par le dessus) ; l'aile verticale se visse sur le flanc du torse (4 vis M3 x 8 posées de l'intérieur, le dos ouvert), avec
    une fenêtre en face de celle du torse pour les câbles du bras. Symétrique en x. S'imprime couchée sur le dessus de l'aile horizontale."""
    s = unir([boite(-24, 24, TY, YS + MOTIF + 8, TZ1 - 8, TZ1), boite(-32, 32, TY, TY + EP_T, TZ1 - EP_H, TZ1)])
    for dx in (-MOTIF, MOTIF):
        for dy in (-MOTIF, MOTIF):
            s = s.cut(cyl(PASSAGE / 2, TZ1 - 9, TZ1 + 1, dx, YS + dy))       # épaule : vis par le dessus
    for x, z in EP_VIS:
        s = s.cut(cyl_y(PILOTE / 2, TY - 1, TY + EP_T + 1, x, z))
    s = s.cut(boite(-8, 8, TY - 1, TY + EP_T + 1, TZ1 - 22, TZ1 - 9))        # la fenêtre des câbles du bras
    return s.removeSplitter()


def antenne():
    z0 = UA0 + 80.0
    return unir([cyl(4.5, z0 - 4, z0 + 1.0), cyl(6.3, z0, z0 + 3.0), cyl(1.8, z0 + 3.0, z0 + 21), Part.makeSphere(3.9, V(0, 0, z0 + 23.5))])


# --- Le pied (repère du monde), fait autour de la base de l'étrier de la cheville --------------------------------------------
def pied(trous, cote):
    """Une semelle : la base de l'étrier de la cheville vissée par le dessus (4 trous, positions réelles) ; centrée sous la jambe."""
    cx = sum(p.x for p in trous) / 4
    cy = sum(p.y for p in trous) / 4
    # v2.2 : la semelle garde sa largeur de 64 mm, centrée un peu à l'extérieur de la jambe (au 08.11, son bord intérieur était à 2 mm du milieu)
    # v2.3 : le bord intérieur ramené de 24 à 16 mm de l'axe de la cheville (le bloc du motif), pour que les pieds ne butent pas (R-051)
    y_in, y_out = cy - cote * float(os.environ.get("N1_PIED_IN", "16")), cy + cote * 40      # R-051 : N1_PIED_IN pour un essai
    y0, y1 = min(y_in, y_out), max(y_in, y_out)
    print("PIED", cote, "centre y", round(cy, 1), "semelle de", round(y0, 1), "à", round(y1, 1))
    s = boite(cx - 52, cx + 70, y0, y1, 0, 6.5)
    s = s.makeFillet(10.0, [e for e in s.Edges if abs(e.BoundBox.ZMax - e.BoundBox.ZMin) > 6])
    s = s.cut(boite(cx - 42, cx + 60, y0 + 10, y1 - 10, 3.2, 7))                 # allègement (la semelle reste à 2,2 mm)
    s = s.fuse(boite(cx - 16, cx + 16, cy - 16, cy + 16, 0, 6.5))                    # le bloc du motif
    for p in trous:
        s = s.cut(cyl(PILOTE / 2, -1, 6, p.x, p.y))
    return s.removeSplitter()


def gabarit():
    """Le gabarit d'essai (version 2) : le haut du boîtier (la poche, 10 mm, et les trous pilotes de la bride) et le bout rond du bras A
    (les 4 trous du palonnier rond). Imprimer, essayer un vrai servo et son palonnier, ajuster les cotes en tête du fichier, puis imprimer le robot."""
    tranche = boitier().common(boite(BX0 - 1, BX1 + 1, -BY - 1, BY + 1, -10.0, 0.01))
    tranche.translate(V(0, 0, 10.0))
    bras = etrier().common(boite(-UY - 1, UY + 1, -UY - 1, UY + 1, UA0 - 0.01, UA0 + UA_T + 0.01))
    bras.translate(V(0, BY + UY + 4, -UA0))
    return tranche.fuse(bras).removeSplitter()


# =========================================================================================================================
# L'assemblage
# =========================================================================================================================
instances = []   # (nom, pièce, placement, couleur, groupe)


def poser(nom, piece, pl, couleur, groupe):
    instances.append((nom, piece, App.Placement(pl.toMatrix()), couleur, groupe))


def articulation(nom, pl_boitier, angle, groupe, piece_etrier="etrier"):
    """Un boîtier, son servo, le palonnier et l'étrier tourné de « angle » ; rend le placement de l'étrier."""
    poser(nom + "-boitier", "boitier-servo", pl_boitier, ORANGE, groupe)
    poser(nom + "-bride", "bride", pl_boitier, GRIS, groupe)
    poser(nom + "-servo", "servo-sts3215", pl_boitier, BLEU, groupe)
    poser(nom + "-fiches", "fiches", pl_boitier, NOIR, groupe)
    pl_u = pl_boitier.multiply(rot(V(0, 0, 1), angle))
    poser(nom + "-palonnier", "palonnier", pl_u, "#f2f2f2", groupe)
    poser(nom + "-etrier", piece_etrier, pl_u, GRIS, groupe)
    return pl_u


def enfant(pl_u, phi, rallonge_mm=0.0, nom=None, groupe=None, poser_rallonge=True):
    """Le boîtier suivant, vissé sur la base de l'étrier (tourné de phi autour de l'axe de la chaîne), après une rallonge.
    poser_rallonge=False (R-060) : le boîtier se pose au même endroit, sans la pièce rallonge (l'étrier long en tient lieu)."""
    if rallonge_mm and poser_rallonge:
        pl_r = pl_u.multiply(trans(UX0, 0, MOTIF_Z)).multiply(rot(V(1, 0, 0), phi)).multiply(trans(0, 0, -MOTIF_Z))
        poser(nom + "-rallonge", "rallonge", pl_r, GRIS, groupe)
    r = rot(V(1, 0, 0), phi)
    p_h = r.multVec(V(BX1, 0, MOTIF_Z))
    p_u = V(UX0 - rallonge_mm, 0, MOTIF_Z)
    return pl_u.multiply(trans(p_u.x - p_h.x, p_u.y - p_h.y, p_u.z - p_h.z)).multiply(r)


def jambe(cote):
    g = "jambe-gauche" if cote > 0 else "jambe-droite"
    # la hanche : le boîtier pend sous le torse, l'axe de la 1re articulation (roulis) le long de x, la face du motif en haut
    za = V(1, 0, 0)
    xa = V(0, 0, 1)
    ya = za.cross(xa)
    p_h = axes(xa, ya, za).multVec(V(BX1, 0, MOTIF_Z))
    pl = axes(xa, ya, za, V(0, cote * YH, TZ0) - p_h)
    u = articulation(g + "-hanche-roulis", pl, 0, g)
    u = articulation(g + "-hanche-tangage", enfant(u, 90 * cote), 0, g)
    u = articulation(g + "-genou", enfant(u, 0, LS, g + "-cuisse", g), 0, g, "etrier-genou" if GENOU_LONG else "etrier")
    u = articulation(g + "-cheville-tangage", enfant(u, 0, LS, g + "-tibia", g, poser_rallonge=not GENOU_LONG), 0, g)
    u = articulation(g + "-cheville-roulis", enfant(u, 90 * cote), 0, g)
    trous = [u.multVec(V(UX0, dy, MOTIF_Z + dz)) for dy in (-MOTIF, MOTIF) for dz in (-MOTIF, MOTIF)]
    return trous, g


def bras(cote):
    g = "bras-gauche" if cote > 0 else "bras-droit"
    za = V(0, cote, 0)
    xa = V(0, 0, 1)
    ya = za.cross(xa)
    p_h = axes(xa, ya, za).multVec(V(BX1, 0, MOTIF_Z))
    pl = axes(xa, ya, za, V(0, cote * YS, TZ1 - 8) - p_h)
    u = articulation(g + "-epaule-tangage", pl, 0, g)
    u = articulation(g + "-epaule-roulis", enfant(u, 90 * cote), 0, g)
    u = articulation(g + "-coude", enfant(u, 90 * cote, LS, g + "-bras", g), 0, g)
    poser(g + "-main", "main", u.multiply(trans(UX0, 0, 0)), ORANGE, g)


def construire():
    # les jambes d'abord : le sol est sous les semelles
    sols = []
    for cote in (1, -1):
        sols.append(jambe(cote))
    z_sol = min(p.z for trous, _ in sols for p in trous) - 6.5
    for trous, g in sols:
        cote = 1 if trous[0].y > 0 else -1
        poser(g + "-pied", "pied-gauche" if cote > 0 else "pied-droit", App.Placement(), ORANGE, g)
        PIEDS[cote] = trous
    for cote in (1, -1):
        bras(cote)
    poser("torse", "torse", App.Placement(), ORANGE, "torse")
    poser("epaulette-gauche", "epaulette", App.Placement(), GRIS, "torse")
    poser("epaulette-droite", "epaulette", rot(V(0, 0, 1), 180), GRIS, "torse")
    poser("dos", "dos", App.Placement(), GRIS, "torse")
    poser("support-cou", "support-cou", App.Placement(), GRIS, "torse")
    # le cou : le servo debout dans le toit, l'arbre vers le haut, le corps vers l'arrière
    pl_cou = axes(V(-1, 0, 0), V(0, -1, 0), V(0, 0, 1), V(XN, 0, TZ1))      # version 2 : le dessus du servo au ras du toit
    poser("cou-boitier", "boitier-servo", pl_cou, ORANGE, "tete")
    poser("cou-bride", "bride", pl_cou, GRIS, "tete")
    poser("cou-servo", "servo-sts3215", pl_cou, BLEU, "tete")
    poser("cou-fiches", "fiches", pl_cou, NOIR, "tete")
    poser("cou-palonnier", "palonnier", pl_cou, "#f2f2f2", "tete")
    poser("tete", "tete", pl_cou, ORANGE, "tete")
    poser("visiere", "visiere", pl_cou, GRIS, "tete")
    poser("antenne", "antenne", pl_cou, GRIS, "tete")
    return z_sol


PIEDS = {}
z_sol = construire()

PIECES = {
    "boitier-servo": boitier(), "etrier": etrier(), "rallonge": rallonge(), "main": main_piece(), "torse": torse(), "dos": dos(),
    "tete": tete(), "visiere": visiere(), "antenne": antenne(), "servo-sts3215": servo_modele(), "palonnier": palonnier_modele(),
    "gabarit-essai": gabarit(), "bride": bride(), "fiches": fiches_modele(), "support-cou": support_cou(), "epaulette": epaulette(),
}
if GENOU_LONG:
    PIECES["etrier-genou"] = etrier(LS)
# les pieds dans le repère du monde, ramenés au sol (z = 0 sous la semelle)
for cote, nom in ((1, "pied-gauche"), (-1, "pied-droit")):
    PIECES[nom] = pied(PIEDS[cote], cote)
# tout le robot remonte de -z_sol : le sol à z = 0
for i, (n, p, pl, col, g) in enumerate(instances):
    if not p.startswith("pied"):
        instances[i] = (n, p, trans(0, 0, -z_sol).multiply(pl), col, g)
    else:
        instances[i] = (n, p, App.Placement(), col, g)

IMPRIMEES = ["boitier-servo", "bride", "support-cou", "etrier", "rallonge", "torse", "epaulette", "dos", "tete", "visiere", "antenne", "pied-gauche", "pied-droit", "main", "gabarit-essai"] + (["etrier-genou"] if GENOU_LONG else [])
# orientation d'impression (appliquée avant de poser la pièce à plat au centre du plateau)
ORIENT = {
    "boitier-servo": App.Placement(), "bride": App.Placement(), "support-cou": rot(V(0, 1, 0), -90), "etrier": rot(V(0, 1, 0), -90), "etrier-genou": rot(V(0, 1, 0), -90), "rallonge": rot(V(0, 1, 0), -90), "torse": rot(V(0, 1, 0), 90),
    "epaulette": rot(V(1, 0, 0), 180), "dos": rot(V(0, 1, 0), -90), "tete": App.Placement(), "visiere": rot(V(0, 1, 0), 90), "antenne": App.Placement(),
    "pied-gauche": App.Placement(), "pied-droit": App.Placement(), "main": rot(V(1, 0, 0), 90), "gabarit-essai": App.Placement(),
}
PLATEAU = float(os.environ.get("N1_PLATEAU", "220"))   # (N1_PLATEAU pour éprouver le contrôle) le plateau de l'Ender-3 V3 SE (220 x 220, 250 de haut)
QUANTITE = {}
for _, p, _, _, _ in instances:
    QUANTITE[p] = QUANTITE.get(p, 0) + 1
QUANTITE["gabarit-essai"] = 1


def maillage(forme, chemin):
    m = MeshPart.meshFromShape(Shape=forme, LinearDeflection=0.04, AngularDeflection=0.3, Relative=False)
    m.write(chemin)
    return m.CountFacets


# --- Les appuis (R-051 § 6, ERREURS E22) : chaque vis M3 qui tient une jambe ou un bras tombe dans la matière des deux pièces qu'elle joint ----
# Le contrôle des collisions ne voit pas une pièce qui pend dans le vide : on vérifie que le tour de chaque trou est plein (4 points à 1,2 mm du bord).
_ep_d = PIECES["epaulette"].copy()
_ep_d.Placement = rot(V(0, 0, 1), 180)
EPAULETTES = {1: PIECES["epaulette"], -1: _ep_d}


def plein(forme, c, axe, r=PASSAGE / 2 + 1.2):
    n = 0
    for a in "xyz":
        if a == axe:
            continue
        for s in (1, -1):
            p = V(c.x, c.y, c.z)
            setattr(p, a, getattr(p, a) + s * r)
            n += forme.isInside(p, 0.01, True)
    return n


APPUIS = []
for sy in (1, -1):
    for dx in (-MOTIF, MOTIF):
        for dy in (-MOTIF, MOTIF):
            APPUIS.append(("hanche dans le torse", sy, plein(PIECES["torse"], V(dx, sy * YH + dy, TZ0 + 1.5), "z")))
            APPUIS.append(("épaule dans l'épaulette", sy, plein(EPAULETTES[sy], V(dx, sy * YS + dy, TZ1 - 4.0), "z")))
    for x, z in EP_VIS:
        APPUIS.append(("épaulette dans le flanc du torse", sy, plein(PIECES["torse"], V(sy * x, sy * (TY - TP / 2), z), "y")))
        APPUIS.append(("flanc du torse dans l'épaulette", sy, plein(EPAULETTES[sy], V(sy * x, sy * (TY + EP_T / 2), z), "y")))
for quoi, sy, n in APPUIS:
    if n < 4:
        print("APPUI MANQUANT", quoi, "côté", sy, ":", n, "points pleins sur 4")
APPUIS_PLEINS = sum(n == 4 for _, _, n in APPUIS)
print("APPUIS :", APPUIS_PLEINS, "vis sur", len(APPUIS), "dans la matière ; le boîtier de hanche dépasse du torse de", round(YH + BY - TY, 1), "mm")

# --- La visserie (ERREURS E24) : la longueur de chaque vis de structure vient des épaisseurs qu'elle traverse ----------------------------------
# La prise (la longueur filetée dans le trou pilote de la pièce qui reçoit) : au moins 4 mm si possible, sinon 3, jamais plus que la profondeur du
# trou pilote (le motif du boîtier : BOUT − 0,5 = 4,5 mm). Les vis du servo (bride, palonnier, disque du bas) suivent R-049 : elles ne dépendent
# que du servo et de l'étrier. Écrit dans assemblage.json ; la page la lit.
LONGUEURS_M3 = (6, 8, 10, 12, 14, 16, 20, 25, 30)
PILOTE_BOITIER = BOUT - 0.5


def nombre_mm(x):
    return f"{x:g}".replace(".", ",")


def longueur_m3(traverse, prise_max):
    for prise_min in (4.0, 3.0):
        for L in LONGUEURS_M3:
            if prise_min <= L - traverse <= prise_max:
                return L
    raise ValueError(f"aucune vis M3 pour {traverse} mm traversés et {prise_max} mm de prise")


_nb = lambda piece: sum(1 for i in instances if i[1] == piece)
_fixes = 2 + _nb("epaulette") + 1              # les boîtiers vissés sur une pièce fixe : deux hanches (torse), deux épaules (épaulettes), le cou
LIAISONS = [  # (où, motifs, vis par motif, mm traversés, prise maximale)
    ("étrier sur le boîtier suivant", _nb("boitier-servo") - _nb("rallonge") - _fixes, 4, UX1 - UX0, PILOTE_BOITIER),
    ("étrier, rallonge, boîtier suivant", _nb("rallonge"), 4, UX1 - UX0 + LS, PILOTE_BOITIER),
    ("étrier sous le pied", _nb("pied-gauche") + _nb("pied-droit"), 4, UX1 - UX0, 6.5),
    ("étrier sur la main", _nb("main"), 4, UX1 - UX0, 12.0),
    ("hanche sous le plancher du torse", 2, 4, 3.0, PILOTE_BOITIER),
    ("épaule sous l'épaulette", _nb("epaulette"), 4, 8.0, PILOTE_BOITIER),
    ("cou sur son support", 1, 4, SC_X1 - SC_X0, PILOTE_BOITIER),
    ("épaulette sur le flanc du torse", _nb("epaulette"), 4, TP, EP_T),
    ("support du cou sous le toit", 1, 4, 3.0, 6.0),
    ("dos sur le torse", 1, 4, 2.4, 6.0),
]
VISSERIE = {}
for ou, n, par, traverse, prise_max in LIAISONS:
    L = longueur_m3(traverse, prise_max)
    v = VISSERIE.setdefault(f"M3 x {L}", {"nombre": 0, "ou": []})
    v["nombre"] += n * par
    v["ou"].append(f"{ou} ({n} x {par} ; {nombre_mm(traverse)} mm traversés, {nombre_mm(L - traverse)} de prise)")
_etriers = _nb("etrier") + _nb("etrier-genou")
for nom_v, n, ou in (("M2 x 8", 4 * _nb("boitier-servo"), "les brides (R-049)"), ("M3 x 6", 4 * (_etriers + 1), "les palonniers : bras A des étriers et la tête (R-049 ; souvent fournies)"),
                     ("M3 x 10", 4 * _etriers, "les disques du bas : bras B des étriers (R-049)"), ("M2 x 6", 4, "le Pico sur ses entretoises (R-049)")):
    v = VISSERIE.setdefault(nom_v, {"nombre": 0, "ou": []})
    v["nombre"] += n
    v["ou"].append(ou)
for nom_v, v in sorted(VISSERIE.items()):
    print("VIS", nom_v, v["nombre"], ";", " ; ".join(v["ou"]))

for d in ("stl-impression", "step", "web"):
    os.makedirs(os.path.join(OUT, d), exist_ok=True)
resume = []
for nom, forme in PIECES.items():
    assert forme.isValid(), nom
    forme.exportStep(os.path.join(OUT, "step", nom + ".step"))
    maillage(forme, os.path.join(OUT, "web", nom + ".stl"))
    if nom in IMPRIMEES:
        f = forme.copy()
        f.Placement = ORIENT[nom].multiply(f.Placement)
        f = f.copy()
        bb = f.BoundBox
        f.translate(V(-(bb.XMin + bb.XMax) / 2, -(bb.YMin + bb.YMax) / 2, -bb.ZMin))
        bb = f.BoundBox
        maillage(f, os.path.join(OUT, "stl-impression", nom + ".stl"))
        # le plateau (ERREURS E23) : l'empreinte de la pièce, tournée au degré près, doit tenir dans 220 x 220 moins 5 mm de marge
        pts = [(p.x, p.y) for p in f.tessellate(1.0)[0]]
        cote_min, angle = min((max(max(x * math.cos(a) - y * math.sin(a) for x, y in pts) - min(x * math.cos(a) - y * math.sin(a) for x, y in pts),
                                   max(x * math.sin(a) + y * math.cos(a) for x, y in pts) - min(x * math.sin(a) + y * math.cos(a) for x, y in pts)), k)
                              for k in range(0, 90) for a in (math.radians(k),))
        if cote_min > PLATEAU - 10 or bb.ZLength > 250:
            print("PLATEAU : NE TIENT PAS", nom, round(cote_min, 1), "mm au mieux, hauteur", round(bb.ZLength, 1))
        resume.append({"piece": nom, "quantite": QUANTITE.get(nom, 1), "x": round(bb.XLength, 1), "y": round(bb.YLength, 1),
                       "z": round(bb.ZLength, 1), "volume_cm3": round(forme.Volume / 1000, 2),
                       "plateau": {"cote_min_mm": round(cote_min, 1), "angle_deg": angle, "tient": cote_min <= PLATEAU - 10 and bb.ZLength <= 250}})
print("PLATEAU :", sum(r["plateau"]["tient"] for r in resume), "pièces imprimées sur", len(resume), "tiennent sur", PLATEAU, "x", PLATEAU, "mm (5 mm de marge)")

# l'assemblage complet en STEP et le JSON pour la page
tout = []
for n, p, pl, col, g in instances:
    f = PIECES[p].copy()
    f.Placement = pl.multiply(f.Placement)
    tout.append(f)
Part.makeCompound(tout).exportStep(os.path.join(OUT, "step", "n1-assemblage.step"))
bb = Part.makeCompound(tout).BoundBox
json.dump({
    "robot": "Navitek N1", "date": "2026-11-08", "unites": "mm",
    "encombrement": [round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1)],
    "instances": [{"nom": n, "piece": p, "couleur": col, "groupe": g, "imprimee": p in IMPRIMEES,
                   "matrice": [round(v, 5) for v in pl.toMatrix().A]} for n, p, pl, col, g in instances],
    "pieces": resume,
    "version": "2.4" if GENOU_LONG else "2.3", "appuis": {"vis_dans_la_matiere": APPUIS_PLEINS, "vis": len(APPUIS)}, "visserie": VISSERIE,
}, open(os.path.join(OUT, "web", "assemblage.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print("ENCOMBREMENT", round(bb.XLength, 1), round(bb.YLength, 1), round(bb.ZLength, 1), "mm ;", len(instances), "instances")
for r in resume:
    print("PIECE", r)


# --- Contrôle des collisions (N0_COLLISIONS=1) ------------------------------------------------------------------------------
# Le servo et son palonnier sont DANS leur boîtier et leur étrier : on n'y cherche pas de collision. Tout le reste doit être libre.
if os.environ.get("N0_COLLISIONS"):
    formes = []
    for (n, p, pl, col, g), f in zip(instances, tout):
        formes.append((n, p, f))
    attendu = lambda a, b: a.rsplit("-", 1)[0] == b.rsplit("-", 1)[0] and {a.rsplit("-", 1)[1], b.rsplit("-", 1)[1]} & {"servo", "palonnier"}
    vus = 0
    for i in range(len(formes)):
        for j in range(i + 1, len(formes)):
            (na, pa, fa), (nb, pb, fb) = formes[i], formes[j]
            if attendu(na, nb) or not fa.BoundBox.intersect(fb.BoundBox):
                continue
            vus += 1
            v = fa.common(fb).Volume
            if v > 0.5:
                print("COLLISION", na, "x", nb, round(v, 1), "mm3")
    print("COLLISIONS : paires examinées", vus)
