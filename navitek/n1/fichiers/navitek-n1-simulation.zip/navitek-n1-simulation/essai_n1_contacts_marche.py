"""B40 / R-048 § 5 : les marches de N1 se heurtent-elles ? Chaque marche publiée est rejouée telle quelle (la boucle de essai_n1_marche.py,
contacts entre pièces coupés comme dans le réglage), et toutes les 50 ms la pose est passée à FCL sur les maillages EXACTS (comme essai_n1_t4.py) :
on compte les paires de pièces de corps différents qui se touchent, hors celles déjà en contact au neutre (les pièces vissées ensemble).

    python -X utf8 essai_n1_contacts_marche.py        → resultats/n1-contacts-marche.json
    python -X utf8 essai_n1_contacts_marche.py sans-glisser        → seulement les marches dont le nom contient « sans-glisser »,
                                                                     resultats/n1-contacts-marche-sans-glisser.json
(09.11 : la boucle de essai_n1_marche.py règle désormais avec les contacts entre jambes et bras allumés ; le contrôle reste sur les maillages exacts.)
"""
import json
import os

import mujoco
import numpy as np
import trimesh
from trimesh.collision import CollisionManager

import commun as C
import essai_n1_marche as em

MARCHES = [("n1-marche-g%d.json" % g, False) for g in (1, 2, 3)] + [("n1-marche-aveugle-g%d.json" % g, True) for g in (1, 2, 3)] + \
          [("n1-marche-robuste-g%d.json" % g, False) for g in (1, 2)] + [("n1-marche-robuste-plafond60-g%d.json" % g, False) for g in (1, 2)] +           [("n1-marche-sans-glisser-g%d.json" % g, False) for g in (1, 2, 3)] + [("n1-marche-robuste-sans-glisser-g%d.json" % g, False) for g in (1, 2)] +           [(os.path.basename(f), False) for f in sorted(__import__("glob").glob(os.path.join(os.path.dirname(os.path.abspath(__file__)), "resultats", "n1-marche-*sans-glisser-droit*-g[0-9].json")))]


MARCHES += [("n1-marche-quasi-statique.json", False)]                  # R-055 (la marche quasi statique, essai_n1_pas.py)


def gestionnaire(m):
    mgr, noms, corps = CollisionManager(), {}, {}
    for g in range(m.ngeom):
        if m.geom_type[g] != mujoco.mjtGeom.mjGEOM_MESH:
            continue
        nom = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, g)
        mid = m.geom_dataid[g]
        v0, nv, f0, nf = m.mesh_vertadr[mid], m.mesh_vertnum[mid], m.mesh_faceadr[mid], m.mesh_facenum[mid]
        mgr.add_object(nom, trimesh.Trimesh(vertices=m.mesh_vert[v0:v0 + nv].copy(), faces=m.mesh_face[f0:f0 + nf].copy(), process=False))
        noms[nom], corps[nom] = g, m.geom_bodyid[g]
    return mgr, noms, corps


def paires(m, d, mgr, noms, corps):
    for nom, g in noms.items():
        T = np.eye(4)
        T[:3, :3] = d.geom_xmat[g].reshape(3, 3)
        T[:3, 3] = d.geom_xpos[g]
        mgr.set_transform(nom, T)
    _, ps = mgr.in_collision_internal(return_names=True)
    return {tuple(sorted(p)) for p in ps if corps[p[0]] != corps[p[1]]}


def main():
    import sys
    global MARCHES
    sortie_json = "n1-contacts-marche.json"
    if len(sys.argv) > 1:                                 # seulement les marches dont le nom contient un des arguments ; un fichier de sortie à part
        MARCHES = [(f, a) for f, a in MARCHES if any(x in f for x in sys.argv[1:])]
        sortie_json = f"n1-contacts-marche-{sys.argv[1].replace('.json', '')}.json"
    MARCHES = [(f, a) for f, a in MARCHES if os.path.exists(os.path.join(C.ICI, "resultats", f))]
    em.init()
    m, d = em._m, em._d
    mgr, noms, corps = gestionnaire(m)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    neutre = paires(m, d, mgr, noms, corps)
    f0 = m.actuator_forcerange.copy()
    sortie = []
    for f, aveugle in MARCHES:
        r = json.load(open(os.path.join(C.ICI, "resultats", f), encoding="utf-8"))
        p = np.array(r["parametres_liste"])
        em.SANS_RETOUR = aveugle
        if r.get("famille") == "quasi-statique":                  # R-055 : la marche quasi statique (essai_n1_pas.py)
            import essai_n1_pas
            pose = essai_n1_pas.pose_pas
        else:
            pose = em.pose_marche
        m.actuator_forcerange[:] = f0 * (0.6 if "plafond60" in f else 1.0)
        mujoco.mj_resetData(m, d)
        mujoco.mj_forward(m, d)
        n, pas_pose, cadre = int(em.DUREE / m.opt.timestep), int(0.01 / m.opt.timestep), int(0.05 / m.opt.timestep)
        c = np.zeros(m.nu)
        vus, instants = {}, 0
        for k in range(n):
            t = k * m.opt.timestep
            if k % pas_pose == 0:
                c = C.consigne(m, pose(p, t, em.attitude(d)), em._sg)
            d.ctrl[:] = c
            mujoco.mj_step(m, d)
            if k % cadre == 0:
                nouveau = paires(m, d, mgr, noms, corps) - neutre
                if nouveau:
                    instants += 1
                for q in nouveau:
                    vus[" ~ ".join(q)] = vus.get(" ~ ".join(q), 0) + 1
        tot = int(n / cadre)
        sortie.append({"marche": f, "instants_en_contact": instants, "sur": tot, "paires": dict(sorted(vus.items(), key=lambda x: -x[1]))})
        print(f"{f:<38} en contact {instants:3d} instants sur {tot} ; {list(sortie[-1]['paires'].items())[:3]}", flush=True)
    json.dump({"essai": "R-048 § 5 : contacts entre pièces (maillages exacts) pendant les marches publiées de N1", "paires_au_neutre": len(neutre),
               "marches": sortie}, open(os.path.join(C.ICI, "resultats", sortie_json), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
