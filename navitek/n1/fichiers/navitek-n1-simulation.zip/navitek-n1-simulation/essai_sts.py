"""L'épreuve du programme de N1 (B40, cahier R-048) : navitek-n1/firmware/sts.py et main.py, tels qu'ils iront sur le Pico, contre un bus
simulé qui parle le protocole des STS3215 octet par octet, et dont les 17 servos sont ceux du modèle MuJoCo de N1 (n1.xml), robot suspendu.

1. Le protocole : l'exemple de Waveshare (lire la position du servo 1 : FF FF 01 04 02 38 02 BE ; réponse FF FF 01 04 00 18 05 DD → 1304),
   l'écho du fil unique, une somme fausse refusée, un servo absent, l'écriture synchronisée.
2. L'auto-étalonnage (main.calibrer) sur les 17 articulations : les butées trouvées contre les limites des articulations du modèle (jnt_range).
3. Le couple plafonné (registre 48) et le bouton d'arrêt (couple coupé).

    python -X utf8 essai_sts.py        → resultats/n1-programme.json
"""
import json
import os
import sys

import mujoco
import numpy as np

import commun as C

ICI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(ICI, "..", "navitek-n1", "firmware"))
import sts  # noqa: E402
import main as PROG  # noqa: E402

RES = []


def verdict(nom, ok, detail=""):
    RES.append({"epreuve": nom, "ok": bool(ok), "detail": detail})
    print(f"{'OK   ' if ok else 'ÉCHEC'} {nom}{' : ' + detail if detail else ''}")


class N1Bus:
    """Le fil du bus : ce que le Pico écrit revient en écho, puis chaque servo répond à sa trame. Les servos sont les actionneurs de
    n1.xml (robot suspendu, torse tenu)."""

    def __init__(self, echo=True, absents=()):
        self.m, self.d = C.charger("n1.xml")
        mujoco.mj_resetData(self.m, self.d)
        self.d.qpos[2] += 0.5
        mujoco.mj_forward(self.m, self.d)
        self.q0 = self.d.qpos[:7].copy()
        self.noms = C.noms(self.m)
        self.par_id = {PROG.IDS[n]: self.noms.index(n) for n in PROG.NOMS}
        self.f0 = self.m.actuator_forcerange.copy()
        self.gain = self.m.actuator_gainprm.copy()
        self.biais = self.m.actuator_biasprm.copy()
        # 09.11 (ERREURS E29) : un servo monté retourné (le côté droit des tangages) tourne l'articulation à l'envers de ses pas. Le modèle le dit
        # par l'axe local de l'articulation (« 0 0 −1 », modele_n1.sens_miroir) ; le fil le reproduit, sans rien lire du programme.
        self.montage = {i: (-1 if self.m.jnt_axis[self.m.actuator_trnid[a, 0]][2] < 0 else 1) for i, a in self.par_id.items()}
        self.couple_actif = {i: 0 for i in self.par_id}
        self.limite = {i: 1000 for i in self.par_id}
        self.echo, self.absents = echo, set(absents)
        self.entree = b""
        self.trames = 0
        for i in self.par_id:
            self._appliquer(i)

    # --- la physique ---------------------------------------------------------------------------------------------------------
    def _appliquer(self, ident):
        a = self.par_id[ident]
        if self.couple_actif[ident]:
            self.m.actuator_gainprm[a] = self.gain[a]
            self.m.actuator_biasprm[a] = self.biais[a]
        else:
            self.m.actuator_gainprm[a] = 0
            self.m.actuator_biasprm[a] = 0
        self.m.actuator_forcerange[a] = self.f0[a] * self.limite[ident] / 1000.0

    def dormir(self, ms):
        for _ in range(int(ms / 1000 / self.m.opt.timestep)):
            mujoco.mj_step(self.m, self.d)
            self.d.qpos[:7] = self.q0
            self.d.qvel[:6] = 0

    def _registre(self, ident, adr):
        a = self.par_id[ident]
        j = self.m.actuator_trnid[a, 0]
        if adr == 56:
            return int(round(2048 + self.montage[ident] * self.d.qpos[self.m.jnt_qposadr[j]] * 4096 / (2 * np.pi))) & 0xFFFF
        if adr == 60:
            v = int(round(self.montage[ident] * self.d.actuator_force[a] / self.f0[a, 1] * 1000))
            return (abs(v) & 0x3FF) | (0x400 if v < 0 else 0)
        if adr == 62:
            return 120
        if adr == 63:
            return 30
        if adr == 48:
            return self.limite[ident]
        if adr == 40:
            return self.couple_actif[ident]
        return 0

    def _ecrire(self, ident, adr, octets):
        a = self.par_id[ident]
        v = octets[0] | (octets[1] << 8 if len(octets) > 1 else 0)
        if adr == 42:
            pas = -(v & 0x7FFF) if v & 0x8000 else v
            self.d.ctrl[a] = self.montage[ident] * (pas - 2048) * 2 * np.pi / 4096
        elif adr == 40:
            self.couple_actif[ident] = v
            self._appliquer(ident)
        elif adr == 48:
            self.limite[ident] = v
            self._appliquer(ident)

    # --- le fil ---------------------------------------------------------------------------------------------------------------
    def write(self, data):
        self.trames += 1
        if self.echo:
            self.entree += bytes(data)
        d = list(data)
        assert d[0] == 0xFF and d[1] == 0xFF
        ident, longueur, instr = d[2], d[3], d[4]
        params = d[5:5 + longueur - 2]
        if sts.somme(d[2:5 + longueur - 2]) != d[5 + longueur - 2]:
            return len(data)                                     # un servo ignore une trame à la somme fausse
        if instr == sts.SYNC_WRITE:
            adr, n = params[0], params[1]
            for k in range(2, len(params), n + 1):
                if params[k] in self.par_id:
                    self._ecrire(params[k], adr, params[k + 1:k + 1 + n])
            return len(data)
        if ident not in self.par_id or ident in self.absents:
            return len(data)
        rep = []
        if instr == sts.READ:
            adr, n = params
            v = self._registre(ident, adr)
            rep = [v & 0xFF] if n == 1 else [v & 0xFF, (v >> 8) & 0xFF]
        elif instr == sts.WRITE:
            self._ecrire(ident, params[0], params[1:])
        corps = [ident, len(rep) + 2, 0] + rep
        self.entree += bytes([0xFF, 0xFF] + corps + [sts.somme(corps)])
        return len(data)

    def any(self):
        return len(self.entree)

    def read(self, n):
        out, self.entree = self.entree[:n], self.entree[n:]
        return out


def horloge():
    t = [0]

    def tic():
        t[0] += 1
        return t[0]
    return tic, (lambda a, b: a - b)


class FilExemple:
    """Le fil de l'exemple de Waveshare : la réponse fixe FF FF 01 04 00 18 05 DD, sans écho."""

    def __init__(self, reponse):
        self.ecrit, self.entree, self.reponse = b"", b"", bytes(reponse)

    def write(self, d):
        self.ecrit += bytes(d)
        self.entree += self.reponse                     # la réponse arrive après la demande (le pilote vide le fil avant d'écrire)
        return len(d)

    def any(self):
        return len(self.entree)

    def read(self, n):
        out, self.entree = self.entree[:n], self.entree[n:]
        return out


def main():
    # 1. le protocole
    verdict("trame de l'exemple Waveshare", sts.trame(1, sts.READ, (0x38, 2)) == bytes.fromhex("FFFF0104023802BE"))
    f = FilExemple(bytes.fromhex("FFFF0104001805DD"))
    b = sts.Bus(f, horloge=horloge(), echo=False)
    v = b.lire(1, "position")
    verdict("réponse de l'exemple Waveshare → 1304", v == 1304 and f.ecrit == bytes.fromhex("FFFF0104023802BE"), str(v))
    f = FilExemple(bytes.fromhex("FFFF0104001805DE"))
    try:
        sts.Bus(f, horloge=horloge(), echo=False).lire(1, "position")
        verdict("somme fausse refusée", False)
    except sts.ErreurBus:
        verdict("somme fausse refusée", True)
    fil = N1Bus(echo=True, absents=(17,))
    bus = sts.Bus(fil, horloge=horloge())
    verdict("ping avec l'écho du fil unique", bus.ping(1) and bus.ping(16))
    verdict("servo absent : ping faux, sans blocage", bus.ping(17) is False)
    verdict("signes : bit 15 et bit 10", sts.signe15(0x8000 | 100) == -100 and sts.signe10(0x400 | 37) == -37)

    # 2. l'auto-étalonnage, sur le modèle entier
    fil = N1Bus(echo=True)
    bus = sts.Bus(fil, horloge=horloge())
    res = PROG.calibrer(bus, fil.dormir)
    lignes, pires = [], []
    for nom in PROG.NOMS:
        a = fil.noms.index(nom)
        j = fil.m.actuator_trnid[a, 0]
        lo, hi = np.degrees(fil.m.jnt_range[j])
        r = res[nom]
        e = max(abs(r["butee_min_deg"] - lo), abs(r["butee_max_deg"] - min(hi, PROG.MAX_DEG)))
        pires.append(e)
        lignes.append({"articulation": nom, "trouve": [r["butee_min_deg"], r["butee_max_deg"]], "modele": [round(lo, 1), round(hi, 1)], "ecart_deg": round(e, 1)})
        print(f"   {nom:<30} trouvé {r['butee_min_deg']:+7.1f} à {r['butee_max_deg']:+7.1f}   modèle {lo:+7.1f} à {hi:+7.1f}   écart {e:.1f}°")
    n_bons = sum(e <= 3.0 for e in pires)
    verdict("auto-étalonnage : butées à 3° près des limites du modèle", n_bons == len(pires), f"{n_bons} sur {len(pires)}, pire écart {max(pires):.1f}°")
    verdict("couple remis à 60 % après l'étalonnage", all(v == PROG.COUPLE_LIMITE for v in fil.limite.values()))

    # 2 bis. (09.11, E29) l'accroupi de la démo plie les deux genoux dans le même sens, de l'angle demandé (le servo droit est retourné)
    bornes = PROG.bornes_depuis(res)
    acc = {}
    for cote in ("gauche", "droite"):
        acc.update({"jambe-%s-hanche-tangage" % cote: -30, "jambe-%s-genou" % cote: 60, "jambe-%s-cheville-tangage" % cote: -30})
    PROG.poser(bus, acc, bornes, 1500, fil.dormir)
    fil.dormir(500)
    gen = {c: float(np.degrees(fil.d.qpos[fil.m.jnt_qposadr[fil.m.actuator_trnid[fil.noms.index("jambe-%s-genou" % c), 0]]])) for c in ("gauche", "droite")}
    verdict("démo : l'accroupi plie les deux genoux dans le même sens", min(gen.values()) > 50 and abs(gen["gauche"] - gen["droite"]) < 3,
            f"genou gauche {gen['gauche']:.1f}°, droit {gen['droite']:.1f}° (geste du modèle ; 60 demandés)")

    # 3. l'arrêt : couple coupé pour tous
    PROG.tous_couple(bus, False)
    fil.dormir(200)
    verdict("arrêt : couple coupé pour les 17", all(v == 0 for v in fil.couple_actif.values()))
    json.dump({"essai": "B40 / R-048 : le programme de N1 contre des servos simulés", "epreuves": RES, "etalonnage": lignes, "trames": fil.trames},
              open(os.path.join(ICI, "resultats", "n1-programme.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(sum(r["ok"] for r in RES), "sur", len(RES), "épreuves réussies")


if __name__ == "__main__":
    main()
