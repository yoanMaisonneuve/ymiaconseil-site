"""Essai N1-T5b : une marche de N1 réglée pour tenir sur PLUSIEURS modèles à la fois (R-038 : la marche réglée sur le seul modèle nominal tombe à ±50 % d'un
paramètre). Même marche à 15 paramètres qu'essai_n1_marche.py ; l'aptitude d'un candidat est celle de son PIRE modèle parmi huit : le nominal, et sept
variantes (masse de l'électronique ×1,4, frottement ×0,6 et ×1,4, inertie du rotor ×1,4, amortissement ×0,6, couple de blocage ×0,7, raideur ×0,7).
La validation se fait ensuite avec essai_n1_t6.py (±50 %, plus large que l'entraînement : un candidat robuste doit généraliser).

    python -X utf8 essai_n1_marche_robuste.py --graine 1 --generations 40 --population 28 --processus 7 --video
--sans-glisser (B42, R-050) : la même aptitude que essai_n1_marche.py --sans-glisser, sur le pire des huit modèles.
"""
import argparse
import json
import multiprocessing as mp
import os

import mujoco
import numpy as np

import commun as C
import essai_n1_marche as M

VARIANTES = [("nominal", 1.0), ("masse_electronique", 1.4), ("frottement_sol", 0.6), ("frottement_sol", 1.4), ("armature", 1.4),
             ("amortissement", 0.6), ("couple_blocage", 0.7), ("kp", 0.7)]
MASSE_ELEC = 0.330
_ref = {}
PLAF = 1.0


def init(plaf=1.0, sans_glisser=False, droit=False):
    global PLAF
    PLAF = plaf
    M.SANS_GLISSER, M.DROIT = sans_glisser, droit
    M.init()
    m = M._m
    if plaf != 1.0:
        m.actuator_forcerange[:] *= plaf          # tous les servos plafonnés à une part du couple de blocage (marge de sécurité)
    _ref.update({"armature": m.dof_armature.copy(), "damping": m.dof_damping.copy(), "friction": m.geom_friction.copy(),
                 "forcerange": m.actuator_forcerange.copy(), "kp": m.actuator_gainprm.copy(), "bias": m.actuator_biasprm.copy(),
                 "masse": m.body_mass.copy(), "inertie": m.body_inertia.copy()})


def varier(nom, f):
    m = M._m
    m.dof_armature[:] = _ref["armature"]
    m.dof_damping[:] = _ref["damping"]
    m.geom_friction[:] = _ref["friction"]
    m.actuator_forcerange[:] = _ref["forcerange"]
    m.actuator_gainprm[:] = _ref["kp"]
    m.actuator_biasprm[:] = _ref["bias"]
    m.body_mass[:] = _ref["masse"]
    m.body_inertia[:] = _ref["inertie"]
    if nom == "armature":
        m.dof_armature[:] *= f
    elif nom == "amortissement":
        m.dof_damping[:] *= f
    elif nom == "frottement_sol":
        m.geom_friction[:, 0] *= f
    elif nom == "couple_blocage":
        m.actuator_forcerange[:] *= f
    elif nom == "masse_electronique":
        dm = MASSE_ELEC * (f - 1)
        m.body_inertia[1] *= (_ref["masse"][1] + dm) / _ref["masse"][1]
        m.body_mass[1] += dm
    elif nom == "kp":
        m.actuator_gainprm[:, 0] *= f
        m.actuator_biasprm[:, 1] *= f


def pire(p):
    vals = []
    for nom, f in VARIANTES:
        varier(nom, f)
        vals.append(M.evaluer(p))
        if vals[-1] > 0:        # une chute : inutile de poursuivre, ce candidat est déjà mauvais
            break
    varier("nominal", 1.0)
    return max(vals)


def f(u):
    return pire(M.BAS + np.clip(u, 0, 1) * (M.HAUT - M.BAS))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--graine", type=int, default=1)
    ap.add_argument("--generations", type=int, default=40)
    ap.add_argument("--population", type=int, default=28)
    ap.add_argument("--processus", type=int, default=7)
    ap.add_argument("--depart", help="JSON d'une marche de départ (la moyenne initiale de CMA-ES)")
    ap.add_argument("--video", action="store_true")
    ap.add_argument("--plafond", type=float, default=1.0, help="part du couple de blocage permise (0,6 = 60 %%)")
    ap.add_argument("--sans-glisser", action="store_true", help="aptitude qui paie le glissement des pieds (R-050)")
    ap.add_argument("--droit", action="store_true", help="avec --sans-glisser : paie aussi le lacet (R-050 § 4.4)")
    a = ap.parse_args()
    init(a.plafond, a.sans_glisser, a.droit)
    from cmaes import CMA
    if a.depart:
        p0 = np.array(json.load(open(a.depart, encoding="utf-8"))["parametres_liste"])
        mean, sigma = np.clip((p0 - M.BAS) / (M.HAUT - M.BAS), 0.02, 0.98), 0.12
    else:
        mean, sigma = np.full(len(M.BAS), 0.5), 0.3
    cma = CMA(mean=mean, sigma=sigma, population_size=a.population, seed=a.graine, bounds=np.array([[0, 1]] * len(M.BAS)))
    meilleur, histo = (1e9, None), []
    with mp.Pool(a.processus, initializer=init, initargs=(a.plafond, a.sans_glisser, a.droit)) as pool:
        for g in range(a.generations):
            xs = [cma.ask() for _ in range(cma.population_size)]
            vals = pool.map(f, xs)
            cma.tell(list(zip(xs, vals)))
            i = int(np.argmin(vals))
            if vals[i] < meilleur[0]:
                meilleur = (vals[i], xs[i])
            histo.append(round(-meilleur[0], 4))
            print(f"génération {g + 1:3d}  pire modèle du meilleur : {-meilleur[0] * 100:7.2f} cm  (cette génération {-vals[i] * 100:7.2f})", flush=True)
    p = M.BAS + meilleur[1] * (M.HAUT - M.BAS)
    fichier = os.path.join(C.ICI, "resultats", f"n1-marche-robuste{'-plafond' + str(int(round(a.plafond * 100))) if a.plafond != 1.0 else ''}"
                                               f"{'-sans-glisser' if a.sans_glisser else ''}{'-droit' if a.droit else ''}-g{a.graine}")
    images, rend = [], (mujoco.Renderer(M._m, 360, 480) if a.video else None)
    cam = mujoco.MjvCamera()
    cam.distance, cam.azimuth, cam.elevation = 1.8, 140, -8

    def video(d):
        cam.lookat[:] = [d.subtree_com[1][0], d.subtree_com[1][1], 0.30]
        rend.update_scene(d, camera=cam)
        images.append(rend.render().copy())

    varier("nominal", 1.0)
    res = M.evaluer(p, trace=True, video=video if a.video else None)
    res["selon_variante"] = {}
    for nom, f_ in VARIANTES:
        varier(nom, f_)
        r = M.evaluer(p, trace=True)
        res["selon_variante"][f"{nom} x{f_}"] = {"avance_m": r["avance_m"], "tombe": r["tombe"], "temps_tenu_s": r["temps_tenu_s"]}
    res.update({"essai": "N1 marche robuste (pire de 8 modèles)", "duree_s": M.DUREE, "parametres": dict(zip(M.NOMS_P, [round(float(v), 4) for v in p])),
                "parametres_liste": [float(v) for v in p], "graine": a.graine, "generations": a.generations, "population": a.population,
                "variantes_entrainement": [f"{n} x{f_}" for n, f_ in VARIANTES], "optimiseur": "CMA-ES (cmaes), aptitude = pire modèle",
                "depart": a.depart, "plafond_part_du_blocage": a.plafond, "meilleur_par_generation_m": histo})
    json.dump(res, open(fichier + ".json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(json.dumps({k: v for k, v in res.items() if k not in ("parametres_liste", "meilleur_par_generation_m")}, ensure_ascii=False, indent=1))
    if a.video:
        import imageio.v2 as iio
        iio.mimsave(fichier + ".mp4", images, fps=20, macro_block_size=1)


if __name__ == "__main__":
    main()
