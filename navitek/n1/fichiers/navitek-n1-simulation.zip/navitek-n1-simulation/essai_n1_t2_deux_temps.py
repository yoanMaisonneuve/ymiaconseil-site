"""B45 (cahier R-052) : N1 sur une jambe, en deux temps. T2 (essai_n1_t2.py) lève la jambe et roule la hanche d'un même geste ; ici, le poids d'abord :
temps 1 (0 à 1,5 s), les deux pieds au sol, les deux hanches roulent du même angle (jambes parallèles), les chevilles à l'inverse, les deux genoux à K ;
temps 2 (1,5 à 2,5 s), la jambe droite se replie (genou à 100°, hanche et cheville de tangage à 0) ; temps 3 (jusqu'à 4 s), on tient.
Critère de T2 : inclinaison finale sous 20° et jamais plus de 35°. Le roulis est cherché de −20 à +20° par pas de 1°.
    python -X utf8 essai_n1_t2_deux_temps.py [<modèle.xml> <signes.json relatif à resultats/> <sortie.json>]
    défaut : n1.xml, signes-n1.json → resultats/n1-t2-une-jambe-deux-temps.json
    la 2.2 gelée : python -X utf8 essai_n1_t2_deux_temps.py n1-v2.2-gele/n1.xml ../n1-v2.2-gele/signes-n1.json n1-t2-une-jambe-deux-temps-v22.json
"""
import json
import os
import sys

import mujoco
import numpy as np

import commun as C

_args = [a for a in sys.argv[1:] if a.endswith((".xml", ".json"))] if __name__ == "__main__" else []
XML = _args[0] if len(_args) > 0 else os.environ.get("N1_XML", "n1.xml")
SIG = _args[1] if len(_args) > 1 else os.environ.get("N1_SIGNES", "signes-n1.json")
SORTIE = _args[2] if len(_args) > 2 else "n1-t2-une-jambe-deux-temps.json"
m, d = C.charger(XML)
SG = C.signes(SIG)
tau = m.actuator_forcerange[0, 1]
idx = {C.court(n): i for i, n in enumerate(C.noms(m))}
T1, T2, DUREE = 1.5, 2.5, 4.0


def poses(K, r):
    p1 = {"hanche_tangage_g": -K / 2, "genou_g": K, "cheville_tangage_g": -K / 2, "hanche_tangage_d": -K / 2, "genou_d": K, "cheville_tangage_d": -K / 2,
          "hanche_roulis_g": r, "cheville_roulis_g": -r, "hanche_roulis_d": r, "cheville_roulis_d": -r}
    p2 = dict(p1, hanche_tangage_d=0.0, genou_d=100.0, cheville_tangage_d=0.0)
    return C.consigne(m, p1, SG), C.consigne(m, p2, SG)


def run(K, r):
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    c1, c2 = poses(K, r)
    incl, somme, ns, pic = 0.0, np.zeros(m.nu), 0, np.zeros(m.nu)
    for k in range(int(DUREE / m.opt.timestep)):
        t = k * m.opt.timestep
        d.ctrl[:] = c1 * min(1.0, t / T1) if t < T1 else c1 + (c2 - c1) * min(1.0, (t - T1) / (T2 - T1))
        mujoco.mj_step(m, d)
        incl = max(incl, C.inclinaison(d))
        if t > DUREE - 1.0:
            somme += np.abs(d.actuator_force)
            ns += 1
        if t > T1:
            pic = np.maximum(pic, np.abs(d.actuator_force))
    fin = C.inclinaison(d)
    return fin < 20 and incl < 35, incl, fin, somme / ns / tau, pic / tau


def principal():
    res = {"essai": "B45 / R-052 : N1 sur une jambe en deux temps", "modele": XML, "temps_s": [T1, T2, DUREE], "une_jambe": {}}
    sel = lambda a: {k: round(float(a[i]), 3) for k, i in idx.items() if k.endswith("_g")}
    for K in (0, 20, 40, 60, 70, 90):
        tiennent, meilleur = [], None
        for r in range(-20, 21):
            ok, incl, fin, moy, pic = run(K, float(r))
            if ok:
                tiennent.append(r)
            if meilleur is None or incl < meilleur[1]:
                meilleur = (r, incl, fin, moy, pic, ok)
        r, incl, fin, moy, pic, ok = meilleur
        res["une_jambe"][str(K)] = {"tient": bool(tiennent), "roulis_qui_tiennent_deg": tiennent, "meilleur_roulis_deg": r,
                                    "inclinaison_max_deg": round(incl, 1), "inclinaison_fin_deg": round(fin, 1),
                                    "couple_moyen_sur_blocage": sel(moy), "couple_max_sur_blocage": sel(pic)}
        print("une jambe, genou", K, ": tient avec un roulis de", tiennent if tiennent else "aucun", "; le moins incliné :", r, "°,", round(incl, 1), "° au plus", flush=True)
    json.dump(res, open(os.path.join(C.ICI, "resultats", SORTIE), "w", encoding="utf-8"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    principal()
