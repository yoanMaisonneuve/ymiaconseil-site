"""Essai T6 du Navitek N0 : la sensibilité aux hypothèses. Chaque hypothèse du modèle (HYPOTHESES de modele_n0.py) est mise à -50 % puis
à +50 %, une à la fois, et on refait : (a) N1-T2 : couple moyen du genou en accroupi à 70° sur deux jambes et sur une jambe à 40° ;
(b) T5 : la meilleure marche trouvée, rejouée telle quelle (non réoptimisée), pour voir si elle survit.
    python -X utf8 essai_t6.py [resultats/t5-marche-gN.json]        → resultats/t6-sensibilite.json
"""
import glob
import json
import os
import sys

import mujoco
import numpy as np

import commun as C
import essai_n1_marche as T5

T5.init()
m, d = T5._m, T5._d
# T2 a besoin des collisions du modèle sans pièces désactivées : on ne touche qu'aux pieds, comme T5 (le sol est la seule chose qui compte)
ref = {"armature": m.dof_armature.copy(), "damping": m.dof_damping.copy(), "friction": m.geom_friction.copy(),
       "forcerange": m.actuator_forcerange.copy(), "kp": m.actuator_gainprm.copy(), "bias": m.actuator_biasprm.copy(),
       "masse": m.body_mass.copy(), "inertie": m.body_inertia.copy()}
MASSE_ELEC = 0.330
SG = C.signes("signes-n1.json")
tau0 = float(ref["forcerange"][0, 1])


def remettre():
    m.dof_armature[:] = ref["armature"]
    m.dof_damping[:] = ref["damping"]
    m.geom_friction[:] = ref["friction"]
    m.actuator_forcerange[:] = ref["forcerange"]
    m.actuator_gainprm[:] = ref["kp"]
    m.actuator_biasprm[:] = ref["bias"]
    m.body_mass[:] = ref["masse"]
    m.body_inertia[:] = ref["inertie"]


def varier(nom, f):
    remettre()
    if nom == "armature":
        m.dof_armature[:] *= f
    elif nom == "amortissement":
        m.dof_damping[:] *= f
    elif nom == "frottement_sol":
        m.geom_friction[:, 0] *= f
    elif nom == "couple_blocage":
        m.actuator_forcerange[:] *= f
    elif nom == "masse_electronique":
        dm = MASSE_ELEC * (f - 1)
        m.body_inertia[1] *= (ref["masse"][1] + dm) / ref["masse"][1]
        m.body_mass[1] += dm
    elif nom == "kp":
        m.actuator_gainprm[:, 0] *= f
        m.actuator_biasprm[:, 1] *= f


def t2(K, une_jambe, roulis=0.0, duree=3.0):
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    s = "_g"
    pose = {"hanche_tangage" + s: -K / 2, "genou" + s: K, "cheville_tangage" + s: -K / 2}
    if une_jambe:
        pose.update({"hanche_tangage_d": 0, "genou_d": 100, "cheville_tangage_d": 0, "hanche_roulis_g": roulis, "cheville_roulis_g": -roulis})
    else:
        pose.update({"hanche_tangage_d": -K / 2, "genou_d": K, "cheville_tangage_d": -K / 2})
    c = C.consigne(m, pose, SG)
    idx = [i for i, n in enumerate(C.noms(m)) if C.court(n) == "genou_g"][0]
    somme, ns, incl = 0.0, 0, 0.0
    for k in range(int(duree / m.opt.timestep)):
        t = k * m.opt.timestep
        d.ctrl[:] = c * min(1.0, t / 1.0)
        mujoco.mj_step(m, d)
        incl = max(incl, C.inclinaison(d))
        if t > duree - 1.0:
            somme += abs(d.actuator_force[idx])
            ns += 1
    return round(somme / ns / m.actuator_forcerange[idx, 1], 3), round(incl, 1)


fich = sys.argv[1] if len(sys.argv) > 1 else None
if not fich:
    cand = []
    for f in glob.glob(os.path.join(C.ICI, "resultats", "n1-marche-g*.json")):
        r = json.load(open(f, encoding="utf-8"))
        cand.append((r["avance_m"] if not r["tombe"] else -1 + r["temps_tenu_s"] / 10, f))
    fich = max(cand)[1] if cand else None
p5 = np.array(json.load(open(fich, encoding="utf-8"))["parametres_liste"]) if fich else None

res = {"essai": "N1-T6 sensibilité ±50 %", "marche_rejouee": os.path.basename(fich) if fich else None, "variations": {}}
remettre()
base = {"t2_deux_jambes_70": t2(70, False), "t2_une_jambe_40": t2(40, True, 6.0)}
if p5 is not None:
    base["t5"] = T5.evaluer(p5, trace=True)
    base["t5"].pop("couple_max_sur_blocage")
res["base"] = base
print("base", base)
for nom in ("masse_electronique", "frottement_sol", "armature", "amortissement", "couple_blocage", "kp"):
    for f in (0.5, 1.5):
        varier(nom, f)
        r = {"t2_deux_jambes_70": t2(70, False), "t2_une_jambe_40": t2(40, True, 6.0)}
        if p5 is not None:
            r["t5"] = T5.evaluer(p5, trace=True)
            r["t5"].pop("couple_max_sur_blocage")
        res["variations"][f"{nom} x{f}"] = r
        print(nom, f, r, flush=True)
remettre()
json.dump(res, open(os.path.join(C.ICI, "resultats", "n1-t6-sensibilite.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
