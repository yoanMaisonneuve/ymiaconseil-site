"""B42 (cahier R-050 § 4.5, ERREURS E20) : le cap des marches publiées de N0, N1, N2 et N3. Chaque marche est rejouée sur son modèle avec la boucle
de son essai, et l'on relève le lacet du torse (sa rotation autour de la verticale) : à la fin, et le plus grand écart au cap de départ.
Les aptitudes qui ont réglé ces marches (avance du centre de masse en x) ne regardaient pas le cap.

    python -X utf8 mesurer_lacet.py        → resultats/lacet-marches.json
"""
import glob
import json
import multiprocessing as mp
import os
import re

import numpy as np

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")


def taches():
    t = []
    for f in sorted(glob.glob(os.path.join(RES, "t5-marche-*g[0-9].json"))):
        t.append(("N0", os.path.basename(f)))
    for f in sorted(glob.glob(os.path.join(RES, "n1-marche-*g[0-9].json")) + glob.glob(os.path.join(RES, "n1-marche-g[0-9].json"))):
        if "video" not in f:
            t.append(("N1", os.path.basename(f)))
    for f in sorted(glob.glob(os.path.join(RES, "n2-marche*-g[0-9].json")) + glob.glob(os.path.join(RES, "n2cao-marche*-g[0-9].json"))):
        t.append(("N2", os.path.basename(f)))
    for f in sorted(glob.glob(os.path.join(RES, "n3-marche*-g[0-9].json"))):
        t.append(("N3", os.path.basename(f)))
    return list(dict.fromkeys(t))


def tache(args):
    robot, f = args
    cap = re.search(r"(?:plafond|cap)(\d+)", f)
    if robot == "N2":
        cao = f.startswith("n2cao")
        os.environ["N2_XML"], os.environ["N2_SIGNES"] = ("n2cao.xml", "signes-n2cao.json") if cao else ("n2.xml", "signes-n1-sans-roulis.json")
        os.environ["N2_CAP"] = cap.group(1) if cap else "0"
    if robot == "N3":
        os.environ["N2_CAP"] = cap.group(1) if cap else "0"
    import mujoco
    import commun as C
    if robot == "N0":
        import essai_t5 as em
        em.init()
        pose = lambda p, t, d: em.pose_marche(p, t)
        seuil = 35
    else:
        em = {"N1": __import__("essai_n1_marche"), "N2": __import__("essai_n2_marche"), "N3": __import__("essai_n3_marche")}[robot]
        em.SANS_RETOUR = "aveugle" in f
        if robot == "N1":
            em.SANS_GLISSER, em.DROIT = "sans-glisser" in f, "-droit" in f
        em.init()
        pose = lambda p, t, d: em.pose_marche(p, t, em.attitude(d))
        seuil = 40
    m, d = em._m, em._d
    if robot == "N1" and cap:
        m.actuator_forcerange[:] *= int(cap.group(1)) / 100
    r = json.load(open(os.path.join(RES, f), encoding="utf-8"))
    p = np.array(r["parametres_liste"])
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    lacet = lambda: float(np.arctan2(d.xmat[1][3], d.xmat[1][0]))
    ecart = lambda: abs((lacet() - l0 + np.pi) % (2 * np.pi) - np.pi)
    l0, lmax, x0, chute = lacet(), 0.0, float(d.subtree_com[1][0]), False
    n, pas_pose = int(em.DUREE / m.opt.timestep), int(0.01 / m.opt.timestep)
    c = np.zeros(m.nu)
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, pose(p, t, d), em._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % 20:
            continue
        if C.inclinaison(d) > seuil:
            chute = True
            break
        lmax = max(lmax, ecart())
    fin = float(np.degrees((lacet() - l0 + np.pi) % (2 * np.pi) - np.pi))
    return {"robot": robot, "marche": f, "avance_publiee_m": r.get("avance_m"), "avance_rejeu_m": round(float(d.subtree_com[1][0]) - x0, 4),
            "tombe": chute, "lacet_fin_deg": round(fin, 1), "lacet_max_deg": round(float(np.degrees(lmax)), 1)}


def main():
    with mp.Pool(4, maxtasksperchild=1) as pool:
        sorties = pool.map(tache, taches(), chunksize=1)
    json.dump({"essai": "B42 / R-050 § 4.5 : le cap des marches publiées de N0 à N3 (lacet du torse)", "marches": sorties},
              open(os.path.join(RES, "lacet-marches.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    for s in sorties:
        print(f"{s['robot']}  {s['marche']:<44} avance pub. {100 * (s['avance_publiee_m'] or 0):6.1f} / rejeu {100 * s['avance_rejeu_m']:6.1f} cm"
              f"   lacet fin {s['lacet_fin_deg']:7.1f}°   max {s['lacet_max_deg']:6.1f}°{'   TOMBE' if s['tombe'] else ''}", flush=True)


if __name__ == "__main__":
    main()
