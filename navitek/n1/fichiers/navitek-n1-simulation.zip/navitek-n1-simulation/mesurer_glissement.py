"""B42 (cahier R-050 § 4) : deux mesures du glissement des pieds de N1, sur des marches déjà réglées.

- « au centre » : le chemin du centre du pied pendant qu'il touche le sol (essai_appuis.py, R-044 ; c'est ce que paie --sans-glisser).
  Un pied qui roule du talon à la pointe sans glisser y compte aussi : son centre avance pendant que le point d'appui ne bouge pas.
- « au contact » : la vitesse horizontale du pied AU POINT DE CONTACT (vitesse du pied en ce point : v + ω × r, mj_objectVelocity),
  intégrée dans le temps ; c'est le vrai glissement : un pied qui roule sans glisser y vaut zéro.
Les deux comptés toutes les 10 ms après la montée de 1,5 s, les deux pieds additionnés. Et le lacet du torse (sa rotation autour de la verticale)
au départ et à la fin : une marche qui tourne sur elle-même avance en x moins qu'elle ne marche.

    python -X utf8 mesurer_glissement.py resultats/n1-marche-g3.json [autres marches…]        → resultats/glissement-deux-mesures.json
"""
import json
import os
import sys

import mujoco
import numpy as np

import commun as C
import essai_n1_marche as em


def mesurer(fichier):
    r = json.load(open(fichier, encoding="utf-8"))
    p = np.array(r["parametres_liste"])
    em.SANS_RETOUR = "aveugle" in fichier
    m, d = em._m, em._d
    m.actuator_forcerange[:] = FR0 * (0.6 if "plafond60" in fichier else 1.0)
    mujoco.mj_resetData(m, d)
    mujoco.mj_forward(m, d)
    pieds = em._pieds
    centre, contact, prec = {c: 0.0 for c in pieds}, {c: 0.0 for c in pieds}, {c: None for c in pieds}
    x0 = float(d.subtree_com[1][0])
    lacet = lambda: float(np.degrees(np.arctan2(d.xmat[1][3], d.xmat[1][0])))
    lacet0, lacet_max = lacet(), 0.0
    n, pas_pose, cadre = int(em.DUREE / m.opt.timestep), int(0.01 / m.opt.timestep), 20
    dt = cadre * m.opt.timestep
    c = np.zeros(m.nu)
    v6 = np.zeros(6)
    for k in range(n):
        t = k * m.opt.timestep
        if k % pas_pose == 0:
            c = C.consigne(m, em.pose_marche(p, t, em.attitude(d)), em._sg)
        d.ctrl[:] = c
        mujoco.mj_step(m, d)
        if k % cadre or t < 1.5:
            continue
        if C.inclinaison(d) > 40:
            break
        lacet_max = max(lacet_max, abs(lacet() - lacet0))
        points = {cc: [] for cc in pieds}
        for i in range(d.ncon):
            g1, g2 = d.contact[i].geom1, d.contact[i].geom2
            for cc, g in pieds.items():
                if (g1 == g and g2 == em._sol) or (g2 == g and g1 == em._sol):
                    points[cc].append(d.contact[i].pos.copy())
        for cc, g in pieds.items():
            xy = d.geom_xpos[g][:2].copy()
            touche = bool(points[cc])
            if touche and prec[cc] is not None:
                centre[cc] += float(np.linalg.norm(xy - prec[cc]))
            prec[cc] = xy if touche else None
            if touche:
                mujoco.mj_objectVelocity(m, d, mujoco.mjtObj.mjOBJ_GEOM, g, v6, 0)      # (ω, v) au centre du pied, repère du monde
                w, v = v6[:3], v6[3:]
                vit = [np.linalg.norm((v + np.cross(w, q - d.geom_xpos[g]))[:2]) for q in points[cc]]
                contact[cc] += float(np.mean(vit)) * dt
    return {"marche": os.path.basename(fichier), "avance_m": round(float(d.subtree_com[1][0]) - x0, 4),
            "glissement_au_centre_m": round(sum(centre.values()), 3), "glissement_au_contact_m": round(sum(contact.values()), 3),
            "par_pied_au_contact_m": {cc: round(v, 3) for cc, v in contact.items()},
            "lacet_fin_deg": round(lacet() - lacet0, 1), "lacet_max_deg": round(lacet_max, 1)}


em.init()
FR0 = em._m.actuator_forcerange.copy()
sortie = []
for f in sys.argv[1:]:
    s = mesurer(f)
    sortie.append(s)
    print(f"{s['marche']:<44} avance {s['avance_m'] * 100:6.1f} cm   glissement au centre {s['glissement_au_centre_m'] * 100:6.1f} cm   "
          f"au contact {s['glissement_au_contact_m'] * 100:6.1f} cm   lacet à la fin {s['lacet_fin_deg']:6.1f}°", flush=True)
json.dump({"essai": "B42 / R-050 : glissement des pieds de N1, au centre du pied et au point de contact", "marches": sortie},
          open(os.path.join(C.ICI, "resultats", "glissement-deux-mesures.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
