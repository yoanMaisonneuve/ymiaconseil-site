"""Essai T4 de N1 (CAO version 2, B40, R-048), copié de essai_t4.py (N0) : les vraies butées par collision, sur les maillages réels (pas leurs enveloppes convexes, que MuJoCo
utilise et qui sont trop larges pour des pièces creuses). Chaque articulation est balayée seule, de 0 à ±120° par pas de 1°, le
reste au neutre (cinématique pure). Les contacts viennent de FCL (trimesh) entre toutes les paires de pièces de corps différents,
parents et enfants compris, sans le sol. Les paires déjà en contact au neutre (les pièces vissées ensemble) sont écartées.
La butée est le dernier angle avant qu'une nouvelle paire entre en contact. Écrit resultats/n1-t4-plages.json.
    python -X utf8 essai_n1_t4.py
"""
import json
import os

import mujoco
import numpy as np
import trimesh
from trimesh.collision import CollisionManager

import commun as C

m, d = C.charger(os.environ.get("N1_XML", "n1.xml"))                # R-051 : N1_XML pour un essai de CAO
noms_g = {}
mgr = CollisionManager()
corps_de = {}
for g in range(m.ngeom):
    if m.geom_type[g] != mujoco.mjtGeom.mjGEOM_MESH:
        continue
    nom = mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_GEOM, g)
    mid = m.geom_dataid[g]
    v0, nv = m.mesh_vertadr[mid], m.mesh_vertnum[mid]
    f0, nf = m.mesh_faceadr[mid], m.mesh_facenum[mid]
    mesh = trimesh.Trimesh(vertices=m.mesh_vert[v0:v0 + nv].copy(), faces=m.mesh_face[f0:f0 + nf].copy(), process=False)
    mgr.add_object(nom, mesh)
    noms_g[nom] = g
    corps_de[nom] = m.geom_bodyid[g]


def transforms():
    for nom, g in noms_g.items():
        T = np.eye(4)
        T[:3, :3] = d.geom_xmat[g].reshape(3, 3)
        T[:3, 3] = d.geom_xpos[g]
        mgr.set_transform(nom, T)


def paires():
    transforms()
    ok, noms = mgr.in_collision_internal(return_names=True)
    return {tuple(sorted(p)) for p in noms if corps_de[p[0]] != corps_de[p[1]]}


def poser(j, deg):
    mujoco.mj_resetData(m, d)
    d.qpos[m.jnt_qposadr[j]] = np.radians(deg)
    mujoco.mj_forward(m, d)
    return paires()


mujoco.mj_forward(m, d)
neutre = paires()
res = {"essai": "T4 plages par collision (maillages réels, FCL)", "pas_deg": 1, "balayage_deg": 120,
       "paires_en_contact_au_neutre": sorted(" ~ ".join(p) for p in neutre), "articulations": {}}
print("paires au neutre :", len(neutre))
for i, n in enumerate(C.noms(m)):
    j = m.actuator_trnid[i, 0]
    r = {}
    for sens, nom in ((1, "max_deg"), (-1, "min_deg")):
        lim, cause = sens * 120, "aucune collision jusqu'à 120°"
        for a in range(1, 121):
            nouveau = poser(j, sens * a) - neutre
            if nouveau:
                lim, cause = sens * (a - 1), " ~ ".join(sorted(nouveau)[0])
                break
        r[nom], r[nom.replace("deg", "cause")] = lim, cause
    res["articulations"][n] = r
    print(f"{n:32s} de {r['min_deg']:5d}° à {r['max_deg']:4d}°   ({r['min_cause']} | {r['max_cause']})", flush=True)
json.dump(res, open(os.path.join(C.ICI, "resultats", os.environ.get("N1_T4_SORTIE", "n1-t4-plages.json")), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
