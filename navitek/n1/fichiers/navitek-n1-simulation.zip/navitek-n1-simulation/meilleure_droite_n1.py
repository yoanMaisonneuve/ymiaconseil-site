"""B43 (R-051 § 7) : la meilleure marche droite de N1 dans resultats/, avec les critères de la page N1 (construire_page_n1.py, R-050 G5 à G8) :
ne tombe pas, cap à moins de 20°, au moins 10 cm, un pied en l'air au moins 30 % du temps, et des pieds qui glissent moins qu'ils n'avancent.
Écrit « <chemin du JSON> <graine> », ou « AUCUNE ».
    python -X utf8 meilleure_droite_n1.py
    python -X utf8 meilleure_droite_n1.py --depart     (la marche sans glisser qui avance le plus sans tomber, n1-marche-sans-glisser-g1..3 :
                                                        le départ de la recette G8)
"""
import glob
import json
import os
import sys

ICI = os.path.dirname(os.path.abspath(__file__))
# 09.11 (ERREURS E27) : une marche plus vieille que n1.xml a été réglée sur un autre modèle ; le réveil 5 a choisi ainsi une marche de la 2.2
# restée dans resultats/. Elles sont écartées.
MODELE = os.path.getmtime(os.path.join(ICI, "n1.xml"))


def du_modele(f):
    return os.path.getmtime(f) >= MODELE


if "--depart" in sys.argv:
    cands = []
    for f in filter(du_modele, glob.glob(os.path.join(ICI, "resultats", "n1-marche-sans-glisser-g[0-9].json"))):
        r = json.load(open(f, encoding="utf-8"))
        if not r["tombe"]:
            cands.append((r["avance_m"], f, r["graine"]))
    print(*((os.path.relpath(max(cands)[1], ICI).replace(os.sep, "/"), max(cands)[2]) if cands else ("AUCUNE",)))
    sys.exit()
droites = []
for f in filter(du_modele, glob.glob(os.path.join(ICI, "resultats", "n1-marche-sans-glisser-droit*-g[0-9].json"))):
    r = json.load(open(f, encoding="utf-8"))
    if (not r["tombe"] and r.get("lacet_max_deg", 999) < 20 and r["avance_m"] >= 0.10 and r.get("appui_simple", 0) >= 0.30
            and sum(r.get("glissement_m", {"x": 9}).values()) < r["avance_m"]):
        droites.append((r["avance_m"], f, r["graine"]))
if droites:
    _, f, g = max(droites)
    print(os.path.relpath(f, ICI).replace(os.sep, "/"), g)
else:
    print("AUCUNE")
