"""B43 (R-051 § 9, hypothèse O2c) : un départ de marche construit d'après R-052 (le poids d'abord, la jambe ensuite), au lieu d'un départ réglé.

Sur la 2.3 au bon signe des chevilles, les marches trouvées roulent les deux hanches en sens contraires (roulis_g et roulis_d de signes opposés) :
les jambes s'ouvrent et se ferment, le poids ne passe jamais d'un pied à l'autre. R-052 : sur une jambe, la 2.3 tient avec les deux hanches roulées
du même angle, 13 à 15°, vers la jambe d'appui. Ici : roulis_g = roulis_d = R (les jambes parallèles), et la phase du roulis réglée pour que le poids
arrive sur un pied un temps delta AVANT que l'autre genou se plie au plus (pose_marche : le roulis est au plus bas, poids à gauche, quand
th + roulis_phase = 3π/2 ; le genou droit est plié au plus quand th + π + genou_phase = π/2 + 2π, d'où roulis_phase = genou_phase + delta).

Balayage : R dans 10, 13, 16 ; delta (rad) dans -0,4, 0, 0,4, 0,8, 1,2 ; la période dans 1,7 et 2,2 s ; les autres réglages pris des marches libres de
la 2.3 n1-marche-g2 et n1-marche-g3. Chaque candidat est rejoué une fois, aptitude « sans glisser » (celle de G8). Le meilleur qui ne tombe pas est
écrit dans resultats/n1-marche-deux-temps.json (le départ d'O2c), le balayage dans resultats/n1-depart-deux-temps-balayage.json.
    python -X utf8 depart_deux_temps_n1.py [--large]
"""
import itertools
import json
import multiprocessing as mp
import os
import sys

import numpy as np

import essai_n1_marche as M

ICI = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ICI, "resultats")
I = {n: i for i, n in enumerate(M.NOMS_P)}


LARGE = "--large" in sys.argv          # O2d (R-051 § 9) : roulis de 4 à 16°, delta de -0,8 à 1,6, période de 1,4 à 2,4 s (336 candidats)
GRILLE = (((4.0, 6.0, 8.0, 10.0, 13.0, 16.0), (-0.8, -0.4, 0.0, 0.4, 0.8, 1.2, 1.6), (1.4, 1.7, 2.0, 2.4)) if LARGE else
          ((10.0, 13.0, 16.0), (-0.4, 0.0, 0.4, 0.8, 1.2), (1.7, 2.2)))
SUFFIXE = "-large" if LARGE else ""


def candidats():
    for base, R, delta, T in itertools.product(("g2", "g3"), *GRILLE):
        p = np.array(json.load(open(os.path.join(RES, f"n1-marche-{base}.json"), encoding="utf-8"))["parametres_liste"][:len(M.NOMS_P)])
        p[I["roulis_g"]] = p[I["roulis_d"]] = R
        p[I["roulis_phase"]] = (p[I["genou_phase"]] + delta + np.pi) % (2 * np.pi) - np.pi
        p[I["periode"]] = T
        yield {"base": base, "R": R, "delta": delta, "periode": T}, np.clip(p, M.BAS, M.HAUT)


def evaluer(c):
    q, p = c
    r = M.evaluer(p, trace=True)
    return {**q, **{k: r[k] for k in ("avance_m", "tombe", "temps_tenu_s", "aptitude", "lacet_max_deg", "glissement_m", "appui_simple", "pied_levee_max_mm")},
            "parametres_liste": [float(v) for v in p]}


if __name__ == "__main__":
    cs = list(candidats())
    with mp.Pool(14, initializer=M.initialiser, initargs=(False, True, False, False, 0.0)) as pool:
        res = pool.map(evaluer, cs)
    for r in sorted(res, key=lambda r: -r["aptitude"])[:12]:
        print(f"{r['base']} R {r['R']:4.0f} delta {r['delta']:4.1f} T {r['periode']}  {r['avance_m'] * 100:6.1f} cm  {'TOMBE' if r['tombe'] else '     '}  "
              f"appui1 {r['appui_simple']:.2f}  levée {min(r['pied_levee_max_mm'].values()):5.1f} mm  gliss {sum(r['glissement_m'].values()) * 100:5.1f} cm  "
              f"cap {r['lacet_max_deg']:5.1f}°  aptitude {r['aptitude']:.3f}")
    debout = [r for r in res if not r["tombe"]]
    print(len(debout), "candidats sur", len(res), "ne tombent pas ;", sum(r["appui_simple"] >= 0.30 for r in debout), "ont un pied en l'air 30 % du temps")
    json.dump({"essai": "R-051 § 9 (O2c) : départs construits d'après R-052, rejoués une fois, aptitude sans glisser", "candidats": res},
              open(os.path.join(RES, f"n1-depart-deux-temps-balayage{SUFFIXE}.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if debout:
        b = max(debout, key=lambda r: r["aptitude"])
        p = np.array(b["parametres_liste"])
        M.initialiser(False, True, False, False, 0.0)
        out = M.evaluer(p, trace=True)
        out.update({"essai": "N1, départ construit d'après R-052 (le poids d'abord) : roulis parallèles, phase avant le genou ; pas réglé", "duree_s": M.DUREE,
                    "construction": {k: b[k] for k in ("base", "R", "delta", "periode")},
                    "parametres": dict(zip(M.NOMS_P, [round(float(v), 4) for v in p])), "parametres_liste": [float(v) for v in p], "graine": 0})
        json.dump(out, open(os.path.join(RES, f"n1-marche-deux-temps{SUFFIXE}.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print("départ :", {k: b[k] for k in ("base", "R", "delta", "periode")}, "→ resultats/n1-marche-deux-temps" + SUFFIXE + ".json")
