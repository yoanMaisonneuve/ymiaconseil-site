# Navitek N1 — le bus des servos Feetech STS3215 (MicroPython sur le Pico 2 W ; le même fichier tourne sous Python ordinaire pour l'épreuve)
#
# Le protocole (Waveshare, « Servo Communication Protocol » et « ST Servo Memory Table », lus le 09.11.2026, cahier R-048) :
#   demande : FF FF id longueur instruction paramètres… somme     longueur = nombre de paramètres + 2
#   réponse : FF FF id longueur erreur paramètres… somme           somme = ~(id + longueur + instruction ou erreur + paramètres) & 0xFF
#   instructions : PING 0x01, READ 0x02, WRITE 0x03, SYNC WRITE 0x83 ; les valeurs de 2 octets en petit-boutiste (l'octet bas d'abord).
# Le câblage (schéma de la page) : un seul fil de données, demi-duplex. Le TX du Pico passe par une résistance de 1 kΩ et rejoint le RX
# sur le fil ; le Pico lit donc d'abord son propre écho, que ce pilote jette avant de lire la réponse.
#
# Version 0.1 (09.11.2026) : éprouvé contre des servos simulés qui parlent le même protocole (essai_sts.py), pas encore sur un vrai bus.

PING, READ, WRITE, SYNC_WRITE = 0x01, 0x02, 0x03, 0x83

# La table mémoire (adresse, octets) : Waveshare, ST Servo Memory Table
REG = {
    "id": (5, 1), "baud": (6, 1), "angle_min": (9, 2), "angle_max": (11, 2), "couple_max": (16, 2), "decalage": (31, 2),
    "mode": (33, 1), "couple_actif": (40, 1), "acceleration": (41, 1), "consigne": (42, 2), "vitesse": (46, 2),
    "couple_limite": (48, 2), "verrou": (55, 1), "position": (56, 2), "vitesse_lue": (58, 2), "charge": (60, 2),
    "tension": (62, 1), "temperature": (63, 1), "bouge": (66, 1), "courant": (69, 2),
}
PAS_PAR_TOUR = 4096                    # 0,087° par pas


def somme(octets):
    return (~sum(octets)) & 0xFF


def trame(ident, instr, params=()):
    corps = [ident & 0xFF, len(params) + 2, instr] + [p & 0xFF for p in params]
    return bytes([0xFF, 0xFF] + corps + [somme(corps)])


def signe15(v):
    """Position et vitesse : le bit 15 donne le sens (Waveshare)."""
    return -(v & 0x7FFF) if v & 0x8000 else v


def signe10(v):
    """Charge : le bit 10 donne le sens, la valeur en 0,1 % (Waveshare)."""
    return -(v & 0x3FF) if v & 0x400 else v & 0x3FF


class ErreurBus(Exception):
    pass


class Bus:
    """uart : un objet avec write(octets), read(n) et any() (machine.UART sur le Pico, ou un bus simulé)."""

    def __init__(self, uart, attente_ms=20, horloge=None, echo=True):
        self.uart = uart
        self.attente_ms = attente_ms
        self.echo = echo                             # False si le TX et le RX ne sont pas sur le même fil (adaptateur à deux fils)
        if horloge is None:
            import time
            self._t = time.ticks_ms if hasattr(time, "ticks_ms") else (lambda: int(time.time() * 1000))
            self._ecart = time.ticks_diff if hasattr(time, "ticks_diff") else (lambda a, b: a - b)
        else:
            self._t, self._ecart = horloge

    def _lire(self, n):
        debut = self._t()
        out = b""
        while len(out) < n:
            if self.uart.any():
                morceau = self.uart.read(n - len(out))
                if morceau:
                    out += morceau
            elif self._ecart(self._t(), debut) > self.attente_ms:
                raise ErreurBus("pas de réponse (%d octets sur %d)" % (len(out), n))
        return out

    def echange(self, ident, instr, params=(), reponse=True):
        t = trame(ident, instr, params)
        while self.uart.any():                       # ce qui traîne sur le fil
            self.uart.read(self.uart.any())
        self.uart.write(t)
        if self.echo:
            self._lire(len(t))                       # l'écho de notre propre trame (TX et RX sur le même fil)
        if not reponse:
            return None
        tete = self._lire(5)
        if tete[0] != 0xFF or tete[1] != 0xFF or tete[2] != (ident & 0xFF):
            raise ErreurBus("réponse mal formée : %s" % tete)
        longueur, erreur = tete[3], tete[4]
        reste = self._lire(longueur - 1)
        params_r, s = reste[:-1], reste[-1]
        if somme(list(tete[2:]) + list(params_r)) != s:
            raise ErreurBus("somme de contrôle fausse")
        return erreur, params_r

    def ping(self, ident):
        try:
            return self.echange(ident, PING)[0] == 0
        except ErreurBus:
            return False

    def lire(self, ident, nom):
        adr, n = REG[nom]
        erreur, p = self.echange(ident, READ, (adr, n))
        v = p[0] if n == 1 else p[0] | (p[1] << 8)
        if nom in ("position", "vitesse_lue"):
            return signe15(v)
        if nom == "charge":
            return signe10(v)
        return v

    def ecrire(self, ident, nom, valeur):
        adr, n = REG[nom]
        valeur = int(valeur)
        if valeur < 0 and nom in ("consigne", "vitesse"):
            valeur = (-valeur) | 0x8000
        params = (adr, valeur & 0xFF) if n == 1 else (adr, valeur & 0xFF, (valeur >> 8) & 0xFF)
        return self.echange(ident, WRITE, params)[0]

    def ecrire_tous(self, nom, valeurs):
        """SYNC WRITE : une seule trame pour plusieurs servos {id: valeur} (pas de réponse)."""
        adr, n = REG[nom]
        params = [adr, n]
        for ident, v in valeurs.items():
            v = int(v)
            params += [ident] + ([v & 0xFF] if n == 1 else [v & 0xFF, (v >> 8) & 0xFF])
        self.echange(0xFE, SYNC_WRITE, params, reponse=False)


def degres_vers_pas(deg, centre=2048):
    return int(round(centre + deg * PAS_PAR_TOUR / 360.0))


def pas_vers_degres(pas, centre=2048):
    return (pas - centre) * 360.0 / PAS_PAR_TOUR
