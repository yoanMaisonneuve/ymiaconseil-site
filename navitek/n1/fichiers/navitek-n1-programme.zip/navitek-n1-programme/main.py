# Navitek N1 — le programme du robot (MicroPython, Raspberry Pi Pico 2 W ; avec sts.py à côté sur le Pico)
#
# MODE = "centrer"  : couple actif, les 17 servos au centre (2048 pas) : l'étape du montage où l'on pose les étriers droits.
# MODE = "calibrer" : LE ROBOT SUSPENDU, pieds dans le vide. Chaque articulation cherche ses deux butées en lisant sa propre position :
#                     elle avance par pas de 2°, et s'arrête dès que la position lue décroche de la consigne de plus de 4°. Les plages
#                     trouvées vont dans calibration.json sur le Pico, et remplacent les BORNES ci-dessous (3° de marge).
# MODE = "demo"     : un salut et un accroupi lents, dans les bornes.
#
# Sécurité : le couple de chaque servo est plafonné à 60 % du blocage (registre 48 : 600) ; à 50 % pendant l'étalonnage. Le bouton
# d'arrêt (à contact fermé au repos, entre GP22 et la masse) : appuyé, ou fil coupé, le Pico coupe le couple de tous les servos. L'arrêt d'urgence matériel coupe la
# pile (schéma) : c'est lui qui compte, celui-ci n'en est que le doublon logiciel.
#
# Câblage (schéma de la page) : bus des servos sur l'UART0 (GP0 TX par 1 kΩ, GP1 RX, réunis sur le fil de données), 1 Mbit/s ;
# servos numérotés 1 à 17 dans l'ordre de NOMS (à régler un par un avec l'adaptateur FE-URT-1, avant le montage).
#
# Version 0.1 (09.11.2026) : éprouvé contre des servos simulés par MuJoCo qui parlent le même protocole (essai_sts.py, cahier R-048).

import json

import sts

MODE = "centrer"

NOMS = ["jambe-gauche-hanche-roulis", "jambe-gauche-hanche-tangage", "jambe-gauche-genou", "jambe-gauche-cheville-tangage",
        "jambe-gauche-cheville-roulis", "jambe-droite-hanche-roulis", "jambe-droite-hanche-tangage", "jambe-droite-genou",
        "jambe-droite-cheville-tangage", "jambe-droite-cheville-roulis", "bras-gauche-epaule-tangage", "bras-gauche-epaule-roulis",
        "bras-gauche-coude", "bras-droit-epaule-tangage", "bras-droit-epaule-roulis", "bras-droit-coude", "cou"]
IDS = {nom: i + 1 for i, nom in enumerate(NOMS)}
# Les bornes de départ, en degrés autour du centre (celles du modèle de simulation, navitek-sim/modele_n1.py) ; l'étalonnage les remplace.
BORNES_TYPE = {"hanche-roulis": (-30, 30), "hanche-tangage": (-90, 90), "genou": (-10, 120), "cheville-tangage": (-60, 60),
               "cheville-roulis": (-30, 30), "epaule-tangage": (-90, 90), "epaule-roulis": (-90, 90), "coude": (-10, 120), "cou": (-80, 80)}
COUPLE_LIMITE, COUPLE_ETALONNAGE = 600, 500        # 0,1 % du couple de blocage (registre 48)
PAS_DEG, ATTENTE_MS, ECART_MAX, MAX_DEG, MARGE = 2.0, 60, 4.0, 130.0, 3.0


def type_de(nom):
    return nom if nom == "cou" else "-".join(nom.split("-")[2:])


def bornes_initiales():
    return {nom: BORNES_TYPE[type_de(nom)] for nom in NOMS}


def borner(nom, deg, bornes):
    lo, hi = bornes[nom]
    return max(lo, min(hi, deg))


def tous_couple(bus, actif):
    bus.ecrire_tous("couple_actif", {i: (1 if actif else 0) for i in IDS.values()})


def aller(bus, nom, deg, bornes):
    d = borner(nom, deg, bornes)
    bus.ecrire(IDS[nom], "consigne", sts.degres_vers_pas(d))
    return d


def lire_deg(bus, nom):
    return sts.pas_vers_degres(bus.lire(IDS[nom], "position"))


def calibrer_un(bus, nom, dormir):
    """Les deux butées d'une articulation, en degrés autour du centre. Elle part du centre, se pose, puis avance par pas de PAS_DEG ;
    la butée est le dernier angle LU avant que la position décroche de la consigne de plus de ECART_MAX (ou MAX_DEG sans butée)."""
    i = IDS[nom]
    bus.ecrire(i, "couple_limite", COUPLE_ETALONNAGE)
    plage = []
    for sens in (1, -1):
        bus.ecrire(i, "consigne", sts.degres_vers_pas(0))
        dormir(400)
        dernier = lire_deg(bus, nom)
        c = 0.0
        while abs(c) < MAX_DEG:
            c += sens * PAS_DEG
            bus.ecrire(i, "consigne", sts.degres_vers_pas(c))
            dormir(ATTENTE_MS)
            lu = lire_deg(bus, nom)
            if abs(c - lu) > ECART_MAX:
                dormir(ATTENTE_MS * 3)                  # une seconde lecture, après un temps : un servo lent n'est pas une butée
                lu = lire_deg(bus, nom)
                if abs(c - lu) > ECART_MAX:
                    break
            dernier = lu
        plage.append(round(dernier, 1))
    bus.ecrire(i, "consigne", sts.degres_vers_pas(0))
    dormir(400)
    bus.ecrire(i, "couple_limite", COUPLE_LIMITE)
    return min(plage), max(plage)


def calibrer(bus, dormir, noms=None):
    tous_couple(bus, True)
    res = {}
    for nom in (noms or NOMS):
        lo, hi = calibrer_un(bus, nom, dormir)
        res[nom] = {"butee_min_deg": lo, "butee_max_deg": hi, "borne_min_deg": round(lo + MARGE, 1), "borne_max_deg": round(hi - MARGE, 1)}
    return res


def bornes_depuis(calib):
    b = bornes_initiales()
    for nom, r in calib.items():
        b[nom] = (r["borne_min_deg"], r["borne_max_deg"])
    return b


def poser(bus, cible, bornes, duree_ms, dormir, pas=20):
    depart = {nom: lire_deg(bus, nom) for nom in cible}
    for k in range(1, pas + 1):
        t = k / pas
        t = t * t * (3 - 2 * t)
        bus.ecrire_tous("consigne", {IDS[n]: sts.degres_vers_pas(borner(n, depart[n] + (a - depart[n]) * t, bornes)) for n, a in cible.items()})
        dormir(duree_ms // pas)


def demo(bus, bornes, dormir):
    poser(bus, {n: 0 for n in NOMS}, bornes, 1500, dormir)
    poser(bus, {"bras-droit-epaule-tangage": -80, "bras-droit-coude": 60}, bornes, 1000, dormir)
    for _ in range(3):
        poser(bus, {"bras-droit-coude": 20}, bornes, 400, dormir)
        poser(bus, {"bras-droit-coude": 70}, bornes, 400, dormir)
    poser(bus, {n: 0 for n in NOMS}, bornes, 1000, dormir)
    accroupi = {}
    for cote in ("gauche", "droite"):
        accroupi.update({"jambe-%s-hanche-tangage" % cote: -30, "jambe-%s-genou" % cote: 60, "jambe-%s-cheville-tangage" % cote: -30})
    poser(bus, accroupi, bornes, 1500, dormir)
    poser(bus, {n: 0 for n in accroupi}, bornes, 1500, dormir)


def principal():
    import time
    from machine import UART, Pin
    uart = UART(0, baudrate=1000000, tx=Pin(0), rx=Pin(1))
    bus = sts.Bus(uart)
    arret = Pin(22, Pin.IN, Pin.PULL_UP)
    led = Pin("LED", Pin.OUT)
    absents = [n for n in NOMS if not bus.ping(IDS[n])]
    if absents:
        print("servos qui ne répondent pas :", absents)
    bus.ecrire_tous("couple_limite", {i: COUPLE_LIMITE for i in IDS.values()})
    try:
        bornes = bornes_depuis(json.load(open("calibration.json")))
        print("bornes : calibration.json")
    except OSError:
        bornes = bornes_initiales()
        print("bornes : celles du modèle (pas encore d'étalonnage)")

    def dormir(ms):
        fin = time.ticks_add(time.ticks_ms(), int(ms))
        while time.ticks_diff(fin, time.ticks_ms()) > 0:
            if arret.value() == 1:               # le bouton relâché ferme le circuit à la masse : 1 = appuyé ou fil coupé
                tous_couple(bus, False)
                raise SystemExit("arrêt")
            time.sleep_ms(5)

    if MODE == "calibrer":
        res = calibrer(bus, dormir)
        json.dump(res, open("calibration.json", "w"))
        for nom, r in res.items():
            print("%-30s butées %+6.1f° à %+6.1f°" % (nom, r["butee_min_deg"], r["butee_max_deg"]))
        tous_couple(bus, False)
    elif MODE == "demo":
        tous_couple(bus, True)
        while True:
            led.on()
            demo(bus, bornes, dormir)
            led.off()
            dormir(3000)
    else:
        tous_couple(bus, True)
        bus.ecrire_tous("consigne", {i: 2048 for i in IDS.values()})
        while True:
            led.toggle()
            dormir(500)


import sys as _sys
if _sys.implementation.name == "micropython":
    principal()
